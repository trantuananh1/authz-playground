# Tài liệu khảo sát: Phân hệ Quản lý đề xuất mua sắm (ví dụ giả lập)

Tài liệu giả lập dùng để minh hoạ và chạy thử bộ skill thiết kế phân quyền.

## 1. Mô hình tổ chức

Hệ thống phục vụ Tổng công ty, các chi nhánh trực thuộc và các phòng của chi nhánh. Mỗi đơn vị có một cấp trên trực tiếp.

## 2. Nhóm người sử dụng

- Lãnh đạo Tổng công ty: phê duyệt đề xuất mua sắm cấp Tổng công ty, theo dõi tình hình mua sắm toàn hệ thống.
- Chuyên viên phòng Kế hoạch Tổng công ty: quản lý danh mục nhà cung cấp, tổng hợp đề xuất của các chi nhánh, trình lãnh đạo phê duyệt.
- Giám đốc chi nhánh: phê duyệt đề xuất mua sắm cấp chi nhánh của các phòng trực thuộc.
- Trưởng phòng: kiểm tra, phê duyệt đề xuất cấp phòng do cán bộ trong phòng lập.
- Cán bộ: lập đề xuất mua sắm của phòng mình.
- Quản trị hệ thống: quản lý tài khoản và phân quyền.

## 3. Thông tin quản lý

| STT | Đối tượng | Thông tin quản lý |
|---|---|---|
| 1 | Đơn vị | Tên đơn vị, cấp, đơn vị cấp trên |
| 2 | Đề xuất mua sắm | Số đề xuất, đơn vị đề xuất, người lập, nội dung, dự toán kinh phí, trạng thái (dự thảo, chờ duyệt, bị trả lại, đã duyệt), cấp đang duyệt |
| 3 | Nhà cung cấp | Mã, tên, mã số thuế, lĩnh vực, trạng thái |
| 4 | Hồ sơ cán bộ | Họ tên, đơn vị, chức vụ, thông tin kỷ luật |

## 4. Danh sách chức năng

| TT | Tên usecase | Tên tác nhân chính | Giao dịch |
|---|---|---|---|
| I | QUẢN LÝ ĐỀ XUẤT MUA SẮM | | |
| 1 | Quản lý đề xuất mua sắm | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị | |
| | Xem danh sách đề xuất | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể xem danh sách đề xuất |
| | Tìm kiếm đề xuất | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể tìm kiếm đề xuất |
| | Thêm mới đề xuất | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể thêm mới đề xuất |
| | Chỉnh sửa đề xuất | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể chỉnh sửa đề xuất |
| | Xoá đề xuất | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể xoá đề xuất |
| | Xem chi tiết đề xuất | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể xem chi tiết đề xuất |
| | Xuất excel danh sách đề xuất | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể xuất excel danh sách đề xuất |
| 2 | Phê duyệt đề xuất mua sắm | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị | |
| | Gửi phê duyệt đề xuất | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể gửi phê duyệt đề xuất |
| | Phê duyệt đề xuất cấp phòng | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể phê duyệt đề xuất cấp phòng |
| | Phê duyệt đề xuất cấp chi nhánh | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể phê duyệt đề xuất cấp chi nhánh |
| | Phê duyệt đề xuất cấp Tổng công ty | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể phê duyệt đề xuất cấp Tổng công ty |
| | Từ chối đề xuất cấp phòng | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể từ chối đề xuất cấp phòng |
| | Từ chối đề xuất cấp chi nhánh | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể từ chối đề xuất cấp chi nhánh |
| | Từ chối đề xuất cấp Tổng công ty | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể từ chối đề xuất cấp Tổng công ty |
| II | DANH MỤC | | |
| 3 | Quản lý nhà cung cấp | Lãnh đạo, chuyên viên Tổng công ty | |
| | Xem danh sách nhà cung cấp | | Lãnh đạo, chuyên viên Tổng công ty có thể xem danh sách nhà cung cấp |
| | Thêm mới nhà cung cấp | | Lãnh đạo, chuyên viên Tổng công ty có thể thêm mới nhà cung cấp |
| | Chỉnh sửa nhà cung cấp | | Lãnh đạo, chuyên viên Tổng công ty có thể chỉnh sửa nhà cung cấp |
| | Khoá nhà cung cấp | | Lãnh đạo, chuyên viên Tổng công ty có thể khoá nhà cung cấp |
| III | HỒ SƠ CÁN BỘ | | |
| 4 | Xem hồ sơ cán bộ | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị | |
| | Xem thông tin chung cán bộ | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể xem thông tin chung cán bộ |
| | Xem thông tin kỷ luật cán bộ | | Lãnh đạo, chuyên viên Tổng công ty; Cán bộ các đơn vị có thể xem thông tin kỷ luật cán bộ |
| IV | DASHBOARD | | |
| 5 | Dashboard tình hình mua sắm | Lãnh đạo, chuyên viên Tổng công ty | |
| | Xem tổng giá trị đề xuất theo chi nhánh | | Lãnh đạo, chuyên viên Tổng công ty có thể xem tổng giá trị đề xuất theo chi nhánh |
| V | API KẾT NỐI | | |
| 6 | API đồng bộ nhà cung cấp từ ERP | Hệ thống ERP | |
| | Lấy danh sách nhà cung cấp từ ERP | | Hệ thống ERP cho phép lấy danh sách nhà cung cấp |

## 5. Quy trình phê duyệt đề xuất

| STT | Tên bước | Người thực hiện | Mô tả chi tiết |
|---|---|---|---|
| 1 | Lập đề xuất mua sắm | Cán bộ | Cán bộ lập đề xuất của phòng và gửi phê duyệt. |
| 2 | Phê duyệt cấp phòng | Trưởng phòng | Trưởng phòng kiểm tra; hợp lệ thì chuyển chi nhánh, không hợp lệ thì trả lại. |
| 3 | Phê duyệt cấp chi nhánh | Giám đốc chi nhánh | Giám đốc chi nhánh duyệt đề xuất của các phòng trực thuộc. |
| 4 | Tổng hợp, trình Tổng công ty | Chuyên viên phòng Kế hoạch | Chuyên viên tổng hợp đề xuất của các chi nhánh, trình lãnh đạo. |
| 5 | Phê duyệt cấp Tổng công ty | Lãnh đạo Tổng công ty | Lãnh đạo phê duyệt hoặc trả lại. |
| 6 | Ký hợp đồng mua sắm | Lãnh đạo Tổng công ty | Ký hợp đồng với nhà cung cấp. Bước này thực hiện ngoài hệ thống. |
