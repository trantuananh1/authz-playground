# Bộ key chuẩn

Một bộ key **tiếng Việt không dấu** dùng chung cho mọi nơi: đặc tả `dac_ta.json`, ma trận Excel của BA, JSON import, DSL playground, hệ phân quyền đích. Mỗi key có một nghĩa duy nhất. Các cách viết khác (key tiếng Anh cũ như `view`, `approve`, `own_unit`; `nhap_lieu`, `nhap_excel`…) là **bí danh**: công cụ tự quy về key chuẩn và báo `KEY-01` để AI sửa đặc tả cho khớp.

Đổi từ bộ key tiếng Anh sang tiếng Việt ngày 16/11/2026 theo yêu cầu người dùng: người đọc thiết kế, JSON, DSL là người Việt, cần đọc key là hiểu ngay. Chỉ các từ khoá cú pháp của playground (`resource`, `role`, `derive`, `assert`, `can`, tiền tố `user.` và `resource.`…) và tên trường theo khuôn JSON của hệ đích (`resources`, `roles`, `grantedTo`…) còn tiếng Anh, vì là cú pháp cố định. Mã người dùng trong điều kiện ABAC dùng thuộc tính `user.ma_nguoi_dung` (không dùng `user.key` có sẵn của playground/Permit); hệ đích phải đồng bộ thuộc tính này bằng mã tài khoản.

Nguồn máy đọc: `scripts/bo_key.py`. Hai tệp phải giữ đồng bộ; in bảng hành động bằng `python -I scripts/bo_key.py`.

Quy tắc đặt key:
- chữ thường tiếng Việt không dấu, nối bằng `_`;
- key tài nguyên, vai trò do AI đặt theo từng phân hệ, cũng bằng tiếng Việt không dấu (`de_xuat_mua_sam`, `truong_phong`, `lanh_dao_cqct`); tên có dấu để ở trường `ten`;
- quan hệ, thuộc tính, phạm vi, điều kiện riêng của phân hệ cũng tiếng Việt không dấu (`thuoc_truong`, `trang_thai_dot`, `hoi_noi_den`, `dot_dang_mo`);
- không đặt key hành động theo tài nguyên (`phe_duyet`, không phải `phe_duyet_de_xuat_mua_sam`): quyền luôn là cặp `tài_nguyên:hành_động`;
- hành động riêng chỉ dùng khi không key chuẩn nào cùng nghĩa; khai `{key, ten, muc, nhom}`, công cụ báo `KEY-02` để người duyệt kiểm tra.

## 1. Hành động

| Key | Tên | Mức | Nhóm | Bí danh |
|---|---|---|---|---|
| `xem` | Xem | ban_ghi | xem | view, xem_ds, xem_ct, xem_danh_sach, xem_chi_tiet, tim_kiem, tra_cuu, loc, read, list, get, search, view_list, view_detail |
| `xem_nhay_cam` | Xem thông tin nhạy cảm | ban_ghi | xem | view_sensitive, xem_thong_tin_nhay_cam |
| `them_moi` | Thêm mới | danh_sach | them_moi | create, them, tao, tao_moi, lap, add, new, insert, upload, khai_bao |
| `chinh_sua` | Chỉnh sửa | ban_ghi | chinh_sua | update, sua, cap_nhat, edit, modify |
| `xoa` | Xoá | ban_ghi | xoa | delete, remove |
| `khoi_phuc` | Khôi phục | ban_ghi | xoa | restore |
| `gui_duyet` | Gửi duyệt | ban_ghi | vong_doi | submit, gui_phe_duyet, trinh, gui, send_for_approval |
| `phe_duyet` | Phê duyệt | ban_ghi | duyet | approve, duyet, xac_nhan |
| `tu_choi` | Từ chối / trả lại | ban_ghi | duyet | reject, tra_lai, yeu_cau_chinh_sua, return |
| `tiep_nhan` | Tiếp nhận | ban_ghi | duyet | receive, phe_duyet_tiep_nhan, accept |
| `tu_choi_tiep_nhan` | Từ chối tiếp nhận | ban_ghi | duyet | decline_receipt |
| `khoa` | Khoá | ban_ghi | vong_doi | lock, khoa_so, khoa_du_lieu |
| `mo_khoa` | Mở khoá | ban_ghi | vong_doi | unlock |
| `sao_chep` | Sao chép | ban_ghi | them_moi | copy, duplicate, clone |
| `xuat` | Xuất danh sách | danh_sach | xuat_nhap | export, xuat_ds, xuat_excel, xuat_file, export_ds, tai_xuong_ds, download_list |
| `nhap` | Nhập danh sách | danh_sach | xuat_nhap | import, nhap_lieu, nhap_ds, nhap_excel, import_ds |
| `chia_tach` | Chia tách | ban_ghi | vong_doi | split |
| `sap_nhap` | Sáp nhập | ban_ghi | vong_doi | merge |
| `giai_the` | Giải thể | ban_ghi | vong_doi | dissolve |
| `chia_se` | Chia sẻ | ban_ghi | khac | share |
| `di_chuyen` | Di chuyển | ban_ghi | chinh_sua | move |
| `tai_xuong` | Tải xuống tệp | ban_ghi | xuat_nhap | download |
| `danh_gia` | Đánh giá, xếp loại | ban_ghi | chinh_sua | evaluate, xep_loai |
| `giao_xu_ly` | Giao xử lý | ban_ghi | vong_doi | assign, phan_cong |
| `gan_vai_tro` | Gán vai trò | ban_ghi | khac | assign_role, phan_quyen |

**Xem chỉ có một hành động `xem`.** Không tách xem danh sách và xem chi tiết. Hệ phân quyền trả danh sách ID bản ghi người dùng được xem (List 1); ứng dụng truy vấn CSDL với điều kiện lọc của màn hình **và** ID thuộc List 1 để ra danh sách hiển thị (List 2). Xem chi tiết một bản ghi là kiểm tra `xem` trên bản ghi đó.

Mức `danh_sach`: kiểm tra khi chưa có bản ghi (thêm mới, xuất, nhập). Mức `ban_ghi`: kiểm tra trên một bản ghi cụ thể, có phạm vi và điều kiện.

Nhóm (dùng trong quy tắc `@nhom`): `xem`, `them_moi`, `chinh_sua`, `xoa`, `vong_doi`, `duyet`, `xuat_nhap`, `khac`; mức: `@danh_sach`, `@ban_ghi`. Bí danh: `view`, `create`, `tao`, `update`, `sua`, `delete`, `lifecycle`, `approval`, `bulk`, `other`, `list`, `record`.

## 2. Kiểu phạm vi

| Key | Ý nghĩa | Cơ chế | Bí danh |
|---|---|---|---|
| `toan_he_thong` | Toàn hệ thống | RBAC | all, toan_bo |
| `danh_sach` | Mức danh sách (thêm, xuất, nhập) | RBAC | list, muc_danh_sach |
| `don_vi_minh` | Bản ghi của đơn vị nơi vai trò được gán | ReBAC | own_unit |
| `don_vi_minh_va_cap_duoi_truc_tiep` | Đơn vị mình và cấp dưới trực tiếp | ReBAC | unit_and_children, cap_duoi_truc_tiep |
| `don_vi_minh_va_cap_duoi` | Đơn vị mình và mọi cấp dưới | ReBAC | unit_and_descendants, toan_bo_cap_duoi, don_vi_va_cap_duoi |
| `cap_duyet` | Bản ghi đang chờ đơn vị mình duyệt | ReBAC | approval_unit |
| `do_minh_lap` | Bản ghi do chính mình lập (`resource.nguoi_lap = user.ma_nguoi_dung`) | ABAC | own_record, cua_minh |
| `duoc_giao` | Bản ghi được giao cho mình (`resource.nguoi_duoc_giao = user.ma_nguoi_dung`) | ABAC | assigned |

## 3. Quan hệ, thuộc tính, trạng thái, điều kiện

| Quan hệ | Ý nghĩa | Bí danh |
|---|---|---|
| `cap_tren` | Đơn vị cấp trên (trên cây đơn vị) | parent |
| `thuoc_don_vi` | Đơn vị sở hữu bản ghi | owner_unit |
| `thuoc_to_chuc` | Tổ chức (cây thứ hai, ví dụ hội) sở hữu bản ghi | owner_org |
| `don_vi_quan_ly` | Đơn vị quản lý tổ chức | managing_unit |
| `cap_duyet` | Đơn vị (cây đơn vị) đang phải duyệt bản ghi | approval_unit |
| `cap_duyet_to_chuc` | Tổ chức (cây thứ hai, ví dụ hội) đang phải duyệt bản ghi | approval_org |
| `noi_di` | Nơi chuyển đi | source_unit |
| `noi_den` | Nơi chuyển đến | target_unit |

| Thuộc tính | Kiểu | Ý nghĩa | Bí danh |
|---|---|---|---|
| `trang_thai` | chuỗi | Trạng thái vòng đời | status |
| `nguoi_lap` | chuỗi | Người lập bản ghi | created_by, nguoi_tao |
| `da_khoa` | đúng/sai | Bản ghi đã bị khoá | locked |
| `nguoi_duoc_giao` | chuỗi | Người được giao xử lý | assignee, nguoi_xu_ly |

Trạng thái vòng đời (`vong_doi` của tài nguyên): nhóm `dang_soan` (giá trị `DU_THAO`, `BI_TRA_LAI`), `cho_duyet` (`CHO_DUYET`), `da_duyet` (`DA_DUYET`). Bí danh: nhóm `draft` → `dang_soan`, `nhap` → `dang_soan`, `pending` → `cho_duyet`, `approved` → `da_duyet`; giá trị `DRAFT` → `DU_THAO`, `NHAP` → `DU_THAO`, `RETURNED` → `BI_TRA_LAI`, `BI_TU_CHOI` → `BI_TRA_LAI`, `TRA_LAI` → `BI_TRA_LAI`, `PENDING` → `CHO_DUYET`, `APPROVED` → `DA_DUYET`, `LOCKED` → `DA_KHOA`.

Điều kiện do quy định kế thừa sinh: `khong_tu_duyet` (KT-13), `dang_soan`, `cho_duyet` (KT-14), `chua_khoa` (KT-15). Bí danh: `not_self_approval`, `draft`, `pending`, `not_locked`.

## 4. Cây đơn vị

Cây đơn vị lấy từ **Cổng**, dùng chung mọi phân hệ: key `don_vi`, quan hệ `cap_tren`. Phân hệ không thiết kế quyền trên cây đơn vị; cây chỉ là nơi gán vai trò theo đơn vị và là gốc tính phạm vi. Đặc tả chưa có cây thì công cụ tự thêm; có hành động trên cây thì công cụ cảnh báo `CONG-01`. Bí danh: `unit`.

`don_vi` là **tên quy ước trong thiết kế**, không cần biết key thật của cây trên Cổng. Thiết kế chỉ dựa vào cấu trúc của cây (nút đơn vị, quan hệ cấp trên `cap_tren`): quy định kế thừa của phân hệ được đặt trước trên cấu trúc đó, còn dữ liệu cây (đơn vị nào, cấp trên là ai, người dùng thuộc đơn vị nào) do Cổng cung cấp khi hệ thống chạy. Tên key chỉ cần khớp ở bước đưa vào hệ phân quyền đích: nếu cây đồng bộ từ Cổng mang tên khác, ánh xạ một lần ở bộ chuyển khi import (hoặc đổi `CAY_CONG` trong `bo_key.py`), không phải sửa thiết kế.

Cây riêng của phân hệ (ví dụ cây tổ chức hội gắn vào đơn vị, M-01) vẫn khai trong đặc tả như tài nguyên `loai: cay`.

## 5. Tên vai trò cầu nối trong JSON import và DSL

Công cụ xuất tự sinh vai trò trên tài nguyên theo dạng `<vai trò>__<phạm vi>`: `__don_vi_minh`, `__don_vi_minh_va_cap_duoi`, `__cap_duyet`, `__o_<cây>_cap_tren`, `__o_<cây>_quan_ly[_hoac_cap_tren]`, `__<tên phạm vi riêng>`; vai trò chung trùng tên mang `__quyen_chung`. Tenant mẫu của DSL là `mac_dinh`; tập điều kiện ABAC mang tiền tố `tap_`, tập người dùng `tai_khoan_hoat_dong` (`user.trang_thai = DANG_HOAT_DONG`).
