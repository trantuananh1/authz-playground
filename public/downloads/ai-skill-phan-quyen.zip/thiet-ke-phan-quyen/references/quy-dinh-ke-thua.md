# Quy định kế thừa quyền (KT-01 … KT-21)

Đã duyệt ngày 16/11/2026; cập nhật theo review cùng ngày (gộp `xem`, người lập theo ABAC, cây đơn vị từ Cổng, bộ key tiếng Việt không dấu — đổi từ tiếng Anh cùng ngày). BA không định nghĩa các quy định này; BA chỉ mô tả vai trò nào được thực hiện tác vụ gì. Skill áp dụng các quy định dưới đây để suy ra phần còn lại, và ghi rõ quyền nào sinh ra từ quy định nào.

## Ba nguồn gốc của một quyền

| Nguồn gốc | Trạng thái trong thiết kế | Hiển thị cho BA |
|---|---|---|
| BA nêu | `giu` | «Theo tài liệu» |
| Suy ra theo quy định kế thừa | `ke_thua` | «Theo quy định chung KT-xx» |
| AI đề xuất thêm / bỏ | `them` / `bo` | «AI đề xuất», kèm lý do, nguyên tắc, mức tin cậy |

## Nguyên tắc áp dụng

1. **Quy định kế thừa chỉ tự sinh quyền xem và các ràng buộc, không tự sinh quyền thêm, sửa, xoá, duyệt.** Quyền ghi luôn do BA nêu hoặc do AI đề xuất để BA duyệt (NT-01).
2. **Ràng buộc đứng trên kế thừa.** Quyền kế thừa gặp ràng buộc nhóm C thì ràng buộc được áp dụng.
3. **Tài liệu nêu rõ khác thì theo tài liệu.** Ghi ngoại lệ trong `dac_ta.json` mục `ke_thua.khong_ap_dung` kèm lý do (xem `dac-ta.md`). Quy tắc `pham_vi`, `dieu_kien` AI viết trong đặc tả cũng thắng phạm vi, điều kiện mặc định của KT.

Cột «Áp dụng» cho biết ai thực hiện: **Công cụ** là `lap_thiet_ke.py` tự tính; **AI** là AI phải áp khi viết đặc tả; **Ứng dụng** là hệ thống nghiệp vụ phải bảo đảm.

## A. Kế thừa giữa các tác vụ của cùng một vai trò

| Mã | Quy định | Áp dụng |
|---|---|---|
| KT-01 | **Làm được trên bản ghi thì xem được bản ghi đó.** Vai trò được sửa, xoá, gửi duyệt, phê duyệt, trả lại, khoá, tiếp nhận… một bản ghi thì được `xem` bản ghi đó (NT-07). | Công cụ |
| KT-02 | **Danh sách là các bản ghi được xem.** Không có quyền xem danh sách riêng: hệ phân quyền trả danh sách ID bản ghi người dùng được `xem` (List 1); ứng dụng truy vấn CSDL với điều kiện lọc **và** ID thuộc List 1 để ra danh sách hiển thị (List 2). Xuất danh sách cũng chỉ gồm List 1 (NT-07). | Ứng dụng |
| KT-03 | **Người lập xem được bản ghi do mình lập**, ở mọi trạng thái và **kể cả khi đã chuyển sang đơn vị khác**. Quyền gắn với người lập, không gắn với vai trò hay đơn vị: **ABAC** `resource.nguoi_lap = user.ma_nguoi_dung` (NT-16). | Công cụ (luật ABAC cấp `xem`); ứng dụng ghi `nguoi_lap` khi tạo |
| KT-04 | **Xem không kéo theo xuất, nhập** (NT-08). | Công cụ (không sinh) |
| KT-05 | **Các tác vụ ghi không kéo theo nhau.** Được thêm không có nghĩa được sửa, xoá. "Người lập sửa, xoá bản nháp của mình" là đề xuất của AI, không phải quy định kế thừa (NT-01). | AI |

## B. Kế thừa theo cơ cấu tổ chức

Cây đơn vị lấy từ **Cổng** (`don_vi`, quan hệ `cap_tren`), dùng chung mọi phân hệ; phân hệ không thiết kế quyền trên cây đơn vị.

| Mã | Quy định | Áp dụng |
|---|---|---|
| KT-06 | **Vai trò gán tại đơn vị nào làm việc trên dữ liệu của đơn vị đó.** Phạm vi mặc định của tác vụ ghi: `don_vi_minh` (NT-12). | Công cụ |
| KT-07 | **Cấp trên xem được tất cả dữ liệu của đơn vị mình và mọi đơn vị cấp dưới trên cây đơn vị; quyền ghi không lan xuống.** Phạm vi mặc định của `xem`: `don_vi_minh_va_cap_duoi`. Cấp trên không sửa, xoá, nhập thay cấp dưới (NT-13). | Công cụ; kiểm tra `KT-07` cảnh báo quyền ghi lan xuống cấp dưới |
| KT-08 | **Duyệt theo cấp: chỉ duyệt bản ghi đang chờ đơn vị mình duyệt.** Khi tài nguyên có quan hệ `cap_duyet`, phạm vi mặc định của `phe_duyet`, `tu_choi` là `cap_duyet`, áp cho mọi vai trò (NT-14). | Công cụ |
| KT-09 | **Vai trò toàn hệ thống (cấp cao nhất) làm việc trên toàn bộ dữ liệu** (`toan_he_thong`), trừ tác vụ duyệt theo KT-08 (NT-12). | Công cụ |
| KT-10 | **Tổ chức gắn vào đơn vị kế thừa phạm vi của đơn vị** (hội, ban, tổ công tác trực thuộc một đơn vị) (M-01). | AI (khai quan hệ trong phạm vi) |
| KT-11 | **Thông tin con theo quyền bản ghi cha.** Dòng chi tiết, tệp đính kèm, lịch sử xử lý không là tài nguyên riêng (NT-05). | AI |
| KT-12 | **Thư mục con kế thừa quyền thư mục cha** trong kho tư liệu, trừ khi được chia sẻ riêng (NT-20). | AI, ứng dụng |

## C. Ràng buộc tự động

| Mã | Quy định | Áp dụng |
|---|---|---|
| KT-13 | **Người lập không tự duyệt, tự trả lại bản ghi do mình lập**, kể cả khi giữ vai trò được duyệt (NT-03). Áp cho tài nguyên có tác vụ thêm hoặc gửi duyệt. | Công cụ (điều kiện `khong_tu_duyet`: `resource.nguoi_lap ≠ user.ma_nguoi_dung`) |
| KT-14 | **Theo trạng thái của bản ghi**, khi tài nguyên có cả `gui_duyet` và `phe_duyet`: `chinh_sua`, `xoa`, `gui_duyet` chỉ khi `trang_thai` thuộc nhóm `dang_soan` (nháp, bị trả lại); `phe_duyet`, `tu_choi` chỉ khi thuộc nhóm `cho_duyet` (NT-15). Giá trị lấy từ `vong_doi` của tài nguyên. | Công cụ (điều kiện `dang_soan`, `cho_duyet`) |
| KT-15 | **Dữ liệu đã khoá không sửa, không xoá**, khi tài nguyên có `khoa`; trừ vai trò được `mo_khoa` (M-07). Dữ liệu thuộc đợt đã đóng: AI viết điều kiện riêng (M-06). | Công cụ (điều kiện `chua_khoa`) |
| KT-16 | **Thông tin nhạy cảm không lan theo cấp trên.** `xem_nhay_cam` (hoặc tác vụ xem đánh dấu `nhay_cam`) có phạm vi mặc định `don_vi_minh` thay vì `don_vi_minh_va_cap_duoi` (NT-17). | Công cụ; AI dùng `xem_nhay_cam` hoặc đánh dấu `nhay_cam` |

## D. Quan hệ giữa các vai trò

| Mã | Quy định | Áp dụng |
|---|---|---|
| KT-17 | **Không kế thừa theo chức vụ.** Lãnh đạo không mặc nhiên có quyền của chuyên viên cùng đơn vị, và ngược lại (NT-09, NT-21). | Công cụ (không sinh) |
| KT-18 | **Kiêm nhiệm là cộng quyền, ràng buộc vẫn theo người.** KT-13 áp cho chính người giữ nhiều vai trò (NT-23). | Ứng dụng (điều kiện so theo người) |
| KT-19 | **Uỷ quyền có thời hạn, không uỷ quyền tiếp**; ghi nhận người thực hiện thực tế. Chỉ áp khi phân hệ có nghiệp vụ uỷ quyền (NT-23). | AI, ứng dụng |
| KT-20 | **Quản trị hệ thống không kế thừa quyền nghiệp vụ**; không tự gán quyền cho chính mình (NT-22). Vai trò `nhom: quan_tri` có quyền trên tài nguyên không thuộc loại `he_thong` bị cảnh báo. | Công cụ (kiểm tra) |
| KT-21 | **Báo cáo, thống kê theo quyền xem dữ liệu gốc** (NT-19). | AI |

## Cách công cụ trình bày cho BA

`lap_thiet_ke.py` sinh **câu mô tả theo vai trò** (`cau_mo_ta` trong `thiet_ke_phan_quyen.json`): mỗi câu gộp các tác vụ cùng tài nguyên, cùng phạm vi, cùng điều kiện, cùng nguồn gốc. Ví dụ:

- «Được xem Đề xuất mua sắm của đơn vị mình và mọi đơn vị cấp dưới.» — Theo quy định chung KT-01, KT-07.
- «Được phê duyệt, từ chối Đề xuất mua sắm đang chờ đơn vị mình duyệt, chỉ khi bản ghi đang chờ duyệt.» — Theo tài liệu.
- «Không được phê duyệt, từ chối Đề xuất mua sắm do chính mình lập.» — Theo quy định chung KT-13.

BA đánh dấu Đúng / Sai từng câu; không cần biết RBAC, ReBAC, ABAC.
