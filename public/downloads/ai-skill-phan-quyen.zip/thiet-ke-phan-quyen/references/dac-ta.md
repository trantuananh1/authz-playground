# Đặc tả thiết kế `dac_ta.json`

AI viết tệp này sau khi đọc tài liệu. Công cụ `lap_thiet_ke.py` áp đặc tả lên danh sách giao dịch (mọi tệp `giao_dich*.json`), áp quy định kế thừa (`quy-dinh-ke-thua.md`), rồi sinh `thiet_ke_phan_quyen.json` kèm câu mô tả theo vai trò cho BA. Đặc tả mô tả **quy tắc**, không liệt kê từng quyền: một phân hệ vài trăm giao dịch chỉ cần vài chục quy tắc.

**Không viết lại những gì quy định kế thừa đã làm**: quyền xem đi kèm (KT-01, KT-02), người lập xem bản ghi của mình (KT-03), phạm vi mặc định (KT-06…KT-09, KT-16), điều kiện trạng thái, khoá, không tự duyệt (KT-13…KT-15). Chỉ viết quy tắc `pham_vi`, `dieu_kien` khi tài liệu nêu khác hoặc nghiệp vụ có điều kiện riêng; quy tắc của đặc tả luôn thắng mặc định.

Công cụ kiểm tra mọi key mà quy tắc nhắc tới (vai trò, tài nguyên, hành động, phạm vi, điều kiện). Key chưa khai báo là **lỗi** `DT-01`; quy tắc không khớp gì là gợi ý `QT-01`.

Ví dụ đầy đủ, chạy được: `vi_du/dac_ta_mau.json` (phân hệ giả lập «Quản lý đề xuất mua sắm»).

## Khung

```json
{
  "phan_he": {"ten": "…", "ma": "…", "mo_ta": "…"},
  "nguyen_tac_ap_dung": ["NT-02", "NT-03", "…"],
  "tai_nguyen": [ … ],
  "vai_tro":    [ … ],
  "pham_vi":    [ … ],
  "dieu_kien":  [ … ],
  "quy_tac": {"bo_qua": [], "tai_nguyen": [], "hanh_dong": [], "tac_nhan": [], "theo_cap_duyet": [],
              "loc_vai_tro": [], "bo_sung": [], "pham_vi": [], "dieu_kien": []},
  "ke_thua": {"khong_ap_dung": [ … ]},
  "cau_hoi": [ … ]
}
```

## Mục `co_so` (dùng ở tài nguyên, vai trò)

```json
{"loai": "tai_lieu | de_xuat", "nguon": [{"vt": "B1.D3", "trich": "câu trích nguyên văn"}],
 "ly_do": "…", "nguyen_tac": ["NT-10"], "tin_cay": "cao | trung_binh | thap"}
```
`vt` lấy đúng nhãn vị trí trong `trich_xuat/N….md` (Đ…, B….D…). Giao diện hiển thị căn cứ này cho BA.

## Tài nguyên

| Trường | Ý nghĩa |
|---|---|
| `key`, `ten`, `mo_ta` | Key chữ thường không dấu; tên nghiệp vụ |
| `loai` | `cay` (cây tổ chức, nơi gán vai trò) · `du_lieu` · `tep` (kho tư liệu) · `he_thong` (tài khoản, phân quyền, cấu hình: kiểm tra KT-20) |
| `mang` | Mảng nghiệp vụ, dùng nhóm dòng trong ma trận và kiểm tra NT-02 |
| `quan_he` | `[{key, toi, y_nghia}]`. Cây có `cap_tren` trỏ về chính nó. Dữ liệu có quan hệ tới cây (`thuoc_to_chuc`, `thuoc_don_vi`, `cap_duyet`…) |
| `thuoc_tinh` | `[{key, kieu, y_nghia}]`, kiểu `chuoi | so | ngay | dung_sai | danh_sach`. Khai mọi thuộc tính dùng trong điều kiện |
| `hanh_dong` | Danh sách key chuẩn theo `bo-key.md` (`xem`, `them_moi`…) hoặc `{key, ten, muc, nhom}` cho hành động riêng. Thêm `"nhay_cam": true` cho tác vụ xem thông tin nhạy cảm (KT-16) |
| `vong_doi` | Với tài nguyên có gửi duyệt: `{"dang_soan": ["DU_THAO", "BI_TRA_LAI"], "cho_duyet": ["CHO_DUYET"], "da_duyet": ["DA_DUYET"]}` (KT-14). Dùng giá trị chuẩn; tên trạng thái trong tài liệu (dự thảo, bị trả lại…) ghi ở `mo_ta`. Thiếu thì công cụ dùng giá trị chuẩn và báo gợi ý |
| `nhay_cam` | `true` khi cả tài nguyên là thông tin nhạy cảm |

Thuộc tính `nguoi_lap`, `trang_thai`, `da_khoa` công cụ tự thêm khi quy định kế thừa cần.

## Vai trò

| Trường | Ý nghĩa |
|---|---|
| `key`, `ten`, `mo_ta` | |
| `loai_pham_vi` | `toan_he_thong` hoặc `theo_don_vi` (gồm cả vai trò gán trên một bản ghi cụ thể: khi đó `gan_tren` là tài nguyên đó) |
| `gan_tren` | Key cây tổ chức nơi vai trò được gán (bắt buộc với `theo_don_vi`) |
| `cap` | Nhãn cấp, dùng nhóm cột ma trận (Trung ương, Đơn vị, Hội…) |
| `nhom` | `lanh_dao`, `chuyen_vien` (kiểm tra NT-21) hoặc `quan_tri` (kiểm tra KT-20) |

Công cụ tự thêm vai trò `nguoi_lap` («Người lập bản ghi», `loai_pham_vi: theo_ban_ghi`) cho KT-03; không khai vai trò này trong đặc tả.

## Phạm vi, điều kiện

```json
{"key": "don_vi_minh", "ten": "Đơn vị mình", "kieu": "don_vi_minh", "mo_ta": "…",
 "quan_he": {"*": "thuoc_don_vi", "don_vi": "(gan_truc_tiep)", "phieu_ban_giao": "noi_di"}}
```
- `kieu` (bo-key.md mục 2): ReBAC `don_vi_minh | don_vi_minh_va_cap_duoi_truc_tiep | don_vi_minh_va_cap_duoi | cap_duyet`; RBAC `toan_he_thong | danh_sach`; ABAC `do_minh_lap | duoc_giao` (khai thêm `bieu_thuc` thay cho `quan_he`, ví dụ `[{"trai": "resource.nguoi_duoc_giao", "phep": "bang", "phai": "user.ma_nguoi_dung"}]`).
- `quan_he`: theo từng tài nguyên, quan hệ nối bản ghi với nơi gán vai trò. `*` là mặc định. `(gan_truc_tiep)`: bản ghi chính là nút được gán. Trên cây, dùng `cap_tren` để lan xuống cấp dưới.
- Phạm vi `toan_he_thong` và `danh_sach` công cụ tự dùng: vai trò toàn hệ thống mặc định `toan_he_thong`; hành động mức danh sách của vai trò theo đơn vị luôn là `danh_sach`.
- Không có quy tắc `pham_vi` khớp thì công cụ đặt phạm vi theo KT: duyệt khi có quan hệ `cap_duyet` → `cap_duyet`; vai trò toàn hệ thống → `toan_he_thong`; xem → `don_vi_minh_va_cap_duoi` (xem nhạy cảm → `don_vi_minh`); còn lại → `don_vi_minh`. Công cụ dùng lại định nghĩa phạm vi cùng `kieu` nếu có, không thì tự tạo, và tự tìm quan hệ nối tài nguyên về nơi gán vai trò (một hoặc hai bước).

```json
{"key": "dot_dang_mo", "ten": "Đợt đang mở", "mo_ta": "…",
 "bieu_thuc": [{"trai": "resource.trang_thai_dot", "phep": "thuoc", "phai": ["DANG_MO"]}]}
```
`phep`: `bang | khac | thuoc`. `phai` bắt đầu bằng `user.` là so với thuộc tính người dùng. Điều kiện trạng thái, khoá, không tự duyệt do quy định kế thừa tự sinh (`dang_soan`, `cho_duyet`, `chua_khoa`, `khong_tu_duyet`); chỉ viết điều kiện riêng của nghiệp vụ.

## Quy tắc

Mọi quy tắc có `id`, `ly_do`, `nguyen_tac`, `tin_cay`. Giao diện hiển thị đúng các trường này ở mục «Vì sao» của từng ô.

| Nhóm | Dạng | Áp dụng |
|---|---|---|
| `bo_qua` | `mau_usecase` / `mau_giao_dich` / `mau_muc` (regex), `tac_nhan` (danh sách) hoặc `"ngoai_he_thong": true` | Giao dịch khớp không vào phân quyền (dashboard, API, bước ngoài hệ thống…) |
| `tai_nguyen` | `mau_giao_dich` (+`mau_usecase`) hoặc `mau_usecase` → `tai_nguyen` | Quy tắc đầu tiên khớp. Đặt quy tắc theo giao dịch trước, theo usecase sau |
| `hanh_dong` | `mau` (regex trên tên giao dịch) → `hanh_dong` | Quy tắc đầu tiên khớp **và** hành động có trên tài nguyên |
| `tac_nhan` | `tac_nhan` (tên đúng như tài liệu) → `vai_tro` | Tác nhân gộp ánh xạ sang nhiều vai trò |
| `theo_cap_duyet` | `mau_giao_dich` → `vai_tro` | Giao dịch khớp chỉ giữ cho các vai trò này; vai trò khác của tác nhân bị đề xuất bỏ |
| `loc_vai_tro` | `vai_tro` + một trong `chi_tai_nguyen`, `chi_nhom_hanh_dong`, `bo_nhom_hanh_dong`, `bo_hanh_dong`; tuỳ chọn `tai_nguyen` (chỉ xét các tài nguyên này) | Quyền tài liệu nêu nhưng trái điều kiện → `bo` |
| `bo_sung` | `vai_tro` × `tai_nguyen` × `hanh_dong` | Quyền tài liệu không nêu → `them` |
| `pham_vi` | `vai_tro`, `tai_nguyen`, `hanh_dong` (key, `@nhom`, `@ban_ghi`, `*` hoặc danh sách) → `pham_vi`; tuỳ chọn `uu_tien`, `ap_dung_toan_he_thong` | Quy tắc cụ thể nhất thắng; `uu_tien` cao thắng trước. `vai_tro: "*"` chỉ áp cho vai trò theo đơn vị; muốn áp cả vai trò toàn hệ thống (ví dụ phạm vi `cap_duyet` cho lãnh đạo cấp cao nhất) thì ghi `"ap_dung_toan_he_thong": true` hoặc nêu tên vai trò |
| `dieu_kien` | như `pham_vi` → `dieu_kien: [...]` | Cộng dồn mọi quy tắc khớp |

Nhóm hành động dùng trong `@nhom`: `xem`, `them_moi`, `chinh_sua`, `xoa`, `vong_doi`, `duyet`, `xuat_nhap`, `khac`; và `@danh_sach`, `@ban_ghi` theo mức (bo-key.md mục 1).

## Ngoại lệ quy định kế thừa

Khi tài liệu nêu rõ khác một quy định kế thừa, ghi ngoại lệ, có lý do và vị trí trích:

```json
"ke_thua": {"khong_ap_dung": [
  {"ma": "KT-07", "vai_tro": ["truong_phong"], "tai_nguyen": ["ho_so_can_bo"],
   "ly_do": "B3.D4: trưởng phòng chỉ xem hồ sơ của phòng mình, không xem phòng khác."}
]}
```
`vai_tro`, `tai_nguyen` bỏ trống là áp cho tất cả. Mã dùng được: KT-01, 02, 03, 06, 07, 08, 09, 13, 14, 15, 16, 20. Khi BA bấm «Sai» một câu «Theo quy định chung» trên giao diện, đây là chỗ sửa.

## Câu hỏi cho BA

```json
{"id": "CH-01", "nhom": "Vai trò | Phạm vi | Điều kiện | Luồng duyệt | …", "noi_dung": "…",
 "phuong_an_ap_dung": "phương án AI đang dùng trong thiết kế", "lien_quan": {"vai_tro": ["…"]},
 "luc": "truoc_thiet_ke | ra_soat", "tra_loi": "câu trả lời của người dùng / BA (nếu đã có)"}
```
Câu đã hỏi ngay trước khi thiết kế (SKILL.md bước 2) ghi `"luc": "truoc_thiet_ke"` kèm `tra_loi`; thiết kế đã theo câu trả lời đó.
