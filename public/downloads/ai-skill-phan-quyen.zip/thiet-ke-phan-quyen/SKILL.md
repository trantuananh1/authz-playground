---
name: thiet-ke-phan-quyen
description: Thiết kế phân quyền (RBAC, ReBAC theo cây tổ chức, ABAC theo điều kiện) cho bất kỳ phân hệ nào từ tài liệu nghiệp vụ của BA — tài liệu khảo sát, SRS, bảng chức năng / usecase, ma trận phân quyền Excel, quy trình (Word, PDF, Markdown, Excel, drawio) — dựa trên bộ nguyên tắc thiết kế phân quyền; AI đọc nghiệp vụ, đề xuất vai trò, tài nguyên, hành động, phạm vi, điều kiện kèm lý do và mức tin cậy, tự áp bộ quy định kế thừa (duyệt thì được xem, cấp trên xem cấp dưới, người lập không tự duyệt…) để BA không phải định nghĩa, tự kiểm tra nguyên tắc (tách nhiệm vụ, đặc quyền tối thiểu…), trình bày cho BA bằng câu mô tả theo vai trò thay cho ma trận, đo độ khớp với ma trận của BA nếu có, rồi xuất JSON import vào hệ thống phân quyền. Người dùng cuối là BA không cần biết RBAC/ReBAC/ABAC. Dùng skill này BẤT CỨ KHI NÀO người dùng đưa tài liệu nghiệp vụ hoặc ma trận phân quyền và muốn thiết kế phân quyền, lập ma trận phân quyền, xác định vai trò / ai được làm gì, rà soát phân quyền theo nguyên tắc, so thiết kế với ma trận của BA, sinh JSON phân quyền / file import phân quyền, hoặc hỏi nên phân quyền một chức năng thế nào, kể cả khi họ không nhắc tên skill. Dùng cùng skill `truc-quan-phan-quyen` để mở giao diện cho BA, SA, dev rà soát.
---

# Thiết kế phân quyền từ tài liệu nghiệp vụ

Người dùng là **BA không chuyên về phân quyền**. BA chỉ đưa tài liệu (tài liệu thiết kế, bảng chức năng, sơ đồ drawio, quy trình…) cho biết vai trò nào được thực hiện tác vụ gì. Skill làm phần còn lại:

1. AI đọc tài liệu, rút các cặp vai trò – tác vụ, dựng mô hình (vai trò, dữ liệu, cây đơn vị);
2. công cụ áp **bộ quy định kế thừa đã duyệt** (`references/quy-dinh-ke-thua.md`): quyền xem đi kèm, phạm vi theo cây đơn vị, ràng buộc trạng thái, người lập không tự duyệt. BA không phải định nghĩa các quy định này;
3. AI đề xuất phần tài liệu chưa nói theo **nguyên tắc thiết kế phân quyền**, ghi rõ vì sao;
4. BA xác nhận từng **câu mô tả theo vai trò** («Được phê duyệt Đề xuất mua sắm đang chờ đơn vị mình duyệt…»), không phải ma trận. Ma trận, phạm vi, JSON dành cho SA, dev.

## Bốn nguồn gốc của một quyền, luôn tách bạch

| Trong thiết kế | Nghĩa | Hiển thị |
|---|---|---|
| **Theo tài liệu** (`giu`) | Tài liệu nêu, AI giữ | ✓ |
| **Theo quy định chung** (`ke_thua`) | Suy ra theo quy định kế thừa KT-xx; chỉ quyền xem và ràng buộc, không bao giờ quyền ghi | ↳ |
| **AI đề xuất thêm** (`them`) | Tài liệu không nêu, AI thêm theo nguyên tắc | + |
| **AI đề xuất bỏ** (`bo`) | Tài liệu nêu nhưng trái nguyên tắc (tách nhiệm vụ, đặc quyền tối thiểu…) | ✕ |

Mọi đề xuất có: lý do bằng lời, mã nguyên tắc `NT-xx` hoặc mẫu `M-xx`, mức tin cậy (`cao` / `trung_binh` / `thap`). Đề xuất `thap` luôn kèm một câu hỏi cho BA. Không trình bày đề xuất như sự thật của tài liệu.

Nguyên tắc là mặc định hợp lý, không phải luật cứng: khi tài liệu hoặc BA nói rõ khác, theo tài liệu và ghi lại vì sao.

## Tài nguyên của skill

| Tệp | Đọc khi |
|---|---|
| `references/bo-key.md` | **Luôn dùng.** Bộ key chuẩn tiếng Việt không dấu: hành động, kiểu phạm vi, quan hệ, thuộc tính, trạng thái; bí danh tự quy (`nhap` = `nhap_lieu` = `nhap_excel`) |
| `references/quy-dinh-ke-thua.md` | **Luôn đọc trước khi thiết kế.** 21 quy định kế thừa KT-xx đã duyệt: công cụ tự áp gì, AI phải áp gì, cách ghi ngoại lệ |
| `references/nguyen-tac.md` | **Luôn đọc trước khi thiết kế.** 24 nguyên tắc, cách chọn RBAC / ReBAC / ABAC |
| `references/mau-thiet-ke.md` | 14 mẫu lặp lại: cây tổ chức, nộp duyệt nhiều cấp, chuyển giữa đơn vị, danh mục, đợt, khoá, giao việc, quản trị… |
| `references/doc-tai-lieu-ba.md` | Phần nào của tài liệu cho tín hiệu gì; quy đổi động từ → hành động; mức tin cậy; cách viết câu hỏi |
| `references/dac-ta.md` | Cấu trúc `dac_ta.json` mà AI viết |
| `references/so-sanh-ma-tran.md` | Đo thiết kế với ma trận phân quyền của BA |
| `vi_du/` | Phân hệ giả lập «Quản lý đề xuất mua sắm»: tài liệu, đặc tả, ma trận BA, cấu hình — chạy được từ đầu đến cuối |
| `scripts/` | Các công cụ ở bảng dưới |

| Công cụ | Việc |
|---|---|
| `bo_key.py` | Bộ key chuẩn và bí danh, mọi công cụ dùng chung |
| `trich_xuat.py` | Đọc tài liệu nguyên trạng kèm nhãn vị trí |
| `bang_chuc_nang.py` | Bảng chức năng / usecase (Word, PDF, Markdown, Excel) → giao dịch |
| `ma_tran_sang_giao_dich.py` | Ma trận phân quyền Excel của BA → giao dịch |
| `quy_trinh_sang_giao_dich.py` | Sơ đồ drawio có làn, bảng bước – người thực hiện → giao dịch |
| `lap_thiet_ke.py` | Kiểm tra tham chiếu của đặc tả, áp đặc tả, áp quy định kế thừa, kiểm tra nguyên tắc, sinh câu mô tả cho BA |
| `so_sanh_ma_tran.py` | So thiết kế với ma trận của BA: độ phủ, độ chính xác, đánh giá đề xuất AI |
| `xuat_json.py` | Xuất JSON import, áp ý kiến rà soát |
| `xuat_dsl.py` | Xuất DSL của playground kéo thả: cấu trúc, dữ liệu mẫu, assert, tự kiểm đồ thị |

## Quy trình

Đặt `<skill>` là thư mục skill, `<lv>` là thư mục làm việc của phân hệ (nên đặt cạnh tài liệu, ví dụ `thiet_ke_<ma_phan_he>/`).

### 1. Trích xuất tài liệu và lập danh sách giao dịch

```bash
python -I <skill>/scripts/trich_xuat.py <lv> <tài liệu 1> [<tài liệu 2> …]
```

`trich_xuat/N….md` chứa nội dung kèm nhãn vị trí (đoạn `Đ…`, dòng bảng `B….D…`, ô Excel, khối drawio). Đọc tệp này, không đọc tệp gốc.

Lập danh sách giao dịch (đơn vị nghiệp vụ "tác nhân – thao tác") bằng công cụ hợp với dạng tài liệu; có thể dùng nhiều công cụ cùng lúc, `lap_thiet_ke.py` đọc mọi tệp `giao_dich*.json`:

| Tài liệu có | Công cụ |
|---|---|
| Bảng chức năng / usecase có cột tác nhân | `bang_chuc_nang.py <lv>` |
| Ma trận phân quyền Excel (dòng chức năng × cột vai trò) | `ma_tran_sang_giao_dich.py <lv> <cau_hinh.json>` (ví dụ `vi_du/ma_tran_ba_mau.json`) |
| Quy trình: sơ đồ drawio có làn, bảng bước – người thực hiện | `quy_trinh_sang_giao_dich.py <lv>` |
| Tài liệu thiết kế, mô tả màn hình, sơ đồ drawio không có làn, mô tả tự do | AI tự lập `giao_dich_tu_lap.json` cùng cấu trúc (mỗi giao dịch: `id` duy nhất, `vt`, `nguon`, `muc`, `usecase`, `ten`, `mo_ta`, `tac_nhan`), mỗi giao dịch có vị trí trích |

Bước quy trình thường mô tả việc nghiệp vụ; trong đặc tả, quy bước về thao tác trên phần mềm, hoặc bỏ qua kèm lý do.

### 2. Hỏi ngay những điểm nghiệp vụ không phổ biến (trước khi thiết kế)

Đọc xong tài liệu, **trước khi viết `dac_ta.json`**, lập danh sách điểm nghiệp vụ mà nguyên tắc, quy định kế thừa và các mẫu M-01…M-14 không trả lời được, rồi hỏi người dùng ngay trong cuộc trò chuyện (dùng công cụ hỏi có lựa chọn nếu có). Không để những điểm này tới vòng rà soát đầu: một câu trả lời muộn thường làm đổi nhiều quyền cùng lúc.

Dấu hiệu nghiệp vụ không phổ biến:
- luồng không khớp mẫu nào: duyệt bởi hội đồng hoặc nhiều đơn vị ngang cấp, duyệt vượt cấp, đồng duyệt, chuyển xử lý giữa các nhánh;
- tác nhân, chức trách lạ, không quy được về lãnh đạo / chuyên viên / quản trị theo cấp;
- dữ liệu dùng chung giữa nhiều đơn vị không theo cây đơn vị (liên thông, chia sẻ chéo);
- tài liệu tự mâu thuẫn (bảng chức năng và quy trình nói khác nhau);
- thao tác không quy được về bộ key chuẩn;
- lựa chọn ảnh hưởng an toàn dữ liệu mà tài liệu im lặng (thông tin nhạy cảm, xoá, xuất hàng loạt ra ngoài đơn vị).

Cách hỏi: mỗi câu nêu tình huống nghiệp vụ cụ thể, phương án AI khuyến nghị đặt đầu, một đến ba phương án khác; không dùng key, tên phạm vi hay thuật ngữ RBAC / ReBAC / ABAC. Mỗi lượt tối đa khoảng bốn câu, câu ảnh hưởng nhiều quyền nhất hỏi trước. Ghi câu trả lời vào `cau_hoi` của đặc tả (`"tra_loi"`, `"luc": "truoc_thiet_ke"`). Câu chưa ai trả lời được ngay thì dùng phương án khuyến nghị, đánh dấu tin cậy thấp và để lại cho BA trên giao diện. Không hỏi điểm phổ biến đã có nguyên tắc, quy định kế thừa hoặc mẫu trả lời.

### 3. Đọc và thiết kế

Đọc `references/quy-dinh-ke-thua.md`, `nguyen-tac.md`, `mau-thiet-ke.md`, `doc-tai-lieu-ba.md`. Đọc trong `trich_xuat/N….md` các phần: nhóm người sử dụng, thông tin quản lý, mô hình tổ chức, quy trình; đọc `giao_dich*.md`. Viết `<lv>/dac_ta.json` theo `references/dac-ta.md` (xem `vi_du/dac_ta_mau.json`):

0. **Mọi key theo bộ key chuẩn tiếng Việt không dấu** (`references/bo-key.md`): hành động (`xem`, `them_moi`, `nhap`…), kiểu phạm vi, quan hệ, thuộc tính; key tài nguyên và vai trò cũng đặt bằng tiếng Việt không dấu (`de_xuat_mua_sam`, `truong_phong`), tên có dấu để ở `ten`. Xem chỉ có một hành động `xem`.
1. Tài nguyên (NT-05). **Cây đơn vị lấy từ Cổng** (`don_vi`): không thiết kế quyền trên cây đơn vị; công cụ tự thêm nếu đặc tả chưa có. Cây riêng của phân hệ (tổ chức đoàn thể…) khai như M-01.
2. Vai trò: tách tác nhân gộp theo chức trách, cấp, mảng (NT-09…NT-11, NT-22).
3. Quy tắc quy đổi giao dịch → tài nguyên, hành động; ánh xạ tác nhân → vai trò.
4. Quy tắc thu hẹp theo nguyên tắc: lãnh đạo (NT-21), mảng (NT-10), cấp duyệt (NT-14), cần biết (NT-17), cấp trên – cấp dưới (NT-13).
5. Khai `vong_doi` cho tài nguyên có gửi duyệt, `nhay_cam` cho tác vụ xem thông tin nhạy cảm, quan hệ `thuoc_don_vi` / `cap_duyet`. **Không viết** phạm vi, điều kiện mà quy định kế thừa đã tự đặt; chỉ viết khi tài liệu nêu khác hoặc nghiệp vụ có điều kiện riêng (đợt đang mở, người được giao…). Tài liệu nêu ngược một quy định kế thừa → ghi `ke_thua.khong_ap_dung` kèm lý do.
6. Câu hỏi cho BA ở mọi chỗ tin cậy thấp hoặc ảnh hưởng an toàn dữ liệu, viết bằng tình huống nghiệp vụ, không dùng thuật ngữ kỹ thuật.

### 4. Lập thiết kế và tự kiểm tra

```bash
python -I <skill>/scripts/lap_thiet_ke.py <lv>
```

Công cụ kiểm tra mọi key quy tắc nhắc tới, áp đặc tả, áp quy định kế thừa, rồi ghi `thiet_ke_phan_quyen.json` (gồm `cau_mo_ta`: câu mô tả theo vai trò cho BA) và `bao_cao_thiet_ke.md`, kèm kiểm tra:

| Mã | Kiểm tra |
|---|---|
| SOD-01 | Vai trò vừa lập / gửi duyệt vừa phê duyệt cùng tài nguyên mà chưa có điều kiện không tự duyệt |
| LP-01 | Vai trò toàn hệ thống có quyền ghi ở từ 4 mảng trở lên |
| LD-01 | Vai trò lãnh đạo có quyền nhập liệu |
| PV-01, PV-02 | Vai trò theo đơn vị thiếu phạm vi; phạm vi cần quan hệ mà tài nguyên chưa có |
| DK-01 | Hành động duyệt chưa có điều kiện trạng thái |
| HD-01, VT-01 | Hành động không ai có; vai trò không có quyền |
| GD-01…03 | Giao dịch chưa xác định được tài nguyên / hành động; tác nhân chưa ánh xạ |
| KEY-01, KEY-02 | Đặc tả dùng key cũ / bí danh (đã tự quy về key chuẩn, cần sửa đặc tả); hành động riêng ngoài bộ key chuẩn |
| CONG-01 | Đặc tả khai hành động trên cây đơn vị lấy từ Cổng |
| DT-01 | Đặc tả nhắc key chưa khai báo (vai trò, tài nguyên, hành động, phạm vi, điều kiện): **lỗi** |
| QT-01, QT-02 | Quy tắc không khớp gì; quy tắc bổ sung cấp lại quyền mà quy tắc thu hẹp đã bỏ |
| KT-07, KT-14, KT-20, KT-XD | Quyền ghi lan xuống cấp dưới; luồng duyệt thiếu `vong_doi`; quản trị có quyền nghiệp vụ; quy định kế thừa phải giữ quyền mà quy tắc thu hẹp đã bỏ |

Lặp bước 3–4 tới khi **không còn lỗi**. Cảnh báo được phép còn nếu là đánh đổi có chủ ý; khi đó nêu trong câu hỏi cho BA. Đừng sửa đặc tả chỉ để làm im cảnh báo.

### 5. Nếu BA có ma trận phân quyền: đo và hiệu chỉnh

```bash
python -I <skill>/scripts/so_sanh_ma_tran.py <lv> <cau_hinh.json>
```

Đọc `references/so-sanh-ma-tran.md`. Chỉnh quy tắc khi sai lệch đến từ quy tắc quá chặt hoặc quá lỏng **và** phản ánh một điều dùng lại được; giữ nguyên khi tài liệu và ma trận nói khác nhau, và nêu thành câu hỏi cho BA. Báo cả số trước và sau khi chỉnh, và nói rõ số sau khi chỉnh đo trên chính ma trận đã dùng để chỉnh nên lạc quan.

### 6. Mở giao diện cho BA, SA, dev rà soát

Dùng skill `truc-quan-phan-quyen`. BA xác nhận ở thẻ **Theo vai trò** (Đúng / Sai từng câu); SA, dev xem các thẻ kỹ thuật. Ý kiến rà soát nằm trong `<lv>/ra_soat.json` (khoá `c:…` cho câu, `q:…` cho ô ma trận).

### 7. Cập nhật theo ý kiến rà soát

- Câu trả lời câu hỏi (`ch:…`) và ghi chú: sửa `dac_ta.json`, chạy lại bước 4.
- «Sai» với câu **AI đề xuất** / **AI đề xuất bỏ**, và ý kiến trên từng ô: bước xuất JSON tự áp, không cần sửa đặc tả.
- «Sai» với câu **Theo tài liệu**: AI đọc lại tài liệu, sửa quy tắc ánh xạ.
- «Sai» với câu **Theo quy định chung**: ghi `ke_thua.khong_ap_dung` cho đúng vai trò, tài nguyên, lấy ghi chú của BA làm lý do. Không sửa bộ quy định chung chỉ vì một phân hệ.
- Khoá câu đổi khi nhóm quyền trong câu đổi. Sau khi lập lại, `xuat_json.py` báo ý kiến không còn mục tương ứng; báo người dùng để BA xác nhận lại các câu đó.

### 8. Xuất JSON import

```bash
python -I <skill>/scripts/xuat_json.py <lv> [--chi-da-duyet]
```

Ghi `phan_quyen_import.json` (khuôn `resources`, `roles`, `condition_sets`, `condition_set_rules`, `resource_menus`, `project_detail`…) và `bao_cao_xuat_json.md`.
- Quyền hiệu lực = giữ + AI thêm, đảo theo ý kiến «không đồng ý». `--chi-da-duyet`: chỉ đưa đề xuất AI đã được đồng ý.
- RBAC → `roles[]`; ReBAC → vai trò trên tài nguyên có `grantedTo`, tự sinh vai trò cầu nối cho phạm vi cấp dưới và quan hệ hai bước.
- ABAC: khuôn này chỉ có luật **cấp thêm** quyền (`condition_set_rules`). Quyền vốn là ABAC (người lập xem bản ghi của mình `do_minh_lap`, người được giao `duoc_giao`) xuất thành luật: userset tài khoản đang hoạt động × resourceset `resource.nguoi_lap / nguoi_duoc_giao = user.ma_nguoi_dung`. Điều kiện ràng buộc (trạng thái, khoá, không tự duyệt) chỉ xuất định nghĩa `condition_sets` và liệt kê trong báo cáo. Nói rõ điều này với người dùng.
- Hệ phân quyền đích dùng khuôn khác: giữ `thiet_ke_phan_quyen.json` làm nguồn, viết bộ chuyển riêng theo khuôn đích.

### 9. Xuất DSL cho playground (khi người dùng cần hiển thị, thử phân quyền)

```bash
python -I <skill>/scripts/xuat_dsl.py <lv> [--so-nhanh 2] [--kiem-thu gon|day_du] [--mot-tep]
```

Ghi `playground.dsl` (toàn bộ), `playground_theo_mang/<mảng>.dsl` (mỗi tệp một mảng nghiệp vụ, cộng cây và vai trò cầu nối cần để tính phạm vi) và `bao_cao_playground.md` (tự chạy `xuat_json.py` nếu JSON import chưa có hoặc cũ hơn thiết kế). **Đưa người dùng các tệp theo mảng để import**: tệp toàn bộ của phân hệ lớn (hàng trăm KB) làm playground chậm và sơ đồ rối; tệp theo mảng chỉ 10–40 KB.
- Cấu trúc: vai trò trên tài nguyên → `role`, kế thừa qua quan hệ → `derive`, vai trò chung → `role k "Tên": res:act`.
- Dữ liệu mẫu tự dựng: cây đơn vị theo các cấp của vai trò, người dùng mỗi vai trò ở hai nhánh, bản ghi ở các trạng thái, mỗi cấp duyệt có một bản ghi đang chờ. Đây là dữ liệu để thử, không phải dữ liệu thật.
- `assert` sinh từ ý đồ thiết kế, mặc định gọn: mỗi cặp vai trò × tài nguyên một câu được, một câu ngoài phạm vi, một câu cho quyền AI đề xuất bỏ (`--kiem-thu day_du`: mỗi quyền mức bản ghi một cặp).
- Key trong DSL toàn tiếng Việt không dấu; tenant mẫu `mac_dinh`, mọi `instance` và `assert` ghi rõ `@mac_dinh` (playground mặc định coi bản ghi thuộc tenant `default`; thiếu `@mac_dinh` thì quyền toàn hệ thống không áp lên bản ghi).
- Tự kiểm chạy riêng cho tệp toàn bộ và từng tệp theo mảng.
- Tự kiểm: tính quyền trên đồ thị DSL cho mọi người × bản ghi × hành động mức bản ghi và so với thiết kế; **lệch khác 0 là lỗi của bước xuất**, báo người dùng.
- Quyền ABAC (người lập, người được giao) xuất thành `userset` / `resourceset … where resource.nguoi_lap == user.ma_nguoi_dung` / `permit`.
- DSL chỉ có `permit` cấp thêm quyền: điều kiện ràng buộc (KT-13…KT-15 và điều kiện riêng) chỉ ghi thành chú thích cuối tệp; assert bỏ qua điều kiện. Nói rõ điều này với người dùng.

## Báo kết quả cho người dùng

Ngắn gọn: số tài nguyên, vai trò; số quyền theo tài liệu / theo quy định chung / AI thêm / AI bỏ; số câu mô tả BA cần xác nhận; số lỗi / cảnh báo; 3–5 quyết định thiết kế quan trọng nhất; số câu hỏi cho BA; độ khớp với ma trận BA nếu có; đường dẫn giao diện và tệp. Không chép nguyên báo cáo.
