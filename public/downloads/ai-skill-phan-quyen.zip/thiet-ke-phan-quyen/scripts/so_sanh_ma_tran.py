# -*- coding: utf-8 -*-
"""So sánh thiết kế (thiet_ke_phan_quyen.json) với một ma trận phân quyền Excel do BA lập, coi ma trận là ý định của BA.

  python -I so_sanh_ma_tran.py <thu_muc_lam_viec> <cau_hinh.json>

Đơn vị so sánh: (vai trò ma trận, tài nguyên thiết kế, hành động đã chuẩn hoá) — có quyền hay không; không so phạm vi bản ghi.
So hai phiên bản thiết kế: «tài liệu thô» (giữ + bỏ: mọi quyền tài liệu nêu) và «sau AI» (giữ + thêm).
Cấu hình: xem references/so-sanh-ma-tran.md và vi_du/so_sanh_ma_tran_mau.json.
Ghi: so_sanh_ma_tran.xlsx (chi tiết, theo vai trò, theo tài nguyên), so_sanh_ma_tran.md
"""
import collections, json, os, re, sys, warnings
import openpyxl

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bo_key as BOKEY  # noqa: E402
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import column_index_from_string, get_column_letter as Lc
warnings.simplefilter("ignore"); sys.stdout.reconfigure(encoding="utf-8")
s = lambda v: " ".join(str(v).split()) if v is not None else ""
cf = lambda x: re.sub(r"[^\w ]", "", s(x).casefold())
col = lambda c: c if isinstance(c, int) else column_index_from_string(c)


def khoang(spec):
    if not spec:
        return []
    out = []
    for p in spec if isinstance(spec, list) else [spec]:
        if isinstance(p, str) and ":" in p:
            a, b = p.split(":"); out += list(range(col(a), col(b) + 1))
        else:
            out.append(col(p))
    return out


# key hành động của ma trận được quy về bộ key chuẩn (bo_key.py); cấu hình có thể ghi đè bằng "hanh_dong"


def main():
    wd, cfgp = sys.argv[1], sys.argv[2]
    C = json.load(open(cfgp, encoding="utf-8"))
    ex_path = C["excel"] if os.path.isabs(C["excel"]) else os.path.join(os.path.dirname(os.path.abspath(cfgp)), C["excel"])
    ws = openpyxl.load_workbook(ex_path, data_only=True)[C["sheet"]]
    HDR, R0, R1 = C["dong_tieu_de"], C["dong_dau"], C.get("dong_cuoi") or ws.max_row
    CV, CD = khoang(C["cot_vai_tro"]), khoang(C.get("cot_dan_xuat"))
    KY = {k.casefold() for k in C.get("ky_hieu", ["x"])}
    MAP_HD = C.get("hanh_dong", {})
    VAI_TRO, TAI_NGUYEN = C["vai_tro"], {cf(k): v for k, v in C["tai_nguyen"].items()}

    def hd(a):
        a = s(a)
        if a in MAP_HD:
            return BOKEY.hanh_dong(MAP_HD[a])
        return BOKEY.hanh_dong(a, tien_to=True)

    # ---- đọc ma trận ----
    cur, row_res = None, {}
    for r in range(R0, R1 + 1):
        vals = [s(ws.cell(r, col(c)).value) for c in C["cot_ten_tai_nguyen"]]
        if any(vals):
            cur = next((v for v in reversed(vals) if v), "")
        row_res[r] = cur
    BK, B4 = C.get("bang_ke_thua") or {}, []
    for r in range(BK.get("dong_dau", 0), BK.get("dong_cuoi", -1) + 1):
        B4.append(tuple(s(ws.cell(r, col(BK[k])).value) for k in ("cot_vai_tro", "cot_tai_nguyen", "cot_vai_tro_dan_xuat")))
    N4 = lambda x: cf(x).replace("quản lý phê duyệt ", "").replace("phiếu ", "").replace("khó khăn", "").strip()
    dan_xuat, khong_goc = {}, collections.Counter()
    for c in CD:
        h = s(ws.cell(HDR, c).value)
        m = re.match(r"(Người quản lý|Người phê duyệt)\s*#?\s*(.*)", h) or re.match(r"(.+?)\s*#\s*(.*)", h)
        if m:
            goc = sorted({v for v, t, d in B4 if v and cf(d) == cf(m.group(1)) and N4(t) == N4(m.group(2))})
            dan_xuat[c] = (h, goc)
    EX, la = collections.defaultdict(set), collections.Counter()
    for r in range(R0, R1 + 1):
        res, act = row_res.get(r), s(ws.cell(r, col(C["cot_hanh_dong"])).value)
        if not res or not act:
            continue
        if cf(res) not in TAI_NGUYEN:
            la[res] += 1; continue
        k = (TAI_NGUYEN[cf(res)], hd(act))
        for c in CV + CD:
            if s(ws.cell(r, c).value).casefold() not in KY:
                continue
            if c in CV:
                EX[(s(ws.cell(HDR, c).value),) + k].add(f"{Lc(c)}{r}")
            elif c in dan_xuat:
                if not dan_xuat[c][1]:
                    khong_goc[dan_xuat[c][0]] += 1
                for g in dan_xuat[c][1]:
                    EX[(g,) + k].add(f"{Lc(c)}{r} ({dan_xuat[c][0]})")
    EX_ROLES = [s(ws.cell(HDR, c).value) for c in CV]

    # ---- thiết kế ----
    D = json.load(open(os.path.join(wd, "thiet_ke_phan_quyen.json"), encoding="utf-8"))
    TN_TEN = {t["key"]: t["ten"] for t in D["tai_nguyen"]}
    SO = set(TAI_NGUYEN.values())
    THO, SAU, QREF = set(), set(), collections.defaultdict(list)
    for q in D["quyen"]:
        if q["vai_tro"] not in VAI_TRO or q["tai_nguyen"] not in SO or q["hanh_dong"] in [BOKEY.hanh_dong(x) for x in C.get("bo_qua_hanh_dong", [])]:
            continue
        for e in VAI_TRO[q["vai_tro"]]:
            k = (e, q["tai_nguyen"], q["hanh_dong"])
            QREF[k].append(q)
            if q["trang_thai"] in ("giu", "bo"):
                THO.add(k)
            if q["trang_thai"] in ("giu", "them", "ke_thua"):   # quyền hiệu lực gồm cả quyền theo quy định kế thừa
                SAU.add(k)
    VT_SO = {e for v in VAI_TRO.values() for e in v}
    EXs = {k for k in EX if k[0] in VT_SO}

    def do(T):
        kh, thieu, thua = EXs & T, EXs - T, T - EXs
        p = len(kh) / (len(kh) + len(thua)) if kh or thua else 0
        r = len(kh) / (len(kh) + len(thieu)) if kh or thieu else 0
        return kh, thieu, thua, p, r, (2 * p * r / (p + r) if p + r else 0)
    A, B = do(THO), do(SAU)
    AIQ = {k for k, qs in QREF.items() if any(q["trang_thai"] == "them" for q in qs)}
    bo, them = THO - SAU, (SAU - THO) & AIQ
    kthua = SAU - THO - AIQ          # chỉ do quy định kế thừa sinh ra

    # ---- xlsx ----
    out = openpyxl.Workbook(); o = out.active; o.title = "Chi_tiet"
    H = ["Vai trò ma trận", "Tài nguyên", "Hành động", "Ma trận BA", "Tài liệu thô", "Thiết kế sau AI", "Kết quả", "Quyết định của AI", "Lý do (quy tắc AI)", "Ô ma trận"]
    for j, h in enumerate(H, 1):
        c = o.cell(1, j, h); c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1F4E78")
        o.column_dimensions[Lc(j)].width = [22, 30, 14, 10, 10, 12, 18, 18, 70, 36][j - 1]
    MAU = {"Khớp": "E2EFDA", "Thiếu so với ma trận": "FCE4D6", "Thừa so với ma trận": "FFF2CC"}
    keys = sorted(EXs | THO | SAU, key=lambda k: (EX_ROLES.index(k[0]) if k[0] in EX_ROLES else 99, k[1], k[2]))
    tk_vt, tk_tn = collections.defaultdict(collections.Counter), collections.defaultdict(collections.Counter)
    for i, k in enumerate(keys, 2):
        e, t, a_ = k in EXs, k in THO, k in SAU
        kq = "Khớp" if e and a_ else "Thiếu so với ma trận" if e else "Thừa so với ma trận" if a_ else "Cùng không có"
        if kq != "Cùng không có":
            tk_vt[k[0]][kq] += 1; tk_tn[k[1]][kq] += 1
        qd = "AI bỏ" if k in bo else "AI thêm" if k in them else "Quy định kế thừa" if k in kthua else ("Theo tài liệu" if t else "")
        ly = "; ".join(sorted({f"{r['id']}: {r['ly_do']}" for q in QREF.get(k, []) for r in q["quy_tac"] if r["loai"] in ("loc_vai_tro", "theo_cap_duyet", "bo_sung", "ke_thua")}))[:500]
        for j, v in enumerate([k[0], TN_TEN.get(k[1], k[1]), k[2], "x" if e else "", "x" if t else "", "x" if a_ else "", kq, qd, ly, "; ".join(sorted(EX.get(k, [])))], 1):
            o.cell(i, j, v).alignment = Alignment(wrap_text=True, vertical="top")
        if kq in MAU:
            o.cell(i, 7).fill = PatternFill("solid", fgColor=MAU[kq])
    o.freeze_panes = "A2"; o.auto_filter.ref = f"A1:J{len(keys) + 1}"
    for name, tb, first, ten in (("Theo_vai_tro", tk_vt, "Vai trò ma trận", lambda x: x), ("Theo_tai_nguyen", tk_tn, "Tài nguyên", lambda x: TN_TEN.get(x, x))):
        w = out.create_sheet(name)
        for j, h in enumerate([first, "Khớp", "Thiếu", "Thừa", "Độ phủ", "Độ chính xác"], 1):
            w.cell(1, j, h).font = Font(bold=True); w.column_dimensions[Lc(j)].width = 28 if j == 1 else 14
        for i, (k, c) in enumerate(sorted(tb.items(), key=lambda x: -sum(x[1].values())), 2):
            kh, ti, th = c["Khớp"], c["Thiếu so với ma trận"], c["Thừa so với ma trận"]
            for j, v in enumerate([ten(k), kh, ti, th, f"{kh / (kh + ti):.0%}" if kh + ti else "-", f"{kh / (kh + th):.0%}" if kh + th else "-"], 1):
                w.cell(i, j, v)
    out.save(os.path.join(wd, "so_sanh_ma_tran.xlsx"))

    pct = lambda x: f"{x:.0%}"
    L = [f"# So sánh thiết kế với ma trận phân quyền «{C['sheet']}»", "",
         f"Phạm vi so: {len(VT_SO)} vai trò ma trận có vai trò tương ứng, {len(SO)} tài nguyên chung; ma trận có {len(EXs)} quyền trong phạm vi này. Chưa so phạm vi bản ghi.", "",
         "| | Khớp | Thiếu so với ma trận | Thừa so với ma trận | Độ phủ | Độ chính xác | F1 |", "|---|---|---|---|---|---|---|",
         f"| Tài liệu thô | {len(A[0])} | {len(A[1])} | {len(A[2])} | {pct(A[4])} | {pct(A[3])} | {pct(A[5])} |",
         f"| Thiết kế sau AI | {len(B[0])} | {len(B[1])} | {len(B[2])} | {pct(B[4])} | {pct(B[3])} | {pct(B[5])} |", "",
         f"Quyết định của AI: bỏ {len(bo)} quyền — {len(bo - EXs)} đúng ý ma trận, {len(bo & EXs)} ma trận lại có; thêm {len(them)} quyền — {len(them & EXs)} ma trận có, {len(them - EXs)} ma trận không có.",
         f"Quy định kế thừa: sinh {len(kthua)} quyền — {len(kthua & EXs)} ma trận có, {len(kthua - EXs)} ma trận không có.", "",
         "## Theo vai trò", "", "| Vai trò ma trận | Khớp | Thiếu | Thừa |", "|---|---|---|---|"]
    L += [f"| `{k}` | {c['Khớp']} | {c['Thiếu so với ma trận']} | {c['Thừa so với ma trận']} |" for k, c in sorted(tk_vt.items(), key=lambda x: EX_ROLES.index(x[0]) if x[0] in EX_ROLES else 99)]
    L += ["", "## Theo tài nguyên", "", "| Tài nguyên | Khớp | Thiếu | Thừa |", "|---|---|---|---|"]
    L += [f"| {TN_TEN.get(k, k)} | {c['Khớp']} | {c['Thiếu so với ma trận']} | {c['Thừa so với ma trận']} |" for k, c in sorted(tk_tn.items(), key=lambda x: -sum(x[1].values()))]
    L += ["", "## Không so được", "",
          f"- Vai trò thiết kế không có vai trò ma trận tương ứng: {', '.join(sorted(v['key'] for v in D['vai_tro'] if v['key'] not in VAI_TRO)) or 'không có'}.",
          f"- Vai trò ma trận không có vai trò thiết kế: {', '.join(f'{r} ({sum(1 for k in EX if k[0] == r)} quyền)' for r in EX_ROLES if r not in VT_SO) or 'không có'}.",
          f"- Tài nguyên chỉ có ở thiết kế: {', '.join(sorted(t['ten'] for t in D['tai_nguyen'] if t['key'] not in SO and t['hanh_dong'])) or 'không có'}.",
          f"- Tài nguyên ma trận chưa ánh xạ: {', '.join(f'{k} ({n} dòng)' for k, n in la.items()) or 'không có'}."]
    if khong_goc:
        L.append("- Cột vai trò dẫn xuất không quy được về vai trò gốc: " + "; ".join(f"{h} ({n} ô)" for h, n in khong_goc.items()) + ".")
    open(os.path.join(wd, "so_sanh_ma_tran.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
    print("\n".join(L[4:9]))


if __name__ == "__main__":
    main()
