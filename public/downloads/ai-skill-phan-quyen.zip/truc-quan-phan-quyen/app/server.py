# -*- coding: utf-8 -*-
"""Khung trực quan hoá thiết kế phân quyền (chạy trên máy, chỉ dùng thư viện chuẩn).

  python -I server.py <thu_muc_lam_viec | thiet_ke_phan_quyen.json> [--cong 4190] [--mo] [--may-khac]

Đọc thiet_ke_phan_quyen.json (không sửa). Ý kiến rà soát ghi vào ra_soat.json cùng thư mục.
"""
import argparse, datetime, json, os, sys, threading, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sys.stdout.reconfigure(encoding="utf-8")
STATIC = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
TYPES = {".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".json": "application/json"}
LOCK = threading.Lock()
KQ = {"dong_y": "Đồng ý", "khong_dong_y": "Không đồng ý", "da_tra_loi": "Đã trả lời", "": "Ghi chú"}


class S:
    tk = rs = ""


def doc(p, mac_dinh):
    if not os.path.exists(p):
        return mac_dinh
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def bien_ban(tk, rs):
    muc = rs.get("muc", {})
    L = [f"# Biên bản rà soát thiết kế phân quyền — {(tk.get('phan_he') or {}).get('ten', '')}", "",
         f"Lập lúc {datetime.datetime.now():%d/%m/%Y %H:%M}. Tổng số mục có ý kiến: {len(muc)}.", ""]
    for kq in ("khong_dong_y", "da_tra_loi", "", "dong_y"):
        ds = [m for m in muc.values() if (m.get("ket_qua") or "") == kq]
        if not ds:
            continue
        L += [f"## {KQ[kq]} ({len(ds)})", "", "| Nội dung | Ý kiến | Người rà soát | Thời điểm |", "|---|---|---|---|"]
        o = lambda x: str(x or "").replace("|", "/").replace("\n", " ")
        L += [f"| {o(m.get('nhan'))} | {o(m.get('ghi_chu'))} | {o(m.get('nguoi'))} | {o(m.get('luc'))[:16].replace('T', ' ')} |" for m in ds]
        L.append("")
    return "\n".join(L)


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def gui(self, code, body, ctype="application/json", extra=None):
        data = body if isinstance(body, bytes) else (body if isinstance(body, str) else json.dumps(body, ensure_ascii=False)).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype + "; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        path = self.path.split("?")[0]
        try:
            if path == "/api/thiet-ke":
                if not os.path.exists(S.tk):
                    return self.gui(404, {"loi": f"Chưa có {S.tk}"})
                m = datetime.datetime.fromtimestamp(os.path.getmtime(S.tk)).isoformat(timespec="seconds")
                return self.gui(200, {"thiet_ke": doc(S.tk, {}), "cap_nhat": m})
            if path == "/api/ra-soat":
                return self.gui(200, doc(S.rs, {"muc": {}}))
            if path == "/api/bien-ban":
                return self.gui(200, bien_ban(doc(S.tk, {}), doc(S.rs, {"muc": {}})), "text/markdown",
                                {"Content-Disposition": 'attachment; filename="bien_ban_ra_soat.md"'})
            f = os.path.join(STATIC, "index.html" if path == "/" else os.path.basename(path))
            if os.path.isfile(f):
                with open(f, "rb") as fh:
                    return self.gui(200, fh.read(), TYPES.get(os.path.splitext(f)[1], "application/octet-stream"))
            self.gui(404, {"loi": "Không tìm thấy"})
        except Exception as e:
            self.gui(500, {"loi": str(e)})

    def do_POST(self):
        if self.path.split("?")[0] != "/api/ra-soat":
            return self.gui(404, {"loi": "Không tìm thấy"})
        try:
            b = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)).decode("utf-8"))
            khoa = str(b.get("khoa") or "").strip()
            if not khoa:
                return self.gui(400, {"loi": "Thiếu khoá"})
            with LOCK:
                rs = doc(S.rs, {"muc": {}})
                kq, gc = b.get("ket_qua") or "", (b.get("ghi_chu") or "").strip()
                if not kq and not gc:
                    rs["muc"].pop(khoa, None)
                else:
                    rs["muc"][khoa] = {"loai": b.get("loai") or "", "nhan": b.get("nhan") or "", "ket_qua": kq, "ghi_chu": gc,
                                       "nguoi": (b.get("nguoi") or "").strip(), "luc": datetime.datetime.now().isoformat(timespec="seconds")}
                tmp = S.rs + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(rs, f, ensure_ascii=False, indent=1)
                os.replace(tmp, S.rs)
            self.gui(200, rs)
        except Exception as e:
            self.gui(500, {"loi": str(e)})


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("duong_dan")
    ap.add_argument("--cong", type=int, default=int(os.environ.get("PORT") or 4190))
    ap.add_argument("--mo", action="store_true")
    ap.add_argument("--may-khac", action="store_true", help="cho máy khác trong mạng nội bộ truy cập")
    a = ap.parse_args()
    p = os.path.abspath(a.duong_dan)
    S.tk = os.path.join(p, "thiet_ke_phan_quyen.json") if os.path.isdir(p) else p
    S.rs = os.path.join(os.path.dirname(S.tk), "ra_soat.json")
    if not os.path.exists(S.tk):
        print("LỖI: không thấy", S.tk); sys.exit(1)
    srv = ThreadingHTTPServer(("0.0.0.0" if a.may_khac else "127.0.0.1", a.cong), H)
    url = f"http://localhost:{a.cong}/"
    print("Khung trực quan:", url, "\nThiết kế:", S.tk, "\nÝ kiến rà soát lưu vào:", S.rs)
    if a.mo:
        threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
