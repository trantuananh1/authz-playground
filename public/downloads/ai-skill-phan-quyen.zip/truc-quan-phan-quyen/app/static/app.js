/* Khung trực quan hoá thiết kế phân quyền — đọc thiet_ke_phan_quyen.json, ghi ý kiến vào ra_soat.json */
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const lc = s => String(s ?? '').toLowerCase();

const NT = {
  'NT-01': 'Mặc định từ chối', 'NT-02': 'Đặc quyền tối thiểu', 'NT-03': 'Tách nhiệm vụ (người lập ≠ người duyệt)', 'NT-04': 'Truy vết',
  'NT-05': 'Tài nguyên là dữ liệu có vòng đời', 'NT-06': 'Hành động theo vòng đời, một key một nghĩa', 'NT-07': 'Mức danh sách và mức bản ghi',
  'NT-08': 'Xuất, nhập là quyền riêng', 'NT-09': 'Vai trò theo chức trách', 'NT-10': 'Tách tác nhân gộp', 'NT-11': 'Tránh bùng nổ vai trò',
  'NT-12': 'Phạm vi theo cây tổ chức', 'NT-13': 'Cấp trên xem, cấp dưới làm', 'NT-14': 'Duyệt nhiều cấp bằng quan hệ cấp duyệt',
  'NT-15': 'Điều kiện theo trạng thái', 'NT-16': 'Điều kiện theo người', 'NT-17': 'Cần biết mới xem', 'NT-18': 'API không là vai trò người dùng',
  'NT-19': 'Dashboard suy ra từ dữ liệu gốc', 'NT-20': 'Kho tư liệu theo chủ sở hữu', 'NT-21': 'Lãnh đạo xem và duyệt, không nhập liệu',
  'NT-22': 'Quản trị tách khỏi nghiệp vụ', 'NT-23': 'Uỷ quyền, kiêm nhiệm', 'NT-24': 'Danh mục, dữ liệu dùng chung'
};
const LOAI_QT = { tai_nguyen: 'Xác định tài nguyên', hanh_dong: 'Quy đổi hành động', tac_nhan: 'Ánh xạ tác nhân → vai trò', theo_cap_duyet: 'Theo cấp duyệt',
  loc_vai_tro: 'Thu hẹp quyền', bo_sung: 'AI bổ sung', pham_vi: 'Phạm vi', dieu_kien: 'Điều kiện', ke_thua: 'Quy định chung' };
const TT = { giu: ['Theo tài liệu', 'giu'], ke_thua: ['Theo quy định chung', 'ke_thua'], them: ['AI đề xuất thêm', 'them'], bo: ['AI đề xuất bỏ', 'bo'] };
const NHOM_VT = { lanh_dao: 'Lãnh đạo', chuyen_vien: 'Chuyên viên', quan_tri: 'Quản trị hệ thống', chung: 'Mọi người dùng' };
const capVT = v => v.loai_pham_vi === 'toan_he_thong' ? 'toàn hệ thống' : v.loai_pham_vi === 'theo_ban_ghi' ? 'theo bản ghi mình lập' : 'gán trên ' + (X.R[v.gan_tren]?.ten || v.gan_tren || '');
const TC = { cao: 'Tin cậy cao', trung_binh: 'Tin cậy trung bình', thap: 'Tin cậy thấp' };
/* bộ key chuẩn tiếng Việt không dấu (bo_key.py); key tiếng Anh và key cũ giữ để đọc được thiết kế lập trước đó */
const NHOM_HD = { xem: 'Xem', them_moi: 'Tạo', chinh_sua: 'Sửa', xoa: 'Xoá', vong_doi: 'Vòng đời', duyet: 'Duyệt', xuat_nhap: 'Xuất / nhập', khac: 'Khác',
  tao: 'Tạo', sua: 'Sửa', view: 'Xem', create: 'Tạo', update: 'Sửa', delete: 'Xoá', lifecycle: 'Vòng đời', approval: 'Duyệt', bulk: 'Xuất / nhập', other: 'Khác' };
const KIEU_PV = { toan_he_thong: 'Toàn bộ (RBAC)', danh_sach: 'Mức danh sách', don_vi_minh: 'Đơn vị mình (ReBAC)', don_vi_minh_va_cap_duoi_truc_tiep: 'Mình + cấp dưới trực tiếp (ReBAC)',
  don_vi_minh_va_cap_duoi: 'Mình + mọi cấp dưới (ReBAC)', cap_duyet: 'Đang chờ đơn vị mình duyệt (ReBAC)', do_minh_lap: 'Do chính mình lập (ABAC)', duoc_giao: 'Được giao cho mình (ABAC)',
  all: 'Toàn bộ (RBAC)', list: 'Mức danh sách', own_unit: 'Đơn vị mình (ReBAC)', unit_and_children: 'Mình + cấp dưới trực tiếp (ReBAC)',
  unit_and_descendants: 'Mình + mọi cấp dưới (ReBAC)', approval_unit: 'Đang chờ đơn vị mình duyệt (ReBAC)', own_record: 'Do chính mình lập (ABAC)', assigned: 'Được giao cho mình (ABAC)',
  toan_bo: 'Toàn bộ', muc_danh_sach: 'Mức danh sách', cap_duoi_truc_tiep: 'Mình + cấp dưới trực tiếp',
  toan_bo_cap_duoi: 'Mình + toàn bộ cấp dưới', cua_minh: 'Của mình / được chia sẻ' };
const PV_TOAN = ['toan_he_thong', 'all', 'toan_bo'], PV_DS = ['danh_sach', 'list', 'muc_danh_sach'];

let D = null, META = {}, RS = { muc: {} }, X = {};
const S = { tab: 'theo-vai-tro', chuaXn: false, moVs: new Set(), tim: '', mang: '', hienBo: false, loc: 'tat-ca', vt: null, mo: null, hienKey: false, gdLoc: 'tat-ca', gdTim: '', anVT: new Set() };

async function tai() {
  const r = await fetch('/api/thiet-ke'); const j = await r.json();
  if (!r.ok) { $('#nd').innerHTML = `<p class="empty">${esc(j.loi)}</p>`; return; }
  D = j.thiet_ke; META = j; RS = await (await fetch('/api/ra-soat')).json(); RS.muc = RS.muc || {};
  chiMuc(); ve();
}
function chiMuc() {
  const by = (a) => Object.fromEntries((a || []).map(x => [x.key, x]));
  X = { R: by(D.tai_nguyen), V: by(D.vai_tro), PV: by(D.pham_vi), DK: by(D.dieu_kien), GD: Object.fromEntries(D.giao_dich.map(g => [g.id, g])), Q: new Map(), HD: {}, cauCua: {} };
  D.cau_mo_ta = D.cau_mo_ta || [];
  for (const c of D.cau_mo_ta) for (const k of c.quyen) X.cauCua[k] = c.key;
  for (const q of D.quyen) X.Q.set(`${q.vai_tro}|${q.tai_nguyen}|${q.hanh_dong}`, q);
  for (const t of D.tai_nguyen) for (const h of t.hanh_dong) X.HD[`${t.key}|${h.key}`] = h;
  const capOrder = []; for (const v of D.vai_tro) if (!capOrder.includes(v.cap || '')) capOrder.push(v.cap || '');
  X.cap = capOrder;
  X.mang = []; for (const t of D.tai_nguyen) if (t.hanh_dong.length && !X.mang.includes(t.mang || '')) X.mang.push(t.mang || '');
}
const ttHieuLuc = q => { const rv = RS.muc[q.khoa]?.ket_qua || RS.muc[X.cauCua[q.khoa]]?.ket_qua; if (rv === 'khong_dong_y' && q.trang_thai === 'them') return 'bo'; if (rv === 'khong_dong_y' && q.trang_thai === 'bo') return 'giu'; return q.trang_thai; };
const key = k => S.hienKey ? `<span class="code">${esc(k)}</span>` : '';
const ntChips = a => (a || []).map(n => `<span class="nt" title="${esc(NT[n] || '')}">${esc(n)}</span>`).join('');
const tcChip = t => t ? `<span class="tc ${t}">${esc(TC[t] || t)}</span>` : '';
const ttChip = t => `<span class="st ${TT[t][1]}">${TT[t][0]}</span>`;
const tenPV = k => X.PV[k]?.ten || ({ toan_he_thong: 'Toàn bộ', danh_sach: 'Mức danh sách', all: 'Toàn bộ', list: 'Mức danh sách', toan_bo: 'Toàn bộ', muc_danh_sach: 'Mức danh sách' }[k] || k || '—');

async function luu(khoa, loai, nhan, ket_qua, ghi_chu) {
  const nguoi = $('#nguoi').value.trim();
  const r = await fetch('/api/ra-soat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ khoa, loai, nhan, ket_qua, ghi_chu, nguoi }) });
  if (r.ok) { RS = await r.json(); ve(true); } else alert('Không lưu được: ' + await r.text());
}

function ve(giu) {
  const w = $('.grid-wrap'), sc = giu && w ? [w.scrollTop, w.scrollLeft] : null, y = giu ? scrollY : 0;
  $('#ten').textContent = D.phan_he?.ten || '';
  document.title = 'Thiết kế phân quyền — ' + (D.phan_he?.ten || '');
  $$('#tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === S.tab));
  $('#dem-kt').textContent = D.kiem_tra.filter(k => k.muc !== 'goi_y').length || '';
  $('#dem-ch').textContent = D.cau_hoi.filter(c => !c.tra_loi).length || '';
  $('#dem-rs').textContent = Object.keys(RS.muc).length || '';
  ({ 'theo-vai-tro': veTheoVaiTro, 'tong-quan': veTongQuan, 'ma-tran': veMaTran, 'vai-tro': veVaiTro, 'tai-nguyen': veTaiNguyen, 'pham-vi': vePhamVi, 'kiem-tra': veKiemTra,
     'giao-dich': veGiaoDich, 'cau-hoi': veCauHoi, 'bien-ban': veBienBan })[S.tab]();
  if (sc && $('.grid-wrap')) { $('.grid-wrap').scrollTop = sc[0]; $('.grid-wrap').scrollLeft = sc[1]; }
  if (giu) scrollTo(0, y);
  if (S.mo) moNgan(S.mo, true);
}

/* ---------------- Theo vai trò (dành cho BA: câu mô tả, không cần biết RBAC/ReBAC/ABAC) ---------------- */
const NGUON_C = { ba: ['Theo tài liệu', 'giu'], ke_thua: ['Theo quy định chung', 'ke_thua'], ai_them: ['AI đề xuất', 'them'], ai_bo: ['AI đề xuất bỏ', 'bo'] };
const Y_SAI = { ba: 'Đã ghi lại; AI sẽ chỉnh thiết kế cho đúng tài liệu.', ke_thua: 'Đã ghi lại; AI sẽ ghi ngoại lệ cho quy định chung này ở vai trò này.',
  ai_them: 'Quyền AI đề xuất này sẽ bị bỏ khi xuất.', ai_bo: 'Quyền này được giữ lại như tài liệu nêu.' };
const daXn = c => ['dong_y', 'khong_dong_y'].includes(RS.muc[c.key]?.ket_qua);
function viSao(c, qk) {
  const dong = r => {
    if (r.loai === 'ke_thua') return `<li><span class="st ke_thua">${esc(r.id)}</span> ${esc(r.ly_do)}</li>`;
    if (r.loai === 'tac_nhan') return `<li><span class="st giu">Tài liệu</span> ${esc(r.ly_do || 'Tác nhân trong tài liệu được giao vai trò này.')}</li>`;
    return `<li><span class="st them">AI</span> ${esc(r.ly_do)} ${r.tin_cay && r.tin_cay !== 'cao' ? tcChip(r.tin_cay) : ''} ${S.hienKey ? `<span class="code">${esc(r.id)}</span>` : ''}</li>`;
  };
  const gds = [...new Set(c.quyen.flatMap(k => qk[k]?.giao_dich || []))].map(id => X.GD[id]).filter(Boolean);
  return `<div class="cau-why"><ul>${c.quy_tac.map(dong).join('')}</ul>
    ${gds.length ? `<div class="muted small">Căn cứ trong tài liệu:</div><ul class="src">${gds.slice(0, 4).map(g => `<li><span class="code">${esc(g.vt)}</span> <b>${esc(g.ten)}</b><blockquote>${esc(g.mo_ta)}</blockquote></li>`).join('')}</ul>${gds.length > 4 ? `<p class="muted small">… và ${gds.length - 4} chỗ khác.</p>` : ''}` : ''}
    ${S.hienKey ? `<div class="code">${c.quyen.map(esc).join(' · ')}</div>` : ''}</div>`;
}
function veTheoVaiTro() {
  if (!S.vt || !X.V[S.vt]) S.vt = D.vai_tro[0]?.key;
  const v = X.V[S.vt], qk = Object.fromEntries(D.quyen.map(q => [q.khoa, q]));
  const cauVT = vk => D.cau_mo_ta.filter(c => c.vai_tro === vk);
  const tienDo = vk => { const a = cauVT(vk); return `${a.filter(daXn).length}/${a.length}`; };
  const list = X.cap.map(c => `<div class="lg">${esc(c || 'Khác')}</div>` + D.vai_tro.filter(x => (x.cap || '') === c).map(x =>
    `<button class="role-item ${x.key === S.vt ? 'on' : ''}" data-vt="${x.key}"><span>${esc(x.ten)}</span><span class="muted">đã xác nhận ${tienDo(x.key)} câu</span></button>`).join('')).join('');
  const cay = X.R[v.gan_tren]?.ten || 'đơn vị';
  const gan = v.loai_pham_vi === 'toan_he_thong' ? 'Vai trò cấp cao nhất: người được giao vai trò này làm việc trên toàn hệ thống.'
    : v.loai_pham_vi === 'theo_ban_ghi' ? 'Không cần giao vai trò: ai lập bản ghi thì tự có các quyền dưới đây với bản ghi đó.'
    : `Giao cho người tại từng «${cay}». Trong các câu dưới đây, «${lc(cay)} mình» là ${lc(cay)} nơi người đó được giao vai trò.`;
  const tac = (v.tac_nhan_tai_lieu || []).map(a => `«${esc(a.tac_nhan)}»`).join(', ');
  const cs = cauVT(v.key).filter(c => !S.chuaXn || !daXn(c));
  const row = c => {
    const rv = RS.muc[c.key] || {}, [l, cls] = NGUON_C[c.nguon] || ['', ''], mo = S.moVs.has(c.key);
    return `<li class="cau ${rv.ket_qua === 'dong_y' ? 'ok' : rv.ket_qua === 'khong_dong_y' ? 'no' : ''}" data-c="${esc(c.key)}">
      <div class="cau-top"><span class="st ${cls}">${l}</span>
        <p class="cau-txt">${esc(c.noi_dung)} ${c.tin_cay === 'thap' ? tcChip('thap') : ''}</p>
        <div class="cau-btn"><button class="btn sm ${rv.ket_qua === 'dong_y' ? 'on ok' : ''}" data-kq="dong_y">✓ Đúng</button><button class="btn sm ${rv.ket_qua === 'khong_dong_y' ? 'on no' : ''}" data-kq="khong_dong_y">✕ Sai</button><button class="btn sm ghost" data-vs>${mo ? 'Ẩn lý do' : 'Vì sao?'}</button></div></div>
      ${rv.ket_qua === 'khong_dong_y' ? `<p class="cau-kq">${esc(Y_SAI[c.nguon] || '')}</p>` : ''}
      ${mo ? viSao(c, qk) : ''}
      ${rv.ket_qua === 'khong_dong_y' || rv.ghi_chu || mo ? `<div class="cau-note"><input type="text" placeholder="Ghi chú: theo nghiệp vụ thì đúng là…" value="${esc(rv.ghi_chu || '')}"></div>` : ''}
    </li>`;
  };
  const muc = [['duoc', 'Được làm'], ['rang_buoc', 'Ràng buộc'], ['khong_duoc', 'AI đề xuất không cho làm']].map(([lo, ten]) => {
    const a = cs.filter(c => c.loai === lo); if (!a.length) return '';
    const g = {}; a.forEach(c => (g[c.tai_nguyen] ||= []).push(c));
    return `<div class="card"><h3>${ten}</h3>${Object.entries(g).map(([rk, b]) => `<div class="grp"><div class="grp-h">${esc(X.R[rk]?.ten || rk)}</div><ul class="cau-list">${b.map(row).join('')}</ul></div>`).join('')}</div>`;
  }).join('');
  const tong = D.cau_mo_ta.length, xn = D.cau_mo_ta.filter(daXn).length;
  $('#nd').innerHTML = `
    <details class="card huong-dan" ${xn ? '' : 'open'}><summary>Cách đọc và xác nhận</summary>
      <p>Mỗi vai trò được mô tả bằng các câu. Với mỗi câu, bấm <b>Đúng</b> nếu khớp nghiệp vụ, <b>Sai</b> nếu không khớp và ghi chú điều đúng.</p>
      <div class="legend-big"><span>${ttChip('giu')} tài liệu của BA có nêu</span><span>${ttChip('ke_thua')} suy ra theo quy định chung, áp dụng như nhau cho mọi phân hệ</span>
        <span><span class="st them">AI đề xuất</span> tài liệu không nêu, AI đề xuất thêm</span><span>${ttChip('bo')} tài liệu có nêu, AI đề xuất không cho</span></div>
      <p class="muted">Bấm Sai với câu AI đề xuất thì đề xuất bị bỏ; với câu AI đề xuất bỏ thì quyền được giữ lại. Với câu theo tài liệu hoặc theo quy định chung, ý kiến được ghi lại để AI chỉnh thiết kế.</p>
      ${(D.ke_thua?.ap_dung || []).length ? `<details><summary class="muted">Quy định chung đã áp dụng (${D.ke_thua.ap_dung.length})</summary><ul>${D.ke_thua.ap_dung.map(k => `<li><span class="st ke_thua">${esc(k.ma)}</span> ${esc(k.ten)} <span class="muted">· ${k.so_quyen} quyền</span></li>`).join('')}</ul></details>` : ''}
    </details>
    <div class="toolbar"><span class="prog"><i style="width:${tong ? xn / tong * 100 : 0}%"></i></span><span class="muted">Đã xác nhận ${xn}/${tong} câu</span>
      <label class="switch"><input id="chua-xn" type="checkbox" ${S.chuaXn ? 'checked' : ''}> Chỉ hiện câu chưa xác nhận</label></div>
    <div class="split"><div class="role-list">${list}</div><div class="role-body">
      <div class="card"><div class="eyebrow">${esc(v.cap || '')}</div><h2>${esc(v.ten)} ${key(v.key)}</h2>${v.mo_ta ? `<p>${esc(v.mo_ta)}</p>` : ''}
        <p class="gan">${esc(gan)}</p>${tac ? `<p class="muted">Trong tài liệu: ${tac}</p>` : ''}</div>
      ${muc || `<p class="empty">${S.chuaXn ? 'Đã xác nhận hết các câu của vai trò này.' : 'Vai trò này chưa có quyền nào.'}</p>`}
    </div></div>`;
  $$('.role-item').forEach(b => b.onclick = () => { S.vt = b.dataset.vt; ve(); });
  $('#chua-xn').onchange = e => { S.chuaXn = e.target.checked; ve(true); };
  $$('li.cau').forEach(li => {
    const c = D.cau_mo_ta.find(x => x.key === li.dataset.c), rv = RS.muc[c.key] || {}, nhan = `${v.ten}: ${c.noi_dung}`, note = () => $('.cau-note input', li)?.value ?? rv.ghi_chu ?? '';
    $$('[data-kq]', li).forEach(b => b.onclick = () => luu(c.key, 'cau', nhan, rv.ket_qua === b.dataset.kq ? '' : b.dataset.kq, note()));
    $('[data-vs]', li).onclick = () => { S.moVs.has(c.key) ? S.moVs.delete(c.key) : S.moVs.add(c.key); ve(true); };
    const inp = $('.cau-note input', li); if (inp) inp.onchange = () => luu(c.key, 'cau', nhan, rv.ket_qua || '', inp.value);
  });
}

/* ---------------- Tổng quan ---------------- */
function veTongQuan() {
  const tk = D.thong_ke, km = c => D.kiem_tra.filter(k => k.muc === c).length;
  const qs = D.quyen.map(ttHieuLuc), dem = t => qs.filter(x => x === t).length;
  const daRs = D.quyen.filter(q => ['dong_y', 'khong_dong_y'].includes(RS.muc[q.khoa]?.ket_qua)).length;
  const deXuat = D.quyen.filter(q => ['them', 'bo'].includes(q.trang_thai)).length;
  const tile = (n, l, s = '', c = '') => `<div class="stat ${c}"><div class="n">${n}</div><div class="l">${l}</div>${s ? `<div class="s">${s}</div>` : ''}</div>`;
  const theoCap = X.cap.map(c => {
    const vs = D.vai_tro.filter(v => (v.cap || '') === c);
    return `<div class="tier"><div class="tier-h">${esc(c || 'Khác')}</div><div class="tier-b">${vs.map(v => {
      const q = D.quyen.filter(x => x.vai_tro === v.key);
      return `<button class="rcard ${v.nhom || ''}" data-vt="${v.key}"><span class="rname">${esc(v.ten)}</span>${key(v.key)}
        <span class="rmeta">${esc(NHOM_VT[v.nhom] || 'Chuyên viên')} · ${esc(capVT(v))}</span>
        <span class="rcount"><b>${q.filter(x => ttHieuLuc(x) !== 'bo').length}</b> quyền${q.filter(x => x.trang_thai === 'them').length ? ` · <i class="them">+${q.filter(x => x.trang_thai === 'them').length}</i>` : ''}${q.filter(x => x.trang_thai === 'bo').length ? ` · <i class="bo">−${q.filter(x => x.trang_thai === 'bo').length}</i>` : ''}</span>
        ${v.co_so?.loai === 'de_xuat' ? '<span class="ai">vai trò do AI tách</span>' : ''}</button>`; }).join('')}</div></div>`;
  }).join('');
  const ntDem = {};
  for (const q of D.quyen) if (['them', 'bo'].includes(q.trang_thai)) for (const r of q.quy_tac) for (const n of r.nguyen_tac || []) ntDem[n] = (ntDem[n] || 0) + 1;
  const ntMax = Math.max(1, ...Object.values(ntDem));
  $('#nd').innerHTML = `
    <section class="stats">
      ${tile(D.tai_nguyen.length, 'Tài nguyên')}${tile(D.vai_tro.length, 'Vai trò', D.vai_tro.filter(v => v.co_so?.loai === 'de_xuat').length + ' do AI tách / đề xuất')}
      ${tile(dem('giu') + dem('them') + dem('ke_thua'), 'Quyền hiệu lực', `${D.quyen.filter(q => q.trang_thai === 'giu').length} theo tài liệu · ${D.quyen.filter(q => q.trang_thai === 'ke_thua').length} theo quy định chung · ${D.quyen.filter(q => q.trang_thai === 'them').length} AI thêm`)}
      ${tile(D.quyen.filter(q => q.trang_thai === 'bo').length, 'AI đề xuất bỏ', 'quyền tài liệu nêu nhưng trái nguyên tắc', 'warn')}
      ${tile(`${tk.giao_dich_anh_xa}/${tk.giao_dich}`, 'Giao dịch đã ánh xạ', `${tk.giao_dich_bo_qua} bỏ qua (dashboard, API) · ${tk.giao_dich_chua_anh_xa} chưa ánh xạ`)}
      ${tile(km('loi') + km('canh_bao'), 'Lỗi / cảnh báo nguyên tắc', km('goi_y') + ' gợi ý', km('loi') ? 'bad' : '')}
      ${tile(`${daRs}/${deXuat}`, 'Đề xuất AI đã rà soát', '', '')}
    </section>
    <div class="legend-big">
      <span>${ttChip('giu')} quyền tài liệu nêu, AI giữ</span><span>${ttChip('ke_thua')} suy ra theo quy định kế thừa KT-xx</span><span>${ttChip('them')} tài liệu không nêu, AI đề xuất thêm</span>
      <span>${ttChip('bo')} tài liệu nêu, AI đề xuất bỏ</span><span class="muted">Mọi đề xuất kèm lý do, mã nguyên tắc và mức tin cậy; BA/SA đồng ý hoặc không đồng ý ngay trên ô.</span>
    </div>
    <div class="cols2">
      <div class="card"><h3>Vai trò theo cấp</h3><p class="muted">Bấm một vai trò để xem quyền.</p><div class="tiers">${theoCap}</div></div>
      <div class="card"><h3>Mô hình tài nguyên và quan hệ</h3><p class="muted">Cây tổ chức bên trái là nơi gán vai trò; dữ liệu nối về cây qua quan hệ, quyết định phạm vi bản ghi (ReBAC).</p>${soDo()}</div>
    </div>
    <div class="cols2">
      <div class="card"><h3>Nguyên tắc dẫn đến đề xuất của AI</h3><p class="muted">Số quyền AI thêm hoặc bỏ có viện dẫn nguyên tắc.</p>
        <div class="bars">${Object.entries(ntDem).sort((a, b) => b[1] - a[1]).map(([n, c]) => `<div class="bar"><span class="bl">${esc(n)} · ${esc(NT[n] || '')}</span><span class="bt"><i style="width:${c / ntMax * 100}%"></i></span><span class="bn">${c}</span></div>`).join('') || '<p class="muted">Chưa có đề xuất.</p>'}</div></div>
      <div class="card"><h3>RBAC · ReBAC · ABAC trong thiết kế</h3>${ba()}</div>
    </div>`;
  $$('.rcard').forEach(b => b.onclick = () => { S.vt = b.dataset.vt; S.tab = 'vai-tro'; ve(); });
}
function ba() {
  const hl = D.quyen.filter(q => ttHieuLuc(q) !== 'bo');
  const rb = hl.filter(q => X.V[q.vai_tro]?.loai_pham_vi === 'toan_he_thong' && !q.dieu_kien.length).length;
  const ab = hl.filter(q => q.dieu_kien.length || X.PV[q.pham_vi]?.co_che === 'ABAC').length;
  const re = hl.filter(q => X.V[q.vai_tro]?.loai_pham_vi !== 'toan_he_thong' && q.pham_vi && !PV_DS.includes(q.pham_vi) && X.PV[q.pham_vi]?.co_che !== 'ABAC').length;
  const ds = hl.filter(q => PV_DS.includes(q.pham_vi)).length;
  const row = (t, n, d) => `<tr><td><b>${t}</b></td><td class="num">${n}</td><td class="muted">${d}</td></tr>`;
  return `<table class="plain"><tbody>
    ${row('RBAC', rb, 'Vai trò toàn hệ thống, không điều kiện')}
    ${row('ReBAC', re, 'Vai trò gán trên cây tổ chức; bản ghi xác định qua quan hệ')}
    ${row('Mức danh sách', ds, 'Thao tác trước khi chọn bản ghi; danh sách lọc theo quyền xem bản ghi')}
    ${row('ABAC', ab, `Có điều kiện: ${D.dieu_kien.map(d => esc(d.ten)).join(', ')}`)}
  </tbody></table>`;
}
function soDo() {
  const T = D.tai_nguyen, cay = T.filter(t => t.loai === 'cay'), keys = new Set(cay.map(t => t.key));
  const lv = {}; cay.forEach(t => lv[t.key] = 0);
  for (let i = 0; i < 4; i++) for (const t of T) if (!(t.key in lv)) { const ts = (t.quan_he || []).map(r => r.toi).filter(k => k in lv && k !== t.key); if (ts.length) lv[t.key] = Math.max(...ts.map(k => lv[k])) + 1; }
  for (const t of T) if (!(t.key in lv)) lv[t.key] = 1;
  const cols = {}; for (const t of T) (cols[lv[t.key]] ||= []).push(t);
  const W = 230, H = 34, GX = 120, GY = 14, pos = {};
  const nc = Object.keys(cols).length, maxR = Math.max(...Object.values(cols).map(c => c.length));
  Object.entries(cols).forEach(([c, ts]) => ts.forEach((t, i) => pos[t.key] = { x: 10 + c * (W + GX), y: 10 + i * (H + GY) + (maxR - ts.length) * (H + GY) / 2 }));
  const width = 20 + nc * W + (nc - 1) * GX, height = 20 + maxR * (H + GY);
  let edges = '', nodes = '';
  for (const t of T) for (const r of t.quan_he || []) {
    const a = pos[t.key], b = pos[r.toi]; if (!a || !b) continue;
    if (t.key === r.toi) continue;
    const x1 = a.x, y1 = a.y + H / 2, x2 = b.x + W, y2 = b.y + H / 2, mx = (x1 + x2) / 2;
    edges += `<path d="M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}" class="edge"><title>${esc(t.ten)} —${esc(r.key)}→ ${esc(X.R[r.toi]?.ten)}: ${esc(r.y_nghia || '')}</title></path>`;
  }
  for (const t of T) {
    const p = pos[t.key], self = (t.quan_he || []).some(r => r.toi === t.key);
    nodes += `<g class="node ${t.loai}" data-tn="${t.key}" transform="translate(${p.x},${p.y})"><rect width="${W}" height="${H}" rx="7"></rect>
      <text x="10" y="21">${esc(t.ten.length > 30 ? t.ten.slice(0, 29) + '…' : t.ten)}</text>${self ? `<text x="${W - 8}" y="21" text-anchor="end" class="self">↻ cấp trên</text>` : ''}<title>${esc(t.ten)} (${esc(t.key)})</title></g>`;
  }
  return `<div class="svgwrap"><svg viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" role="img" aria-label="Sơ đồ tài nguyên và quan hệ">${edges}${nodes}</svg></div>
    <div class="legend"><span><i class="sw cay"></i>Cây tổ chức</span><span><i class="sw du_lieu"></i>Dữ liệu nghiệp vụ</span><span><i class="sw tep"></i>Kho tư liệu</span><span class="muted">Rê chuột vào đường nối để xem quan hệ.</span></div>`;
}

/* ---------------- Ma trận ---------------- */
function oHtml(v, rk, h) {
  const q = X.Q.get(`${v.key}|${rk}|${h.key}`);
  if (!q) return `<td class="cell"></td>`;
  const t = ttHieuLuc(q), rv = RS.muc[q.khoa]?.ket_qua;
  if (t === 'bo' && !S.hienBo) return `<td class="cell has-bo" data-q="${q.khoa}" title="AI đề xuất bỏ — bật «Hiện quyền bị đề xuất bỏ» để xem"></td>`;
  const dim = (S.loc === 'de-xuat' && ['giu', 'ke_thua'].includes(q.trang_thai)) || (S.loc === 'tin-cay-thap' && q.tin_cay !== 'thap') || (S.loc === 'chua-rs' && rv);
  const icon = t === 'giu' ? '<span class="mk giu">✓</span>' : t === 'ke_thua' ? '<span class="mk ke_thua">↳</span>' : t === 'them' ? '<span class="mk them">+</span>' : '<span class="mk bo">✕</span>';
  const pv = q.pham_vi && ![...PV_TOAN, ...PV_DS].includes(q.pham_vi) ? `<span class="chip pv">${esc(tenPV(q.pham_vi))}</span>` : '';
  const dk = q.dieu_kien.length ? `<span class="chip dk" title="${esc(q.dieu_kien.map(d => X.DK[d]?.ten || d).join('; '))}">ĐK ${q.dieu_kien.length}</span>` : '';
  const low = q.tin_cay === 'thap' ? '<span class="lowdot" title="Tin cậy thấp"></span>' : '';
  return `<td class="cell s-${t} ${rv === 'dong_y' ? 'ok' : rv === 'khong_dong_y' ? 'no' : ''} ${dim ? 'dim' : ''}" tabindex="0" data-q="${q.khoa}">${icon}${low}${pv}${dk}</td>`;
}
function veMaTran() {
  const vs = D.vai_tro.filter(v => !S.anVT.has(v.key)), tim = lc(S.tim);
  const caps = X.cap.map(c => [c, vs.filter(v => (v.cap || '') === c)]).filter(x => x[1].length);
  let rows = '', n = 0;
  for (const m of X.mang) {
    if (S.mang && S.mang !== m) continue;
    const ts = D.tai_nguyen.filter(t => (t.mang || '') === m && t.hanh_dong.length);
    let blk = '';
    for (const t of ts) {
      const hs = t.hanh_dong.filter(h => !tim || lc(t.ten + ' ' + h.ten + ' ' + h.key + ' ' + t.key).includes(tim));
      if (!hs.length) continue;
      blk += `<tr class="g2"><th class="first"><span class="tn-name" data-tn="${t.key}">${esc(t.ten)}</span> ${key(t.key)}</th><td colspan="${vs.length}"></td></tr>`;
      for (const h of hs) { n++; blk += `<tr><th class="first act">${esc(h.ten)} ${key(h.key)} <span class="muted">${h.muc === 'danh_sach' ? 'DS' : ''}</span></th>${vs.map(v => oHtml(v, t.key, h)).join('')}</tr>`; }
    }
    if (blk) rows += `<tr class="g1"><th class="first">${esc(m || 'Khác')}</th><td colspan="${vs.length}"></td></tr>` + blk;
  }
  $('#nd').innerHTML = `
  <div class="toolbar">
    <input id="tim" type="search" placeholder="Tìm tài nguyên, hành động…" value="${esc(S.tim)}">
    <select id="mang"><option value="">Mọi mảng nghiệp vụ</option>${X.mang.map(m => `<option ${S.mang === m ? 'selected' : ''}>${esc(m)}</option>`).join('')}</select>
    <select id="loc">${[['tat-ca', 'Mọi ô'], ['de-xuat', 'Làm nổi đề xuất của AI'], ['tin-cay-thap', 'Làm nổi tin cậy thấp'], ['chua-rs', 'Làm nổi ô chưa rà soát']].map(([v, l]) => `<option value="${v}" ${S.loc === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
    <label class="switch"><input id="hien-bo" type="checkbox" ${S.hienBo ? 'checked' : ''}> Hiện quyền bị đề xuất bỏ</label>
    <details class="pick"><summary>Vai trò (${vs.length}/${D.vai_tro.length})</summary><div class="pick-list">${D.vai_tro.map(v => `<label><input type="checkbox" data-vt="${v.key}" ${S.anVT.has(v.key) ? '' : 'checked'}> ${esc(v.ten)}</label>`).join('')}</div></details>
    <span class="muted">${n} hành động</span>
  </div>
  <div class="legend"><span><span class="mk giu">✓</span> theo tài liệu</span><span><span class="mk ke_thua">↳</span> theo quy định chung</span><span><span class="mk them">+</span> AI thêm</span><span><span class="mk bo">✕</span> AI đề xuất bỏ</span>
    <span><span class="chip pv">Phạm vi</span> áp dụng trên bản ghi nào</span><span><span class="chip dk">ĐK</span> có điều kiện</span><span><span class="lowdot"></span> tin cậy thấp</span>
    <span><i class="sw okb"></i> đã đồng ý</span><span><i class="sw nob"></i> không đồng ý</span><span class="muted">DS = hành động mức danh sách. Ô không ghi phạm vi = toàn bộ hoặc mức danh sách.</span></div>
  <div class="grid-wrap"><table class="grid"><thead>
    <tr><th class="first corner" rowspan="2">Tài nguyên · hành động</th>${caps.map(([c, x]) => `<th class="cap" colspan="${x.length}">${esc(c)}</th>`).join('')}</tr>
    <tr>${caps.flatMap(([, x]) => x).map(v => `<th class="role ${v.nhom || ''}" data-vt="${v.key}" title="${esc(v.mo_ta || '')}"><span class="rname">${esc(v.ten)}</span>${key(v.key)}</th>`).join('')}</tr>
  </thead><tbody>${rows || `<tr><td class="empty" colspan="${vs.length + 1}">Không có dòng nào.</td></tr>`}</tbody></table></div>`;
  $('#tim').oninput = e => { S.tim = e.target.value; veMaTran(); const i = $('#tim'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); };
  $('#mang').onchange = e => { S.mang = e.target.value; veMaTran(); };
  $('#loc').onchange = e => { S.loc = e.target.value; veMaTran(); };
  $('#hien-bo').onchange = e => { S.hienBo = e.target.checked; veMaTran(); };
  $$('.pick-list input').forEach(c => c.onchange = () => { c.checked ? S.anVT.delete(c.dataset.vt) : S.anVT.add(c.dataset.vt); veMaTran(); $('.pick').open = true; });
  $$('th.role').forEach(th => th.onclick = () => { S.vt = th.dataset.vt; S.tab = 'vai-tro'; ve(); });
  $$('.tn-name').forEach(s => s.onclick = () => { S.tab = 'tai-nguyen'; ve(); document.getElementById('tn-' + s.dataset.tn)?.scrollIntoView({ block: 'start' }); });
  $$('td.cell[data-q]').forEach(td => { td.onclick = () => moNgan(td.dataset.q); td.onkeydown = e => { if (e.key === 'Enter') td.click(); }; });
}

/* ---------------- Ngăn chi tiết quyền ---------------- */
function moNgan(khoa, giu) {
  S.mo = khoa;
  const q = D.quyen.find(x => x.khoa === khoa); if (!q) return;
  const v = X.V[q.vai_tro], t = X.R[q.tai_nguyen], h = X.HD[`${q.tai_nguyen}|${q.hanh_dong}`], st = ttHieuLuc(q), rv = RS.muc[khoa] || {};
  const p = X.PV[q.pham_vi];
  const cau = st === 'bo' ? `<b>${esc(v.ten)}</b> <b>không</b> được <b>${esc(h.ten.toLowerCase())}</b> «${esc(t.ten)}» (AI đề xuất bỏ quyền tài liệu nêu).`
    : `<b>${esc(v.ten)}</b> được <b>${esc(h.ten.toLowerCase())}</b> «${esc(t.ten)}»` + (q.pham_vi && !PV_TOAN.includes(q.pham_vi) ? `, phạm vi <b>${esc(tenPV(q.pham_vi))}</b>` : ', trên toàn bộ dữ liệu') +
      (q.dieu_kien.length ? `, khi <b>${q.dieu_kien.map(d => esc((X.DK[d]?.ten || d).toLowerCase())).join('</b> và <b>')}</b>` : '') + '.';
  const gds = q.giao_dich.map(id => X.GD[id]).filter(Boolean);
  const ghiDo = giu ? $('#rv-note')?.value : null;
  const el = $('#ngan');
  el.innerHTML = `
    <div class="dh"><div><div class="eyebrow">${esc(t.ten)} · ${esc(h.ten)}</div><h2>${esc(v.ten)}</h2>${key(khoa)}</div><button class="btn ghost" id="dong">Đóng ✕</button></div>
    <div class="row-chips">${ttChip(st)}${tcChip(q.tin_cay)}${st !== q.trang_thai ? '<span class="st ok">đã đổi theo rà soát</span>' : ''}</div>
    <p class="sentence">${cau}</p>
    <h3>Vì sao</h3>
    <ol class="why">${q.quy_tac.map(r => `<li><span class="rt">${esc(LOAI_QT[r.loai] || r.loai)}</span> <span class="code">${esc(r.id)}</span> ${ntChips(r.nguyen_tac)} ${r.tin_cay && r.tin_cay !== 'cao' ? tcChip(r.tin_cay) : ''}<div>${esc(r.ly_do || '')}</div></li>`).join('')}</ol>
    ${p ? `<h3>Phạm vi</h3><div class="def"><span class="chip pv">${esc(p.ten)}</span> <span class="muted">${esc(KIEU_PV[p.kieu] || p.kieu || '')}</span><div>${esc(p.mo_ta || '')}</div></div>` : ''}
    ${q.dieu_kien.length ? `<h3>Điều kiện (ABAC)</h3>${q.dieu_kien.map(d => { const k = X.DK[d] || {}; return `<div class="def"><span class="chip dk">${esc(k.ten || d)}</span><div>${esc(k.mo_ta || '')}</div><div class="code">${esc((k.bieu_thuc || []).map(b => `${b.trai} ${b.phep} ${Array.isArray(b.phai) ? b.phai.join(' | ') : b.phai}`).join(' VÀ '))}</div></div>`; }).join('')}` : ''}
    <h3>Căn cứ trong tài liệu (${gds.length} giao dịch)</h3>
    ${gds.length ? `<ul class="src">${gds.slice(0, 8).map(g => `<li><span class="code">${esc(g.vt)}</span> <b>${esc(g.ten)}</b> <span class="muted">— ${esc(g.usecase)}</span><blockquote>${esc(g.mo_ta)}</blockquote></li>`).join('')}</ul>${gds.length > 8 ? `<p class="muted">… và ${gds.length - 8} giao dịch khác.</p>` : ''}` : '<p class="muted">Tài liệu không nêu; đây là đề xuất của AI.</p>'}
    <h3>Ý kiến rà soát</h3>
    <div class="rv-btns"><button class="btn ${rv.ket_qua === 'dong_y' ? 'on ok' : ''}" data-kq="dong_y">✓ Đồng ý</button><button class="btn ${rv.ket_qua === 'khong_dong_y' ? 'on no' : ''}" data-kq="khong_dong_y">✕ Không đồng ý</button>${rv.ket_qua || rv.ghi_chu ? '<button class="btn ghost" data-kq="">Bỏ ý kiến</button>' : ''}</div>
    <p class="muted small">${['giu', 'ke_thua'].includes(q.trang_thai) ? 'Không đồng ý với quyền theo tài liệu hoặc theo quy định chung sẽ được ghi vào biên bản để AI sửa đặc tả.' : 'Không đồng ý với đề xuất của AI sẽ đảo kết quả: quyền AI thêm bị bỏ, quyền AI bỏ được giữ lại.'}</p>
    <textarea id="rv-note" rows="3" placeholder="Ghi chú cho BA / SA…">${esc(ghiDo ?? rv.ghi_chu ?? '')}</textarea>
    <div class="rv-foot"><button class="btn" id="rv-luu">Lưu ghi chú</button><span class="muted">${rv.luc ? `${esc(rv.nguoi || 'không ghi tên')} · ${esc(rv.luc.replace('T', ' ').slice(0, 16))}` : ''}</span></div>`;
  el.classList.add('open'); $('#man').classList.add('open');
  const nhan = `${v.ten} – ${h.ten} – ${t.ten} (${TT[q.trang_thai][0]})`;
  $('#dong').onclick = dongNgan;
  $$('.rv-btns .btn', el).forEach(b => b.onclick = () => luu(khoa, 'quyen', nhan, b.dataset.kq, b.dataset.kq === '' ? '' : $('#rv-note').value));
  $('#rv-luu').onclick = () => luu(khoa, 'quyen', nhan, rv.ket_qua || '', $('#rv-note').value);
  $$('td.cell.sel').forEach(x => x.classList.remove('sel')); $(`td.cell[data-q="${CSS.escape(khoa)}"]`)?.classList.add('sel');
}
function dongNgan() { S.mo = null; $('#ngan').classList.remove('open'); $('#man').classList.remove('open'); $$('td.cell.sel').forEach(x => x.classList.remove('sel')); }

/* ---------------- Vai trò ---------------- */
function veVaiTro() {
  if (!S.vt || !X.V[S.vt]) S.vt = D.vai_tro[0]?.key;
  const v = X.V[S.vt], qs = D.quyen.filter(q => q.vai_tro === v.key), rv = RS.muc['vt:' + v.key] || {};
  const list = X.cap.map(c => `<div class="lg">${esc(c)}</div>` + D.vai_tro.filter(x => (x.cap || '') === c).map(x => `<button class="role-item ${x.key === S.vt ? 'on' : ''}" data-vt="${x.key}"><span>${esc(x.ten)}</span><span class="muted">${D.quyen.filter(q => q.vai_tro === x.key && ttHieuLuc(q) !== 'bo').length} quyền${RS.muc['vt:' + x.key]?.ket_qua === 'dong_y' ? ' · ✓' : RS.muc['vt:' + x.key]?.ket_qua === 'khong_dong_y' ? ' · ✕' : ''}</span></button>`).join('')).join('');
  const hl = qs.filter(q => ttHieuLuc(q) !== 'bo'), bo = qs.filter(q => ttHieuLuc(q) === 'bo');
  const nhomTN = a => { const g = {}; a.forEach(q => (g[q.tai_nguyen] ||= []).push(q)); return Object.entries(g); };
  const li = q => { const h = X.HD[`${q.tai_nguyen}|${q.hanh_dong}`]; return `<li data-q="${q.khoa}" tabindex="0">${ttChip(ttHieuLuc(q))} <b>${esc(h.ten)}</b> ${key(q.hanh_dong)}
      <span class="perm-sub">${q.pham_vi && !PV_TOAN.includes(q.pham_vi) ? 'Phạm vi: <span class="chip pv">' + esc(tenPV(q.pham_vi)) + '</span>' : 'Toàn bộ'}${q.dieu_kien.length ? ' · Điều kiện: ' + q.dieu_kien.map(d => `<span class="chip dk">${esc(X.DK[d]?.ten || d)}</span>`).join(' ') : ''} ${q.tin_cay === 'thap' ? tcChip('thap') : ''}</span></li>`; };
  const cs = v.co_so || {};
  $('#nd').innerHTML = `<div class="split"><div class="role-list">${list}</div><div class="role-body">
    <div class="card"><div class="role-head"><div><div class="eyebrow">${esc(v.cap || '')}</div><h2>${esc(v.ten)} ${key(v.key)}</h2><p>${esc(v.mo_ta || '')}</p>
      <div class="row-chips"><span class="tag">${esc(NHOM_VT[v.nhom] || 'Chuyên viên')}</span><span class="tag">${v.loai_pham_vi === 'toan_he_thong' ? 'Toàn hệ thống (RBAC)' : v.loai_pham_vi === 'theo_ban_ghi' ? 'Theo người lập bản ghi (ABAC)' : 'Gán trên «' + esc(X.R[v.gan_tren]?.ten || v.gan_tren) + '» (ReBAC)'}</span>${cs.loai === 'de_xuat' ? '<span class="st them">AI đề xuất vai trò</span>' : cs.loai === 'ke_thua' ? '<span class="st ke_thua">Vai trò theo quy định chung</span>' : '<span class="st giu">Có trong tài liệu</span>'}${tcChip(cs.tin_cay)}</div></div>
      <div class="rv-inline"><button class="btn ${rv.ket_qua === 'dong_y' ? 'on ok' : ''}" data-kq="dong_y">✓ Đồng ý vai trò</button><button class="btn ${rv.ket_qua === 'khong_dong_y' ? 'on no' : ''}" data-kq="khong_dong_y">✕ Không đồng ý</button>
        <input id="vt-note" type="text" placeholder="Ghi chú cho vai trò…" value="${esc(rv.ghi_chu || '')}"></div></div>
      <h3>Căn cứ</h3>${(cs.nguon || []).map(n => `<div class="def"><span class="code">${esc(n.vt)}</span><blockquote>${esc(n.trich)}</blockquote></div>`).join('')}${cs.ly_do ? `<p>${esc(cs.ly_do)} ${ntChips(cs.nguyen_tac)}</p>` : ''}
      <h3>Tác nhân trong tài liệu được ánh xạ vào vai trò này</h3>${(v.tac_nhan_tai_lieu || []).map(a => `<div class="def"><b>«${esc(a.tac_nhan)}»</b> <span class="code">${esc(a.quy_tac)}</span> ${tcChip(a.tin_cay)}<div class="muted">${esc(a.ly_do || '')}</div></div>`).join('') || '<p class="muted">Không có — vai trò do AI bổ sung.</p>'}
    </div>
    <div class="card"><h3>Quyền hiệu lực (${hl.length})</h3>${nhomTN(hl).map(([rk, a]) => `<div class="grp"><div class="grp-h">${esc(X.R[rk].ten)}</div><ul class="perm">${a.map(li).join('')}</ul></div>`).join('') || '<p class="muted">Không có.</p>'}</div>
    ${bo.length ? `<details class="card"><summary>AI đề xuất bỏ ${bo.length} quyền tài liệu nêu</summary>${nhomTN(bo).map(([rk, a]) => `<div class="grp"><div class="grp-h">${esc(X.R[rk].ten)}</div><ul class="perm">${a.map(li).join('')}</ul></div>`).join('')}</details>` : ''}
  </div></div>`;
  $$('.role-item').forEach(b => b.onclick = () => { S.vt = b.dataset.vt; veVaiTro(); });
  $$('.perm li').forEach(l => { l.onclick = () => moNgan(l.dataset.q); l.onkeydown = e => { if (e.key === 'Enter') l.click(); }; });
  $$('.rv-inline .btn').forEach(b => b.onclick = () => luu('vt:' + v.key, 'vai_tro', 'Vai trò ' + v.ten, rv.ket_qua === b.dataset.kq ? '' : b.dataset.kq, $('#vt-note').value));
  $('#vt-note').onchange = e => luu('vt:' + v.key, 'vai_tro', 'Vai trò ' + v.ten, rv.ket_qua || '', e.target.value);
}

/* ---------------- Tài nguyên ---------------- */
function veTaiNguyen() {
  $('#nd').innerHTML = `<div class="tn-grid">${D.tai_nguyen.map(t => {
    const cs = t.co_so || {};
    const rows = t.hanh_dong.map(h => { const qs = D.quyen.filter(q => q.tai_nguyen === t.key && q.hanh_dong === h.key);
      const co = qs.filter(q => ttHieuLuc(q) !== 'bo'), bo = qs.filter(q => ttHieuLuc(q) === 'bo');
      return `<tr><td><b>${esc(h.ten)}</b> ${key(h.key)}</td><td class="muted">${['list', 'danh_sach'].includes(h.muc) ? 'Danh sách' : 'Bản ghi'} · ${esc(NHOM_HD[h.nhom] || h.nhom)}</td>
        <td>${co.map(q => `<span class="chip vt ${q.trang_thai === 'them' ? 'them' : q.trang_thai === 'ke_thua' ? 'ke_thua' : ''}" data-q="${q.khoa}" title="${esc(tenPV(q.pham_vi))}">${esc(X.V[q.vai_tro].ten)}</span>`).join(' ') || '<span class="muted">chưa ai</span>'}
        ${bo.length ? `<span class="muted"> · bỏ: </span>${bo.map(q => `<span class="chip vt bo" data-q="${q.khoa}">${esc(X.V[q.vai_tro].ten)}</span>`).join(' ')}` : ''}</td></tr>`; }).join('');
    return `<div class="card" id="tn-${t.key}"><div class="eyebrow">${esc(t.mang || '')} · ${{ cay: 'Cây tổ chức', du_lieu: 'Dữ liệu nghiệp vụ', tep: 'Kho tư liệu' }[t.loai] || t.loai}</div>
      <h3>${esc(t.ten)} ${key(t.key)}</h3><p>${esc(t.mo_ta || '')}</p>
      ${(t.quan_he || []).length ? `<div class="kv"><b>Quan hệ:</b> ${(t.quan_he).map(r => `<span class="chip rel" title="${esc(r.y_nghia || '')}">${esc(r.key)} → ${esc(X.R[r.toi]?.ten || r.toi)}</span>`).join(' ')}</div>` : ''}
      ${(t.thuoc_tinh || []).length ? `<div class="kv"><b>Thuộc tính:</b> ${t.thuoc_tinh.map(a => `<span class="chip at" title="${esc(a.y_nghia || '')}">${esc(a.key)}</span>`).join(' ')}</div>` : ''}
      ${(cs.nguon || []).length ? `<div class="kv muted"><b>Căn cứ:</b> ${cs.nguon.map(n => `${esc(n.vt)} «${esc(n.trich)}»`).join('; ')}</div>` : ''}
      ${t.hanh_dong.length ? `<table class="plain"><thead><tr><th>Hành động</th><th>Mức · nhóm</th><th>Vai trò có quyền</th></tr></thead><tbody>${rows}</tbody></table>` : '<p class="muted">Không có hành động người dùng; dùng làm nơi gán vai trò.</p>'}</div>`;
  }).join('')}</div>`;
  $$('.chip[data-q]').forEach(c => c.onclick = () => moNgan(c.dataset.q));
}

/* ---------------- Phạm vi & điều kiện ---------------- */
function vePhamVi() {
  const dem = k => D.quyen.filter(q => q.pham_vi === k && ttHieuLuc(q) !== 'bo').length;
  const demDK = k => D.quyen.filter(q => q.dieu_kien.includes(k) && ttHieuLuc(q) !== 'bo').length;
  $('#nd').innerHTML = `<div class="card"><h3>Phạm vi dữ liệu</h3><p class="muted">Quyền áp dụng trên bản ghi nào. Cột «Kiểu» ghi cơ chế: ReBAC theo quan hệ cây đơn vị, ABAC theo thuộc tính người (người lập, người được giao), RBAC toàn hệ thống.</p>
    <table class="plain"><thead><tr><th>Phạm vi</th><th>Kiểu</th><th>Ý nghĩa</th><th>Quan hệ dùng</th><th class="num">Số quyền</th></tr></thead><tbody>
    ${D.pham_vi.map(p => `<tr><td><span class="chip pv">${esc(p.ten)}</span> ${key(p.key)}</td><td>${esc(KIEU_PV[p.kieu] || p.kieu || '')}</td><td>${esc(p.mo_ta || '')}</td>
      <td>${p.quan_he ? Object.entries(p.quan_he).map(([k, r]) => `<span class="chip rel">${esc(k === '*' ? 'mọi tài nguyên' : X.R[k]?.ten || k)}: ${esc(r)}</span>`).join(' ') : '<span class="muted">—</span>'}</td><td class="num">${dem(p.key)}</td></tr>`).join('')}
    </tbody></table></div>
    <div class="card"><h3>Điều kiện (ABAC)</h3><p class="muted">Quyền chỉ có hiệu lực khi bản ghi hoặc người dùng thoả điều kiện.</p>
    <table class="plain"><thead><tr><th>Điều kiện</th><th>Ý nghĩa</th><th>Biểu thức</th><th class="num">Số quyền</th></tr></thead><tbody>
    ${D.dieu_kien.map(d => `<tr><td><span class="chip dk">${esc(d.ten)}</span> ${key(d.key)}</td><td>${esc(d.mo_ta || '')}</td><td class="code">${esc((d.bieu_thuc || []).map(b => `${b.trai} ${b.phep} ${Array.isArray(b.phai) ? b.phai.join(' | ') : b.phai}`).join(' VÀ '))}</td><td class="num">${demDK(d.key)}</td></tr>`).join('')}
    </tbody></table></div>`;
}

/* ---------------- Kiểm tra ---------------- */
function veKiemTra() {
  const M = { loi: ['Lỗi', 'bad'], canh_bao: ['Cảnh báo', 'warn'], goi_y: ['Gợi ý', ''] };
  const ds = ['loi', 'canh_bao', 'goi_y'].map(m => [m, D.kiem_tra.filter(k => k.muc === m)]).filter(x => x[1].length);
  $('#nd').innerHTML = `<p class="hint">Công cụ tự đối chiếu thiết kế với các nguyên tắc. Lỗi phải sửa trước khi xuất JSON; cảnh báo và gợi ý cần BA/SA xem.</p>
    ${ds.map(([m, a]) => `<h2 class="gt">${M[m][0]} (${a.length})</h2>${a.map((k, i) => `<div class="card kt ${M[m][1]}"><div><span class="code">${esc(k.ma)}</span> ${ntChips(k.nguyen_tac)}</div><p>${esc(k.noi_dung)}</p>
      ${k.lien_quan.quyen.length ? `<div class="rel">${k.lien_quan.quyen.slice(0, 12).map(id => { const q = D.quyen.find(x => x.id === id); return q ? `<a href="#" data-q="${q.khoa}">${esc(X.V[q.vai_tro].ten)} – ${esc(X.HD[q.tai_nguyen + '|' + q.hanh_dong].ten)} – ${esc(X.R[q.tai_nguyen].ten)}</a>` : ''; }).join(' · ')}</div>` : ''}
      ${k.lien_quan.vai_tro.length ? `<div class="rel">${k.lien_quan.vai_tro.map(v => `<a href="#" data-vt="${v}">vai trò ${esc(X.V[v]?.ten || v)}</a>`).join(' · ')}</div>` : ''}</div>`).join('')}`).join('') || '<p class="empty">Không có vấn đề nào.</p>'}`;
  $$('a[data-q]').forEach(a => a.onclick = e => { e.preventDefault(); moNgan(a.dataset.q); });
  $$('a[data-vt]').forEach(a => a.onclick = e => { e.preventDefault(); S.vt = a.dataset.vt; S.tab = 'vai-tro'; ve(); });
}

/* ---------------- Truy vết giao dịch ---------------- */
function veGiaoDich() {
  const tim = lc(S.gdTim);
  const ds = D.giao_dich.filter(g => (S.gdLoc === 'tat-ca' || g.trang_thai === S.gdLoc) && (!tim || lc(g.ten + ' ' + g.usecase + ' ' + g.tac_nhan.join(' ')).includes(tim)));
  const TTG = { anh_xa: ['Đã ánh xạ', 'giu'], bo_qua: ['Bỏ qua', 'bo'], chua_anh_xa: ['Chưa ánh xạ', 'warnc'] };
  $('#nd').innerHTML = `<div class="toolbar"><input id="gtim" type="search" placeholder="Tìm giao dịch, usecase, tác nhân…" value="${esc(S.gdTim)}">
    ${[['tat-ca', 'Tất cả'], ['anh_xa', 'Đã ánh xạ'], ['bo_qua', 'Bỏ qua'], ['chua_anh_xa', 'Chưa ánh xạ']].map(([v, l]) => `<button class="btn seg ${S.gdLoc === v ? 'on' : ''}" data-l="${v}">${l} (${v === 'tat-ca' ? D.giao_dich.length : D.giao_dich.filter(g => g.trang_thai === v).length})</button>`).join('')}</div>
    <p class="hint">Mỗi giao dịch lấy từ tài liệu (bảng chức năng, ma trận của BA, bước quy trình) được quy về một cặp tài nguyên – hành động, hoặc bỏ qua kèm lý do.</p>
    <div class="card"><table class="plain"><thead><tr><th>Vị trí</th><th>Usecase · giao dịch</th><th>Tác nhân</th><th>Kết quả</th></tr></thead><tbody>
    ${ds.slice(0, 600).map(g => `<tr><td class="code">${esc(g.vt)}</td><td><div class="muted">${esc(g.usecase)}</div><b>${esc(g.ten)}</b></td><td class="small">${g.tac_nhan.map(esc).join('<br>')}</td>
      <td><span class="st ${TTG[g.trang_thai][1]}">${TTG[g.trang_thai][0]}</span> ${g.tai_nguyen ? `<span class="chip rel">${esc(X.R[g.tai_nguyen]?.ten || g.tai_nguyen)}${g.hanh_dong ? ' : ' + esc(X.HD[g.tai_nguyen + '|' + g.hanh_dong]?.ten || g.hanh_dong) : ''}</span>` : ''}<div class="muted small">${esc(g.ly_do || '')}</div></td></tr>`).join('')}
    </tbody></table></div>`;
  $('#gtim').oninput = e => { S.gdTim = e.target.value; veGiaoDich(); const i = $('#gtim'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); };
  $$('.seg').forEach(b => b.onclick = () => { S.gdLoc = b.dataset.l; veGiaoDich(); });
}

/* ---------------- Câu hỏi ---------------- */
function veCauHoi() {
  $('#nd').innerHTML = `<p class="hint">Các điểm AI đã chọn phương án để thiết kế chạy được, nhưng cần BA xác nhận. Trả lời ở đây; AI dùng câu trả lời để lập lại thiết kế.</p>
    ${D.cau_hoi.map(c => { const rv = RS.muc['ch:' + c.id] || {}; return `<div class="card q ${rv.ghi_chu ? 'done' : ''}"><div class="qh"><span class="qn">${esc(c.id)}</span><span class="tag">${esc(c.nhom || '')}</span>${rv.ghi_chu ? '<span class="st giu">đã trả lời</span>' : ''}</div>
      <p>${esc(c.noi_dung)}</p>${c.tra_loi ? `<div class="def"><span class="st giu">Đã trả lời trước khi thiết kế</span> ${esc(c.tra_loi)}</div>` : ''}<div class="def"><b>${c.tra_loi ? 'Thiết kế đang theo:' : 'AI đang áp dụng:'}</b> ${esc(c.phuong_an_ap_dung || '')}</div>
      ${(c.lien_quan?.vai_tro || []).length ? `<div class="rel">${c.lien_quan.vai_tro.map(v => `<a href="#" data-vt="${v}">${esc(X.V[v]?.ten || v)}</a>`).join(' · ')}</div>` : ''}
      <textarea rows="2" data-ch="${c.id}" placeholder="Câu trả lời của BA…">${esc(rv.ghi_chu || '')}</textarea>
      <div class="rv-foot"><button class="btn" data-luu="${c.id}">Lưu câu trả lời</button><span class="muted">${rv.luc ? `${esc(rv.nguoi || '')} · ${esc(rv.luc.replace('T', ' ').slice(0, 16))}` : ''}</span></div></div>`; }).join('')}`;
  $$('[data-luu]').forEach(b => b.onclick = () => { const c = D.cau_hoi.find(x => x.id === b.dataset.luu), v = $(`textarea[data-ch="${c.id}"]`).value.trim(); luu('ch:' + c.id, 'cau_hoi', `${c.id}: ${c.noi_dung.slice(0, 140)}`, v ? 'da_tra_loi' : '', v); });
  $$('a[data-vt]').forEach(a => a.onclick = e => { e.preventDefault(); S.vt = a.dataset.vt; S.tab = 'vai-tro'; ve(); });
}

/* ---------------- Biên bản ---------------- */
function veBienBan() {
  const K = { dong_y: ['Đồng ý', 'giu'], khong_dong_y: ['Không đồng ý', 'bo'], da_tra_loi: ['Đã trả lời', 'giu'], '': ['Ghi chú', ''] };
  const ds = Object.entries(RS.muc).sort((a, b) => (b[1].luc || '').localeCompare(a[1].luc || ''));
  $('#nd').innerHTML = `<div class="toolbar"><a class="btn" href="/api/bien-ban" download>Tải biên bản (.md)</a><span class="muted">Ý kiến lưu trong ra_soat.json cạnh tệp thiết kế.</span></div>
    ${ds.length ? `<div class="card"><table class="plain"><thead><tr><th>Nội dung</th><th>Kết quả</th><th>Ý kiến</th><th>Người</th><th>Lúc</th></tr></thead><tbody>
    ${ds.map(([, m]) => `<tr><td>${esc(m.nhan)}</td><td><span class="st ${K[m.ket_qua || ''][1]}">${K[m.ket_qua || ''][0]}</span></td><td>${esc(m.ghi_chu)}</td><td>${esc(m.nguoi)}</td><td class="nowrap">${esc((m.luc || '').replace('T', ' ').slice(0, 16))}</td></tr>`).join('')}</tbody></table></div>` : '<p class="empty">Chưa có ý kiến. Bắt đầu ở thẻ «Theo vai trò».</p>'}`;
}

$$('#tabs button').forEach(b => b.onclick = () => { S.tab = b.dataset.tab; dongNgan(); ve(); });
$('#tai-lai').onclick = tai; $('#man').onclick = dongNgan;
$('#hien-key').onchange = e => { S.hienKey = e.target.checked; ve(true); };
document.addEventListener('keydown', e => { if (e.key === 'Escape') dongNgan(); });
try { $('#nguoi').value = localStorage.getItem('tkpq_nguoi') || ''; } catch (e) { /* bỏ qua */ }
$('#nguoi').onchange = e => { try { localStorage.setItem('tkpq_nguoi', e.target.value); } catch (x) { /* bỏ qua */ } };
tai();
