---
name: truc-quan-phan-quyen
description: Mở khung trực quan hoá thiết kế phân quyền (web chạy trên máy) để BA, SA, dev cùng rà soát bằng ngôn ngữ nghiệp vụ, không phải JSON — BA xác nhận Đúng / Sai từng câu mô tả theo vai trò (không cần biết RBAC/ReBAC/ABAC), phân biệt theo tài liệu / theo quy định chung / AI đề xuất thêm / AI đề xuất bỏ; SA, dev xem ma trận vai trò × hành động, lý do và nguyên tắc của từng đề xuất, sơ đồ vai trò theo cấp và tài nguyên – quan hệ, phạm vi và điều kiện, kiểm tra nguyên tắc, truy vết từng giao dịch của tài liệu, câu hỏi cho BA, ghi ý kiến đồng ý / không đồng ý và xuất biên bản. Dùng skill này BẤT CỨ KHI NÀO người dùng muốn xem, trình bày, rà soát, review thiết kế phân quyền, ma trận phân quyền, chính sách phân quyền, hoặc mở giao diện cho BA/SA/dev, và ngay sau khi skill `thiet-ke-phan-quyen` lập xong thiết kế, kể cả khi họ không nhắc tên skill.
---

# Khung trực quan hoá thiết kế phân quyền

Web app nhỏ chạy trên máy, đọc `thiet_ke_phan_quyen.json` (do skill `thiet-ke-phan-quyen` lập). App không sửa thiết kế; ý kiến rà soát ghi vào `ra_soat.json` cùng thư mục. Không cần cài thêm thư viện, không gọi ra Internet.

## Chạy

```bash
python -I <skill>/app/server.py <thư mục làm việc> --cong 4190
```

- Chạy nền rồi đưa địa chỉ `http://localhost:4190/` cho người dùng; nếu môi trường có khung xem trước trình duyệt thì mở luôn. Cổng bận thì đổi `--cong`.
- `--mo`: tự mở trình duyệt. `--may-khac`: cho máy khác trong mạng nội bộ vào (chỉ khi người dùng yêu cầu; nói rõ ai biết địa chỉ đều xem và ghi ý kiến được).
- Kiểm tra `/api/thiet-ke` trả dữ liệu trước khi báo người dùng.

## Các thẻ

Thẻ dành cho BA đứng trước; nhóm «Kỹ thuật · SA, dev» đứng sau.

| Thẻ | Dùng để |
|---|---|
| **Theo vai trò** (mở mặc định, cho BA) | Mỗi vai trò là một danh sách câu: «Được làm», «Ràng buộc», «AI đề xuất không cho làm». Mỗi câu có nhãn nguồn gốc, nút Đúng / Sai, «Vì sao?» (quy định KT-xx, lý do của AI, câu trích tài liệu), ô ghi chú. Thanh tiến độ «đã xác nhận x/y câu», lọc «chỉ câu chưa xác nhận» |
| **Tổng quan** | Số liệu chính; vai trò theo cấp (vai trò do AI tách được đánh dấu); sơ đồ tài nguyên – quan hệ tới cây tổ chức; nguyên tắc nào dẫn tới đề xuất; tỉ lệ RBAC / ReBAC / ABAC |
| **Ma trận quyền** | Dòng = tài nguyên / hành động theo mảng; cột = vai trò theo cấp. ✓ theo tài liệu, + AI thêm, ✕ AI bỏ (ẩn mặc định); nhãn phạm vi, số điều kiện, chấm cam = tin cậy thấp. Bấm ô để xem «Vì sao» (từng quy tắc, mã nguyên tắc, mức tin cậy), phạm vi, điều kiện, giao dịch căn cứ và ghi ý kiến |
| **Vai trò** | Mô tả, căn cứ, tác nhân của tài liệu được ánh xạ vào vai trò, quyền hiệu lực và quyền bị đề xuất bỏ |
| **Tài nguyên** | Quan hệ, thuộc tính, từng hành động và vai trò có quyền |
| **Phạm vi & điều kiện** | Định nghĩa, quan hệ dùng, số quyền áp dụng |
| **Kiểm tra nguyên tắc** | Lỗi, cảnh báo, gợi ý; bấm để tới ô liên quan |
| **Truy vết giao dịch** | Mỗi giao dịch của tài liệu → tài nguyên : hành động, hoặc lý do bỏ qua |
| **Câu hỏi cho BA** | Phương án AI đang áp dụng; ô trả lời |
| **Biên bản** | Mọi ý kiến; tải `.md` |

## Ý nghĩa của ý kiến rà soát

Ý kiến trên một câu áp cho mọi quyền trong câu; ý kiến trên một ô ma trận thắng ý kiến của câu chứa ô đó.

- **Đúng** / **Đồng ý** một đề xuất AI: giữ đề xuất.
- **Sai** / **Không đồng ý** với «AI thêm» → quyền bị bỏ; với «AI bỏ» → quyền tài liệu nêu được giữ. Bước xuất JSON tự áp, không cần sửa đặc tả.
- **Sai** với câu theo tài liệu hoặc theo quy định chung, ghi chú, câu trả lời câu hỏi: là thông tin để AI sửa đặc tả (với quy định chung: ghi ngoại lệ `ke_thua.khong_ap_dung`) và lập lại thiết kế (skill `thiet-ke-phan-quyen`, bước 7). Sau khi lập lại, bấm **Tải lại** trên app.

## Gợi ý buổi rà soát

1. Mỗi người ghi tên ở ô «Người rà soát».
2. BA đi thẻ **Câu hỏi cho BA** trước: các câu trả lời thường thay đổi nhiều câu cùng lúc.
3. BA đi thẻ **Theo vai trò**, từng vai trò, bấm Đúng / Sai từng câu; bật «Chỉ hiện câu chưa xác nhận» để làm tiếp.
4. SA xem ma trận, **Kiểm tra nguyên tắc** và sơ đồ tài nguyên ở **Tổng quan**; dev bật «Hiện key».
5. Tải biên bản.

Khi người dùng hỏi kết quả rà soát: đọc `ra_soat.json` và tóm tắt (bao nhiêu câu đã xác nhận / sai theo từng nguồn gốc, bao nhiêu đề xuất đã đồng ý / không đồng ý, câu hỏi nào đã trả lời, ghi chú quan trọng), không thêm nhận định của mình nếu không được hỏi.
