# Mẫu thiết kế thường gặp

Các mẫu lặp lại ở nhiều phân hệ quản lý. Khi tài liệu có tín hiệu khớp một mẫu, áp mẫu và ghi mã (`M-xx`) vào lý do đề xuất. Mẫu là điểm xuất phát; điều chỉnh theo nghiệp vụ cụ thể.

## M-01 Cây tổ chức, có thể nhiều cây lồng nhau
Cây đơn vị hành chính (cơ quan → đơn vị → phòng ban) lấy từ Cổng (`don_vi`), dùng chung mọi phân hệ; các cây riêng của phân hệ gắn vào nó: tổ chức đoàn thể, ban chuyên trách, cơ sở trực thuộc.
- Mỗi cây là một tài nguyên có quan hệ `cap_tren` trỏ về chính nó; cây con có quan hệ tới đơn vị quản lý (`don_vi_quan_ly` → cây đơn vị).
- Vai trò hành chính gán trên cây đơn vị; vai trò của tổ chức gắn kèm gán trên cây của tổ chức đó.
- Phạm vi của vai trò đơn vị lan sang các tổ chức mà đơn vị quản lý qua quan hệ hai bước.

## M-02 Dữ liệu thuộc đơn vị
Bản ghi nghiệp vụ có quan hệ `thuoc_don_vi` (hoặc tên tương đương). Đơn vị tự lập, sửa (`don_vi_minh`); cấp trên xem (`don_vi_minh_va_cap_duoi`) — NT-13.

## M-03 Nộp duyệt nhiều cấp
Cấp cơ sở lập → gửi duyệt → cấp trên duyệt / trả lại → … → cấp cao nhất xác nhận.
- Hành động `gui_duyet`, `phe_duyet`, `tu_choi`; quan hệ `cap_duyet` → đơn vị đang duyệt.
- Điều kiện: sửa / xoá / gửi duyệt khi đang soạn hoặc bị trả lại; duyệt / từ chối khi chờ duyệt; người duyệt khác người lập.
- Vai trò duyệt của từng cấp (lãnh đạo và cán bộ được giao kiểm tra) có `phe_duyet` / `tu_choi` với phạm vi `cap_duyet` (NT-14).
- Cấp trên xem và duyệt dữ liệu cấp dưới gửi lên; không xoá, nhập, xuất hàng loạt dữ liệu cấp dưới (NT-13, NT-08).

## M-04 Chuyển giữa hai đơn vị
Phiếu điều chuyển, bàn giao, luân chuyển: quan hệ `noi_di`, `noi_den`. Nơi đi lập, gửi, xem xét; nơi đến `tiep_nhan` / `tu_choi_tiep_nhan`; cấp trên chung xem cả hai.

## M-05 Danh mục do cấp trên ban hành
Tiêu chí, loại, biểu mẫu, danh mục dùng chung: cấp ban hành thêm, sửa, khoá; mọi cấp dưới xem (NT-24).

## M-06 Làm việc theo đợt / kỳ
Đánh giá, bình xét, kê khai, báo cáo theo đợt / kỳ. Đợt có trạng thái mở / đóng; thao tác trên dữ liệu của đợt chỉ khi đợt đang mở (NT-15). Nếu tài liệu cho đơn vị tự mở đợt riêng, đợt cũng thuộc đơn vị (M-02).

## M-07 Khoá dữ liệu
"Khoá thông tin", "khoá sổ", "chốt số liệu": cấp quản lý có `khoa` / `mo_khoa`; khi khoá, người nhập liệu mất `chinh_sua` / `xoa` (điều kiện); người bị khoá không tự mở.

## M-08 Hồ sơ người
Hồ sơ nhân sự, thành viên, học viên, khách hàng…: đơn vị quản lý xem, sửa; cấp trên xem tổng hợp; thẻ thông tin nhạy cảm theo NT-17; người đó tự xem (`do_minh_lap`) nếu có tài khoản.

## M-09 Kho tư liệu
Thư mục, tệp: `do_minh_lap`, chia sẻ cho người / nhóm, kế thừa thư mục cha (NT-20).

## M-10 Dashboard và báo cáo
Theo NT-19: không tài nguyên; quyền xem từ dữ liệu gốc; ẩn hiện bằng menu.

## M-11 Lãnh đạo – chuyên viên
Mỗi cấp có cặp lãnh đạo (thẩm định, duyệt, xem) và chuyên viên (lập, tổng hợp, sửa). Tách thành hai vai trò ngay cả khi tài liệu viết gộp (NT-10, NT-21).

## M-12 Giao việc, xử lý theo người được giao
Văn bản đến, yêu cầu, sự vụ, nhiệm vụ: người phân công `giao_xu_ly`; người được giao thao tác trên bản ghi được giao (`duoc_giao`, NT-16); lãnh đạo đơn vị xem mọi bản ghi của đơn vị.

## M-13 Quản trị hệ thống
Quản trị tài khoản, gán vai trò, cấu hình: vai trò quản trị tách khỏi nghiệp vụ (NT-22); quản trị đơn vị chỉ gán vai trò trong đơn vị mình.

## M-14 Tích hợp
Đồng bộ, API, trao đổi với hệ thống khác: loại khỏi phân quyền người dùng (NT-18). Nếu người dùng bấm thực hiện (ví dụ "đẩy hồ sơ sang hệ thống ký số"), coi là hành động vòng đời của bản ghi và phân quyền như thao tác thường.
