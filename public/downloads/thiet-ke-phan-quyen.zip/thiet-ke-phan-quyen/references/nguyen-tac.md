# Nguyên tắc thiết kế phân quyền

Mỗi nguyên tắc có mã `NT-xx`. Mọi đề xuất trong bản thiết kế phải ghi mã nguyên tắc làm căn cứ, để BA/SA đọc được vì sao AI đề xuất như vậy và bác bỏ khi nghiệp vụ khác đi. Nguyên tắc là **mặc định hợp lý**, không phải luật cứng: khi tài liệu hoặc BA nói rõ khác, theo tài liệu và ghi chú lại.

## Mục lục
- [A. Nền tảng](#a-nền-tảng): NT-01 → NT-04
- [B. Tài nguyên và hành động](#b-tài-nguyên-và-hành-động): NT-05 → NT-08
- [C. Vai trò](#c-vai-trò): NT-09 → NT-11, NT-21, NT-22
- [D. Phạm vi dữ liệu theo cây đơn vị (ReBAC)](#d-phạm-vi-dữ-liệu-theo-cây-đơn-vị-rebac): NT-12 → NT-14
- [E. Điều kiện (ABAC)](#e-điều-kiện-abac): NT-15 → NT-17
- [F. Trường hợp đặc biệt](#f-trường-hợp-đặc-biệt): NT-18 → NT-20, NT-23, NT-24
- [G. Chọn RBAC, ReBAC hay ABAC](#g-chọn-rbac-rebac-hay-abac)

## A. Nền tảng

**NT-01 Mặc định từ chối.** Không có quyền nào được ngầm cấp. Thao tác không xuất hiện trong thiết kế thì không ai làm được. Khi tài liệu im lặng về một quyền ghi hoặc xoá, thiếu an toàn hơn thừa: thiếu thì người dùng báo, thừa thì không ai biết.

**NT-02 Đặc quyền tối thiểu.** Mỗi vai trò chỉ có đúng quyền cần cho chức trách, trên đúng phần dữ liệu cần. Dấu hiệu vi phạm: một vai trò toàn hệ thống có quyền ghi ở nhiều mảng nghiệp vụ; một nhóm tác nhân gộp nhận toàn bộ quyền của các thành phần.

**NT-03 Tách nhiệm vụ.** Người lập và người duyệt cùng một bản ghi phải là hai người khác nhau; người duyệt cấp dưới không tự duyệt cấp trên. Áp dụng cho mọi luồng gửi duyệt → duyệt / từ chối, và cho cặp "lập chứng từ – xác nhận" liên quan tiền, tài sản, khen thưởng, kỷ luật. Có thể bảo đảm bằng hai vai trò khác nhau hoặc bằng điều kiện "người duyệt khác người lập" (NT-16).

**NT-04 Truy vết.** Mỗi quyền phải trả lời được: lấy từ đâu (trích tài liệu), theo quy tắc nào, ai duyệt. Đề xuất của AI luôn ghi lý do, mã nguyên tắc, mức tin cậy và chờ người duyệt.

## B. Tài nguyên và hành động

**NT-05 Tài nguyên là loại dữ liệu có vòng đời và đơn vị chủ quản.** Một tài nguyên tốt có bản ghi riêng, có người tạo, có trạng thái, gắn được với một đơn vị hoặc một người.
- Không lập tài nguyên cho màn hình, menu, dashboard, báo cáo thống kê: các thứ này đọc dữ liệu của tài nguyên khác (NT-19).
- Không lập tài nguyên cho một tập con dữ liệu ("hồ sơ cấp trung ương", "phiếu chờ duyệt"): tập con là phạm vi (NT-12) hoặc điều kiện (NT-15).
- Dòng chi tiết không có vòng đời riêng (dòng hàng của phiếu, nội dung chi của một kỳ) thuộc cùng tài nguyên với bản ghi cha.
- Cây tổ chức là tài nguyên đặc biệt: có quan hệ cấp trên (`cap_tren`) với chính nó và là nơi gán vai trò theo đơn vị. **Cây đơn vị lấy từ Cổng** (`don_vi`), dùng chung mọi phân hệ: phân hệ không thiết kế quyền trên cây đơn vị, chỉ dùng cây làm nơi gán vai trò và gốc tính phạm vi. Cây riêng của phân hệ (ví dụ tổ chức đoàn thể gắn vào đơn vị, M-01) vẫn khai như tài nguyên cây.

**NT-06 Hành động theo vòng đời, một key một nghĩa trên mọi tài nguyên, theo bộ key chuẩn.** Key hành động lấy từ bộ key chuẩn tiếng Việt không dấu (`references/bo-key.md`); cách viết khác (`nhap`, `nhap_lieu`, `nhap_excel`…) là bí danh của một key duy nhất.

| Nhóm | Key | Mức |
|---|---|---|
| Xem | `xem` (xem danh sách, tìm kiếm, lọc, xem chi tiết, thẻ thông tin, lịch sử: một quyền), `xem_nhay_cam` (thông tin nhạy cảm, NT-17) | bản ghi |
| Tạo | `them_moi` (thêm, tạo, lập, upload), `sao_chep` | danh sách |
| Sửa | `chinh_sua`, `di_chuyen`, `danh_gia` | bản ghi |
| Xoá | `xoa`, `khoi_phuc` | bản ghi |
| Vòng đời, duyệt | `gui_duyet`, `phe_duyet`, `tu_choi`, `tiep_nhan`, `tu_choi_tiep_nhan`, `khoa`, `mo_khoa`, `giao_xu_ly`, `chia_tach`, `sap_nhap`, `giai_the` | bản ghi |
| Xuất nhập | `xuat`, `nhap`, `tai_xuong` | danh sách (download: bản ghi) |
| Khác | `chia_se`, `gan_vai_tro` | bản ghi |

Key không mang tên tài nguyên (`phe_duyet`, không phải `phe_duyet_hop_dong`): quyền luôn là cặp `tài_nguyên:hành_động`. Hai thao tác cùng nghĩa luôn được cấp cùng nhau thì dùng chung key (tìm kiếm, xem danh sách, xem chi tiết = `xem`); cần cấp riêng thì tách key.

**NT-07 Mức danh sách và mức bản ghi.** Hành động mức danh sách kiểm tra khi chưa có bản ghi (`them_moi`, `xuat`, `nhap`). Hành động mức bản ghi kiểm tra trên một bản ghi cụ thể và cần phạm vi (NT-12) hoặc điều kiện (NT-16) với vai trò theo đơn vị. Thêm một bản ghi *dưới* một bản ghi có sẵn (thêm đơn vị con) là hành động mức bản ghi trên bản ghi cha.
- **Xem danh sách không phải quyền riêng.** Hệ phân quyền trả danh sách ID bản ghi người dùng được `xem` (List 1); ứng dụng truy vấn CSDL với điều kiện lọc của màn hình **và** ID thuộc List 1 để ra danh sách hiển thị (List 2). Xuất danh sách (`xuat`) cũng chỉ gồm bản ghi trong List 1.

**NT-08 Xuất và nhập là quyền riêng.** Xuất cho phép mang dữ liệu hàng loạt ra ngoài; nhập cho phép ghi hàng loạt. Không gộp vào xem / thêm; mặc định chỉ cấp cho vai trò quản lý dữ liệu của mảng.

## C. Vai trò

**NT-09 Vai trò theo chức trách, không theo chức danh.** Vai trò mô tả việc người đó làm trong hệ thống (lập, kiểm tra, duyệt, xem tổng hợp). Một chức danh có thể giữ nhiều vai trò; nhiều chức danh có thể cùng một vai trò.

**NT-10 Tách tác nhân gộp.** Tài liệu hay viết tác nhân gộp ("Lãnh đạo, chuyên viên phòng X", "Cán bộ các cấp"). Tách theo:
- chức trách: lãnh đạo (thẩm định, duyệt, xem) ≠ chuyên viên / trợ lý (lập, sửa, tổng hợp) — NT-03, NT-21;
- cấp: cơ quan trung ương ≠ đơn vị trực thuộc ≠ cơ sở;
- mảng nghiệp vụ khi tài liệu cho biết người phụ trách mảng ("chuyên viên tài chính", "cán bộ phụ trách hồ sơ"…). Gán mảng theo bản chất dữ liệu: dữ liệu có kinh phí liên quan người phụ trách tài chính; hồ sơ người liên quan mọi người có nghiệp vụ dùng đến người đó.

**NT-11 Tránh bùng nổ vai trò.** Không tạo vai trò theo từng đơn vị ("trưởng phòng A", "trưởng phòng B"): một vai trò `truong_phong` gán tại từng phòng, phạm vi đi theo nơi gán (NT-12). Không tạo vai trò theo từng cấp duyệt khi chức trách giống nhau; cấp duyệt là quan hệ (NT-14).

**NT-21 Lãnh đạo xem rộng và duyệt, không nhập liệu nghiệp vụ.** Vai trò lãnh đạo mặc định: xem, xuất, duyệt / từ chối. Với dữ liệu chuyên môn, danh mục và dữ liệu có luồng gửi – duyệt: thêm, sửa, xoá, nhập, khoá thuộc chuyên viên. Ngoại lệ thường gặp: **dữ liệu tổ chức và hồ sơ người thuộc quyền** — lãnh đạo được cập nhật khi tài liệu giao cho họ.

**NT-22 Quản trị hệ thống tách khỏi nghiệp vụ.** Quản lý tài khoản, gán vai trò, cấu hình danh mục hệ thống là vai trò quản trị riêng; người quản trị không mặc nhiên xem hay sửa dữ liệu nghiệp vụ. Người gán quyền không tự gán quyền cho chính mình.

## D. Phạm vi dữ liệu theo cây đơn vị (ReBAC)

**NT-12 Vai trò theo đơn vị gán trên một nút của cây đơn vị; phạm vi tính qua quan hệ cây.** Nhóm này chỉ gồm phạm vi theo **quan hệ** (bản ghi nối với cây đơn vị qua `thuoc_don_vi`, `cap_duyet`…, cây nối cấp trên qua `cap_tren`). Phạm vi theo thuộc tính của người (do chính mình lập, được giao) là ABAC, xem NT-16.

| Key | Ý nghĩa |
|---|---|
| `toan_he_thong` | Mọi bản ghi (vai trò cấp cao nhất, RBAC) |
| `don_vi_minh` | Bản ghi thuộc đúng đơn vị nơi vai trò được gán |
| `don_vi_minh_va_cap_duoi_truc_tiep` | Đơn vị mình và các đơn vị con liền kề |
| `don_vi_minh_va_cap_duoi` | Đơn vị mình và mọi đơn vị trong nhánh |
| `cap_duyet` | Bản ghi mà đơn vị mình đang là cấp duyệt (NT-14) |

Mỗi tài nguyên dữ liệu phải có quan hệ tới cây đơn vị (`thuoc_don_vi`…) để phạm vi có nghĩa.

**NT-13 Cấp trên xem, cấp dưới làm.** Đơn vị tự lập và sửa dữ liệu của mình; cấp trên xem và duyệt dữ liệu cấp dưới gửi lên, không sửa thay, không xoá, nhập, xuất hàng loạt dữ liệu của cấp dưới. Đề xuất mặc định: ghi ở `don_vi_minh`, xem ở `don_vi_minh_va_cap_duoi`, trừ khi tài liệu nêu khác.

**NT-14 Phê duyệt nhiều cấp = một hành động + quan hệ cấp duyệt + điều kiện trạng thái.** Bản ghi mang quan hệ `cap_duyet` trỏ tới đơn vị đang phải duyệt; khi duyệt xong cấp này, quan hệ chuyển lên cấp trên. Vai trò duyệt của từng cấp dùng chung `phe_duyet` / `tu_choi` với phạm vi `cap_duyet`. Không tách key theo cấp, không tạo tài nguyên theo cấp.
- Ở mỗi cấp, giao duyệt / trả lại cho **những người chịu trách nhiệm xem xét ở cấp đó**, không chỉ người đứng đầu: thường là lãnh đạo và cán bộ được giao kiểm tra ở cấp đó. Tách nhiệm vụ đã có điều kiện "người duyệt khác người lập" bảo đảm.
- "Từ chối … cấp X" mà không có "Phê duyệt … cấp X" thường là trả lại hồ sơ cấp X gửi lên; người làm là người xem xét ở cấp kế trên.

## E. Điều kiện (ABAC)

**NT-15 Điều kiện theo trạng thái vòng đời.**
- `chinh_sua`, `xoa`, `gui_duyet`: chỉ khi bản ghi đang soạn hoặc bị trả lại (`trang_thai` thuộc nhóm `dang_soan`);
- `phe_duyet`, `tu_choi`: chỉ khi đang chờ duyệt (`trang_thai` thuộc nhóm `cho_duyet`);
- dữ liệu bị khoá (khoá sổ, chốt kỳ, đợt đã đóng): không sửa, không xoá.

**NT-16 Điều kiện theo người (ABAC).** Dùng khi quyền phụ thuộc vào một người cụ thể chứ không phải vị trí trong cây đơn vị: so thuộc tính bản ghi với người dùng.

| Key phạm vi / điều kiện | Ý nghĩa | Biểu thức |
|---|---|---|
| `do_minh_lap` | Bản ghi do chính mình lập (KT-03) | `resource.nguoi_lap = user.ma_nguoi_dung` |
| `duoc_giao` | Bản ghi được giao cho mình xử lý (M-12) | `resource.nguoi_duoc_giao = user.ma_nguoi_dung` |
| `khong_tu_duyet` | Người duyệt khác người lập (NT-03, KT-13) | `resource.nguoi_lap ≠ user.ma_nguoi_dung` |

Hồ sơ của chính mình (người là đối tượng của bản ghi), người được ghi tên làm người duyệt: cùng dạng, thuộc tính riêng của tài nguyên.

**NT-17 Dữ liệu nhạy cảm cần biết mới xem.** Thông tin cá nhân nhạy cảm (sức khoẻ, tôn giáo, kỷ luật, tài chính cá nhân, hoàn cảnh gia đình…) chỉ vai trò quản lý trực tiếp xem chi tiết; vai trò xem tổng hợp chỉ thấy số liệu. Nếu tài liệu có thẻ thông tin nhạy cảm riêng, đề xuất hành động xem riêng hoặc ghi câu hỏi.

## F. Trường hợp đặc biệt

**NT-18 Tích hợp, API không phải vai trò người dùng.** Giao dịch có tác nhân là hệ thống, cổng, CSDL ngoài, hoặc là bước đồng bộ tự động: loại khỏi phân quyền người dùng; dùng tài khoản dịch vụ ở tầng tích hợp.

**NT-19 Dashboard, báo cáo thống kê.** Không là tài nguyên. Quyền xem suy ra từ `xem` trên dữ liệu gốc, số liệu lọc theo phạm vi người xem; ẩn hiện bằng menu. Nếu một tác nhân được xem dashboard mà không được xem dữ liệu gốc, đề xuất hành động riêng `view_statistics` (báo `KEY-02` để người duyệt xác nhận).

**NT-20 Kho tư liệu, tệp.** Phạm vi theo chủ sở hữu (`do_minh_lap`, ABAC) và chia sẻ (`chia_se`), thư mục con kế thừa thư mục cha.

**NT-23 Uỷ quyền, kiêm nhiệm, tạm thời.** Người được uỷ quyền nhận vai trò của người uỷ quyền trong thời hạn và phạm vi uỷ quyền; ghi rõ người thực hiện thực tế. Kiêm nhiệm là gán thêm vai trò tại nút khác, không tạo vai trò gộp.

**NT-24 Dữ liệu dùng chung, danh mục.** Danh mục dùng chung (loại, tiêu chí, biểu mẫu) do cấp ban hành thêm, sửa; mọi người dùng cần xem để làm việc. Dữ liệu công khai (thông báo, văn bản phổ biến) cho mọi tài khoản xem; vẫn chỉ người phụ trách được ghi.

## G. Chọn RBAC, ReBAC hay ABAC

| Câu hỏi nghiệp vụ | Cơ chế |
|---|---|
| Ai được làm gì, trên mọi bản ghi | RBAC: vai trò toàn hệ thống |
| Trên bản ghi của đơn vị nào, có lan xuống cấp dưới không | ReBAC: vai trò gán trên cây đơn vị + quan hệ (NT-12…NT-14) |
| Khi bản ghi / người dùng thoả điều kiện gì | ABAC: trạng thái, khoá (NT-15); người lập, người được giao, chính mình (NT-16) |

Không dồn mọi thứ vào ABAC (so `user.don_vi` với `resource.don_vi` thay cho quan hệ cây): mất cấu trúc cấp trên – cấp dưới, khó rà soát, phải đồng bộ thuộc tính. Không dồn mọi thứ vào RBAC: buộc tạo vai trò theo từng đơn vị (NT-11).
