# So thiết kế với ma trận phân quyền của BA

Khi BA đã có ma trận phân quyền (Excel: dòng = chức năng / hành động, cột = vai trò, ô đánh dấu), ma trận là thước đo tốt nhất cho thiết kế. `so_sanh_ma_tran.py` đo hai phiên bản thiết kế với ma trận:
- **tài liệu thô**: mọi quyền tài liệu nêu (giữ + AI bỏ) — cho biết nếu chỉ chép tài liệu thì đúng bao nhiêu;
- **sau AI**: quyền hiệu lực (giữ + AI thêm) — cho biết giá trị của các đề xuất.

Đơn vị so: (vai trò ma trận, tài nguyên, hành động đã chuẩn hoá), có quyền hay không. Chưa so phạm vi bản ghi.

## Cấu hình


| Trường | Ý nghĩa |
|---|---|
| `excel`, `sheet` | Tệp ma trận (đường dẫn tương đối tính từ tệp cấu hình) và tên sheet |
| `dong_tieu_de` | Dòng ghi tên vai trò |
| `dong_dau`, `dong_cuoi` | Khoảng dòng dữ liệu |
| `cot_ten_tai_nguyen` | Danh sách cột ghi tên / key tài nguyên; ô trống lấy giá trị dòng trên |
| `cot_hanh_dong` | Cột ghi hành động |
| `cot_vai_tro` | Các cột vai trò, ví dụ `"C:G"` hoặc `["C", "E:G"]` |
| `ky_hieu` | Giá trị ô coi là có quyền, mặc định `["x"]` |
| `vai_tro` | Ánh xạ vai trò thiết kế → danh sách vai trò ma trận |
| `tai_nguyen` | Ánh xạ tên tài nguyên trong ma trận → key tài nguyên thiết kế (nhiều dòng ma trận có thể về một tài nguyên, ví dụ tập con) |
| `hanh_dong` | (tuỳ chọn) ánh xạ key hành động ma trận → key chuẩn khi quy tắc tiền tố mặc định không đủ |
| `bo_qua_hanh_dong` | (tuỳ chọn) hành động thiết kế không có đối ứng trong ma trận |
| `cot_dan_xuat`, `bang_ke_thua` | (tuỳ chọn) ma trận có cột vai trò dẫn xuất kiểu «Người quản lý # X» và bảng kế thừa vai trò quy về vai trò gốc |

Key hành động ma trận được quy về bộ key chuẩn (`bo-key.md`) qua bí danh và tiền tố: `xem_ds`, `xem_ct` → `xem`; `nhap_lieu`, `nhap_excel` → `nhap`; `phe_duyet_cap_phong` → `phe_duyet`… Ma trận cũ ghi key tiếng Việt vẫn so được.

## Đọc kết quả

- **Thiếu so với ma trận**: tách hai loại.
  - Tài liệu cũng không giao → tài liệu và ma trận nói khác nhau. Không tự thêm theo ma trận; ghi câu hỏi cho BA.
  - AI đã bỏ → kiểm tra quy tắc thu hẹp có quá chặt không.
- **Thừa so với ma trận**: tài liệu giao rộng hơn ma trận, hoặc AI thêm. Xem quy tắc nào giữ / thêm.
- **Quyết định của AI**: tỉ lệ "bỏ đúng" và "thêm đúng" cho biết nguyên tắc có hợp với cách BA nghĩ không.

## Hiệu chỉnh

Chỉ chỉnh quy tắc khi sai lệch phản ánh một điều dùng lại được (ví dụ "ở mỗi cấp, cán bộ kiểm tra cũng được trả lại hồ sơ"). Nếu bài học có tính chung, ghi lại cho lần sau (bổ sung vào nguyên tắc hoặc mẫu). Không chỉnh từng ô cho khớp: thiết kế khớp 100% với ma trận chỉ là chép lại ma trận.

Luôn báo cả số trước và sau khi chỉnh. Nói rõ: số sau khi chỉnh được đo trên chính ma trận đã dùng để chỉnh, nên là con số lạc quan; độ đúng thật cần đo trên một phân hệ khác chưa dùng để chỉnh.
