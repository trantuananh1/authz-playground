# -*- coding: utf-8 -*-
"""Đọc bảng danh sách chức năng / usecase (trong Word, PDF, Markdown hoặc Excel) thành danh sách giao dịch.

  python -I bang_chuc_nang.py <thu_muc_lam_viec> [--nguon N1] [--bang B16 | --sheet "Tên sheet"]

Nhận dạng bảng có cột tên usecase / chức năng, cột tác nhân và cột giao dịch / mô tả.
- Dòng có tác nhân = usecase; dòng có giao dịch = một giao dịch của usecase gần nhất; dòng chỉ có tên = tiêu đề mục.
- Bảng chỉ có hai cột chức năng – tác nhân (không có cột giao dịch): mỗi dòng là một giao dịch.
- Tác nhân của giao dịch lấy từ câu "<tác nhân> có thể / cho phép …"; không có thì lấy tác nhân của usecase. Nhiều tác nhân cách nhau bằng ; hoặc xuống dòng.
Ghi: giao_dich.json, giao_dich.md (lap_thiet_ke.py đọc mọi tệp giao_dich*.json).
"""
import argparse, collections, json, os, re, sys

sys.stdout.reconfigure(encoding="utf-8")
cf = lambda s: re.sub(r"\s+", " ", str(s or "")).strip()
tach = lambda s: [cf(a) for a in re.split(r"[;\n]", s or "") if cf(a)]
KW_UC, KW_TN, KW_GD = ("usecase", "use case", "chức năng", "tên"), ("tác nhân", "actor", "người dùng", "đối tượng sử dụng", "vai trò"), ("giao dịch", "transaction", "mô tả")


def tim_cot(hdr):
    h = [cf(x).casefold() for x in hdr]
    idx = lambda kws, bo=(): next((i for i, x in enumerate(h) if any(k in x for k in kws) and i not in bo), None)
    ct = idx(KW_TN)
    cg = idx(KW_GD, (ct,))
    cu = idx(KW_UC, (ct, cg))
    return cu, ct, cg


def bang_tai_lieu(d):
    bang = collections.OrderedDict()
    for x in d.get("doan", []):
        m = re.match(r"(B\d+)\.D(\d+)$", x["vt"])
        if m and x.get("o"):
            bang.setdefault(m.group(1), []).append((x["vt"], x["o"]))
    return bang


def bang_excel(d):
    """Mỗi sheet: tìm dòng tiêu đề có đủ cột usecase / tác nhân; trả về các dòng phía dưới."""
    from openpyxl.utils import column_index_from_string as ci
    out = collections.OrderedDict()
    for sh in d.get("sheets", []):
        rows = collections.defaultdict(dict)
        for cell, v in sh["o"].items():
            m = re.match(r"([A-Z]+)(\d+)$", cell)
            rows[int(m.group(2))][ci(m.group(1))] = v
        if not rows:
            continue
        ncol = max(c for r in rows.values() for c in r)
        for r in sorted(rows):
            hdr = [rows[r].get(c, "") for c in range(1, ncol + 1)]
            cu, ct, cg = tim_cot(hdr)
            if cu is not None and ct is not None:
                out[sh["ten"]] = [(f'Sheet "{sh["ten"]}" dòng {r}', hdr)] + [(f'Sheet "{sh["ten"]}" dòng {i}', [rows[i].get(c, "") for c in range(1, ncol + 1)])
                                                                         for i in sorted(rows) if i > r]
                break
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("thu_muc"); ap.add_argument("--nguon"); ap.add_argument("--bang"); ap.add_argument("--sheet")
    a = ap.parse_args()
    nguon = json.load(open(os.path.join(a.thu_muc, "nguon.json"), encoding="utf-8"))
    ids = [a.nguon] if a.nguon else [n["id"] for n in nguon if n["loai"] in ("tai_lieu", "excel")]
    out, bao = [], []
    for nid in ids:
        d = json.load(open(os.path.join(a.thu_muc, "trich_xuat", nid + ".json"), encoding="utf-8"))
        bangs = bang_tai_lieu(d) if d["loai"] == "tai_lieu" else bang_excel(d)
        for b, rows in bangs.items():
            if (a.bang and b != a.bang) or (a.sheet and b != a.sheet):
                continue
            cu, ct, cg = tim_cot(rows[0][1])
            if cu is None or ct is None:
                continue
            hai_cot = cg is None
            muc, uc, n0 = "", None, len(out)
            for vt, o in rows[1:]:
                o = list(o) + [""] * 10
                ten, tn = cf(o[cu]), cf(o[ct]) if ct is not None else ""
                gd = cf(o[cg]) if cg is not None else ""
                if hai_cot:
                    if ten and tn:
                        out.append({"id": f"GD{len(out) + 1}", "nguon": nid, "vt": vt, "muc": muc, "usecase": muc or ten, "usecase_vt": vt,
                                    "ten": ten, "mo_ta": ten, "tac_nhan": tach(tn), "tac_nhan_tu": "bang"})
                    elif ten:
                        muc = ten
                    continue
                if tn and tn.casefold() not in KW_TN and not any(k in tn.casefold() for k in ("tên tác nhân",)):
                    uc = {"ten": ten, "vt": vt, "tac_nhan": tach(tn)}
                    if not gd:
                        continue
                if not gd:
                    if ten:
                        muc, uc = ten, (None if ten.isupper() else uc)
                    continue
                if uc is None:
                    bao.append(f"{nid} {vt}: giao dịch «{ten or gd}» không nằm dưới usecase nào → bỏ qua")
                    continue
                mm = re.match(r"^(.+?)\s+(có thể|cho phép|được phép|được)\s+(.*)$", gd)
                tac, tu = (tach(mm.group(1)), "giao_dich") if mm and len(mm.group(1)) < 200 else (uc["tac_nhan"], "usecase")
                out.append({"id": f"GD{len(out) + 1}", "nguon": nid, "vt": vt, "muc": muc, "usecase": uc["ten"], "usecase_vt": uc["vt"],
                            "ten": ten or gd, "mo_ta": gd, "tac_nhan": tac, "tac_nhan_tu": tu})
            if len(out) > n0:
                bao.append(f"{nid} {b}: {len(out) - n0} giao dịch")
    if not out:
        print("Không nhận dạng được bảng chức năng nào. Dựng danh sách giao dịch bằng ma_tran_sang_giao_dich.py / quy_trinh_sang_giao_dich.py, hoặc tự lập giao_dich.json.")
    json.dump(out, open(os.path.join(a.thu_muc, "giao_dich.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    viet_md(a.thu_muc, out, bao, "giao_dich.md")
    print(f"{len(out)} giao dịch · {len({(g['muc'], g['usecase']) for g in out})} usecase · {len({t for g in out for t in g['tac_nhan']})} tác nhân → giao_dich.json, giao_dich.md")
    for x in bao:
        print(" ", x)


def viet_md(wd, out, bao, ten):
    tn = collections.Counter(t for g in out for t in g["tac_nhan"])
    uc = collections.OrderedDict()
    for g in out:
        uc.setdefault((g["muc"], g["usecase"]), []).append(g)
    L = ["# Giao dịch", "", *[f"- {x}" for x in bao], "", "## Tác nhân", ""] + [f"- {t}: {n} giao dịch" for t, n in tn.most_common()] + ["", "## Usecase", ""]
    m0 = None
    for (m, u), gs in uc.items():
        if m != m0:
            L += ["", f"### {m or '(không có mục)'}"]; m0 = m
        L.append(f"- **{u}** ({gs[0]['usecase_vt']}, {len(gs)} giao dịch): " + "; ".join(f"{g['id']} {g['ten']}" for g in gs))
    open(os.path.join(wd, ten), "w", encoding="utf-8").write("\n".join(L) + "\n")


if __name__ == "__main__":
    main()
