# -*- coding: utf-8 -*-
"""Trích xuất nguyên trạng tài liệu nghiệp vụ (docx, pdf, md, txt, xlsx, drawio) kèm nhãn vị trí.

  python -I trich_xuat.py <thu_muc_lam_viec> <tep> [<tep> ...]

Mỗi tệp nhận mã N1, N2…; ghi trich_xuat/N….json (dữ liệu) và trich_xuat/N….md (để đọc).
"""
import argparse, base64, collections, hashlib, html, json, os, re, sys, unicodedata, urllib.parse, zipfile, zlib
import xml.etree.ElementTree as ET

sys.stdout.reconfigure(encoding="utf-8")
OD = collections.OrderedDict


# ---------------------------------------------------------------------------------------------
# Chuẩn hóa cơ học (không làm đổi nghĩa)
# ---------------------------------------------------------------------------------------------
def chuan(v):
    """Chuỗi hiển thị: NFC, gộp khoảng trắng."""
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return re.sub(r"\s+", " ", unicodedata.normalize("NFC", str(v))).strip()


def khoa_ten(s):
    """Hai tên được coi là MỘT khi chỉ khác khoảng trắng và chữ hoa/thường."""
    return chuan(s).casefold()


def khoa_gan(s):
    """Hai tên được coi là GẦN TRÙNG (phải hỏi lại) khi chỉ khác dấu, ký tự phân cách."""
    s = unicodedata.normalize("NFD", chuan(s).casefold()).replace("đ", "d")
    return re.sub(r"[^a-z0-9]", "", "".join(c for c in s if unicodedata.category(c) != "Mn"))


def doc_json(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def ghi_json(p, d):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)


def ghi_text(p, s):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)


def loi(msg):
    print("LỖI:", msg)
    sys.exit(1)


# ---------------------------------------------------------------------------------------------
# trich-xuat: đọc nguyên trạng từng tệp nguồn, không diễn giải
# ---------------------------------------------------------------------------------------------
def trich_excel(path):
    import openpyxl
    from openpyxl.utils import get_column_letter
    wb = openpyxl.load_workbook(path, data_only=True)
    sheets, md = [], []
    for ws in wb.worksheets:
        o, ghi_chu = OD(), OD()
        for row in ws.iter_rows():
            for c in row:
                v = chuan(c.value.isoformat() if hasattr(c.value, "isoformat") else c.value)
                if v:
                    o[c.coordinate] = v
                if getattr(c, "comment", None) is not None and chuan(c.comment.text):
                    ghi_chu[c.coordinate] = chuan(c.comment.text)
        an = ws.sheet_state != "visible"
        gop = [str(r) for r in ws.merged_cells.ranges]
        sheets.append({"ten": ws.title, "an": an, "so_dong": ws.max_row, "so_cot": ws.max_column, "o": o, "ghi_chu_o": ghi_chu, "gop": gop})
        md.append(f'## Sheet "{ws.title}"' + (" (sheet ẩn)" if an else "") + f" — {ws.max_row} dòng × {ws.max_column} cột")
        if gop:
            md.append("Ô gộp: " + ", ".join(gop))
        for r in range(1, ws.max_row + 1):
            cells = [f"{get_column_letter(c)}: {o[get_column_letter(c) + str(r)]}" for c in range(1, ws.max_column + 1) if get_column_letter(c) + str(r) in o]
            if cells:
                md.append(f"- Dòng {r} | " + " | ".join(cells))
        for k, v in ghi_chu.items():
            md.append(f"- Ghi chú ô {k}: {v}")
        md.append("")
    van_ban = [v for s in sheets for v in list(s["o"].values()) + list(s["ghi_chu_o"].values())]
    return {"loai": "excel", "sheets": sheets, "van_ban": van_ban}, md


def _nhan_drawio(v):
    v = re.sub(r"<br\s*/?>|</div>|</p>|</li>", " ", v or "", flags=re.I)
    return chuan(html.unescape(re.sub(r"<[^>]+>", "", v)))


def trich_drawio(path):
    root = ET.parse(path).getroot()
    models = []
    if root.tag == "mxGraphModel":
        models.append(("Trang 1", root))
    for i, dg in enumerate(root.iter("diagram"), 1):
        m = dg.find("mxGraphModel")
        if m is None:
            raw = (dg.text or "").strip()
            try:
                m = ET.fromstring(urllib.parse.unquote(zlib.decompress(base64.b64decode(raw), -15).decode("utf-8")))
            except Exception as e:
                loi(f"{path}: không giải nén được trang {i} ({e}). Mở bằng draw.io, chọn File > Properties, bỏ chọn Compressed rồi lưu lại.")
        models.append((dg.get("name") or f"Trang {i}", m))
    trang, md = [], []
    for ten, m in models:
        raw = OD()
        holder = m.find("root") if m.find("root") is not None else m
        for el in holder:
            cell = el if el.tag == "mxCell" else el.find("mxCell")
            if cell is None:
                continue
            cid = el.get("id") or cell.get("id")
            style = cell.get("style") or ""
            raw[cid] = {"id": cid, "nhan": _nhan_drawio(el.get("label") if el.tag != "mxCell" else cell.get("value")), "cha": cell.get("parent"),
                        "canh": cell.get("edge") == "1", "dinh": cell.get("vertex") == "1", "tu": cell.get("source"), "den": cell.get("target"),
                        "kieu": style.split(";")[0] if style and "=" not in style.split(";")[0] else ("nhan_mui_ten" if "edgeLabel" in style else "")}
        # nhãn mũi tên là ô con của mũi tên
        for c in list(raw.values()):
            if c["dinh"] and c["cha"] in raw and raw[c["cha"]]["canh"]:
                p = raw[c["cha"]]
                p["nhan"] = chuan((p["nhan"] + " " + c["nhan"]).strip())
                del raw[c["id"]]
        khoi = [{"id": c["id"], "nhan": c["nhan"], "kieu": c["kieu"], "thuoc": c["cha"] if c["cha"] in raw and raw[c["cha"]]["dinh"] else None}
                for c in raw.values() if c["dinh"]]
        mui = [{"id": c["id"], "tu": c["tu"], "den": c["den"], "nhan": c["nhan"]} for c in raw.values() if c["canh"]]
        trang.append({"ten": ten, "khoi": khoi, "mui_ten": mui})
        by = {k["id"]: k for k in khoi}
        md += [f'## Trang "{ten}"', "### Khối (khối lồng trong khối khác được thụt vào)"]

        def in_khoi(k, lv):
            md.append("  " * lv + f'- khối {k["id"]}' + (f' [{k["kieu"]}]' if k["kieu"] else "") + f': "{k["nhan"]}"')
            for c in khoi:
                if c["thuoc"] == k["id"]:
                    in_khoi(c, lv + 1)
        for k in khoi:
            if not k["thuoc"]:
                in_khoi(k, 0)
        md.append("### Mũi tên")
        ten_khoi = lambda i: f'"{by[i]["nhan"]}" (khối {i})' if i in by else "(không nối vào khối nào)"
        for e in mui:
            md.append(f'- mũi tên {e["id"]}: {ten_khoi(e["tu"])} → {ten_khoi(e["den"])}' + (f' — nhãn "{e["nhan"]}"' if e["nhan"] else ""))
        md.append("")
    van_ban = [x["nhan"] for t in trang for x in t["khoi"] + t["mui_ten"] if x["nhan"]]
    return {"loai": "drawio", "trang": trang, "van_ban": van_ban}, md


W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _docx_p(p):
    out = []
    for el in p.iter():
        if el.tag == W + "t":
            out.append(el.text or "")
        elif el.tag in (W + "tab", W + "br"):
            out.append(" ")
    return chuan("".join(out))


def trich_tai_lieu(path):
    ext = os.path.splitext(path)[1].lower()
    doan, n, b = [], 0, 0

    def them(text, loai="doan", vt=None, o=None):
        nonlocal n
        text = chuan(text)
        if not text:
            return
        if vt is None:
            n += 1
            vt = f"Đ{n}"
        doan.append({"vt": vt, "loai": loai, "van_ban": text, **({"o": o} if o else {})})

    if ext == ".doc":
        loi(f"{path}: định dạng .doc cũ chưa hỗ trợ; mở bằng Word và lưu lại dạng .docx.")
    if ext == ".docx":
        body = ET.fromstring(zipfile.ZipFile(path).read("word/document.xml")).find(W + "body")
        for el in body:
            if el.tag == W + "p":
                st = el.find(f"{W}pPr/{W}pStyle")
                them(_docx_p(el), "tieu_de" if st is not None and re.match(r"(?i)heading|tieu|title|\d$", st.get(W + "val") or "") else "doan")
            elif el.tag == W + "tbl":
                b += 1
                for d, tr in enumerate(el.iter(W + "tr"), 1):
                    cells = [chuan(" ".join(_docx_p(p) for p in tc.iter(W + "p"))) for tc in tr.findall(W + "tc")]
                    them(" | ".join(cells), "dong_bang", f"B{b}.D{d}", cells)
    elif ext == ".pdf":
        try:
            import pymupdf as mu
        except ImportError:
            try:
                import fitz as mu
            except ImportError:
                loi(f"{path}: chưa có thư viện đọc PDF (pymupdf). Cài `pip install pymupdf` hoặc chuyển tệp sang .docx / .md.")
        for pi, page in enumerate(mu.open(path), 1):
            for bi, blk in enumerate([x for x in page.get_text("blocks") if x[6] == 0 and chuan(x[4])], 1):
                them(blk[4], "doan", f"Tr{pi}.Đ{bi}")
    else:
        with open(path, encoding="utf-8-sig") as f:
            trong_bang, d = False, 0
            for line in f.read().splitlines():
                if re.match(r"^\s*\|?[\s:|-]+\|?\s*$", line) and "-" in line:
                    continue  # dòng kẻ bảng markdown
                if line.strip().startswith("|"):          # dòng bảng markdown → B{n}.D{m}, giữ từng ô
                    if not trong_bang:
                        b, d, trong_bang = b + 1, 0, True
                    d += 1
                    cells = [chuan(c) for c in line.strip().strip("|").split("|")]
                    them(" | ".join(cells), "dong_bang", f"B{b}.D{d}", cells)
                    continue
                trong_bang = False
                them(line, "tieu_de" if line.lstrip().startswith("#") else "doan")
    md = [f'- [{d["vt"]}]' + (" (tiêu đề)" if d["loai"] == "tieu_de" else "") + f' {d["van_ban"]}' for d in doan]
    van_ban = [d["van_ban"] for d in doan] + [c for d in doan for c in d.get("o", [])]
    return {"loai": "tai_lieu", "doan": doan, "van_ban": van_ban}, md


def trich_ra_soat(path):
    """Câu trả lời BA đã ghi trong ra_soat.json → dùng làm nguồn."""
    d = doc_json(path)
    doan = []
    for i, (k, m) in enumerate(((k, m) for k, m in d.get("muc", {}).items() if chuan(m.get("ghi_chu"))), 1):
        doan.append({"vt": f"RS{i}", "loai": "doan", "khoa": k,
                     "van_ban": chuan(f'{m.get("nhan", "")} — {m.get("nguoi") or "(không ghi tên)"}, {(m.get("luc") or "")[:10]}: {m["ghi_chu"]}')})
    md = [f'- [{x["vt"]}] {x["van_ban"]}' for x in doan]
    return {"loai": "ra_soat", "doan": doan, "van_ban": [x["van_ban"] for x in doan] + [chuan(m.get("ghi_chu")) for m in d.get("muc", {}).values()]}, md


def cmd_trich_xuat(a):
    wd = a.thu_muc
    pn = os.path.join(wd, "nguon.json")
    nguon = doc_json(pn) if os.path.exists(pn) else []
    for tep in a.tep:
        if not os.path.exists(tep):
            loi(f"không thấy tệp {tep}")
        full = os.path.abspath(tep)
        ext = os.path.splitext(tep)[1].lower()
        if ext in (".xlsx", ".xlsm"):
            d, md = trich_excel(full)
        elif ext in (".drawio", ".xml"):
            d, md = trich_drawio(full)
        elif ext == ".json":
            d, md = trich_ra_soat(full)
        elif ext in (".docx", ".doc", ".pdf", ".md", ".txt"):
            d, md = trich_tai_lieu(full)
        else:
            loi(f"{tep}: chưa hỗ trợ định dạng {ext}. Hỗ trợ: .xlsx, .drawio, .docx, .pdf, .md, .txt, và tệp ra_soat.json.")
        cu = next((x for x in nguon if os.path.normcase(x["tep"]) == os.path.normcase(full)), None)
        if cu is None:
            cu = {"id": f"N{max([int(x['id'][1:]) for x in nguon] + [0]) + 1}", "tep": full}
            nguon.append(cu)
        cu.update({"ten": os.path.basename(full), "loai": d["loai"]})
        ghi_json(os.path.join(wd, "trich_xuat", cu["id"] + ".json"), d)
        ghi_text(os.path.join(wd, "trich_xuat", cu["id"] + ".md"), f'# {cu["id"]} — {cu["ten"]} ({d["loai"]})\n\n' + "\n".join(md) + "\n")
        print(f'{cu["id"]}  {d["loai"]:9}  {cu["ten"]}  →  trich_xuat/{cu["id"]}.md')
    ghi_json(pn, nguon)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("thu_muc"); ap.add_argument("tep", nargs="+")
    cmd_trich_xuat(ap.parse_args())


if __name__ == "__main__":
    main()
