# -*- coding: utf-8 -*-
"""Xuất thiết kế phân quyền sang DSL của playground (resource / role / derive / user / instance / assign / relate / assert).

  python -I xuat_dsl.py <thu_muc_lam_viec> [--so-nhanh 2] [--kiem-thu gon|day_du] [--mot-tep]

Đọc thiet_ke_phan_quyen.json, ra_soat.json (nếu có) và phan_quyen_import.json (tự chạy xuat_json.py nếu chưa có hoặc cũ hơn thiết kế).
- Phần cấu trúc lấy từ phan_quyen_import.json: vai trò trên tài nguyên → `role`, grantedTo → `derive`, vai trò chung → `role … "Tên": res:act`.
- Dữ liệu mẫu tự dựng: cây đơn vị theo các cấp của vai trò, mỗi vai trò theo đơn vị một người ở mỗi nhánh, vài bản ghi mỗi loại ở các trạng thái.
- `assert` sinh từ ý đồ thiết kế: mặc định gọn, mỗi cặp vai trò × tài nguyên một câu được, một câu ngoài phạm vi
  (--kiem-thu day_du: mỗi quyền mức bản ghi một cặp).
- Ngoài playground.dsl (toàn bộ) còn tách playground_theo_mang/<mảng>.dsl: mỗi tệp chỉ có tài nguyên của một mảng,
  cộng cây và vai trò cầu nối cần để tính phạm vi; tự kiểm riêng từng tệp (--mot-tep để bỏ).
- Tự kiểm: tính quyền trên đồ thị DSL (role, derive, assign, relate) cho mọi người × bản ghi × hành động mức bản ghi
  và so với ý đồ thiết kế; lệch là lỗi của bước xuất.
Điều kiện ràng buộc (trạng thái, không tự duyệt, khoá…) DSL chưa biểu diễn được: ghi thành chú thích và báo cáo; assert bỏ qua điều kiện.
Ghi: playground.dsl, playground_theo_mang/*.dsl, bao_cao_playground.md
"""
import argparse, collections, json, os, re, subprocess, sys, unicodedata

sys.stdout.reconfigure(encoding="utf-8"); sys.stderr.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
KIEU_DSL = {"string": "string", "number": "number", "bool": "bool", "time": "string", "array": "string"}


def doc(p, md=None):
    if not os.path.exists(p):
        return md
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def q_str(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', "'") + '"'


def gia_tri(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    return q_str(v)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("thu_muc"); ap.add_argument("--so-nhanh", type=int, default=2, help="số đơn vị con của mỗi nút trong cây mẫu")
    ap.add_argument("--kiem-thu", choices=["gon", "day_du"], default="gon", help="gon: mỗi cặp vai trò × tài nguyên một câu được, một câu ngoài phạm vi; day_du: mỗi quyền mức bản ghi")
    ap.add_argument("--mot-tep", action="store_true", help="chỉ ghi playground.dsl, không tách tệp theo mảng")
    ap.add_argument("--tai-nguyen", help="chỉ xuất các tài nguyên này (key cách nhau bởi dấu phẩy) ra playground_chon/<key>__<key>.dsl, không ghi lại tệp khác")
    ap.add_argument("--chua-xac-nhan", action="store_true", help="xuất dù BA chưa xác nhận bản xem trước (chỉ để thử kỹ thuật)")
    a = ap.parse_args()
    a.theo_mang = not a.mot_tep
    wd = a.thu_muc
    if not a.chua_xac_nhan:
        tt = json.loads(subprocess.run([sys.executable, "-I", os.path.join(HERE, "xac_nhan.py"), "trang-thai", wd],
                                       capture_output=True, text=True, encoding="utf-8", check=True).stdout)
        if not tt["da_xac_nhan_xem_truoc"]:
            sys.exit("BA chưa xác nhận bản xem trước (hoặc thiết kế / ý kiến đã đổi sau khi xác nhận). "
                     "Chạy xac_nhan.py xem-truoc, để BA xác nhận, ghi bằng xac_nhan.py ghi <lv> xem_truoc dong_y, rồi xuất lại.")
    p_tk, p_im = os.path.join(wd, "thiet_ke_phan_quyen.json"), os.path.join(wd, "phan_quyen_import.json")
    p_rs = os.path.join(wd, "ra_soat.json")
    moc = max(os.path.getmtime(p) for p in (p_tk, p_rs) if os.path.exists(p))
    if not os.path.exists(p_im) or os.path.getmtime(p_im) < moc:
        subprocess.run([sys.executable, "-I", os.path.join(HERE, "xuat_json.py"), wd], check=True)
    D, IM = doc(p_tk), doc(p_im)
    RS = (doc(p_rs, {"muc": {}}) or {}).get("muc", {})
    TN = {t["key"]: t for t in D["tai_nguyen"]}
    VT = {v["key"]: v for v in D["vai_tro"]}
    PV = {p["key"]: p for p in D["pham_vi"]}
    DK = {d["key"]: d for d in D["dieu_kien"]}
    HD = {(t["key"], h["key"]): h for t in D["tai_nguyen"] for h in t["hanh_dong"]}
    R = {r["key"]: r for r in IM["resources"]}
    G = {g["key"]: g for g in IM["roles"]}
    co_abac = bool(IM.get("condition_set_rules"))
    BC = collections.defaultdict(list)

    # ---------- quyền hiệu lực theo ý đồ thiết kế (cùng cách tính với xuat_json.py) ----------
    cau_cua = {k: c["key"] for c in D.get("cau_mo_ta", []) for k in c["quyen"]}
    HL = []
    for q in D["quyen"]:
        kq = RS.get(q["khoa"], {}).get("ket_qua") or RS.get(cau_cua.get(q["khoa"], ""), {}).get("ket_qua")
        t = q["trang_thai"]
        if kq == "khong_dong_y":
            t = {"them": "bo", "bo": "giu"}.get(t, t)
        if t != "bo":
            HL.append(q)

    # ---------- dữ liệu mẫu: cây ----------
    cay_cua_vt = {}
    for v in VT.values():
        if v["loai_pham_vi"] == "theo_don_vi" and TN.get(v.get("gan_tren"), {}).get("loai") == "cay":
            cay_cua_vt[v["key"]] = v["gan_tren"]
    co_toan_ht = any(v["loai_pham_vi"] == "toan_he_thong" for v in VT.values())
    INST = collections.OrderedDict()     # id "res:key" → {"type", "key", "ten", "attrs", "rel": {quan_he: id}}
    CAY = {}                             # cây → {"goc", "cap": [nhãn], "nut_theo_sau": {độ sâu: [id]}, "cha": {id: id}}

    def them_inst(rk, key, ten, attrs=None):
        i = f"{rk}:{key}"
        INST[i] = {"type": rk, "key": key, "ten": ten, "attrs": attrs or {}, "rel": {}}
        return i

    for ck, t in TN.items():
        if t.get("loai") != "cay":
            continue
        caps = []
        for vk, g in cay_cua_vt.items():
            c = VT[vk].get("cap") or VT[vk]["ten"]
            if g == ck and c not in caps:
                caps.append(c)
        goc_ten = next((v.get("cap") for v in VT.values() if v["loai_pham_vi"] == "toan_he_thong" and v.get("cap")), None) or t["ten"]
        nhan = ([goc_ten] if co_toan_ht or not caps else []) + caps
        if not nhan:
            nhan = [t["ten"]]
        rel_cha = next((r["key"] for r in t.get("quan_he", []) if r["toi"] == ck), None)
        theo_sau, cha = collections.defaultdict(list), {}
        goc = them_inst(ck, "goc", nhan[0])
        theo_sau[0].append(goc)
        for d in range(1, len(nhan)):
            for p in theo_sau[d - 1]:
                for j in range(a.so_nhanh):
                    hau = INST[p]["key"].replace("goc", "") + "abcdefgh"[j] if d == 1 else INST[p]["key"] + str(j + 1)
                    c = them_inst(ck, hau, f"{nhan[d]} {hau.upper()}")
                    cha[c] = p; theo_sau[d].append(c)
                    if rel_cha:
                        INST[c]["rel"][rel_cha] = p
        CAY[ck] = {"goc": goc, "cap": nhan, "theo_sau": theo_sau, "cha": cha}
    for ck, t in TN.items():      # cây gắn vào cây khác (M-01): nút cùng vị trí
        for r in t.get("quan_he", []):
            if t.get("loai") == "cay" and r["toi"] != ck and r["toi"] in CAY and ck in CAY:
                ds_a = [i for d in sorted(CAY[ck]["theo_sau"]) for i in CAY[ck]["theo_sau"][d]]
                ds_b = [i for d in sorted(CAY[r["toi"]]["theo_sau"]) for i in CAY[r["toi"]]["theo_sau"][d]]
                for x, y in zip(ds_a, ds_b):
                    INST[x]["rel"][r["key"]] = y

    def do_sau(ck, i):
        return next(d for d, ds in CAY[ck]["theo_sau"].items() if i in ds)

    def noi_sang(i, cay):        # nút của cây khác ứng với nút i: đi lên tới nút có quan hệ sang cây đó
        for x in to_tien(INST[i]["type"], i):
            t = next((v for k, v in INST[x]["rel"].items() if INST[v]["type"] == cay), None)
            if t:
                return t
        return None

    def to_tien(ck, i):          # i và mọi nút cha
        out = [i]
        while i in CAY[ck]["cha"]:
            i = CAY[ck]["cha"][i]; out.append(i)
        return out

    # ---------- dữ liệu mẫu: người dùng, gán vai trò ----------
    USERS = collections.OrderedDict()   # key → {"ten", "gan": [(vai trò, id nút hoặc None)]}
    for vk, v in VT.items():
        if v["loai_pham_vi"] == "theo_ban_ghi":
            continue          # người lập (ABAC): không gán, xét theo created_by
        if v["loai_pham_vi"] == "toan_he_thong":
            USERS[vk] = {"ten": f"{v['ten']}", "gan": [(vk, None)], "vai_tro": vk}
            continue
        ck = cay_cua_vt.get(vk)
        if not ck:
            if TN.get(v.get("gan_tren"), {}).get("loai") != "cay" and v.get("gan_tren") in TN:
                continue      # gán trên bản ghi dữ liệu (ví dụ cơ sở do vai trò quản lý trực tiếp): dựng sau khi có bản ghi
            BC["Vai trò theo đơn vị không gán trên cây: chưa dựng người dùng mẫu"].append(vk); continue
        d = CAY[ck]["cap"].index(v.get("cap") or v["ten"])
        nuts = CAY[ck]["theo_sau"][d]
        chon = [nuts[0]] + ([nuts[-1]] if len(nuts) > 1 else [])
        for n in chon:
            uk = f"{vk}_{INST[n]['key']}"
            USERS[uk] = {"ten": f"{v['ten']} – {INST[n]['ten']}", "gan": [(vk, n)], "vai_tro": vk}

    # ---------- dữ liệu mẫu: bản ghi ----------
    tao_ds = collections.defaultdict(list)   # tài nguyên → các vai trò theo đơn vị được thêm (để chọn người lập)
    for q in HL:
        if q["hanh_dong"] == "them_moi" and VT[q["vai_tro"]]["loai_pham_vi"] == "theo_don_vi" and q["vai_tro"] not in tao_ds[q["tai_nguyen"]]:
            tao_ds[q["tai_nguyen"]].append(q["vai_tro"])
    tao_boi = {}
    for rk, t in TN.items():
        if t.get("loai") == "cay":
            continue
        rel_cay = [r for r in t.get("quan_he", []) if r["toi"] in CAY and not r["key"].startswith("cap_duyet") and r["toi"] != rk]
        rel_cds = [r for r in t.get("quan_he", []) if r["key"].startswith("cap_duyet") and r["toi"] in CAY]
        rel_cd = rel_cds[0] if rel_cds else None
        vd = t.get("vong_doi") or {}
        tts = [x for k in ("dang_soan", "cho_duyet", "da_duyet") for x in vd.get(k, [])[:1]]
        at_keys = {x["key"] for x in t.get("thuoc_tinh", [])}
        cho = vd.get("cho_duyet") or ["CHO_DUYET"]
        ck = rel_cay[0]["toi"] if rel_cay else None
        # người lập mẫu: vai trò được thêm và gán trên đúng cây mà bản ghi thuộc về
        cv = [v for v in tao_ds.get(rk, []) if cay_cua_vt.get(v) == ck]
        if cv:
            tao_boi[rk] = cv[0]
        noi_lap = [u["gan"][0][1] for u in USERS.values() if u["vai_tro"] == tao_boi.get(rk)] if ck else []
        if ck and rel_cd and tts:
            # luồng duyệt: dự thảo ở mỗi đơn vị có người lập; một bản ghi chờ duyệt ở từng cấp phía trên người lập đầu tiên; một bản ghi đã duyệt
            goc_lap = noi_lap[0] if noi_lap else CAY[ck]["theo_sau"][max(CAY[ck]["theo_sau"])][0]
            mau = [(n, tts[0], None) for n in (noi_lap or [goc_lap])]
            # một bản ghi chờ duyệt ở từng cấp, lần lượt trên từng cây duyệt (cây của người lập trước, rồi cây nối tới)
            for rc in sorted(rel_cds, key=lambda r: r["toi"] != ck):
                nut = goc_lap if rc["toi"] == ck else noi_sang(goc_lap, rc["toi"])
                mau += [(goc_lap, cho[0], (rc["key"], cd)) for cd in (to_tien(rc["toi"], nut) if nut else [])]
            mau += [(goc_lap, x, None) for x in tts[2:3]]
        elif ck:
            sau = max(CAY[ck]["theo_sau"])
            nuts = CAY[ck]["theo_sau"][sau] + (CAY[ck]["theo_sau"][1][:1] if sau > 1 else [])
            mau = [(n, tts[(j % len(tts))] if tts else None, None) for j, n in enumerate(nuts)]
        else:
            mau = [(None, tts[j % len(tts)] if tts else None, None) for j in range(2)]
        for j, (n, tt, cd) in enumerate(mau, 1):
            attrs = {}
            if "trang_thai" in at_keys and tt:
                attrs["trang_thai"] = tt
            if "da_khoa" in at_keys:
                attrs["da_khoa"] = j % 3 == 0
            ten = f"{t['ten']} {j}" + (f" của {INST[n]['ten']}" if n else "") + (f", chờ {INST[cd[1]]['ten']} duyệt" if cd else "")
            if "nguoi_lap" in at_keys and n and rk in tao_boi:
                ung = [uk for uk, u in USERS.items() if u["vai_tro"] == tao_boi[rk] and u["gan"][0][1] == n]
                if ung:
                    attrs["nguoi_lap"] = ung[0]
            i = them_inst(rk, f"{rk}_{j}", ten, attrs)
            if n:
                for r in rel_cay:
                    if r["toi"] == ck:
                        INST[i]["rel"][r["key"]] = n
            if cd:
                INST[i]["rel"][cd[0]] = cd[1]
    for rk, t in TN.items():      # quan hệ tới dữ liệu khác: bản ghi đầu tiên
        for r in t.get("quan_he", []):
            if r["toi"] not in CAY and r["toi"] in TN:
                dich = next((i for i, x in INST.items() if x["type"] == r["toi"]), None)
                for i, x in INST.items():
                    if x["type"] == rk and dich:
                        x["rel"].setdefault(r["key"], dich)

    # vai trò gán trên bản ghi dữ liệu (không phải cây): người dùng ở bản ghi đầu và cuối của loại đó
    for vk, v in VT.items():
        g = v.get("gan_tren")
        if v["loai_pham_vi"] != "theo_don_vi" or cay_cua_vt.get(vk) or g not in TN or TN[g].get("loai") == "cay":
            continue
        ids = [i for i, x in INST.items() if x["type"] == g]
        for n in ids[:1] + ids[-1:] if len(ids) > 1 else ids:
            USERS[f"{vk}_{INST[n]['key']}"] = {"ten": f"{v['ten']} – {INST[n]['ten']}", "gan": [(vk, n)], "vai_tro": vk}
    # người lập cho bản ghi chưa có: người dùng được thêm loại đó và gán trên bản ghi cha mà bản ghi trỏ tới
    for i, x in INST.items():
        rk = x["type"]
        if TN[rk].get("loai") == "cay" or "nguoi_lap" in x["attrs"] or "nguoi_lap" not in {a["key"] for a in TN[rk].get("thuoc_tinh", [])}:
            continue
        cha = set(x["rel"].values())
        ung = [uk for uk, u in USERS.items() if u["vai_tro"] in tao_ds.get(rk, []) and u["gan"][0][1] in cha]             or [uk for uk, u in USERS.items() if any(q["hanh_dong"] == "them_moi" and q["tai_nguyen"] == rk for q in HL if q["vai_tro"] == u["vai_tro"]) and u["gan"][0][1] in cha]
        if ung:
            x["attrs"]["nguoi_lap"] = ung[0]

    # vai trò toàn hệ thống có vai trò trên nút cây (phạm vi theo quan hệ, ví dụ cấp duyệt cao nhất): gán thêm ở gốc
    for uk, u in USERS.items():
        vk = u["vai_tro"]
        if VT[vk]["loai_pham_vi"] == "toan_he_thong":
            for ck, c in CAY.items():
                if vk in R.get(ck, {}).get("roles", {}):
                    u["gan"].append((vk, c["goc"]))
                    BC["Vai trò toàn hệ thống được gán thêm ở nút gốc của cây để dùng phạm vi theo quan hệ"].append(f"{uk} → {c['goc']}")
        else:   # vai trò theo đơn vị có quyền mức danh sách: gán thêm vai trò chung
            if vk in G:
                u["gan"].append((vk, None))

    # ---------- ý đồ thiết kế: được hay không (bỏ qua điều kiện) ----------
    def qh_pv(p, rk):
        m = p.get("quan_he")
        return m.get(rk, m.get("*")) if isinstance(m, dict) else m

    def nut_cua(i, rel, ck):
        x = INST[i]
        if rel == "(gan_truc_tiep)":
            return i
        if x["type"] == ck and rel == next((r["key"] for r in TN[ck].get("quan_he", []) if r["toi"] == ck), None):
            return i                       # chính cây, phạm vi lan xuống qua cấp trên
        t = x["rel"].get(rel)
        while t and INST[t]["type"] != ck:  # hai bước: bản ghi → tổ chức trung gian → nơi gán
            nxt = next((v for k, v in INST[t]["rel"].items() if INST[v]["type"] == ck and k != "cap_tren"), None) \
                or next((v for k, v in INST[t]["rel"].items() if v != t), None)
            t = nxt if nxt != t else None
        return t

    QUYEN_VT = collections.defaultdict(list)
    for q in HL:
        QUYEN_VT[(q["vai_tro"], q["tai_nguyen"], q["hanh_dong"])].append(q)

    def y_do(uk, act, i):
        x, u = INST[i], USERS.get(uk)
        ly = []
        gan = list(u["gan"]) if u else []
        if "nguoi_lap_ban_ghi" in VT and x["attrs"].get("nguoi_lap") == uk:
            gan.append(("nguoi_lap_ban_ghi", i))
        for vk, n in gan:
            for q in QUYEN_VT.get((vk, x["type"], act), []):
                p = PV.get(q["pham_vi"]) or {}
                kieu = p.get("kieu") or q["pham_vi"]
                if kieu == "danh_sach":
                    return None             # hành động mức danh sách: không đánh giá theo bản ghi
                if kieu == "toan_he_thong" or (VT[vk]["loai_pham_vi"] == "toan_he_thong" and not p):
                    ly.append((q, "toàn hệ thống")); continue
                if kieu in ("do_minh_lap", "duoc_giao"):
                    if x["attrs"].get("nguoi_lap" if kieu == "do_minh_lap" else "nguoi_duoc_giao") == uk:
                        ly.append((q, "do chính mình lập"))
                    continue
                if not n:
                    continue
                ck = INST[n]["type"]
                t = nut_cua(i, qh_pv(p, x["type"]), ck)
                if not t:
                    continue
                if kieu in ("don_vi_minh", "cap_duyet") and t == n:
                    ly.append((q, "đơn vị mình" if kieu == "don_vi_minh" else "đang chờ đơn vị mình duyệt"))
                elif kieu == "don_vi_minh_va_cap_duoi" and n in to_tien(ck, t):
                    ly.append((q, "đơn vị mình hoặc cấp dưới"))
                elif kieu == "don_vi_minh_va_cap_duoi_truc_tiep" and (t == n or CAY[ck]["cha"].get(t) == n):
                    ly.append((q, "đơn vị mình hoặc cấp dưới trực tiếp"))
        return ly

    # ---------- tính trên đồ thị DSL (role, derive, assign, relate) ----------
    def do_thi(Rf, gan_cua, INSTf):
        co = collections.defaultdict(set)          # (user, inst) → vai trò trên tài nguyên
        for uk, gl in gan_cua.items():
            for vk, n in gl:
                if n:
                    co[(uk, n)].add(vk)
        doi = True
        while doi:
            doi = False
            for i, x in INSTf.items():
                for rk_role, ro in Rf.get(x["type"], {}).get("roles", {}).items():
                    for g in (ro.get("grantedTo") or {}).get("users_with_role", []):
                        t = x["rel"].get(g["linked_by_relation"])
                        if not t or t not in INSTf or INSTf[t]["type"] != g["on_resource"]:
                            continue
                        for uk in gan_cua:
                            if g["role"] in co[(uk, t)] and rk_role not in co[(uk, i)]:
                                co[(uk, i)].add(rk_role); doi = True
        return co

    CS = {c["key"]: c for c in IM.get("condition_sets", [])}
    UATTR = {"trang_thai": "DANG_HOAT_DONG"}           # thuộc tính người dùng mẫu (userset tài khoản đang hoạt động)

    def thoa(c, uk, x):
        def mot(b):
            trai = b["left"]
            ua = dict(UATTR, ma_nguoi_dung=uk)
            l = ua.get(trai[5:]) if trai.startswith("user.") else x["attrs"].get(trai[9:]) if x else None
            r = ua.get(b["right"][5:]) if str(b["right"]).startswith("user.") else b["right"]
            return {"EQUALS": l == r, "EQUALS_REF": l == r, "NOT_EQUALS": l != r, "IN": l in (r if isinstance(r, list) else [r])}.get(b["operator"], False)
        return any(all(mot(b) for b in nh["all_of"]) for nh in (c["conditions"].get("any_of") or []))

    ban_ghi = lambda rk: [h["key"] for h in TN[rk]["hanh_dong"] if h["muc"] == "ban_ghi"]

    def tu_kiem(Rf, Gperm, gan_cua, INSTf, CSRf, chi_tn=None):
        """So đồ thị DSL (đã lọc) với ý đồ thiết kế; trả (số cặp, danh sách lệch)."""
        CO_ = do_thi(Rf, gan_cua, INSTf)

        def duoc(uk, act, i):
            x = INSTf[i]; perm = f"{x['type']}:{act}"
            for r in CSRf:
                if r["permission"] == perm and thoa(CS[r["user_set"]], uk, None) and CS[r["resource_set"]].get("resource") == x["type"] and thoa(CS[r["resource_set"]], uk, x):
                    return True
            for vk, n in gan_cua[uk]:
                if n is None and perm in Gperm.get(vk, ()):
                    return True
            return any(perm in Rf[x["type"]]["roles"][r]["permissions"] for r in CO_[(uk, i)] if r in Rf[x["type"]]["roles"])

        so, lc = 0, []
        for uk in gan_cua:
            for i, x in INSTf.items():
                if chi_tn is not None and x["type"] not in chi_tn:
                    continue
                for act in ban_ghi(x["type"]):
                    yd = y_do(uk, act, i)
                    if yd is None:
                        continue
                    so += 1
                    if bool(yd) != duoc(uk, act, i):
                        lc.append(f"{uk} {act} {i}: thiết kế {'được' if yd else 'không'} · DSL {'được' if not yd else 'không'}")
        return so, lc

    GPERM = {g["key"]: set(g["permissions"]) for g in IM["roles"]}
    so_cap, lech = tu_kiem(R, GPERM, {uk: u["gan"] for uk, u in USERS.items()}, INST, IM.get("condition_set_rules", []))

    # ---------- assert ----------
    # gọn (mặc định): mỗi cặp vai trò × tài nguyên một câu được, một câu ngoài phạm vi; mỗi cặp có quyền AI đề xuất bỏ một câu
    # day_du: mỗi quyền mức bản ghi một cặp được / không được (như trước)
    AS = []        # {"uk", "can", "act", "i", "ghi"}
    ten_hd = lambda rk, act: HD[(rk, act)]["ten"].lower()

    def liet_ke(rk, acts, toi_da=5):
        ds = [ten_hd(rk, a) for a in acts]
        return ", ".join(ds[:toi_da]) + (f" và {len(ds) - toi_da} quyền khác" if len(ds) > toi_da else "")

    nhom = collections.OrderedDict()
    for (vk, rk, act), qs in QUYEN_VT.items():
        if HD[(rk, act)]["muc"] != "ban_ghi" or VT[vk]["loai_pham_vi"] == "theo_ban_ghi":
            continue
        nhom.setdefault((vk, rk), []).append(act)
    for (vk, rk), acts in nhom.items():
        ung = [uk for uk, u in USERS.items() if u["vai_tro"] == vk]
        inst = [i for i, x in INST.items() if x["type"] == rk]
        cac = acts if a.kiem_thu == "day_du" else [acts]
        for act_nhom in cac:
            ds_act = act_nhom if isinstance(act_nhom, list) else [act_nhom]
            duoc = next(((uk, act, i, yd) for act in ds_act for uk in ung for i in inst if (yd := y_do(uk, act, i))), None)
            khong = next(((uk, act, i) for act in ds_act for uk in ung for i in inst if y_do(uk, act, i) == []), None)
            if a.kiem_thu == "day_du":
                ghi = f"{VT[vk]['ten']} – {ten_hd(rk, ds_act[0])} – {TN[rk]['ten']}"
            else:
                ghi = f"được {liet_ke(rk, ds_act)}"
            if duoc:
                AS.append({"uk": duoc[0], "can": True, "act": duoc[1], "i": duoc[2], "ghi": f"{ghi} ({duoc[3][0][1]})"})
            if khong:
                AS.append({"uk": khong[0], "can": False, "act": khong[1], "i": khong[2],
                           "ghi": f"{ghi} (ngoài phạm vi)" if a.kiem_thu == "day_du" else f"bản ghi ngoài phạm vi của quyền {ten_hd(rk, khong[1])}"})
    bo = collections.OrderedDict()   # quyền AI đề xuất bỏ (sau rà soát) mà không vai trò nào của người đó còn giữ
    for q in D["quyen"]:
        if q in HL or HD[(q["tai_nguyen"], q["hanh_dong"])]["muc"] != "ban_ghi":
            continue
        bo.setdefault((q["vai_tro"], q["tai_nguyen"]), []).append(q["hanh_dong"])
    for (vk, rk), acts in bo.items():
        uk = next((uk for uk, u in USERS.items() if u["vai_tro"] == vk), None)
        i = next((i for i, x in INST.items() if x["type"] == rk), None)
        if not (uk and i):
            continue
        cac = [[x] for x in dict.fromkeys(acts)] if a.kiem_thu == "day_du" else [list(dict.fromkeys(acts))]
        for ds_act in cac:
            act = next((x for x in ds_act if y_do(uk, x, i) == []), None)
            if act:
                ghi = (f"{VT[vk]['ten']} – {ten_hd(rk, act)} – {TN[rk]['ten']}" if a.kiem_thu == "day_du"
                       else liet_ke(rk, ds_act))
                AS.append({"uk": uk, "can": False, "act": act, "i": i, "ghi": f"AI đề xuất bỏ: {ghi}"})
    AS = list({(x["uk"], x["can"], x["act"], x["i"]): x for x in AS}.values())

    # ---------- ghi DSL ----------
    ph = D.get("phan_he") or {}
    TENANT = "mac_dinh"   # tenant mẫu; bản ghi và assert ghi rõ @mac_dinh (playground mặc định coi là tenant «default»)
    TEN_RO = {k for r in IM["resources"] for k in r["roles"]}
    ten_chung = lambda k: f"{k}__quyen_chung" if k in TEN_RO else k   # tránh trùng key vai trò trên tài nguyên
    OPD = {"EQUALS": "==", "EQUALS_REF": "==", "NOT_EQUALS": "!="}
    rb = collections.defaultdict(list)      # điều kiện → [(tài nguyên, mô tả quyền)]
    for q in HL:
        for d in q["dieu_kien"]:
            if d in DK:
                rb[d].append((q["tai_nguyen"], f"{q['vai_tro']} · {ten_hd(q['tai_nguyen'], q['hanh_dong'])} {TN[q['tai_nguyen']]['ten']}"))

    def bao_dong(rs):
        """Tài nguyên + vai trò cần giữ để các quyền trên rs tính đúng: vai trò cầu nối mà derive nhắc tới, cây mà quan hệ trỏ tới."""
        giu_tn, giu_ro = set(rs), {(rk, k) for rk in rs for k in R[rk]["roles"]}
        hang = list(giu_ro)
        while hang:
            rk, k = hang.pop()
            for g in (R[rk]["roles"][k].get("grantedTo") or {}).get("users_with_role", []):
                x = (g["on_resource"], g["role"])
                giu_tn.add(x[0])
                if g["role"] in R[x[0]]["roles"] and x not in giu_ro:
                    giu_ro.add(x); hang.append(x)
        doi = True
        while doi:                        # cây và dữ liệu mà quan hệ của tài nguyên giữ lại trỏ tới
            doi = False
            for rk in list(giu_tn):
                for r in R[rk]["relations"].values():
                    if r["resource"] not in giu_tn:
                        giu_tn.add(r["resource"]); doi = True
        return giu_tn, giu_ro

    def viet(ten_tep, rs, tieu_de):
        """Ghi một tệp DSL chỉ gồm quyền trên các tài nguyên rs (None = toàn bộ). Trả số liệu và kết quả tự kiểm."""
        toan_bo = rs is None
        rs = set(R) if toan_bo else set(rs)
        giu_tn, giu_ro = (set(R), {(rk, k) for rk in R for k in R[rk]["roles"]}) if toan_bo else bao_dong(rs)
        Rf = {}
        for rk in R:
            if rk not in giu_tn:
                continue
            r = R[rk]
            Rf[rk] = dict(r, roles=collections.OrderedDict((k, ro) for k, ro in r["roles"].items() if (rk, k) in giu_ro),
                          actions=r["actions"] if rk in rs else [])
        Gp = {g["key"]: [p for p in g["permissions"] if p.split(":", 1)[0] in rs] for g in IM["roles"]}
        CSRf = [r for r in IM.get("condition_set_rules", []) if r["permission"].split(":", 1)[0] in rs]
        vt_co = {q["vai_tro"] for q in HL if q["tai_nguyen"] in rs}
        gan_cua = collections.OrderedDict()
        for uk, u in USERS.items():
            if u["vai_tro"] not in vt_co:
                continue
            gl = [(vk, n) for vk, n in u["gan"] if (n is None and Gp.get(vk)) or (n and (INST[n]["type"], vk) in giu_ro)]
            if gl:
                gan_cua[uk] = gl
        INSTf = collections.OrderedDict((i, x) for i, x in INST.items() if x["type"] in giu_tn)
        so, lc = tu_kiem(Rf, {k: set(v) for k, v in Gp.items()}, gan_cua, INSTf, CSRf, None if toan_bo else rs)
        ASf = [x for x in AS if INST[x["i"]]["type"] in rs and x["uk"] in gan_cua]

        vd_cau_noi = next((k for r in Rf.values() for k in r["roles"] if "__" in k and not k.endswith("__quyen_chung")), None)
        L = [f"// {tieu_de} — sinh tự động từ thiet_ke_phan_quyen.json bởi skill thiet-ke-phan-quyen.",
             "// Người dùng, bản ghi, quan hệ là DỮ LIỆU MẪU để thử. Điều kiện ràng buộc (trạng thái, không tự duyệt, khoá…) chưa có cú pháp: xem chú thích cuối tệp.",
             "// Tên vai trò cầu nối: <vai trò>__<phạm vi>" + (f", ví dụ {vd_cau_noi}" if vd_cau_noi else "") + "; …__quyen_chung là quyền không theo bản ghi (thêm mới, xuất, nhập).", "",
             f"tenant {TENANT} {q_str(ph.get('ten') or 'Mặc định')}", ""]
        for rk, r in Rf.items():
            L.append(f"resource {rk} {q_str(r['name'])} {{")
            if r["actions"]:
                L.append("  actions " + ", ".join(r["actions"]))
            if r["attributes"] and rk in rs:
                L.append("  attributes { " + ", ".join(f"{k}: {KIEU_DSL.get(x['type'], 'string')}" for k, x in r["attributes"].items()) + " }")
            if r["relations"]:
                L.append("  relations { " + ", ".join(f"{k}: {x['resource']}" for k, x in r["relations"].items()) + " }")
            if r["roles"]:
                L.append("")
            for k, ro in r["roles"].items():
                acts = [p.split(":", 1)[1] for p in ro["permissions"]] if rk in rs else []
                L.append(f"  role {k}" + (": " + ", ".join(acts) if acts else ""))
            der = [(k, g) for k, ro in r["roles"].items() for g in (ro.get("grantedTo") or {}).get("users_with_role", [])
                   if (g["on_resource"], g["role"]) in giu_ro or g["role"] not in R[g["on_resource"]]["roles"]]
            if der:
                L.append("")
                for k, g in der:
                    L.append(f"  derive {k} from {g['on_resource']}#{g['role']} via {g['linked_by_relation']}")
            L += ["}", ""]
        for g in IM["roles"]:
            if Gp[g["key"]]:
                L.append(f"role {ten_chung(g['key'])} {q_str(g['name'])}: " + ", ".join(Gp[g["key"]]))
        if CSRf:
            L += ["", "// ABAC: người lập xem bản ghi của mình (KT-03)"]
            dung = {r["user_set"] for r in CSRf} | {r["resource_set"] for r in CSRf}
            for c in IM["condition_sets"]:
                if c["key"] not in dung:
                    continue
                bt = " and ".join(f"{b['left']} {OPD.get(b['operator'], b['operator'])} " + (b["right"] if b["operator"] == "EQUALS_REF" else gia_tri(b["right"]))
                                  for nh in c["conditions"]["any_of"] for b in nh["all_of"])
                L.append(f"userset {c['key']} {q_str(c['name'])} where {bt}" if c["type"] == "userset" else f"resourceset {c['key']} {q_str(c['name'])} on {c['resource']} where {bt}")
            gom = collections.defaultdict(list)
            for r in CSRf:
                gom[(r["user_set"], r["resource_set"])].append(r["permission"].split(":", 1)[1])
            for (us, rset), acts in gom.items():
                L.append(f"permit {us} to {rset}: {', '.join(acts)}")
        L += ["", "// ---------- dữ liệu mẫu ----------", ""]
        for uk in gan_cua:
            L.append(f"user {uk} {q_str(USERS[uk]['ten'])}" + (f' {{ trang_thai: "DANG_HOAT_DONG", ma_nguoi_dung: "{uk}" }}' if CSRf else ""))
        L.append("")
        for i, x in INSTf.items():
            at = x["attrs"] if x["type"] in rs else {}
            L.append(f"instance {i} @{TENANT}" + (" { " + ", ".join(f"{k}: {gia_tri(v)}" for k, v in at.items()) + " }" if at else "") + f"  // {x['ten']}")
        L.append("")
        for uk, gl in gan_cua.items():
            for vk, n in gl:
                L.append(f"assign {uk} {vk} on {n}" if n else f"assign {uk} {ten_chung(vk)} @{TENANT}")
        L.append("")
        for i, x in INSTf.items():
            for rel, t in x["rel"].items():
                if t in INSTf and rel in Rf[x["type"]]["relations"]:
                    L.append(f"relate {t} {rel} {i}")
        L += ["", "// ---------- kiểm chứng (bỏ qua điều kiện ràng buộc) ----------", ""]
        L += [f"assert {x['uk']} {'can' if x['can'] else 'cannot'} {x['act']} {x['i']} @{TENANT}  // {x['ghi']}" for x in ASf]
        dk_tep = {d: sorted({m for rk, m in ds if rk in rs}) for d, ds in rb.items()}
        dk_tep = {d: ds for d, ds in dk_tep.items() if ds}
        if dk_tep:
            L += ["", "// ---------- điều kiện ràng buộc chưa biểu diễn được trong DSL ----------"]
            for d, ds in dk_tep.items():
                bt = " VÀ ".join(f"{b['trai']} {b['phep']} {b['phai']}" for b in DK[d].get("bieu_thuc", []))
                L.append(f"// {DK[d]['ten']} ({bt}):")
                L += [f"//   - {m}" for m in ds]
        noi_dung = "\n".join(L) + "\n"
        p = os.path.join(wd, ten_tep)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(noi_dung)
        return {"tep": ten_tep, "kb": round(len(noi_dung.encode("utf-8")) / 1024), "tn": len([k for k in Rf if k in rs]), "tn_ho_tro": len(Rf) - len([k for k in Rf if k in rs]),
                "vt": sum(len(r["roles"]) for r in Rf.values()) + len([1 for v in Gp.values() if v]), "nd": len(gan_cua), "bg": len(INSTf),
                "as": len(ASf), "so": so, "lech": lc}

    def slug(s):
        s = s.lower().replace("đ", "d")
        s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
        return "_".join(re.findall(r"[a-z0-9]+", s))

    if a.tai_nguyen:
        chon = [k.strip() for k in a.tai_nguyen.split(",") if k.strip()]
        thieu = [k for k in chon if k not in R or not R[k]["actions"]]
        if thieu:
            sys.exit(f"Không có tài nguyên (hoặc không có hành động): {', '.join(thieu)}")
        k = viet(os.path.join("playground_chon", "__".join(chon) + ".dsl"), chon, f"Phân quyền «{ph.get('ten', '')}» — chỉ {', '.join(chon)}")
        print(f"{k['tep']}: {k['kb']} KB · {k['tn']} tài nguyên (+{k['tn_ho_tro']} hỗ trợ) · {k['vt']} vai trò · {k['nd']} người dùng · {k['as']} assert · tự kiểm {k['so']} cặp, {len(k['lech'])} lệch")
        for x in k["lech"][:5]:
            print("  LỆCH", x)
        return
    KQ = [viet("playground.dsl", None, f"Phân quyền phân hệ «{ph.get('ten', '')}» — toàn bộ")]
    if a.theo_mang:
        mang = collections.OrderedDict()
        for t in D["tai_nguyen"]:
            if t["key"] in R and R[t["key"]]["actions"]:
                mang.setdefault(t.get("mang") or "Khác", []).append(t["key"])
        for m, rs in mang.items():
            KQ.append(viet(os.path.join("playground_theo_mang", f"{slug(m)}.dsl"), rs, f"Phân quyền «{ph.get('ten', '')}» — mảng {m}"))

    B = [f"# Báo cáo xuất DSL playground — {ph.get('ten', '')}", "",
         f"- Kiểm thử: {'gọn (mỗi cặp vai trò × tài nguyên một câu được, một câu ngoài phạm vi)' if a.kiem_thu == 'gon' else 'đầy đủ (mỗi quyền mức bản ghi)'}.",
         f"- Dữ liệu mẫu: {len(USERS)} người dùng, {len(INST)} bản ghi (gồm nút cây).", "",
         "| Tệp | KB | Tài nguyên (+ hỗ trợ) | Vai trò | Người dùng | Bản ghi | Assert | Tự kiểm |",
         "|---|---|---|---|---|---|---|---|"]
    for k in KQ:
        B.append(f"| `{k['tep']}` | {k['kb']} | {k['tn']} (+{k['tn_ho_tro']}) | {k['vt']} | {k['nd']} | {k['bg']} | {k['as']} | {k['so']} cặp, **{len(k['lech'])} lệch** |")
    B.append("")
    B.append("«Hỗ trợ» là cây và tài nguyên được giữ lại chỉ để tính phạm vi (không có hành động trong tệp đó).")
    B.append("")
    for k in KQ:
        if k["lech"]:
            B += [f"## Lệch trong `{k['tep']}`", ""] + [f"- {x}" for x in k["lech"][:80]] + [""]
    B += ["## Giới hạn của DSL hiện tại", "",
          "- Điều kiện ràng buộc (thu hẹp quyền theo trạng thái, không tự duyệt, khoá) chưa có cú pháp: DSL chỉ có `permit` cấp thêm quyền. Assert bỏ qua điều kiện; chú thích cuối tệp liệt kê điều kiện từng quyền.",
          "- Hành động mức danh sách (thêm, xuất, nhập) nằm ở vai trò chung `…__quyen_chung`, nên trong DSL áp cho mọi bản ghi; danh sách thực tế cần lọc theo quyền xem từng bản ghi.",
          "- `resourceset … where resource.nguoi_lap == user.ma_nguoi_dung` so thuộc tính bản ghi với người dùng (ABAC, KT-03).", ""]
    for k, ds in BC.items():
        B += [f"## {k}", ""] + [f"- {x}" for x in ds] + [""]
    with open(os.path.join(wd, "bao_cao_playground.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(B) + "\n")
    for k in KQ:
        print(f"{k['tep']}: {k['kb']} KB · {k['tn']} tài nguyên (+{k['tn_ho_tro']} hỗ trợ) · {k['vt']} vai trò · {k['nd']} người dùng · {k['as']} assert · tự kiểm {k['so']} cặp, {len(k['lech'])} lệch")
        for x in k["lech"][:5]:
            print("  LỆCH", x)

def OrderedSet(a):
    return list(dict.fromkeys(a))


if __name__ == "__main__":
    main()
