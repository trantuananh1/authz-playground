# -*- coding: utf-8 -*-
"""Chuyển ma trận phân quyền Excel do BA lập (dòng = chức năng / thao tác, cột = vai trò, ô đánh dấu) thành danh sách giao dịch.

  python -I ma_tran_sang_giao_dich.py <thu_muc_lam_viec> <cau_hinh.json>

Cấu hình:
  nguon          mã nguồn của tệp Excel trong nguon.json (đã chạy trich_xuat.py)
  sheet          tên sheet
  dong_tieu_de   dòng ghi tên vai trò ở các cột vai trò
  dong_dau, dong_cuoi   khoảng dòng dữ liệu
  cot_nhom       (tuỳ chọn) cột ghi nhóm chức năng / đối tượng; ô trống lấy giá trị dòng trên
  cot_chuc_nang  cột ghi tên chức năng / thao tác
  cot_vai_tro    "C:H" hoặc danh sách ["C", "E:G"]
  ky_hieu        các giá trị trong ô được coi là có quyền, ví dụ ["x", "X", "✓"]
Mỗi dòng có ít nhất một ô đánh dấu → một giao dịch; tác nhân = tên các cột được đánh dấu.
Ký hiệu lạ (không thuộc ky_hieu) được liệt kê để hỏi BA, không được coi là có quyền.
Ghi: giao_dich_ma_tran.json, giao_dich_ma_tran.md
"""
import collections, json, os, re, sys

sys.stdout.reconfigure(encoding="utf-8")
cf = lambda s: re.sub(r"\s+", " ", str(s or "")).strip()


def cot_so(c):
    n = 0
    for ch in c.upper():
        n = n * 26 + ord(ch) - 64
    return n


def cot_chu(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26); s = chr(65 + r) + s
    return s


def mo_cot(spec):
    out = []
    for p in spec if isinstance(spec, list) else [spec]:
        if ":" in p:
            x, y = p.split(":"); out += [cot_chu(i) for i in range(cot_so(x), cot_so(y) + 1)]
        else:
            out.append(p.upper())
    return out


def main():
    wd, cfg = sys.argv[1], json.load(open(sys.argv[2], encoding="utf-8"))
    d = json.load(open(os.path.join(wd, "trich_xuat", cfg["nguon"] + ".json"), encoding="utf-8"))
    sh = next((s for s in d.get("sheets", []) if s["ten"] == cfg["sheet"]), None)
    if not sh:
        sys.exit(f"Không có sheet «{cfg['sheet']}» trong {cfg['nguon']}")
    o = sh["o"]
    g = lambda c, r: cf(o.get(f"{c}{r}", "")) if c else ""
    roles = [(c, g(c, cfg["dong_tieu_de"])) for c in mo_cot(cfg["cot_vai_tro"]) if g(c, cfg["dong_tieu_de"])]
    ky = {k.casefold() for k in cfg.get("ky_hieu", ["x"])}
    out, la, nhom = [], collections.defaultdict(list), ""
    for r in range(cfg["dong_dau"], cfg.get("dong_cuoi", sh["so_dong"]) + 1):
        nhom = g(cfg.get("cot_nhom"), r) or nhom
        cn = g(cfg["cot_chuc_nang"], r)
        if not cn:
            continue
        tac = []
        for c, ten in roles:
            v = g(c, r)
            if not v:
                continue
            if v.casefold() in ky:
                tac.append(ten)
            else:
                la[v].append(f"{c}{r}")
        if tac:
            out.append({"id": f"MT{len(out) + 1}", "nguon": cfg["nguon"], "vt": f'Sheet "{sh["ten"]}" dòng {r}', "muc": nhom, "usecase": nhom or cn,
                        "usecase_vt": f'Sheet "{sh["ten"]}" dòng {r}', "ten": cn, "mo_ta": f"{cn} — đánh dấu cho: {'; '.join(tac)}", "tac_nhan": tac, "tac_nhan_tu": "ma_tran"})
    json.dump(out, open(os.path.join(wd, "giao_dich_ma_tran.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    L = [f"# Giao dịch từ ma trận «{sh['ten']}»", "", f"- {len(out)} dòng có đánh dấu; {len(roles)} cột vai trò: " + ", ".join(t for _, t in roles), ""]
    if la:
        L += ["## Ký hiệu chưa rõ nghĩa (không được coi là có quyền — hỏi BA)", ""] + [f"- «{k}»: {len(v)} ô ({', '.join(v[:15])}{' …' if len(v) > 15 else ''})" for k, v in la.items()]
    L += ["", "## Giao dịch", ""] + [f"- {x['id']} [{x['muc']}] {x['ten']} — {', '.join(x['tac_nhan'])}" for x in out]
    open(os.path.join(wd, "giao_dich_ma_tran.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
    print(f"{len(out)} giao dịch từ ma trận · {len(roles)} vai trò · {sum(len(v) for v in la.values())} ô có ký hiệu lạ → giao_dich_ma_tran.json")


if __name__ == "__main__":
    main()
