# -*- coding: utf-8 -*-
"""Bộ key chuẩn (tiếng Việt không dấu) dùng chung cho mọi công cụ: đặc tả, ma trận Excel, JSON import, DSL playground.

Mỗi key chuẩn có danh sách bí danh (key tiếng Anh cũ, cách viết khác). Công cụ tự quy bí danh về key chuẩn
và báo lại để AI sửa đặc tả. Tài liệu cho người đọc: references/bo-key.md (giữ đồng bộ với tệp này).

  python -I bo_key.py            in bảng key chuẩn (dạng markdown) để đối chiếu với references/bo-key.md
"""
import re
import unicodedata

# hành động: key → (tên tiếng Việt, mức, nhóm, bí danh). Key tiếng Anh cũ (view, approve…) là bí danh.
HANH_DONG = {
    'xem': ('Xem', 'ban_ghi', 'xem', ['view', 'xem_ds', 'xem_ct', 'xem_danh_sach', 'xem_chi_tiet', 'tim_kiem', 'tra_cuu', 'loc', 'read', 'list', 'get', 'search', 'view_list', 'view_detail']),
    'xem_nhay_cam': ('Xem thông tin nhạy cảm', 'ban_ghi', 'xem', ['view_sensitive', 'xem_thong_tin_nhay_cam']),
    'them_moi': ('Thêm mới', 'danh_sach', 'them_moi', ['create', 'them', 'tao', 'tao_moi', 'lap', 'add', 'new', 'insert', 'upload', 'khai_bao']),
    'chinh_sua': ('Chỉnh sửa', 'ban_ghi', 'chinh_sua', ['update', 'sua', 'cap_nhat', 'edit', 'modify']),
    'xoa': ('Xoá', 'ban_ghi', 'xoa', ['delete', 'remove']),
    'khoi_phuc': ('Khôi phục', 'ban_ghi', 'xoa', ['restore']),
    'gui_duyet': ('Gửi duyệt', 'ban_ghi', 'vong_doi', ['submit', 'gui_phe_duyet', 'trinh', 'gui', 'send_for_approval']),
    'phe_duyet': ('Phê duyệt', 'ban_ghi', 'duyet', ['approve', 'duyet', 'xac_nhan']),
    'tu_choi': ('Từ chối / trả lại', 'ban_ghi', 'duyet', ['reject', 'tra_lai', 'yeu_cau_chinh_sua', 'return']),
    'tiep_nhan': ('Tiếp nhận', 'ban_ghi', 'duyet', ['receive', 'phe_duyet_tiep_nhan', 'accept']),
    'tu_choi_tiep_nhan': ('Từ chối tiếp nhận', 'ban_ghi', 'duyet', ['decline_receipt']),
    'khoa': ('Khoá', 'ban_ghi', 'vong_doi', ['lock', 'khoa_so', 'khoa_du_lieu']),
    'mo_khoa': ('Mở khoá', 'ban_ghi', 'vong_doi', ['unlock']),
    'sao_chep': ('Sao chép', 'ban_ghi', 'them_moi', ['copy', 'duplicate', 'clone']),
    'xuat': ('Xuất danh sách', 'danh_sach', 'xuat_nhap', ['export', 'xuat_ds', 'xuat_excel', 'xuat_file', 'export_ds', 'tai_xuong_ds', 'download_list']),
    'nhap': ('Nhập danh sách', 'danh_sach', 'xuat_nhap', ['import', 'nhap_lieu', 'nhap_ds', 'nhap_excel', 'import_ds']),
    'chia_tach': ('Chia tách', 'ban_ghi', 'vong_doi', ['split']),
    'sap_nhap': ('Sáp nhập', 'ban_ghi', 'vong_doi', ['merge']),
    'giai_the': ('Giải thể', 'ban_ghi', 'vong_doi', ['dissolve']),
    'chia_se': ('Chia sẻ', 'ban_ghi', 'khac', ['share']),
    'di_chuyen': ('Di chuyển', 'ban_ghi', 'chinh_sua', ['move']),
    'tai_xuong': ('Tải xuống tệp', 'ban_ghi', 'xuat_nhap', ['download']),
    'danh_gia': ('Đánh giá, xếp loại', 'ban_ghi', 'chinh_sua', ['evaluate', 'xep_loai']),
    'giao_xu_ly': ('Giao xử lý', 'ban_ghi', 'vong_doi', ['assign', 'phan_cong']),
    'gan_vai_tro': ('Gán vai trò', 'ban_ghi', 'khac', ['assign_role', 'phan_quyen']),
}
NHOM = {
    'xem': ['view'],
    'them_moi': ['create', 'tao'],
    'chinh_sua': ['update', 'sua'],
    'xoa': ['delete'],
    'vong_doi': ['lifecycle'],
    'duyet': ['approval'],
    'xuat_nhap': ['bulk'],
    'khac': ['other'],
}
MUC = {
    'danh_sach': ['list'],
    'ban_ghi': ['record'],
}
# kiểu phạm vi: key → (tên, cơ chế, bí danh). ReBAC = theo quan hệ cây đơn vị; ABAC = so thuộc tính bản ghi với người dùng
PHAM_VI = {
    'toan_he_thong': ('Toàn hệ thống', 'RBAC', ['all', 'toan_bo']),
    'danh_sach': ('Mức danh sách', 'RBAC', ['list', 'muc_danh_sach']),
    'don_vi_minh': ('Đơn vị mình', 'ReBAC', ['own_unit']),
    'don_vi_minh_va_cap_duoi_truc_tiep': ('Đơn vị mình và cấp dưới trực tiếp', 'ReBAC', ['unit_and_children', 'cap_duoi_truc_tiep']),
    'don_vi_minh_va_cap_duoi': ('Đơn vị mình và mọi cấp dưới', 'ReBAC', ['unit_and_descendants', 'toan_bo_cap_duoi', 'don_vi_va_cap_duoi']),
    'cap_duyet': ('Đang chờ đơn vị mình duyệt', 'ReBAC', ['approval_unit']),
    'do_minh_lap': ('Do chính mình lập', 'ABAC', ['own_record', 'cua_minh']),
    'duoc_giao': ('Được giao cho mình', 'ABAC', ['assigned']),
}
# quan hệ chuẩn: key → (ý nghĩa, bí danh)
QUAN_HE = {
    'cap_tren': ('Đơn vị cấp trên (trên cây đơn vị)', ['parent']),
    'thuoc_don_vi': ('Đơn vị sở hữu bản ghi', ['owner_unit']),
    'thuoc_to_chuc': ('Tổ chức (cây thứ hai, ví dụ hội) sở hữu bản ghi', ['owner_org']),
    'don_vi_quan_ly': ('Đơn vị quản lý tổ chức', ['managing_unit']),
    'cap_duyet': ('Đơn vị (cây đơn vị) đang phải duyệt bản ghi', ['approval_unit']),
    'cap_duyet_to_chuc': ('Tổ chức (cây thứ hai, ví dụ hội) đang phải duyệt bản ghi', ['approval_org']),
    'noi_di': ('Nơi chuyển đi', ['source_unit']),
    'noi_den': ('Nơi chuyển đến', ['target_unit']),
}
# thuộc tính chuẩn: key → (kiểu, ý nghĩa, bí danh)
THUOC_TINH = {
    'trang_thai': ('chuoi', 'Trạng thái vòng đời', ['status']),
    'nguoi_lap': ('chuoi', 'Người lập bản ghi', ['created_by', 'nguoi_tao']),
    'da_khoa': ('dung_sai', 'Bản ghi đã bị khoá', ['locked']),
    'nguoi_duoc_giao': ('chuoi', 'Người được giao xử lý', ['assignee', 'nguoi_xu_ly']),
}
# nhóm trạng thái vòng đời (khoá của vong_doi) và giá trị trạng thái chuẩn
VONG_DOI = {
    'dang_soan': ['draft', 'nhap'],
    'cho_duyet': ['pending'],
    'da_duyet': ['approved'],
}
TRANG_THAI = {
    'DU_THAO': ['DRAFT', 'NHAP'],
    'BI_TRA_LAI': ['RETURNED', 'BI_TU_CHOI', 'TRA_LAI'],
    'CHO_DUYET': ['PENDING'],
    'DA_DUYET': ['APPROVED'],
    'DA_KHOA': ['LOCKED'],
}
VONG_DOI_MAC_DINH = {'dang_soan': ['DU_THAO', 'BI_TRA_LAI'], 'cho_duyet': ['CHO_DUYET'], 'da_duyet': ['DA_DUYET']}
# điều kiện do quy định kế thừa tự sinh
DIEU_KIEN_TU_SINH = {"khong_tu_duyet": ["not_self_approval"], "dang_soan": ["draft"], "cho_duyet": ["pending"], "chua_khoa": ["not_locked"]}
# tài nguyên chung: cây đơn vị do Cổng quản lý, dùng chung mọi phân hệ
CAY_CONG = {'key': 'don_vi', 'ten': 'Đơn vị (từ Cổng)', 'bi_danh': ['unit']}

def _bang(d, i=None):
    out = {}
    for k, v in d.items():
        out[k] = k
        for a in (v if isinstance(v, list) else v[i] if i is not None else v):
            out[a] = k
    return out


BD_HD = _bang(HANH_DONG, 3)
BD_NHOM, BD_MUC = _bang(NHOM), _bang(MUC)
BD_PV = _bang(PHAM_VI, 2)
BD_QH, BD_TT = _bang(QUAN_HE, 1), _bang(THUOC_TINH, 2)
BD_VD, BD_TTH = _bang(VONG_DOI), _bang(TRANG_THAI)


def khong_dau(s):
    s = unicodedata.normalize("NFD", str(s)).replace("đ", "d").replace("Đ", "D")
    s = "".join(c for c in s if unicodedata.category(c) != "Mn").lower()
    return re.sub(r"[^a-z0-9]+", "_", s).strip("_")


def hanh_dong(k, tien_to=False):
    """Quy một key / nhãn hành động về key chuẩn. tien_to=True: nhận cả key có hậu tố (phe_duyet_cap_phong → approve)."""
    if k is None:
        return k
    if k in BD_HD:
        return BD_HD[k]
    k2 = khong_dau(k)
    if k2 in BD_HD:
        return BD_HD[k2]
    if tien_to:
        for a in sorted(BD_HD, key=len, reverse=True):
            if k2.startswith(a + "_"):
                return BD_HD[a]
    return k


def nhom(k):
    return BD_NHOM.get(k, k)


def muc(k):
    return BD_MUC.get(k, k)


def pham_vi(k):
    return BD_PV.get(k, k)


def quan_he(k):
    return BD_QH.get(k, k)


def thuoc_tinh(k):
    return BD_TT.get(k, k)


def vong_doi(k):
    return BD_VD.get(k, k)


def trang_thai(v):
    return BD_TTH.get(v, v) if isinstance(v, str) else v


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    print("| Key | Tên | Mức | Nhóm | Bí danh |\n|---|---|---|---|---|")
    for k, (t, m, n, a) in HANH_DONG.items():
        print(f"| `{k}` | {t} | {m} | {n} | {', '.join(a)} |")
