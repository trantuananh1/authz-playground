# -*- coding: utf-8 -*-
"""Xuất thiết kế phân quyền thành JSON import (khuôn resources / roles / condition_sets / … của hệ phân quyền).

  python -I xuat_json.py <thu_muc_lam_viec> [--chi-da-duyet]

Đọc thiet_ke_phan_quyen.json và ra_soat.json (nếu có). Quyền hiệu lực = «theo tài liệu» + «theo quy định kế thừa» + «AI thêm»,
đảo theo ý kiến «không đồng ý» của người rà soát (ý kiến trên từng quyền, hoặc trên câu mô tả chứa quyền đó).
--chi-da-duyet: chỉ xuất đề xuất AI đã được đồng ý. Ý kiến không còn mục tương ứng được báo, không bị bỏ qua im lặng.
Ghi: phan_quyen_import.json, bao_cao_xuat_json.md
"""
import argparse, collections, json, os, re, sys, unicodedata

sys.stdout.reconfigure(encoding="utf-8")
OD = collections.OrderedDict
KIEU = {"chuoi": "string", "so": "number", "ngay": "time", "dung_sai": "bool", "danh_sach": "array"}


def doc(p, md=None):
    if not os.path.exists(p):
        return md
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("thu_muc"); ap.add_argument("--chi-da-duyet", action="store_true")
    a = ap.parse_args()
    D = doc(os.path.join(a.thu_muc, "thiet_ke_phan_quyen.json"))
    RS = (doc(os.path.join(a.thu_muc, "ra_soat.json"), {"muc": {}}) or {}).get("muc", {})
    TN = {t["key"]: t for t in D["tai_nguyen"]}
    VT = {v["key"]: v for v in D["vai_tro"]}
    PV = {p["key"]: p for p in D["pham_vi"]}
    DK = {d["key"]: d for d in D["dieu_kien"]}
    BC = collections.defaultdict(list)
    CAU = {c["key"]: c for c in D.get("cau_mo_ta", [])}
    cau_cua = {k: c for c in CAU.values() for k in c["quyen"]}
    QK = {q["khoa"] for q in D["quyen"]}

    # ---------- ý kiến không còn mục tương ứng (đổi key, lập lại thiết kế) ----------
    con = lambda k: (k in QK or k in CAU or (k.startswith("vt:") and k[3:] in VT)
                     or (k.startswith("ch:") and k[3:] in {c.get("id") for c in D.get("cau_hoi", [])}))
    mo_coi = [(k, m) for k, m in RS.items() if not con(k)]
    for k, m in mo_coi:
        BC["Ý kiến rà soát không còn mục tương ứng — cần người rà soát xem lại"].append(f"{m.get('nhan') or k} · {m.get('ket_qua') or 'ghi chú'} · {m.get('ghi_chu', '')}".strip(" ·"))

    # ---------- quyền hiệu lực ----------
    hl = []
    for q in D["quyen"]:
        c = cau_cua.get(q["khoa"])
        kq = RS.get(q["khoa"], {}).get("ket_qua") or (RS.get(c["key"], {}).get("ket_qua") if c else None)
        t = q["trang_thai"]
        if kq == "khong_dong_y" and t in ("giu", "ke_thua"):
            BC["Không đồng ý với quyền theo tài liệu / theo quy định chung — AI cần sửa đặc tả (vẫn xuất như hiện tại)"].append(
                f"{VT[q['vai_tro']]['ten']} · {TN[q['tai_nguyen']]['ten']}:{q['hanh_dong']}" + (f" — {RS.get(c['key'], {}).get('ghi_chu', '')}" if c else ""))
        if kq == "khong_dong_y":
            t = {"them": "bo", "bo": "giu"}.get(t, t)
        if t == "them" and a.chi_da_duyet and kq != "dong_y":
            BC["Đề xuất AI chưa được đồng ý (bỏ vì --chi-da-duyet)"].append(f"{q['vai_tro']} · {q['tai_nguyen']}:{q['hanh_dong']}")
            continue
        if t != "bo":
            hl.append(q)

    # ---------- tài nguyên ----------
    R = OD()
    for t in D["tai_nguyen"]:
        R[t["key"]] = OD([("key", t["key"]), ("name", t["ten"]), ("description", t.get("mo_ta") or t["ten"]), ("group", False), ("urn", None),
                          ("actions", OD((h["key"], OD([("key", h["key"]), ("name", h["ten"]), ("description", None), ("attributes", None)])) for h in t["hanh_dong"])),
                          ("attributes", OD((x["key"], OD([("key", x["key"]), ("type", KIEU.get(x.get("kieu"), "string")), ("description", x.get("y_nghia"))])) for x in t.get("thuoc_tinh", []))),
                          ("roles", OD()),
                          ("relations", OD((r["key"], OD([("resource", r["toi"]), ("name", r["key"]), ("description", r.get("y_nghia"))])) for r in t.get("quan_he", [])))])
    G = OD()

    def g_role(k):
        v = VT[k]
        return G.setdefault(k, OD([("key", k), ("name", v["ten"]), ("description", v.get("mo_ta") or ""), ("permissions", []), ("resource", None), ("grantedTo", None)]))

    def r_role(rk, k, ten, mo_ta):
        return R[rk]["roles"].setdefault(k, OD([("key", k), ("name", ten), ("description", mo_ta), ("permissions", []), ("resource", rk), ("grantedTo", None)]))

    def cap(ro, perm):
        if perm and perm not in ro["permissions"]:
            ro["permissions"].append(perm)

    def nhan(ro, role, on, rel):
        g = ro["grantedTo"] or OD([("users_with_role", [])])
        e = OD([("role", role), ("on_resource", on), ("linked_by_relation", rel)])
        if e not in g["users_with_role"]:
            g["users_with_role"].append(e)
        ro["grantedTo"] = g

    def rel_toi(rk, dich):
        """Quan hệ của rk trỏ tới dich (ưu tiên quan hệ không phải parent)."""
        ds = [r["key"] for r in TN[rk].get("quan_he", []) if r["toi"] == dich]
        ds.sort(key=lambda k: k == "cap_tren")
        return ds[0] if ds else None

    def cay_cap_tren(rk):
        return next((r["key"] for r in TN[rk].get("quan_he", []) if r["toi"] == rk), None)

    def cau_noi(vk, g, xuong):
        """Vai trò cầu nối trên cây g: người có vk ở nút cha nhận ở nút con (xuong='truc_tiep' | 'tat_ca')."""
        ct = cay_cap_tren(g)
        if not ct:
            return None
        k = f"{vk}__o_{slug(TN[g]['ten'])}_cap_tren" + ("" if xuong == "tat_ca" else "_truc_tiep")
        ro = r_role(g, k, f"{VT[vk]['ten']} – ở {TN[g]['ten'].split(' (')[0].lower()} cấp trên{'' if xuong == 'tat_ca' else ' trực tiếp'}",
                    f"Người có vai trò {vk} ở {TN[g]['ten']} cấp trên ({'mọi cấp' if xuong == 'tat_ca' else 'trực tiếp'}) nhận vai trò này ở nút cấp dưới")
        nhan(ro, vk, g, ct)
        if xuong == "tat_ca":
            nhan(ro, k, g, ct)
        return k

    def slug(s):
        """Tên tiếng Việt → key không dấu, bỏ phần trong ngoặc: «Phòng nghiệp vụ (cấp 2)» → phong_nghiep_vu."""
        s = s.split(" (")[0].lower().replace("đ", "d")
        s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
        return "_".join(re.findall(r"[a-z0-9]+", s))

    def ten_pham_vi(vk, pk, kieu, g):
        """Key vai trò trên tài nguyên, đọc ra ngay phạm vi: <vai trò>__don_vi_minh_va_cap_duoi, <vai trò>__cap_duyet…"""
        p = PV.get(pk) or {}
        chuan = pk == kieu or pk.startswith(kieu + "__") or p.get("tu_sinh")
        if not chuan:
            return f"{vk}__{slug(p.get('ten') or pk)}"   # phạm vi riêng của đặc tả: theo tên phạm vi («Hội nơi chuyển đến»…)
        c = slug(TN[g]["ten"]) if g in TN else "don_vi"
        return {"don_vi_minh_va_cap_duoi": f"{vk}__{c}_minh_va_cap_duoi", "don_vi_minh_va_cap_duoi_truc_tiep": f"{vk}__{c}_minh_va_cap_duoi_truc_tiep",
                "don_vi_minh": f"{vk}__{c}_minh", "cap_duyet": f"{vk}__cap_duyet"}.get(kieu, f"{vk}__{slug(p.get('ten') or pk)}")

    # ---------- dựng quyền ----------
    can_dk = collections.defaultdict(list)
    ABAC = []
    for q in hl:
        vk, rk, hd = q["vai_tro"], q["tai_nguyen"], q["hanh_dong"]
        v, perm, p = VT[vk], f"{q['tai_nguyen']}:{q['hanh_dong']}", PV.get(q["pham_vi"]) or {}
        nhan_q = f"{v['ten']} · {TN[rk]['ten']}:{hd}"
        if q["dieu_kien"]:
            can_dk[" + ".join(DK[d]["ten"] for d in q["dieu_kien"] if d in DK)].append(nhan_q)
        kieu = p.get("kieu") or q["pham_vi"]
        if kieu in ("toan_he_thong", "danh_sach") or q["pham_vi"] in ("toan_he_thong", "danh_sach"):
            cap(g_role(vk), perm); continue
        if kieu in ("do_minh_lap", "duoc_giao"):
            # ABAC: mọi tài khoản đang hoạt động × bản ghi thoả biểu thức (created_by / assignee = user.ma_nguoi_dung)
            ABAC.append((rk, perm, nhan_q, q["pham_vi"], kieu, vk)); continue
        g = v.get("gan_tren")
        qhm = p.get("quan_he") or {}
        rel = qhm.get(rk, qhm.get("*")) if isinstance(qhm, dict) else qhm
        if not g and rel and v["loai_pham_vi"] == "toan_he_thong":
            g = next((r["toi"] for r in TN[rk].get("quan_he", []) if r["key"] == rel), None)
            if g:
                BC[f"Vai trò toàn hệ thống cần gán thêm trên một nút của «{TN[g]['ten']}» để dùng phạm vi theo quan hệ"].append(f"{nhan_q} → gán {vk} trên nút tương ứng (ví dụ nút cấp cao nhất)")
        if not g or not rel:
            BC["Chưa xuất được: thiếu nơi gán vai trò hoặc quan hệ của phạm vi"].append(nhan_q); continue
        xuong = {"don_vi_minh_va_cap_duoi": "tat_ca", "don_vi_minh_va_cap_duoi_truc_tiep": "truc_tiep"}.get(kieu)
        if rel == "(gan_truc_tiep)" and rk == g:
            cap(r_role(g, vk, v["ten"], "Gán trực tiếp trên bản ghi"), perm); continue
        if rk == g and rel == cay_cap_tren(g):          # chính cây: mình + cấp dưới
            cap(r_role(g, vk, v["ten"], "Gán trực tiếp trên bản ghi"), perm)
            k = cau_noi(vk, g, xuong or "truc_tiep")
            if k:
                cap(R[g]["roles"][k], perm)
            continue
        dich = next((r["toi"] for r in TN[rk].get("quan_he", []) if r["key"] == rel), None)
        if not dich:
            BC["Chưa xuất được: tài nguyên thiếu quan hệ của phạm vi"].append(f"{nhan_q} (quan hệ {rel})"); continue
        r_role(g, vk, v["ten"], "Gán trực tiếp trên bản ghi")
        nguon = [(vk, g)]
        if xuong:
            k = cau_noi(vk, g, xuong)
            if k:
                nguon.append((k, g))
        if dich != g:                                    # hai bước: tài nguyên → dich → nơi gán
            lk = rel_toi(dich, g)
            if not lk:
                BC["Chưa xuất được: không nối được tới nơi gán vai trò"].append(f"{nhan_q} ({rk} →{rel}→ {dich} ↛ {g})"); continue
            bk = f"{vk}__o_{slug(TN[g]['ten'])}_quan_ly" + ("_hoac_cap_tren" if xuong else "")
            gt = TN[g]["ten"].split(" (")[0].lower()
            br = r_role(dich, bk, f"{v['ten']} – ở {gt} quản lý" + (" hoặc cấp trên" if xuong else ""),
                        f"Người có vai trò {vk} ở {TN[g]['ten']} quản lý bản ghi này qua quan hệ {lk}" + (", hoặc ở cấp trên của nơi đó" if xuong else ""))
            for nk, ng in nguon:
                nhan(br, nk, ng, lk)
            ct = cay_cap_tren(dich)
            if xuong and ct:
                nhan(br, bk, dich, ct)
            nguon = [(bk, dich)]
        key2 = ten_pham_vi(vk, q["pham_vi"], kieu, g)
        cay_ten = TN[g]["ten"].split(" (")[0].lower() if g in TN else "đơn vị"
        ten_pv = {"don_vi_minh_va_cap_duoi": f"{cay_ten} mình và mọi cấp dưới", "don_vi_minh_va_cap_duoi_truc_tiep": f"{cay_ten} mình và cấp dưới trực tiếp",
                  "don_vi_minh": f"{cay_ten} mình", "cap_duyet": "đang chờ cấp mình duyệt"}.get(kieu) if key2.split("__", 1)[1] != slug(p.get("ten") or q["pham_vi"]) else None
        ro = r_role(rk, key2, f"{v['ten']} – {ten_pv or p.get('ten', q['pham_vi']).lower()}", p.get("mo_ta", ""))
        cap(ro, perm)
        for nk, ng in nguon:
            nhan(ro, nk, ng, rel)

    # ---------- điều kiện: chỉ xuất định nghĩa, không xuất luật cấp quyền ----------
    OP = {"bang": "EQUALS", "khac": "NOT_EQUALS", "thuoc": "IN"}
    CS = []
    for d in D["dieu_kien"]:
        dung = [q for q in hl if d["key"] in q["dieu_kien"]]
        for rk in sorted({q["tai_nguyen"] for q in dung}):
            at = []
            for b in d.get("bieu_thuc", []):
                ph = b["phai"]
                ref = isinstance(ph, str) and ph.startswith("user.")
                at.append(OD([("left", b["trai"]), ("operator", "EQUALS_REF" if ref and b["phep"] == "bang" else OP.get(b["phep"], b["phep"])), ("right", ph)]))
                if OP.get(b["phep"]) not in ("EQUALS",) and not (ref and b["phep"] == "bang"):
                    BC["Toán tử chưa có trong file JSON mẫu (cần hệ đích xác nhận)"].append(f"{d['key']}: {b['phep']}")
            CS.append(OD([("key", f"{d['key']}__{rk}"), ("name", f"{d['ten']} – {TN[rk]['ten']}"), ("description", d.get("mo_ta")), ("type", "resourceset"), ("resource", rk),
                          ("conditions", OD([("all_of", None), ("any_of", [OD([("all_of", at), ("any_of", None)])])]))]))
    CSR = []
    if ABAC:
        CS.append(OD([("key", "tai_khoan_hoat_dong"), ("name", "Tài khoản đang hoạt động"), ("description", "Mọi người dùng có user.trang_thai = DANG_HOAT_DONG"), ("type", "userset"),
                      ("conditions", OD([("all_of", None), ("any_of", [OD([("all_of", [OD([("left", "user.trang_thai"), ("operator", "EQUALS"), ("right", "DANG_HOAT_DONG")])]), ("any_of", None)])])]))]))
        MAC = {"do_minh_lap": [{"trai": "resource.nguoi_lap", "phep": "bang", "phai": "user.ma_nguoi_dung"}], "duoc_giao": [{"trai": "resource.nguoi_duoc_giao", "phep": "bang", "phai": "user.ma_nguoi_dung"}]}
        OPR = {"bang": "EQUALS", "khac": "NOT_EQUALS", "thuoc": "IN"}
        for rk, pk in sorted({(x[0], x[3]) for x in ABAC}):
            p = PV.get(pk) or {}
            bt = p.get("bieu_thuc") or MAC.get(p.get("kieu", pk), MAC["do_minh_lap"])
            at = [OD([("left", b["trai"]), ("operator", "EQUALS_REF" if str(b["phai"]).startswith("user.") and b["phep"] == "bang" else OPR.get(b["phep"], b["phep"])), ("right", b["phai"])]) for b in bt]
            CS.append(OD([("key", f"tap_{rk}_{pk}"), ("name", f"{TN[rk]['ten']} — {p.get('ten', pk).lower()}"), ("description", p.get("mo_ta") or pk),
                          ("type", "resourceset"), ("resource", rk), ("conditions", OD([("all_of", None), ("any_of", [OD([("all_of", at), ("any_of", None)])])]))]))
        for rk, perm, nhan_q, pk, kieu, vk in ABAC:
            r = OD([("user_set", "tai_khoan_hoat_dong"), ("permission", perm), ("resource_set", f"tap_{rk}_{pk}")])
            if r not in CSR:
                CSR.append(r)
            BC["Luật ABAC (người lập, người được giao): ứng dụng ghi nguoi_lap / nguoi_duoc_giao; userset dùng user.trang_thai = DANG_HOAT_DONG"].append(nhan_q)
            if VT[vk].get("loai_pham_vi") != "theo_ban_ghi":
                BC["Luật ABAC áp cho mọi người thoả thuộc tính, không giới hạn theo vai trò — BA xác nhận"].append(nhan_q)
    out = OD([("resources", list(R.values())), ("roles", list(G.values())), ("condition_sets", CS), ("condition_set_rules", CSR),
              ("project_detail", OD([("appVersion", None), ("versionDescription", None), ("icon", None), ("color", None), ("path", (D.get("phan_he") or {}).get("ma")), ("userManual", [])])),
              ("resource_menus", []), ("resource_instances", []), ("users", []), ("role_assignments", []), ("relationship_tuples", [])])
    with open(os.path.join(a.thu_muc, "phan_quyen_import.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    err = kiem_tra(out)
    nr = sum(len(x["roles"]) for x in R.values())
    L = [f"# Báo cáo xuất JSON import — {(D.get('phan_he') or {}).get('ten', '')}", "",
         f"- {len(hl)} quyền hiệu lực → {len(R)} tài nguyên, {len(G)} vai trò chung (RBAC), {nr} vai trò trên tài nguyên (ReBAC, gồm vai trò cầu nối), {len(CS)} tập điều kiện, {len(CSR)} luật ABAC cấp quyền.",
         f"- Kiểm tra tham chiếu: {len(err)} lỗi." + ("" if not err else "\n" + "\n".join("  - " + e for e in err)), "",
         "## Điều kiện ràng buộc (ABAC)", "",
         "Khuôn file mẫu chỉ có luật điều kiện kiểu **cấp thêm** quyền (`condition_set_rules`), không có kiểu **thu hẹp** quyền của một vai trò. Luật cấp thêm chỉ dùng cho quyền vốn là ABAC (người lập xem bản ghi của mình, KT-03). Các điều kiện ràng buộc chỉ xuất định nghĩa `condition_sets`, không xuất luật cấp quyền, để không cấp thừa. Hệ phân quyền đích hoặc ứng dụng cần áp các điều kiện dưới đây như ràng buộc:", ""]
    for k, ds in can_dk.items():
        L.append(f"- **{k}** ({len(ds)} quyền): " + "; ".join(ds[:12]) + (" …" if len(ds) > 12 else ""))
    for k, ds in BC.items():
        L += ["", f"## {k} ({len(ds)})", ""] + [f"- {x}" for x in sorted(set(ds))[:60]]
    with open(os.path.join(a.thu_muc, "bao_cao_xuat_json.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    if mo_coi:
        print(f"  CẢNH BÁO: {len(mo_coi)} ý kiến rà soát không còn mục tương ứng — xem bao_cao_xuat_json.md")
    print(f"{len(hl)} quyền → {len(R)} tài nguyên · {len(G)} vai trò chung · {nr} vai trò trên tài nguyên · {len(CS)} tập điều kiện · kiểm tra {len(err)} lỗi")
    for e in err[:10]:
        print("  LỖI", e)


def kiem_tra(d):
    err = []
    R = {r["key"]: r for r in d["resources"]}
    GR = {r["key"] for r in d["roles"]}
    def perm(p, w):
        rk, _, a = p.partition(":")
        if rk not in R or a not in R[rk]["actions"]:
            err.append(f"{w}: quyền {p} không tồn tại")
    for k, r in R.items():
        for rel in r["relations"].values():
            if rel["resource"] not in R:
                err.append(f"{k}: quan hệ {rel['name']} trỏ tài nguyên lạ")
        for rk, ro in r["roles"].items():
            for p in ro["permissions"]:
                perm(p, f"{k}#{rk}")
                if not p.startswith(k + ":"):
                    err.append(f"{k}#{rk}: quyền {p} thuộc tài nguyên khác")
            for g in (ro.get("grantedTo") or {}).get("users_with_role", []):
                rel = r["relations"].get(g["linked_by_relation"])
                if not rel:
                    err.append(f"{k}#{rk}: không có quan hệ {g['linked_by_relation']}")
                elif rel["resource"] != g["on_resource"]:
                    err.append(f"{k}#{rk}: quan hệ {g['linked_by_relation']} trỏ {rel['resource']}, không phải {g['on_resource']}")
                if g["role"] not in R.get(g["on_resource"], {}).get("roles", {}):
                    err.append(f"{k}#{rk}: {g['role']} không phải vai trò trên {g['on_resource']}")
    for g in d["roles"]:
        for p in g["permissions"]:
            perm(p, "vai trò " + g["key"])
    cs = {c["key"]: c for c in d["condition_sets"]}
    for r in d["condition_set_rules"]:
        perm(r["permission"], "luật ABAC")
        if cs.get(r["user_set"], {}).get("type") != "userset" or cs.get(r["resource_set"], {}).get("type") != "resourceset":
            err.append(f"luật ABAC {r}: userset / resourceset không tồn tại")
    return err


if __name__ == "__main__":
    main()
