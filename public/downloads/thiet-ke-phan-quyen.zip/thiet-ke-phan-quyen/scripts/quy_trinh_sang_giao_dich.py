# -*- coding: utf-8 -*-
"""Chuyển quy trình nghiệp vụ thành danh sách giao dịch: sơ đồ drawio có làn (swimlane) và bảng bước – người thực hiện.

  python -I quy_trinh_sang_giao_dich.py <thu_muc_lam_viec> [--nguon N2]

- drawio: mỗi khối hành động nằm trong một làn → giao dịch, tác nhân = nhãn làn. Bỏ khối bắt đầu / kết thúc (hình elip)
  và khối rẽ nhánh (hình thoi); nhãn khối rẽ nhánh được ghi vào mô tả của bước phía trước để AI cân nhắc điều kiện.
- Tài liệu: bảng có cột tên bước và cột người thực hiện → mỗi dòng là một giao dịch. Dòng ghi "ngoài hệ thống" được đánh dấu.
Bước quy trình thường mô tả việc nghiệp vụ, không trực tiếp là thao tác trên hệ thống: AI phải quy về tài nguyên – hành động
trong đặc tả, và bỏ qua các bước không thao tác trên phần mềm.
Ghi: giao_dich_quy_trinh.json, giao_dich_quy_trinh.md
"""
import argparse, collections, json, os, re, sys

sys.stdout.reconfigure(encoding="utf-8")
cf = lambda s: re.sub(r"\s+", " ", str(s or "")).strip()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("thu_muc"); ap.add_argument("--nguon")
    a = ap.parse_args()
    nguon = json.load(open(os.path.join(a.thu_muc, "nguon.json"), encoding="utf-8"))
    out, bao = [], []
    for n in nguon:
        if a.nguon and n["id"] != a.nguon:
            continue
        d = json.load(open(os.path.join(a.thu_muc, "trich_xuat", n["id"] + ".json"), encoding="utf-8"))
        if d["loai"] == "drawio":
            for tr in d["trang"]:
                by = {k["id"]: k for k in tr["khoi"]}
                lan = lambda k: next((by[p] for p in [k.get("thuoc")] if p in by), None)
                ra = collections.defaultdict(list)
                for e in tr["mui_ten"]:
                    ra[e["tu"]].append(e)
                for k in tr["khoi"]:
                    if k["kieu"] in ("swimlane", "ellipse", "rhombus") or not k["nhan"]:
                        continue
                    l = lan(k)
                    if not l or l["kieu"] != "swimlane":
                        bao.append(f'{n["id"]} trang «{tr["ten"]}» khối {k["id"]} «{k["nhan"]}» không nằm trong làn nào → bỏ qua')
                        continue
                    nhanh = [by[e["den"]]["nhan"] for e in ra[k["id"]] if e["den"] in by and by[e["den"]]["kieu"] == "rhombus"]
                    out.append({"id": f"QT{len(out) + 1}", "nguon": n["id"], "vt": f'Trang "{tr["ten"]}", khối {k["id"]}', "muc": tr["ten"], "usecase": tr["ten"],
                                "usecase_vt": f'Trang "{tr["ten"]}"', "ten": k["nhan"], "mo_ta": k["nhan"] + (f" (sau đó rẽ nhánh: {'; '.join(nhanh)})" if nhanh else ""),
                                "tac_nhan": [l["nhan"]], "tac_nhan_tu": "lan_quy_trinh"})
        elif d["loai"] == "tai_lieu":
            bang = collections.OrderedDict()
            for x in d["doan"]:
                m = re.match(r"(B\d+)\.D(\d+)$", x["vt"])
                if m and x.get("o"):
                    bang.setdefault(m.group(1), []).append(x)
            for b, rows in bang.items():
                h = [cf(c).casefold() for c in rows[0]["o"]]
                cb = next((i for i, c in enumerate(h) if "bước" in c or "công việc" in c or "hoạt động" in c), None)
                cn = next((i for i, c in enumerate(h) if "người thực hiện" in c or "thực hiện" in c or "chịu trách nhiệm" in c), None)
                cm = next((i for i, c in enumerate(h) if "mô tả" in c), None)
                if cb is None or cn is None:
                    continue
                tieu_de = next((y["van_ban"] for y in reversed(d["doan"][:d["doan"].index(rows[0])]) if y["loai"] == "tieu_de"), b)
                for x in rows[1:]:
                    o = x["o"] + [""] * 10
                    if not cf(o[cb]) or not cf(o[cn]):
                        continue
                    mo = cf(o[cm]) if cm is not None else ""
                    out.append({"id": f"QT{len(out) + 1}", "nguon": n["id"], "vt": x["vt"], "muc": tieu_de, "usecase": tieu_de, "usecase_vt": b,
                                "ten": cf(o[cb]), "mo_ta": mo or cf(o[cb]), "tac_nhan": [cf(o[cn])], "tac_nhan_tu": "bang_quy_trinh",
                                "ngoai_he_thong": bool(re.search(r"ngoài hệ thống|ngoài phân hệ|ngoài phần mềm", mo, re.I))})
    json.dump(out, open(os.path.join(a.thu_muc, "giao_dich_quy_trinh.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    L = ["# Giao dịch từ quy trình", ""] + [f"- {x}" for x in bao] + [""]
    m0 = None
    for x in out:
        if x["muc"] != m0:
            L += ["", f"## {x['muc']}"]; m0 = x["muc"]
        L.append(f"- {x['id']} [{x['vt']}] {x['ten']} — {', '.join(x['tac_nhan'])}{' (ngoài hệ thống)' if x.get('ngoai_he_thong') else ''}")
    open(os.path.join(a.thu_muc, "giao_dich_quy_trinh.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
    print(f"{len(out)} bước quy trình ({sum(1 for x in out if x.get('ngoai_he_thong'))} ngoài hệ thống) → giao_dich_quy_trinh.json")


if __name__ == "__main__":
    main()
