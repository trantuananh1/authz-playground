---
name: thiet-ke-phan-quyen
description: "Thiết kế phân quyền cuối cho mọi phân hệ, sau khi BA đã rà soát và xác nhận bản xem trước bằng /ra-soat-phan-quyen: xuất DSL playground cuối (chỉ cấu trúc, tự kiểm 0 lệch), JSON import cho hệ phân quyền, bảng «ai được làm gì trên tài nguyên nào», và bản Excel cuối giữ đúng định dạng mẫu 3 bảng đầu vào để đưa vào tài liệu, các chỗ thay đổi được tô màu (xanh thêm, vàng sửa, đỏ gạch bỏ) kèm ghi chú căn cứ; nạp DSL lên playground. Chưa có xác nhận thì chuyển sang /ra-soat-phan-quyen. Dùng khi người dùng cần xuất DSL, JSON import, Excel phân quyền cuối, bản sạch cho tài liệu, thử vài tài nguyên trên playground, kể cả khi không nhắc tên skill. Gọi /thiet-ke-phan-quyen [thư mục | excel | trai-phang | dsl a,b | playground | thu | json]."
---

# Thiết kế phân quyền cuối

Skill này là **nửa sau** của việc phân quyền một phân hệ: từ thiết kế BA đã xác nhận, xuất các tệp cuối cho đội phát triển và cho tài liệu. Nửa đầu (đọc tài liệu, hỏi đáp nghiệp vụ, xung đột, bản xem trước, so với ma trận của BA) là skill `/ra-soat-phan-quyen`.

| Giai đoạn | Skill | Kết quả |
|---|---|---|
| Rà soát nghiệp vụ | `/ra-soat-phan-quyen` | Bản xem trước trên Artifact, bảng thay đổi so với 3 bảng, trang so sánh, **xác nhận của BA** |
| Thiết kế cuối | `/thiet-ke-phan-quyen` (skill này) | `phan_quyen_import.json`, `playground.dsl` + tệp theo mảng, `ai_duoc_lam_gi.md`, **Excel cuối** `<tệp gốc>_phan_quyen_cuoi.xlsx` |

**Điều kiện bắt đầu.** Thư mục thiết kế `thiet_ke_*` có `thiet_ke_phan_quyen.json` và BA **đã xác nhận** bản xem trước đúng thiết kế hiện tại (`xac_nhan.py trang-thai` báo `da_xac_nhan_xem_truoc: true`). Thiếu một trong hai:
- chưa có thiết kế, hoặc người dùng đưa tài liệu mới → làm theo `/ra-soat-phan-quyen` (đọc SKILL.md của skill đó và chạy từ đầu);
- có thiết kế nhưng chưa xác nhận, hoặc thiết kế đổi sau khi xác nhận → báo BA, chạy `/ra-soat-phan-quyen xem-truoc` để BA duyệt và xác nhận lại. **Không tự ghi xác nhận thay BA**; `--chua-xac-nhan` chỉ để thử kỹ thuật, không dùng khi làm với BA.

Skill này **không sửa thiết kế**: không đổi đặc tả, không thêm, bỏ quyền. BA muốn sửa sau khi xem tệp cuối → `/ra-soat-phan-quyen cap-nhat <điều cần sửa>`, xác nhận lại, rồi xuất lại ở đây. Ngoại lệ duy nhất: điền `anh_xa_ba_bang.json` (ghép key 3 bảng với thiết kế) khi công cụ chưa ghép được, vì đó là việc trình bày, không đổi quyền.

**Không sinh dữ liệu giả, không nới rộng.** Tệp chính thức chỉ gồm cấu trúc phân quyền và các câu trả lời «ai (vai trò, nơi gán) được làm gì (hành động) trên tài nguyên nào, với bản ghi nào (phạm vi), khi nào (điều kiện)». Mọi quyền hoặc được áp đủ phạm vi và điều kiện, hoặc **không cấp** (báo lý do); không quyền nào bị nới rộng.

## Thư mục dùng chung

Công cụ, tài liệu tham chiếu, mẫu Excel nằm ở `<chung>` = `~/.claude/skills/phan-quyen-chung` (cạnh thư mục skill này), dùng chung với `/ra-soat-phan-quyen`. Mọi lệnh chạy `python -I <chung>/scripts/<công cụ>.py …`. Tham chiếu cần cho skill này: `references/bo-key.md` (key chuẩn, khi điền ánh xạ), `references/dac-ta.md` (cấu trúc thiết kế).

## Gọi bằng lệnh `/thiet-ke-phan-quyen`

BA có thể chỉ gõ tên lệnh. Khi đó **không hỏi lại mục đích**: đọc đối số và chạy trọn việc tương ứng. «Thư mục thiết kế gần nhất» = thư mục `thiet_ke_*` sửa đổi gần nhất trong thư mục hiện tại và một cấp con.

| Đối số | Việc làm |
|---|---|
| *(trống)* hoặc đường dẫn thư mục thiết kế | Kiểm điều kiện bắt đầu, rồi chạy trọn: bước 1 (JSON import) → bước 2 (DSL) → bước 3 (tệp thử) → bước 4 (Excel cuối, nếu đầu vào là mẫu 3 bảng) → bước 5 (bảng trải phẳng, nếu thư mục có `ma_tran_trai_phang.json`) → nạp tệp theo mảng nhỏ nhất lên playground → báo kết quả. Có nhiều thư mục thiết kế đã xác nhận thì hỏi một câu chọn. |
| `excel [--ban-sach]` | Chỉ bước 4 trên thư mục gần nhất; `--ban-sach` thêm bản không màu để dán vào tài liệu. |
| `trai-phang [tệp khung] [sheet]` | Chỉ bước 5: bảng phân quyền trải phẳng cuối theo khung (dùng `ma_tran_trai_phang.json` đã lập khi rà soát; chưa có thì lập theo tệp khung BA nêu). |
| `json` | Chỉ bước 1. |
| `dsl <key tài nguyên, cách nhau bởi dấu phẩy>` | `xuat_dsl.py <lv> --tai-nguyen …` → `playground_chon/…dsl`, rồi nạp lên playground. Key sai: liệt kê key tài nguyên có hành động để BA chọn. |
| `playground [tệp .dsl]` | Nạp tệp lên playground (mục «Nạp lên playground»). Không nêu tệp: tệp theo mảng nhỏ nhất của thư mục gần nhất. |
| `thu [thư mục]` | Bước 3, rồi nạp tệp thử theo mảng nhỏ nhất lên playground để xem tab Matrix. |

**Kết thúc** bằng báo cáo theo mục «Báo kết quả cho người dùng», cộng các lệnh dùng tiếp:
- cần sửa thiết kế → `/ra-soat-phan-quyen cap-nhat <điều cần sửa>` (xác nhận lại rồi xuất lại);
- muốn thử vài tài nguyên → `/thiet-ke-phan-quyen dsl <key>,<key>` (gợi ý hai key cụ thể của phân hệ, chọn cặp có quan hệ cha – con và ít vai trò);
- cần bản Excel không màu cho tài liệu → `/thiet-ke-phan-quyen excel --ban-sach`.

## Quy trình

Đặt `<lv>` là thư mục thiết kế. Trước khi xuất, chạy `python -I <chung>/scripts/xac_nhan.py trang-thai <lv>`; `da_xac_nhan_xem_truoc` phải là `true`.

### 1. Xuất JSON import

```bash
python -I <chung>/scripts/xuat_json.py <lv> [--chi-da-duyet]
```

Ghi `phan_quyen_import.json` (khuôn `resources`, `roles`, `condition_sets`, `condition_set_rules`, `resource_menus`, `project_detail`…) và `bao_cao_xuat_json.md`.
- Quyền hiệu lực = quyền theo tài liệu / BA chốt, đảo theo ý kiến «không đồng ý». Mục thiếu nguồn không được xuất.
- RBAC → `roles[]`; ReBAC → vai trò trên tài nguyên có `grantedTo`, tự sinh vai trò cầu nối cho phạm vi cấp dưới và quan hệ hai bước.
- Quyền «trên bản ghi mình lập / được giao» (`do_minh_lap`, `duoc_giao`):
  - của vai trò theo đơn vị → **vai trò trên bản ghi** `<vai trò>__<phạm vi>` (ghi thêm `vai_tro_tren_ban_ghi.json`): ứng dụng gán cho người lập / người được giao đang giữ vai trò gốc, gỡ khi người đó thôi giữ vai trò. Nhờ vậy mỗi vai trò chỉ nhận đúng bộ quyền của mình trên bản ghi mình lập; nói rõ việc gán này với người dùng và đội phát triển;
  - của vai trò xét theo bản ghi (ví dụ «Người lập bản ghi») → luật cấp thêm (`condition_set_rules`): userset tài khoản đang hoạt động × resourceset `resource.nguoi_lap / nguoi_duoc_giao = user.ma_nguoi_dung`.
- **Điều kiện** (trạng thái, khoá, loại hồ sơ, công khai…): khuôn chỉ có luật **cấp thêm** quyền (`condition_set_rules` = userset × resourceset), không có luật thu hẹp quyền của vai trò.
  - Quyền **toàn hệ thống** có điều kiện chỉ xét thuộc tính bản ghi → luật cấp thêm: userset `nguoi_giu_<vai trò>` (`user.vai_tro_chung` chứa key vai trò) × resourceset `tap_<tài nguyên>__<điều kiện>`; không gán thẳng cho vai trò chung. Hệ đích phải ghi key vai trò toàn hệ thống vào `user.vai_tro_chung` của tài khoản.
  - Quyền của vai trò xét theo bản ghi có điều kiện → điều kiện gộp vào resourceset của luật người lập / người được giao.
  - Quyền cấp qua **vai trò trên tài nguyên** (ReBAC) có điều kiện chỉ so thuộc tính bản ghi với hằng (trạng thái, khoá, loại, công khai…) → **quan hệ theo điều kiện**: hệ phân quyền không đặt được điều kiện trên `derive` (đã thử trên playground: `where`, `when` đều lỗi cú pháp), nên quyền đi qua quan hệ riêng `<quan hệ>__<điều kiện>` (ví dụ `cap_duyet__cho_duyet`, `thuoc_don_vi__ban_nhap`) trỏ cùng nơi với quan hệ gốc, vai trò trên tài nguyên tương ứng `<vai trò>__<phạm vi>__<điều kiện>`. **Ứng dụng chỉ ghi quan hệ này khi hồ sơ thoả điều kiện, gỡ ngay khi hết thoả** (đổi trạng thái, khoá, đổi loại…); quan hệ gốc vẫn ghi như cũ cho quyền không có điều kiện. Ghi thêm `quan_he_theo_dieu_kien.json` (quan hệ, quan hệ gốc, điều kiện bằng giá trị CSDL, quyền đi qua) cho đội phát triển; báo cáo có bảng «Quan hệ theo điều kiện». Số vai trò người dùng được gán và số hành động không đổi. Nói rõ với người dùng: quyền đúng như thiết kế **khi và chỉ khi** ứng dụng ghi, gỡ quan hệ đúng lúc.
  - Điều kiện có **so với người hỏi** (ví dụ không tự duyệt `resource.nguoi_lap != user.ma_nguoi_dung`) trên quyền theo phạm vi đơn vị, hoặc quyền có điều kiện ngay trên cây / gán trực tiếp → **vai trò trên bản ghi theo người** `<vai trò>__<phạm vi>__<điều kiện>` (`vai_tro_tren_ban_ghi.json`, `cach_gan: theo_pham_vi`): ứng dụng gán cho **từng người** đang có vai trò gốc theo phạm vi và thoả điều kiện khi xét với chính người đó; tính lại khi bản ghi đổi thuộc tính, quan hệ, hoặc khi gán / gỡ vai trò gốc. Toán tử `NOT_EQUALS_REF` có trong mã sinh Rego của VAuthz, chưa có trong file JSON mẫu.
  - Quyền «mình lập / được giao» của vai trò theo đơn vị **có điều kiện** → vai trò trên bản ghi riêng `<…>__<điều kiện>` (`cach_gan: theo_thuoc_tinh`, kèm `dieu_kien_dsl`): ứng dụng **chỉ gán khi bản ghi thoả**, gỡ khi hết thoả (ví dụ «chỉ sửa hồ sơ mình lập khi còn nháp»).
  - **Xuất danh sách** (loại `xuat`, `xuat_file`, `tai_xuong_ds` có dữ liệu) → **hạ xuống mức bản ghi** (`scripts/ha_muc.py`, dùng chung cho xuất JSON và DSL), **có hay không có điều kiện**: theo KT-02 tệp xuất chỉ gồm bản ghi được xem, nên quyền xuất cấp trên từng bản ghi theo **đúng phạm vi xem của chính vai trò đó**, điều kiện = điều kiện xem + điều kiện xuất. Không thêm phạm vi, không thêm người. Đội phát triển: tệp xuất = các bản ghi người dùng được quyền xuất. Vai trò không có quyền xem trên tài nguyên → **không cấp** (tệp xuất luôn rỗng theo KT-02).
  - **Thêm mới, nhập danh sách** của vai trò theo đơn vị → hành động `<tài nguyên>__<hành động>[__<điều kiện>]` trên **nút cây mà bản ghi mới gắn vào** (quan hệ đơn vị sở hữu, ví dụ `thuoc_don_vi`), không để ở vai trò chung (vai trò chung cho tạo bản ghi cho mọi đơn vị). Có điều kiện theo dữ liệu bản ghi (ví dụ chỉ tạo hồ sơ loại A): biến thể theo điều kiện, ứng dụng chỉ kiểm biến thể khi dữ liệu sắp ghi thoả; vai trò toàn hệ thống: biến thể `<hành động>__<điều kiện>` trên tài nguyên. Ghi `kiem_khi_tao.json`; báo cáo mục «Thêm mới, nhập danh sách». Chỉ hành động không đọc, không ghi bản ghi (tải tệp mẫu tách từ nhập danh sách) còn ở `…__quyen_chung`.
  - **Không bao giờ nới rộng**: quyền không áp được phạm vi hoặc điều kiện (điều kiện chưa có `bieu_thuc`, phép so chưa áp được, thiếu quan hệ, thiếu nơi gán) thì **không cấp**; báo cáo mục «Quyền không cấp» nêu lý do, `ai_duoc_lam_gi.md` ghi «KHÔNG CẤP — …». Báo người dùng số quyền không cấp và cách sửa (viết biểu thức, thêm quan hệ, hỏi BA — sửa qua `/ra-soat-phan-quyen cap-nhat`).
  - `cach_ap.json`: mỗi quyền hiệu lực một dòng — cách áp (`vai_tro_chung`, `vai_tro_tren_tai_nguyen`, `quan_he_theo_dieu_kien`, `luat_cap_them`, `luat_nguoi_lap`, `vai_tro_ban_ghi`, `vai_tro_ban_ghi_theo_nguoi`, `tao_tren_cay`, `bien_the`, `khong_cap`) và quyền DSL thực hiện; `xuat_dsl.py`, `so_sanh_thu.py` đọc tệp này.
  - Báo cáo có mục «Lưu ý cho đội phát triển khi gọi kiểm quyền»: VAuthz ưu tiên thuộc tính gửi kèm yêu cầu hơn thuộc tính đã lưu, nên với bản ghi đã có **không gửi `resource.attributes` / `user.attributes`**, không chuyển tiếp thuộc tính từ máy khách; mọi API kiểm `(người dùng, hành động, bản ghi)`; đổi trạng thái thì gỡ cũ trước, ghi mới sau.
  - Giá trị trong điều kiện dùng key chuẩn (`DU_THAO`, `CHO_DUYET`…); CSDL ghi khác (`DRAFT`, `PENDING_APP`…) thì đặc tả phải khai `gia_tri` cho thuộc tính, công cụ đổi sang giá trị CSDL khi xuất. Chưa khai mà mô tả trường ghi giá trị khác, công cụ cảnh báo: điều kiện sẽ không bao giờ thoả, tức là mất quyền khi hệ đích áp điều kiện. Báo người dùng; bổ sung `gia_tri` qua `/ra-soat-phan-quyen cap-nhat`.
  - Báo cáo liệt kê thuộc tính ứng dụng phải đồng bộ sang hệ phân quyền theo đúng key thiết kế (không dùng tên cột CSDL), và toán tử chưa có trong file JSON mẫu (`IN`, `CONTAINS`).
- Hệ phân quyền đích dùng khuôn khác: giữ `thiet_ke_phan_quyen.json` làm nguồn, viết bộ chuyển riêng theo khuôn đích.

### 2. Xuất DSL cho playground

```bash
python -I <chung>/scripts/xuat_dsl.py <lv> [--mot-tep] [--tai-nguyen a,b]
```

Từ chối nếu bản xem trước chưa được xác nhận. Tự chạy `xuat_json.py` nếu JSON import chưa có hoặc cũ hơn thiết kế; xoá tệp đánh dấu `BAN_NHAP_CHUA_XAC_NHAN.txt` do bước so sánh của `/ra-soat-phan-quyen` để lại (bản xuất lúc này là bản cuối). Ghi:

| Tệp | Nội dung |
|---|---|
| `ai_duoc_lam_gi.md` | **Câu trả lời chính.** Theo mảng → tài nguyên, mỗi dòng: ai (vai trò, nơi gán), được làm gì, trên bản ghi nào (phạm vi bằng chữ), điều kiện, nguồn gốc, vai trò DSL thực hiện quyền |
| `playground.dsl` | Toàn bộ cấu trúc phân quyền của phân hệ |
| `playground_theo_mang/<mảng>.dsl` | Mỗi tệp một mảng, cộng cây và vai trò cầu nối cần để tính phạm vi |
| `bao_cao_playground.md` | Số liệu và kết quả tự kiểm |

**Đưa người dùng các tệp theo mảng để import**: tệp toàn bộ của phân hệ lớn (hàng trăm KB) làm playground chậm và sơ đồ rối.
- Cấu trúc: vai trò trên tài nguyên → `role`, kế thừa qua quan hệ → `derive`, vai trò chung → `role k "Tên": res:act`.
- Quyền «trên bản ghi mình lập / được giao» của vai trò theo đơn vị → `role` trên tài nguyên, không `derive` (ứng dụng gán trên bản ghi); của vai trò xét theo bản ghi → `userset` / `resourceset … where resource.nguoi_lap == user.ma_nguoi_dung` / `permit`.
- **Không có dữ liệu mẫu**: không `user`, `instance`, `assign`, `relate`, `assert`. Đầu mỗi tệp là khối chú thích «Ai được làm gì trên tài nguyên nào» cùng nội dung với `ai_duoc_lam_gi.md`, chỉ gồm các tài nguyên của tệp.
- Key trong DSL toàn tiếng Việt không dấu; tenant `mac_dinh`.
- Tự kiểm trên cấu trúc, chạy riêng cho tệp toàn bộ và từng tệp theo mảng. Với mỗi vai trò, công cụ lần theo `derive` từ nơi vai trò được gán và tính tập (tài nguyên, hành động) DSL cấp, kèm loại phạm vi của đường đi: nơi được gán / lan xuống cấp dưới qua `cap_tren` / theo cấp duyệt / quyền chung / ABAC. Kết quả so với thiết kế; **lệch khác 0 là lỗi của bước xuất**, báo người dùng. Lệch gồm ba loại: thiết kế có mà DSL không cấp; DSL cấp mà thiết kế không có; sai loại phạm vi.
- Quan hệ theo điều kiện là quan hệ thường trong `relations { … }` và `derive … via <quan hệ>__<điều kiện>`; đầu tệp ghi chú quan hệ nào ứng dụng chỉ ghi khi hồ sơ thoả điều kiện gì.
- DSL chỉ có `permit` cấp thêm quyền. Luật điều kiện của JSON xuất thành `userset … where user.vai_tro_chung contains "<vai trò>"`, `resourceset … where resource.trang_thai in [...] and resource.public == true`, `permit … to …: <hành động>` (cú pháp đã thử trên playground). Điều kiện chưa áp được chỉ ghi thành chú thích cuối tệp.
- **Tự kiểm điều kiện**: theo `cach_ap.json`; in `… 0 lệch · 0 nới rộng · N không cấp`. Quyền không cấp không tính là lệch (cố ý), nhưng phải báo người dùng cùng lý do. Thêm mới kiểm trên cây và biến thể theo điều kiện được tự kiểm như quyền thiết kế tương ứng (kỳ vọng phạm vi «nơi được gán»).
- Thư mục có `so_sanh.json` (từ bước so sánh của `/ra-soat-phan-quyen`): công cụ tự chạy lại so sánh với ma trận của BA trên bản cuối và ghi bản trải phẳng theo thiết kế cuối `so_sanh/trai_phang_theo_thiet_ke.xlsx` (khung baseline, ô lệch tô màu); xuất bản lại trang so sánh; báo số ô lệch, và nếu số ô lệch khác lần rà soát thì nêu rõ (thiết kế đã đổi sau so sánh).

### 3. Tệp thử để xem trực quan (mỗi vai trò một người dùng)

```bash
python -I <chung>/scripts/du_lieu_thu.py <lv>
```

`xuat_dsl.py` tự chạy bước này. Tệp DSL chính thức không có người dùng nên tab **Matrix** của playground trống. Bước này ghi tệp riêng `playground_thu/<mảng>_thu.dsl` = DSL chính thức + dữ liệu thử, ghi rõ «DỮ LIỆU THỬ»; tệp chính thức không đổi.
- Mỗi vai trò thiết kế một người dùng, key là key vai trò (vai trò theo bản ghi như «người lập» thể hiện bằng thuộc tính hồ sơ).
- Cây đơn vị thử dùng tên cấp thật của cây CTĐ-CTCT, có nhánh nội bộ, nhánh cấp dưới và một đơn vị ngang cấp để thấy chỗ không được.
- Mỗi tài nguyên dữ liệu một hồ sơ thử tại mỗi nút ở «ban_ghi_tai»; không có assert.
- Cấu hình `<lv>/du_lieu_thu.json` thường đã có từ bước so sánh khi rà soát; chưa có thì công cụ tạo với nơi gán mặc định là Quân khu 1 và **AI sửa tệp này** theo `cap` của từng vai trò (trợ lý, trưởng phòng tại phòng; thủ trưởng tại cơ quan chính trị; vai trò tiếp nhận tại đơn vị tiếp nhận), thêm nút cây khi phân hệ cần, đặt «nguoi_lap» là vai trò lập hồ sơ, khai `ho_so` với thuộc tính trạng thái, khoá, loại… theo giá trị CSDL (một hồ sơ chờ duyệt, một hồ sơ đã duyệt và khoá, một bản nháp) để thấy quyền theo điều kiện, rồi chạy lại. Nơi gán là dữ liệu thử, không phải nguồn; nêu rõ với BA.

### 4. Excel cuối giữ định dạng 3 bảng, tô màu thay đổi (khi đầu vào là mẫu 3 bảng)

```bash
python -I <chung>/scripts/doi_chieu_ba_bang.py anh-xa <lv>
python -I <chung>/scripts/doi_chieu_ba_bang.py excel <lv> [--ban-sach] [--tep <xlsx gốc>]
```

1. `anh-xa` đọc lại `anh_xa_ba_bang.json` (thường đã có từ rà soát) và bổ sung phần còn thiếu. Còn mục `null` (thoát mã 1): **AI điền** theo `thiet_ke_phan_quyen.json` — tài nguyên: key thiết kế; thuộc tính: key thiết kế hoặc `""` (không dùng trong phân quyền, giữ nguyên dòng); hành động: danh sách key thiết kế (`[]` = bỏ); vai trò tài nguyên: danh sách vai trò thiết kế (tách theo nhóm người giữ thì nhiều vai trò; `[]` = bỏ); quan hệ: `"<tài nguyên thiết kế>.<key quan hệ>"` hoặc `""`. Chỉ ghép theo nội dung thiết kế (`mo_ta`, `y_nghia`, `tach_tu`, nguồn), không đổi quyền. Mục nào không quyết được thì hỏi BA một câu, không đoán.
2. `excel` từ chối khi BA chưa xác nhận hoặc còn mục chưa ghép. Công cụ chép **tệp Excel gốc** (đường dẫn trong `ba_bang.json`; không thấy thì truyền `--tep`) và viết lại sheet 3 bảng theo **quyền hiệu lực** của thiết kế đã xác nhận (cùng nguồn với JSON import và DSL):
   - giữ nguyên tiêu đề bảng, tên cột, thứ tự cột, kiểu ô, độ rộng cột, ô gộp theo khối tài nguyên; Bảng 4 trở đi và các sheet khác giữ nguyên nội dung (dời xuống khi Bảng 2, Bảng 3 dài thêm);
   - Bảng 1: chỉ điền key AI đặt (nếu sheet gốc để trống key);
   - Bảng 2: key tài nguyên, thuộc tính, hành động, vai trò tài nguyên theo key thiết kế (key chuẩn của thuộc tính, hành động tách / gộp, vai trò tách theo người giữ), ô «Hành động được phép» là danh sách key hành động hiệu lực của vai trò đó, cách nhau bởi dấu phẩy; cây đơn vị lấy từ Cổng giữ nguyên các dòng, chỉ đổi key;
   - bảng vai trò riêng («… hành động được phép của vai trò», không nằm trong cột của Bảng 2): viết lại tại chỗ, các vai trò theo thứ tự tài nguyên, giữ tiêu đề, tên cột, kiểu ô;
   - mẫu không có cột key (chỉ ghi tên): giữ cách ghi bằng tên — ô vai trò, hành động, quan hệ ghi tên, ô «Hành động được phép» ghi tên hành động; key thiết kế nằm trong ghi chú của ô;
   - Bảng 3: quan hệ theo key thiết kế, thêm các quan hệ thiết kế bổ sung khi rà soát (thường là quan hệ AI suy ra);
   - **tô màu**: nền xanh = thêm (dòng, hành động, vai trò, quan hệ mới), nền vàng = sửa (đổi key, tách / gộp, đổi hành động được phép), nền đỏ nhạt chữ đỏ gạch ngang = bỏ; trong ô «Hành động được phép», hành động được thêm in xanh đậm, hành động bị bỏ in đỏ gạch ngang; ô thay đổi có **ghi chú** (comment) nêu bản gốc và căn cứ (tài liệu / BA chốt / AI suy ra);
   - thêm sheet «Thay đổi» (chú thích màu và danh sách từng thay đổi: bảng, loại, mục, ô gốc, cũ, mới, căn cứ, dấu AI suy ra) và sheet «Phạm vi, điều kiện» (mỗi quyền hiệu lực: vai trò, tài nguyên, hành động, phạm vi bằng chữ, điều kiện, nguồn), vì định dạng 3 bảng không có cột cho phạm vi, điều kiện.
3. Kết quả: `<lv>/<tên tệp gốc>_phan_quyen_cuoi.xlsx`; với `--ban-sach` thêm `…_phan_quyen_cuoi_ban_sach.xlsx` (không màu, không ghi chú, không dòng bỏ, không sheet «Thay đổi») để dán thẳng vào tài liệu. Bản sạch đọc lại được bằng `ba_bang.py doc` như một mẫu 3 bảng bình thường. Không ghi đè tệp Excel gốc của BA.
4. Kiểm sau khi xuất: chạy `python -I <chung>/scripts/ba_bang.py doc <thư mục tạm> <bản sạch> --sheet <tên sheet>` (thư mục tạm, không phải `<lv>`) và báo số cảnh báo (phải là 0); báo người dùng số thêm / sửa / bỏ theo `thay_doi.md`. Nhắc rằng Bảng 4 trở đi của sheet gốc (nếu có) không được skill cập nhật và có thể còn key cũ.

Đầu vào là mẫu cũ 6 sheet hoặc chỉ có tài liệu Word / PDF: bỏ qua bước này (không có định dạng 3 bảng gốc để giữ); báo người dùng có thể lập Excel 3 bảng từ thiết kế nếu cần.

### 5. Bảng phân quyền trải phẳng theo khung (chỉ khi BA không có ma trận trải phẳng cho nghiệp vụ này)

Có baseline trải phẳng thì bỏ qua bước này: bản trải phẳng theo thiết kế đã ra ở bước 2 (`so_sanh/trai_phang_theo_thiet_ke.xlsx`).

```bash
python -I <chung>/scripts/ma_tran_trai_phang.py lap <lv> [--khong-ghi-chu]
```

- Dùng `<lv>/ma_tran_trai_phang.json` đã lập ở bước 9b của `/ra-soat-phan-quyen` (khung, cột thông tin, ghép cột chức danh – vai trò, tách dòng). Chưa có: BA nêu tệp và sheet khung (một sheet trải phẳng của nghiệp vụ khác hoặc bản cũ), chạy `ma_tran_trai_phang.py khung <tệp> <sheet>`, AI lập tệp cấu hình theo khuôn ở đầu script; ghép cột với vai trò chỉ theo nguồn, cột không ghép được thì hỏi BA, không đoán.
- Từ chối khi BA chưa xác nhận. Ghi `<lv>/ma_tran_trai_phang/<ten>.xlsx` (sheet khung giữ định dạng, ô gộp, nhóm cột, chú thích; dòng = tài nguyên × hành động của thiết kế; ô «x» / «x*» / trống tính thẳng từ quyền hiệu lực, cùng nguồn với JSON và DSL; ghi chú ô nêu vai trò, phạm vi, điều kiện; sheet «Cột – vai trò»), `ma_tran.html`, `ma_tran.md`. `--khong-ghi-chu` bỏ ghi chú ô khi dán vào tài liệu.
- Xuất bản `ma_tran.html` thành Artifact (cùng đường dẫn, cùng link với bản nháp nếu đã có). Báo số dòng, cột, ô x / x*, cột không có vai trò, vai trò không cột nào ghép. Nhắc: bảng là cách trình bày thiết kế, không phải nguồn.

### Nạp lên playground

Playground: https://trantuananh1.github.io/authz-playground/ (chạy hoàn toàn trong trình duyệt).
- Phiên có trình duyệt tích hợp (công cụ `mcp__Claude_Browser__*`): mở trang; nén tệp `gzip -9c <tệp> | base64 -w0`; trong trang giải nén bằng `DecompressionStream('gzip')`, gán vào `input[type=file]` qua `DataTransfer`, phát sự kiện `change`; đợi khoảng 2 giây rồi đọc nhãn **Valid** và mục **Problems**, báo cho BA. Nút Import mở hộp chọn tệp của hệ điều hành, trình duyệt tích hợp không điều khiển được, nên không bấm nút này.
- Không có trình duyệt tích hợp: đưa BA đường dẫn tệp và hướng dẫn bấm **Import** → chọn tệp `.dsl`.
- Tệp chính thức chỉ có cấu trúc nên mục Tests và Data trống (0); playground dùng để xem sơ đồ tài nguyên – vai trò – kế thừa. Cảnh báo «Resource '…' has no actions» là chủ ý (cây đơn vị chỉ để tính phạm vi). Tab Matrix: dùng tệp thử (bước 3).

## Báo kết quả cho người dùng

Ngắn gọn, gồm:
- số tài nguyên, vai trò, quyền hiệu lực; số quyền không cấp kèm lý do và cách sửa;
- kết quả tự kiểm DSL (lệch / nới rộng / không cấp) và kết quả nạp playground (Valid / Problems);
- việc đội phát triển phải làm: quan hệ theo điều kiện, vai trò trên bản ghi, thuộc tính đồng bộ theo key thiết kế, giá trị CSDL còn thiếu;
- Excel cuối: số thêm / sửa / bỏ, đường dẫn bản màu và bản sạch;
- bảng trải phẳng theo khung (nếu có): đường dẫn Excel, link Artifact lưới;
- độ khớp với ma trận BA trên bản cuối nếu có;
- đường dẫn JSON import, `ai_duoc_lam_gi.md`, các tệp DSL theo mảng.

Không chép nguyên báo cáo.
