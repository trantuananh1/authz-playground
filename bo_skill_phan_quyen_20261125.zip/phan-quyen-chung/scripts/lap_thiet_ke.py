# -*- coding: utf-8 -*-
"""Lập bản thiết kế phân quyền từ giao dịch của tài liệu (mọi tệp giao_dich*.json) và đặc tả do AI viết (dac_ta.json).

  python -I lap_thiet_ke.py <thu_muc_lam_viec>

Ghi: thiet_ke_phan_quyen.json (xac_nhan.py, xuat_json.py, xuat_dsl.py đọc tệp này), bao_cao_thiet_ke.md.
- Key hành động giữ đúng như tài liệu, KHÔNG gộp (xem_ds, xem_ct, tim_kiem là ba hành động); bộ key chuẩn (bo_key.py) chỉ để phân loại
  hành động khi áp quy định kế thừa. Ngoại lệ: xem_ds, xem_ct (xem danh sách, xem chi tiết) gộp thành `xem`.
  Phạm vi, quan hệ, thuộc tính vẫn quy bí danh về key chuẩn (báo KEY-01).
- Cây đơn vị lấy từ Cổng (`unit`): tự thêm nếu đặc tả chưa có; phân hệ không thiết kế quyền trên cây đơn vị.
MỌI QUYỀN CÓ NGUỒN: mọi quyền, phạm vi, điều kiện phải có căn cứ là ô / đoạn tài liệu, câu BA chốt, hoặc «AI suy ra»
kèm ô căn cứ (chỉ khi đặc tả bật `suy_ra`, mặc định; thiếu `suy_ra.bat` mà có nguồn suy ra là lỗi SR-01).
- Quy tắc tac_nhan, theo_cap_duyet, loc_vai_tro, bo_sung, pham_vi, dieu_kien và mỗi vai trò phải ghi `nguon`
  (danh sách vị trí tài liệu, «BA chốt …» hoặc «AI suy ra …»); thiếu thì báo lỗi NG-01 / NG-02 và không áp.
- Quy định kế thừa KT-xx KHÔNG tự cấp quyền, không tự đặt phạm vi, không tự thêm điều kiện; chỗ quy định đó
  lẽ ra áp được ghi thành mục `thieu_nguon` và câu hỏi «Thiếu nguồn» (id NG-…) cho BA.
- Quyền chưa có phạm vi theo nguồn, tác nhân chưa biết ai giữ: không đưa vào thiết kế, ghi vào `thieu_nguon`.
Trạng thái quyền: giu (theo tài liệu / BA chốt / AI suy ra) · bo (tài liệu hoặc BA chốt nói bỏ).
Quy định kế thừa: references/quy-dinh-ke-thua.md. Câu mô tả cho BA: mục cau_mo_ta.
"""
import argparse, collections, hashlib, json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bo_key as BK  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
OD = collections.OrderedDict
GHI = {"them_moi", "chinh_sua", "xoa"}  # nhóm quyền ghi dữ liệu (cộng thêm hành động import)
RANK = {"cao": 3, "trung_binh": 2, "thap": 1}
HIEU_LUC = ("giu", "them", "ke_thua")
# quy định kế thừa công cụ dò chỗ thiếu nguồn (references/quy-dinh-ke-thua.md): mã → (tên ngắn, nguyên tắc)
KT = {
    "KT-01": ("Làm được trên bản ghi thì xem được bản ghi đó", "NT-07"),
    "KT-03": ("Người lập xem được bản ghi do mình lập, kể cả khi đã chuyển đơn vị", "NT-16"),
    "KT-06": ("Tác vụ ghi làm trên dữ liệu của đơn vị nơi được gán", "NT-12"),
    "KT-07": ("Cấp trên xem được dữ liệu của mình và mọi cấp dưới; quyền ghi không lan xuống", "NT-13"),
    "KT-08": ("Chỉ duyệt bản ghi đang chờ đơn vị mình duyệt", "NT-14"),
    "KT-09": ("Vai trò toàn hệ thống làm việc trên toàn bộ dữ liệu", "NT-12"),
    "KT-13": ("Người lập không tự duyệt, tự trả lại bản ghi của mình", "NT-03"),
    "KT-14": ("Sửa, xoá, gửi khi còn nháp; duyệt khi đang chờ duyệt", "NT-15"),
    "KT-15": ("Dữ liệu đã khoá không sửa, không xoá", "NT-15"),
    "KT-16": ("Thông tin nhạy cảm không lan theo cấp trên", "NT-17"),
    "KT-20": ("Quản trị hệ thống không kế thừa quyền nghiệp vụ", "NT-22"),
}
NGUON = {"giu": "ba", "them": "ai_them", "ke_thua": "ke_thua", "bo": "nguon_bo"}
CAN_NGUON = ("tac_nhan", "theo_cap_duyet", "loc_vai_tro", "bo_sung", "pham_vi", "dieu_kien")   # quy tắc phải ghi `nguon`


def co_nguon(x):
    n = x.get("nguon") if isinstance(x, dict) else None
    return isinstance(n, list) and any((isinstance(i, str) and i.strip()) or (isinstance(i, dict) and (i.get("vt") or i.get("trich"))) for i in n)


def nguon_chu(n):
    """Danh sách nguồn → chuỗi ngắn để in."""
    return "; ".join(i if isinstance(i, str) else (i.get("vt") or i.get("trich") or "") for i in (n or []))
TU_DUYET = [{"trai": "resource.nguoi_lap", "phep": "khac", "phai": "user.ma_nguoi_dung"}]


def doc(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def ds(x):
    return [] if x in (None, "*") else (x if isinstance(x, list) else [x])


def noi(a):
    a = [x for x in a if x]
    return a[0] if len(a) == 1 else ", ".join(a[:-1]) + " và " + a[-1] if a else ""


def thuong(s):
    s = str(s or "")
    return s[:1].lower() + s[1:] if s[:2] != s[:2].upper() else s


def chuan_hoa(S):
    """Quy mọi key của đặc tả về bộ key chuẩn. Trả về Counter (loại, cũ, mới) đã đổi."""
    LOG = collections.Counter()

    def doi(loai, cu, moi):
        if cu != moi:
            LOG[(loai, cu, moi)] += 1
        return moi

    ten_tn = {t["key"]: BK.CAY_CONG["key"] for t in S["tai_nguyen"] if t.get("loai") == "cay" and t["key"] in BK.CAY_CONG["bi_danh"]}
    if any(t["key"] == BK.CAY_CONG["key"] for t in S["tai_nguyen"]):
        ten_tn = {}
    tn = lambda k: doi("tài nguyên", k, ten_tn.get(k, k)) if isinstance(k, str) else k
    tns = lambda x: [tn(k) for k in x] if isinstance(x, list) else tn(x)
    hd = lambda k: doi("hành động", k, BK.hanh_dong(k))

    def hds(x):
        out = []
        for k in (x if isinstance(x, list) else [x]):
            if isinstance(k, str) and k.startswith("@"):
                k2 = "@" + BK.muc(BK.nhom(k[1:]))
                doi("nhóm hành động", k, k2)
            else:
                k2 = hd(k) if k != "*" else k
            if k2 not in out:
                out.append(k2)
        return out if isinstance(x, list) else out[0]

    tt = lambda k: doi("thuộc tính", k, BK.thuoc_tinh(k))
    qh = lambda k: doi("quan hệ", k, BK.quan_he(k)) if k not in ("(gan_truc_tiep)",) else k
    ttv = lambda v: [doi("giá trị trạng thái", x, BK.trang_thai(x)) for x in v] if isinstance(v, list) else doi("giá trị trạng thái", v, BK.trang_thai(v)) if isinstance(v, str) else v
    for t in S["tai_nguyen"]:
        t["key"] = tn(t["key"])
        for r in t.get("quan_he", []):
            r["key"], r["toi"] = qh(r["key"]), tn(r["toi"])
        for x in t.get("thuoc_tinh", []):
            x["key"] = tt(x["key"])
        moi = []
        for h in t.get("hanh_dong", []):
            h = dict(h) if isinstance(h, dict) else {"key": h}
            h["key"] = hd(h["key"])
            if "nhom" in h:
                h["nhom"] = BK.nhom(h["nhom"])
            if "muc" in h:
                h["muc"] = BK.muc(h["muc"])
            if all(x["key"] != h["key"] for x in moi):
                moi.append(h)
        t["hanh_dong"] = moi
        if t.get("vong_doi"):
            t["vong_doi"] = {doi("nhóm trạng thái", k, BK.vong_doi(k)): ttv(v) for k, v in t["vong_doi"].items()}
    for v in S["vai_tro"]:
        if v.get("gan_tren"):
            v["gan_tren"] = tn(v["gan_tren"])
    ten_pv = {}
    for p in S.get("pham_vi", []):
        p["kieu"] = doi("kiểu phạm vi", p.get("kieu"), BK.pham_vi(p.get("kieu")))
        if p["key"] in BK.BD_PV and BK.BD_PV[p["key"]] != p["key"]:
            ten_pv[p["key"]] = BK.BD_PV[p["key"]]
            p["key"] = doi("phạm vi", p["key"], BK.BD_PV[p["key"]])
        if isinstance(p.get("quan_he"), dict):
            p["quan_he"] = {(k if k == "*" else tn(k)): qh(v) for k, v in p["quan_he"].items()}
        elif isinstance(p.get("quan_he"), str):
            p["quan_he"] = qh(p["quan_he"])
    for d in S.get("dieu_kien", []) + [p for p in S.get("pham_vi", []) if p.get("bieu_thuc")]:
        for b in d.get("bieu_thuc", []):
            if str(b.get("trai", "")).startswith("resource."):
                b["trai"] = "resource." + tt(b["trai"][9:])
            b["phai"] = ttv(b.get("phai"))
    Q = S.get("quy_tac", {})
    for r in Q.get("tai_nguyen", []):
        r["tai_nguyen"] = tn(r["tai_nguyen"])
    for r in Q.get("hanh_dong", []):
        r["hanh_dong"] = hd(r["hanh_dong"])
        if r.get("tai_nguyen"):
            r["tai_nguyen"] = tns(r["tai_nguyen"])
    for r in Q.get("loc_vai_tro", []):
        for k in ("tai_nguyen", "chi_tai_nguyen"):
            if k in r:
                r[k] = tns(r[k])
        if "bo_hanh_dong" in r:
            r["bo_hanh_dong"] = hds(r["bo_hanh_dong"])
        for k in ("chi_nhom_hanh_dong", "bo_nhom_hanh_dong"):
            if k in r:
                r[k] = [doi("nhóm hành động", x, BK.nhom(x)) for x in r[k]]
    for r in Q.get("bo_sung", []):
        r["tai_nguyen"], r["hanh_dong"] = tns(r["tai_nguyen"]), hds(r["hanh_dong"])
    for nhom in ("pham_vi", "dieu_kien"):
        for r in Q.get(nhom, []):
            if r.get("tai_nguyen", "*") != "*":
                r["tai_nguyen"] = tns(r["tai_nguyen"])
            if "hanh_dong" in r:
                r["hanh_dong"] = hds(r["hanh_dong"])
            if "pham_vi" in r:
                r["pham_vi"] = ten_pv.get(r["pham_vi"], BK.pham_vi(r["pham_vi"]) if r["pham_vi"] in ("toan_bo", "muc_danh_sach") else r["pham_vi"])
    for r in (S.get("ke_thua") or {}).get("khong_ap_dung", []):
        if r.get("tai_nguyen"):
            r["tai_nguyen"] = tns(r["tai_nguyen"])
    return LOG


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("thu_muc")
    wd = ap.parse_args().thu_muc
    S = doc(os.path.join(wd, "dac_ta.json"))
    GD = []   # mọi tệp giao_dich*.json: bảng chức năng, ma trận BA, quy trình, tự lập
    for f in sorted(x for x in os.listdir(wd) if x.startswith("giao_dich") and x.endswith(".json")):
        GD += doc(os.path.join(wd, f))
    if len({g["id"] for g in GD}) != len(GD):
        sys.exit("Trùng id giao dịch giữa các tệp giao_dich*.json")
    nguon = doc(os.path.join(wd, "nguon.json")) if os.path.exists(os.path.join(wd, "nguon.json")) else []
    LOG_KEY = chuan_hoa(S)
    Q = S.get("quy_tac", {})
    LOI = []

    # ---------- cây đơn vị lấy từ Cổng ----------
    CK = BK.CAY_CONG["key"]
    tro_toi_cong = any(r.get("toi") == CK for t in S["tai_nguyen"] for r in t.get("quan_he", [])) or any(v.get("gan_tren") == CK for v in S["vai_tro"])
    if not any(t["key"] == CK for t in S["tai_nguyen"]) and (tro_toi_cong or not any(t.get("loai") == "cay" for t in S["tai_nguyen"])):
        S["tai_nguyen"].insert(0, {"key": CK, "ten": BK.CAY_CONG["ten"], "loai": "cay", "mang": "Tổ chức", "tu_cong": True, "hanh_dong": [],
                                   "quan_he": [{"key": "cap_tren", "toi": CK, "y_nghia": "Đơn vị cấp trên"}],
                                   "mo_ta": "Cây đơn vị do Cổng quản lý, dùng chung mọi phân hệ; nơi gán vai trò theo đơn vị."})
    for t in S["tai_nguyen"]:
        if t["key"] == CK:
            t["tu_cong"] = True
    for v in S["vai_tro"]:
        if v.get("loai_pham_vi") == "theo_don_vi" and not v.get("gan_tren") and any(t["key"] == CK for t in S["tai_nguyen"]):
            v["gan_tren"] = CK

    # ---------- tài nguyên, hành động ----------
    TN = OD()
    for t in S["tai_nguyen"]:
        hd = OD()
        for h in t.get("hanh_dong", []):
            # key giữ đúng như tài liệu (không gộp); loại chuẩn chỉ để áp quy định kế thừa. Đặc tả ghi «loai» để phân loại key lạ.
            c = BK.thong_tin_hanh_dong(h["key"])
            lo = BK.loai_hanh_dong(h["loai"]) if h.get("loai") else c[3]
            if h.get("loai") and lo:
                c = BK.thong_tin_hanh_dong(lo)
            hd[h["key"]] = {"key": h["key"], "ten": h.get("ten", c[0]), "muc": h.get("muc", c[1]), "nhom": h.get("nhom", c[2]), "loai": lo,
                            **({"tach_tu": h["tach_tu"]} if h.get("tach_tu") else {}),
                            **({"nhay_cam": True} if h.get("nhay_cam") or lo == "xem_nhay_cam" else {}),
                            **({"rieng": True} if not lo and not h.get("nhom") else {})}
        TN[t["key"]] = {**t, "hanh_dong": list(hd.values()), "_hd": hd, "thuoc_tinh": list(t.get("thuoc_tinh", []))}
    for t in TN.values():
        for r in t.get("quan_he", []):
            if r["toi"] not in TN:
                LOI.append(f"Tài nguyên {t['key']}: quan hệ {r['key']} trỏ tới {r['toi']} không có")
    VT = OD((v["key"], dict(v)) for v in S["vai_tro"])
    PV = OD((p["key"], dict(p)) for p in S.get("pham_vi", []))
    DK = OD((d["key"], dict(d)) for d in S.get("dieu_kien", []))
    hd_cua = lambda rk, a: TN[rk]["_hd"].get(a) if rk in TN else None
    loai = lambda rk, a: (hd_cua(rk, a) or {}).get("loai")   # loại chuẩn của hành động (key giữ như tài liệu)

    # ---------- 0. kiểm tra tham chiếu của đặc tả (gõ sai key không được im lặng) ----------
    for v in VT.values():
        if v.get("loai_pham_vi") not in ("toan_he_thong", "theo_don_vi", "theo_ban_ghi"):
            # theo_ban_ghi: vai trò xét theo thuộc tính bản ghi, không gán theo đơn vị (ví dụ «Người lập bản ghi» khi tài liệu / BA nêu)
            LOI.append(f"Vai trò {v['key']}: loai_pham_vi phải là toan_he_thong, theo_don_vi hoặc theo_ban_ghi")
            v["loai_pham_vi"] = "toan_he_thong"
        if v["loai_pham_vi"] == "theo_don_vi" and v.get("gan_tren") not in TN:
            LOI.append(f"Vai trò {v['key']}: theo đơn vị nhưng gan_tren «{v.get('gan_tren')}» không phải tài nguyên đã khai báo")

    def chk(nhom, r, truong, tap, ten):
        for k in ds(r.get(truong)):
            if k not in tap:
                LOI.append(f"Quy tắc {nhom} {r.get('id', '?')}: {ten} «{k}» chưa khai báo")

    tat_ca_hd = {h for t in TN.values() for h in t["_hd"]}
    for r in Q.get("tai_nguyen", []):
        chk("tai_nguyen", r, "tai_nguyen", TN, "tài nguyên")
    for r in Q.get("hanh_dong", []):
        chk("hanh_dong", r, "tai_nguyen", TN, "tài nguyên")
        if r.get("hanh_dong") not in tat_ca_hd:
            LOI.append(f"Quy tắc hanh_dong {r.get('id', '?')}: hành động «{r.get('hanh_dong')}» không có trên tài nguyên nào")
    for r in Q.get("tac_nhan", []):
        chk("tac_nhan", r, "vai_tro", VT, "vai trò")
    for r in Q.get("theo_cap_duyet", []):
        chk("theo_cap_duyet", r, "vai_tro", VT, "vai trò")
    for r in Q.get("loc_vai_tro", []):
        chk("loc_vai_tro", r, "vai_tro", VT, "vai trò"); chk("loc_vai_tro", r, "tai_nguyen", TN, "tài nguyên")
        chk("loc_vai_tro", r, "chi_tai_nguyen", TN, "tài nguyên")
        for a in r.get("bo_hanh_dong", []):
            if a not in tat_ca_hd:
                LOI.append(f"Quy tắc loc_vai_tro {r.get('id', '?')}: hành động «{a}» không có trên tài nguyên nào")
    for r in Q.get("bo_sung", []):
        chk("bo_sung", r, "vai_tro", VT, "vai trò"); chk("bo_sung", r, "tai_nguyen", TN, "tài nguyên")
        for a in r.get("hanh_dong", []):
            if not any(a in TN[rk]["_hd"] for rk in ds(r.get("tai_nguyen")) if rk in TN):
                LOI.append(f"Quy tắc bo_sung {r.get('id', '?')}: hành động «{a}» không có trên tài nguyên nào được nêu")
    for nhom in ("pham_vi", "dieu_kien"):
        for r in Q.get(nhom, []):
            chk(nhom, r, "vai_tro", VT, "vai trò"); chk(nhom, r, "tai_nguyen", TN, "tài nguyên")
    for r in Q.get("pham_vi", []):
        if r.get("pham_vi") not in PV and r.get("pham_vi") not in ("toan_he_thong", "danh_sach"):
            LOI.append(f"Quy tắc pham_vi {r.get('id', '?')}: phạm vi «{r.get('pham_vi')}» chưa khai báo")
    for r in Q.get("dieu_kien", []):
        for d in r.get("dieu_kien", []):
            if d not in DK:
                LOI.append(f"Quy tắc dieu_kien {r.get('id', '?')}: điều kiện «{d}» chưa khai báo")
    KA = (S.get("ke_thua") or {}).get("khong_ap_dung", [])
    for r in KA:
        if r.get("ma") not in KT:
            LOI.append(f"ke_thua.khong_ap_dung: mã «{r.get('ma')}» không phải quy định công cụ dò ({', '.join(KT)})")
        if not r.get("ly_do"):
            LOI.append(f"ke_thua.khong_ap_dung {r.get('ma')}: thiếu lý do (tài liệu nêu khác ở đâu)")
    # chỉ theo nguồn: quy tắc quyết định ai, làm gì, trên bản ghi nào, khi nào phải có `nguon`
    for nhom in CAN_NGUON:
        giu = []
        for r in Q.get(nhom, []):
            if co_nguon(r) or r.get("tu_excel"):   # quy tắc đọc từ mẫu Excel: nguồn là ô BA khai
                giu.append(r)
            else:
                LOI.append(f"NG-01 Quy tắc {nhom} {r.get('id', '?')}: thiếu `nguon` (ô / đoạn tài liệu hoặc «BA chốt …»); quy tắc không được áp.")
        if nhom in Q:
            Q[nhom] = giu
    for v in VT.values():
        if not co_nguon(v.get("co_so") or {}) and not v.get("tu_excel"):
            LOI.append(f"NG-02 Vai trò «{v.get('ten', v['key'])}»: `co_so.nguon` trống; ghi ô / đoạn tài liệu hoặc «BA chốt …» nêu vai trò này.")
    # chế độ suy ra (mặc định, «suy_ra»: {"bat": true}); nguồn «AI suy ra …» khi đặc tả ở chế độ chỉ theo nguồn là lỗi
    SR = S.get("suy_ra") or {}
    if not SR.get("bat"):
        for nhom in CAN_NGUON:
            for r in Q.get(nhom, []):
                if BK.la_suy_ra(r.get("nguon")):
                    LOI.append(f"SR-01 Quy tắc {nhom} {r.get('id', '?')}: nguồn ghi «{BK.SUY_RA}» nhưng đặc tả đang ở chế độ chỉ theo nguồn (thiếu \"suy_ra\": {{\"bat\": true}}).")
        for v in VT.values():
            if BK.la_suy_ra((v.get("co_so") or {}).get("nguon")):
                LOI.append(f"SR-01 Vai trò «{v.get('ten', v['key'])}»: nguồn ghi «{BK.SUY_RA}» nhưng đặc tả chưa bật chế độ suy ra.")

    def khop(mau, s):
        return bool(mau) and re.search(mau, s or "", re.I) is not None

    def rule(r, loai):
        return {"id": r.get("id", ""), "loai": loai, "ly_do": r.get("ly_do", ""), "nguyen_tac": r.get("nguyen_tac", []), "tin_cay": r.get("tin_cay", "trung_binh"),
                "nguon": r.get("nguon", [])}

    DUNG = collections.Counter()   # quy tắc đã khớp ít nhất một lần
    def dung(nhom, r):
        DUNG[(nhom, r.get("id") or id(r))] += 1

    # ---------- 1. giao dịch → (tài nguyên, hành động, vai trò) ----------
    tac = {}
    for r in Q.get("tac_nhan", []):
        tac[r["tac_nhan"]] = r
    QUYEN = OD()      # (vai trò, tài nguyên, hành động) → bản ghi quyền
    GDX, chua_tn, chua_hd, chua_tac = [], collections.Counter(), collections.Counter(), collections.Counter()

    def lay(k):
        return QUYEN.setdefault(k, {"vai_tro": k[0], "tai_nguyen": k[1], "hanh_dong": k[2], "trang_thai": "giu", "giao_dich": [], "quy_tac": [], "pham_vi": None, "dieu_kien": []})

    for g in GD:
        rec = {"id": g["id"], "vt": g["vt"], "nguon": g["nguon"], "muc": g.get("muc", ""), "usecase": g["usecase"], "ten": g["ten"], "mo_ta": g.get("mo_ta", ""),
               "tac_nhan": g["tac_nhan"], "tai_nguyen": None, "hanh_dong": None, "trang_thai": "anh_xa", "ly_do": ""}
        GDX.append(rec)
        if g.get("tai_nguyen") and g.get("hanh_dong") and g.get("vai_tro"):
            # giao dịch khai trực tiếp (mẫu Excel): đã có vai trò, tài nguyên, hành động; không qua quy tắc ánh xạ
            rk, a = g["tai_nguyen"], BK.hanh_dong(g["hanh_dong"])
            if rk not in TN or not hd_cua(rk, a):
                rec.update(trang_thai="chua_anh_xa", ly_do=f"Tài nguyên «{rk}» hoặc hành động «{a}» chưa có trong đặc tả"); chua_hd[(rk, g["ten"])] += 1
                continue
            rec.update(tai_nguyen=rk, hanh_dong=a)
            xl = {"id": "XL", "loai": "tai_nguyen", "ly_do": "Khai trực tiếp trong mẫu Excel", "nguyen_tac": [], "tin_cay": "cao"}
            for vk in g["vai_tro"]:
                if vk not in VT:
                    chua_tac[vk] += 1; continue
                q = lay((vk, rk, a))
                q["giao_dich"].append(g["id"])
                if not any(x["id"] == "XL" for x in q["quy_tac"]):
                    q["quy_tac"].append(dict(xl))
            continue
        nht = g.get("ngoai_he_thong") or BK.ngoai_he_thong(g.get("ten"), g.get("mo_ta"))
        if nht:
            # bước làm ngoài hệ thống: không phân quyền, áp cho mọi phân hệ, không cần quy tắc bo_qua trong đặc tả
            rec.update(trang_thai="ngoai_he_thong", ly_do="Tài liệu ghi bước này làm ngoài hệ thống: không phân quyền")
            continue
        bq = next((r for r in Q.get("bo_qua", []) if khop(r.get("mau_giao_dich"), g["ten"]) or khop(r.get("mau_usecase"), g["usecase"]) or khop(r.get("mau_muc"), g.get("muc"))
                   or (r.get("tac_nhan") and set(g["tac_nhan"]) <= set(r["tac_nhan"])) or (r.get("ngoai_he_thong") and g.get("ngoai_he_thong"))), None)
        if bq:
            dung("bo_qua", bq)
            rec.update(trang_thai="bo_qua", ly_do=f"{bq.get('id', '')}: {bq.get('ly_do', '')}")
            continue
        tr = next((r for r in Q.get("tai_nguyen", []) if r.get("tai_nguyen") in TN and ((r.get("mau_giao_dich") and khop(r["mau_giao_dich"], g["ten"]) and (not r.get("mau_usecase") or khop(r["mau_usecase"], g["usecase"])))
                   or (not r.get("mau_giao_dich") and khop(r.get("mau_usecase"), g["usecase"])))), None)
        if not tr:
            rec.update(trang_thai="chua_anh_xa", ly_do="Chưa xác định được tài nguyên"); chua_tn[g["usecase"]] += 1
            continue
        dung("tai_nguyen", tr)
        rk = tr["tai_nguyen"]
        hr = next((r for r in Q.get("hanh_dong", []) if khop(r["mau"], g["ten"]) and hd_cua(rk, r["hanh_dong"]) and (not r.get("tai_nguyen") or rk in r["tai_nguyen"])), None)
        if not hr:
            rec.update(trang_thai="chua_anh_xa", tai_nguyen=rk, ly_do="Chưa xác định được hành động"); chua_hd[(rk, g["ten"])] += 1
            continue
        dung("hanh_dong", hr)
        rec.update(tai_nguyen=rk, hanh_dong=hr["hanh_dong"])
        roles = []
        for t in g["tac_nhan"]:
            if t in tac:
                dung("tac_nhan", tac[t])
                roles += [x for x in tac[t]["vai_tro"] if x not in roles and x in VT]
            else:
                chua_tac[t] += 1
        cap = next((r for r in Q.get("theo_cap_duyet", []) if khop(r["mau_giao_dich"], g["ten"])), None)
        if cap:
            dung("theo_cap_duyet", cap)
        for vk in roles:
            q = lay((vk, rk, hr["hanh_dong"]))
            if cap and vk not in cap["vai_tro"]:
                q.setdefault("giao_dich_khac_cap", []).append(g["id"])   # giao dịch của cấp duyệt khác
            else:
                q["giao_dich"].append(g["id"])
            for r_, l in ((tr, "tai_nguyen"), (hr, "hanh_dong")):
                if not any(x["id"] == r_.get("id") for x in q["quy_tac"]):
                    q["quy_tac"].append(rule(r_, l))
            for t in g["tac_nhan"]:
                if t in tac and vk in tac[t]["vai_tro"] and not any(x["id"] == tac[t].get("id") for x in q["quy_tac"]):
                    q["quy_tac"].append(rule(tac[t], "tac_nhan"))
            if cap and vk not in cap["vai_tro"]:
                q.setdefault("_bo_cap", rule(cap, "theo_cap_duyet"))
            elif cap:
                q["_giu_cap"] = True
                if not any(x["id"] == cap.get("id") for x in q["quy_tac"]):
                    q["quy_tac"].append(rule(cap, "theo_cap_duyet"))
    for q in QUYEN.values():
        b = q.pop("_bo_cap", None)
        if b and not q.pop("_giu_cap", False):
            q["trang_thai"] = "bo"; q["quy_tac"].append(b)
            q["giao_dich"] = q.pop("giao_dich_khac_cap", [])
        q.pop("_giu_cap", None)
        q.pop("giao_dich_khac_cap", None)

    # ---------- 2. lọc vai trò (tách nhiệm vụ, phân mảng, đặc quyền tối thiểu) ----------
    for r in Q.get("loc_vai_tro", []):
        for q in QUYEN.values():
            if q["vai_tro"] not in r["vai_tro"] or q["trang_thai"] != "giu":
                continue
            h = hd_cua(q["tai_nguyen"], q["hanh_dong"])
            ngoai = (("chi_tai_nguyen" in r and q["tai_nguyen"] not in r["chi_tai_nguyen"]) or
                     ("chi_nhom_hanh_dong" in r and h["nhom"] not in r["chi_nhom_hanh_dong"]) or
                     (q["hanh_dong"] in r.get("bo_hanh_dong", [])) or (h["nhom"] in r.get("bo_nhom_hanh_dong", [])))
            if ngoai and (not r.get("tai_nguyen") or q["tai_nguyen"] in r["tai_nguyen"]):
                q["trang_thai"] = "bo"; q["quy_tac"].append(rule(r, "loc_vai_tro")); dung("loc_vai_tro", r)
    # ---------- 3. bổ sung ----------
    XUNG = []   # (mã, nội dung, quyền) mâu thuẫn giữa các quy tắc
    for r in Q.get("bo_sung", []):
        for vk in r["vai_tro"]:
            for rk in r["tai_nguyen"]:
                for a in r["hanh_dong"]:
                    if vk not in VT or not hd_cua(rk, a):
                        continue
                    dung("bo_sung", r)
                    q = QUYEN.get((vk, rk, a))
                    if q is None:   # bổ sung có nguồn (tài liệu nêu ở chỗ khác, BA chốt): theo nguồn, không phải AI thêm
                        q = lay((vk, rk, a))
                    elif q["trang_thai"] == "bo":
                        lv = [x["id"] for x in q["quy_tac"] if x["loai"] in ("loc_vai_tro", "theo_cap_duyet")]
                        XUNG.append(("QT-02", f"Quy tắc bổ sung {r.get('id', '')} cấp lại quyền mà {', '.join(lv)} bỏ.", q))
                        q["trang_thai"] = "giu"
                    q["quy_tac"].append(rule(r, "bo_sung"))

    # ---------- 4. quy định kế thừa KT-xx: chỉ sinh quyền xem và ràng buộc ----------
    def kt_tat(ma, vk=None, rk=None):
        return any(r.get("ma") == ma and (not r.get("vai_tro") or vk in ds(r["vai_tro"])) and (not r.get("tai_nguyen") or rk in ds(r["tai_nguyen"])) for r in KA)

    def kt_rule(ma, ly_do):
        return {"id": ma, "loai": "ke_thua", "ly_do": f"{KT[ma][0]}. {ly_do}".strip(), "nguyen_tac": [KT[ma][1]], "tin_cay": "cao"}

    hl = lambda q: q["trang_thai"] in HIEU_LUC
    THIEU = OD()   # mục thiếu nguồn → câu hỏi NG-… cho BA

    def thieu(ma, loai_tn, vk, rk, a, noi_dung, quyen=None):
        k = "|".join([ma, loai_tn, vk or "", rk or "", a or ""])
        if k not in THIEU:
            THIEU[k] = {"id": "NG-" + hashlib.sha1(k.encode()).hexdigest()[:6].upper(), "ma": ma, "loai": loai_tn, "vai_tro": vk, "tai_nguyen": rk,
                        "hanh_dong": a, "ten_hanh_dong": (hd_cua(rk, a) or {}).get("ten") if rk and a else None,
                        "noi_dung": noi_dung, "quy_dinh": KT[ma][0] if ma in KT else "", "quyen": quyen}

    xem_bg = lambda rk: [h["key"] for h in TN[rk]["hanh_dong"] if h.get("loai") in BK.LOAI_XEM_BAN_GHI]   # các hành động «xem bản ghi» của tài nguyên (không gộp: xem danh sách, xem chi tiết… là hành động riêng)
    # Quy định kế thừa không tự cấp quyền, không tự đặt phạm vi, không tự thêm điều kiện.
    # Chỗ quy định lẽ ra áp → mục thiếu nguồn + câu hỏi cho BA (BA chốt hoặc AI suy ra thì AI ghi quy tắc có `nguon` vào đặc tả).
    for q in list(QUYEN.values()):          # KT-01 → câu hỏi
        h = hd_cua(q["tai_nguyen"], q["hanh_dong"])
        if hl(q) and h["muc"] == "ban_ghi" and h["nhom"] != "xem" and not kt_tat("KT-01", q["vai_tro"], q["tai_nguyen"]):
            for a2 in xem_bg(q["tai_nguyen"]):
                q2 = QUYEN.get((q["vai_tro"], q["tai_nguyen"], a2))
                if q2 is None or not hl(q2):
                    thieu("KT-01", "quyen", q["vai_tro"], q["tai_nguyen"], a2,
                          f"«{VT[q['vai_tro']]['ten']}» được {thuong(h['ten'])} «{TN[q['tai_nguyen']]['ten']}» nhưng tài liệu không nêu được "
                          f"{thuong(hd_cua(q['tai_nguyen'], a2)['ten'])} bản ghi đó.")

    # KT-03 (ABAC): người lập xem được bản ghi của mình; đi theo người, không theo vai trò hay đơn vị
    lap_tn = lambda rk: [q for q in QUYEN.values() if q["tai_nguyen"] == rk and hl(q) and (hd_cua(rk, q["hanh_dong"])["nhom"] == "them_moi" or loai(rk, q["hanh_dong"]) == "gui_duyet")]
    co_lap = [rk for rk, t in TN.items() if t.get("loai", "du_lieu") in ("du_lieu", "tep") and xem_bg(rk) and not kt_tat("KT-03", None, rk)
              and any(VT[q["vai_tro"]]["loai_pham_vi"] == "theo_don_vi" for q in lap_tn(rk))]
    for rk in co_lap:   # KT-03 → câu hỏi
        thieu("KT-03", "quyen", None, rk, (xem_bg(rk) or [None])[0],
              f"Tài liệu không nêu người lập «{TN[rk]['ten']}» có được xem bản ghi do mình lập khi không còn giữ vai trò hay đơn vị đã lập bản ghi đó.")

    # ---------- 5. phạm vi: theo quy tắc của đặc tả; thiếu thì thành câu hỏi theo KT-06, KT-07, KT-08, KT-16 ----------
    def diem(r, q):
        h = hd_cua(q["tai_nguyen"], q["hanh_dong"])
        sao_ok = VT[q["vai_tro"]]["loai_pham_vi"] == "theo_don_vi" or r.get("ap_dung_toan_he_thong")
        ok_v = (r.get("vai_tro", "*") == "*" and sao_ok) or r.get("vai_tro") == q["vai_tro"] or (isinstance(r.get("vai_tro"), list) and q["vai_tro"] in r["vai_tro"])
        ok_t = r.get("tai_nguyen", "*") in ("*", q["tai_nguyen"]) or (isinstance(r.get("tai_nguyen"), list) and q["tai_nguyen"] in r["tai_nguyen"])
        ha = r.get("hanh_dong", "*")
        ha = ha if isinstance(ha, list) else [ha]
        ok_h = "*" in ha or q["hanh_dong"] in ha or ("@" + h["nhom"]) in ha or ("@" + h["muc"]) in ha or (h.get("loai") and ("@" + h["loai"]) in ha)
        if not (ok_v and ok_t and ok_h):
            return -1
        return r.get("uu_tien", 0) * 100 + (r.get("vai_tro", "*") != "*") * 4 + (r.get("tai_nguyen", "*") != "*") * 2 + ("*" not in ha) * (1 if any(x == q["hanh_dong"] for x in ha) else 0.5)

    def qh_cua(p, rk):
        m = p.get("quan_he")
        return m.get(rk, m.get("*")) if isinstance(m, dict) else m

    pv_rules = [r for r in Q.get("pham_vi", []) if r.get("pham_vi") in PV or r.get("pham_vi") in ("toan_he_thong", "danh_sach")]
    for q in QUYEN.values():
        v, h, rk = VT.get(q["vai_tro"]), hd_cua(q["tai_nguyen"], q["hanh_dong"]), q["tai_nguyen"]
        if v is None:
            LOI.append(f"Vai trò {q['vai_tro']} dùng trong quy tắc nhưng chưa khai báo"); continue
        if v["loai_pham_vi"] == "theo_don_vi" and h["muc"] == "danh_sach":
            q["pham_vi"] = "danh_sach"   # NT-07: thêm, xuất, nhập kiểm tra khi chưa có bản ghi
        else:
            best = max(((diem(r, q), i, r) for i, r in enumerate(pv_rules)), default=(-1, 0, None), key=lambda x: (x[0], -x[1]))
            if best[0] >= 0:
                r = best[2]; q["pham_vi"] = r["pham_vi"]; q["quy_tac"].append(rule(r, "pham_vi")); dung("pham_vi", r)
            elif v["loai_pham_vi"] == "toan_he_thong":
                q["pham_vi"] = "toan_he_thong"
                q["quy_tac"].append({"id": "VT", "loai": "pham_vi", "ly_do": "Vai trò toàn hệ thống theo khai báo vai trò.", "nguyen_tac": [], "tin_cay": "cao",
                                     "nguon": (v.get("co_so") or {}).get("nguon", [])})
            else:   # không đặt phạm vi mặc định (KT-06, KT-07, KT-08, KT-16): thành câu hỏi
                co_cd = any(r["key"].startswith("cap_duyet") for r in TN[rk].get("quan_he", []))
                ma = ("KT-08" if h["nhom"] == "duyet" and h.get("loai") not in ("tiep_nhan", "tu_choi_tiep_nhan") and co_cd
                      else "KT-16" if h["nhom"] == "xem" and (h.get("nhay_cam") or TN[rk].get("nhay_cam"))
                      else "KT-07" if h["nhom"] == "xem" else "KT-06")
                q["pham_vi"] = None
                if hl(q): thieu(ma, "pham_vi", q["vai_tro"], rk, q["hanh_dong"],
                      f"Tài liệu chưa nêu «{v['ten']}» được {thuong(h['ten'])} «{TN[rk]['ten']}» trên những bản ghi nào (phạm vi).")
        for r in Q.get("dieu_kien", []):
            if diem(r, q) >= 0:
                dung("dieu_kien", r)
                for d in r["dieu_kien"]:
                    if d in DK and d not in q["dieu_kien"]:
                        q["dieu_kien"].append(d)
                q["quy_tac"].append(rule(r, "dieu_kien"))

    # ---------- 6. ràng buộc KT-13, KT-14, KT-15 ----------
    def bt(d):
        return DK.get(d, {}).get("bieu_thuc", [])

    def tu_duyet(d):
        return any(str(b.get("trai", "")).endswith("nguoi_lap") and b.get("phep") == "khac" and str(b.get("phai", "")).startswith("user.") for b in bt(d))

    def co_dk(q, truong):
        return any(b.get("trai") == "resource." + truong for d in q["dieu_kien"] for b in bt(d))

    def dk_lay(key, ten, dien_giai, bieu_thuc):
        for d in DK.values():   # dùng lại định nghĩa có cùng biểu thức
            if d.get("bieu_thuc") == bieu_thuc:
                return d["key"]
        k, i = key, 1
        while k in DK:
            i += 1; k = f"{key}_{i}"
        DK[k] = {"key": k, "ten": ten, "mo_ta": dien_giai[:1].upper() + dien_giai[1:] + ".", "dien_giai": dien_giai, "bieu_thuc": bieu_thuc, "tu_sinh": True}
        return k

    def gan_dk(q, d, ma, ly_do):
        if d not in q["dieu_kien"]:
            q["dieu_kien"].append(d)
        if not any(x["id"] == ma for x in q["quy_tac"]):
            q["quy_tac"].append(kt_rule(ma, ly_do))

    mac_dinh_tt = []
    for rk, t in TN.items():
        qs = [q for q in QUYEN.values() if q["tai_nguyen"] == rk and hl(q) and q["vai_tro"] != "nguoi_lap_ban_ghi"]
        lap = any(hd_cua(rk, q["hanh_dong"])["nhom"] == "them_moi" or loai(rk, q["hanh_dong"]) == "gui_duyet" for q in qs)
        lt = {h.get("loai") for h in t["hanh_dong"]}
        luong = "gui_duyet" in lt and bool(lt & set(BK.LOAI_DUYET))
        vd = t.get("vong_doi") or {}
        if luong and not vd:
            mac_dinh_tt.append(rk)
        nhap, cho = vd.get("dang_soan", BK.VONG_DOI_MAC_DINH["dang_soan"]), vd.get("cho_duyet", BK.VONG_DOI_MAC_DINH["cho_duyet"])
        mo_khoa = {q["vai_tro"] for q in qs if loai(rk, q["hanh_dong"]) == "mo_khoa"}
        tt_cua = lambda q: {v for d in q["dieu_kien"] for b in bt(d) if b.get("trai") == "resource.trang_thai" for v in (b["phai"] if isinstance(b["phai"], list) else [b["phai"]])}
        tt_khoa = set().union(*[tt_cua(q) for q in qs if loai(rk, q["hanh_dong"]) == "khoa"] or [set()])   # trạng thái bản ghi được khoá (theo điều kiện có nguồn)
        for q in qs:
            a = q["hanh_dong"]
            la = loai(rk, a)
            ten_q = f"«{VT[q['vai_tro']]['ten']}» {thuong(hd_cua(rk, a)['ten'])} «{TN[rk]['ten']}»"
            if la in BK.LOAI_DUYET and lap and not kt_tat("KT-13", q["vai_tro"], rk) and not any(tu_duyet(d) for d in q["dieu_kien"]):
                thieu("KT-13", "dieu_kien", q["vai_tro"], rk, a, f"Tài liệu không nêu người lập có được tự {thuong(hd_cua(rk, a)['ten'])} bản ghi do mình lập hay không ({ten_q}).", f"q:{q['vai_tro']}|{rk}|{a}")
            if luong and not kt_tat("KT-14", q["vai_tro"], rk) and not co_dk(q, "trang_thai") and (la in BK.LOAI_SOAN or la in BK.LOAI_DUYET):
                thieu("KT-14", "dieu_kien", q["vai_tro"], rk, a, f"Tài liệu chưa nêu {ten_q} khi bản ghi ở trạng thái nào.", f"q:{q['vai_tro']}|{rk}|{a}")
            if ("khoa" in lt and la in BK.LOAI_SUA_XOA and q["vai_tro"] not in mo_khoa and not kt_tat("KT-15", q["vai_tro"], rk) and not co_dk(q, "da_khoa")
                    and not (tt_khoa and tt_cua(q) and not (tt_khoa & tt_cua(q)))):   # điều kiện trạng thái có nguồn đã loại bản ghi khoá được
                thieu("KT-15", "dieu_kien", q["vai_tro"], rk, a, f"Tài liệu chưa nêu {ten_q} khi bản ghi đã bị khoá được hay không.", f"q:{q['vai_tro']}|{rk}|{a}")

    # ---------- 7. hoàn thiện ----------
    out_q = []
    for k in [k for k, q in QUYEN.items() if hl(q) and q["pham_vi"] is None and VT.get(q["vai_tro"], {}).get("loai_pham_vi") != "toan_he_thong"
              and hd_cua(q["tai_nguyen"], q["hanh_dong"])["muc"] == "ban_ghi"]:
        del QUYEN[k]   # chưa có phạm vi theo nguồn: không đưa vào thiết kế (đã ghi thiếu nguồn)
    gd_tac = {g["id"]: g["tac_nhan"] for g in GD}
    for t, n in chua_tac.items():   # tác nhân tài liệu nêu nhưng không biết ai giữ
        hds = sorted({g["hanh_dong"] for g in GDX if g["hanh_dong"] and t in gd_tac.get(g["id"], [])})
        thieu("GD-03", "tac_nhan", None, None, None,
              f"Tài liệu nêu tác nhân «{t}» ({n} giao dịch" + (f": {', '.join(hds)}" if hds else "") + ") nhưng không nêu ai (vai trò, chức danh, đơn vị) giữ tác nhân này.")
    for i, q in enumerate(QUYEN.values(), 1):
        tin = [x["tin_cay"] for x in q["quy_tac"] if x["loai"] not in ("tai_nguyen", "hanh_dong") or x["tin_cay"] != "cao"]
        q["tin_cay"] = min(tin, key=lambda x: RANK.get(x, 2)) if tin else "cao"
        q["id"] = f"Q{i}"
        q["khoa"] = f"q:{q['vai_tro']}|{q['tai_nguyen']}|{q['hanh_dong']}"
        out_q.append(q)
    hieu_luc = [q for q in out_q if hl(q)]

    # ---------- 8. kiểm tra nguyên tắc ----------
    KTR = []
    def kt(ma, muc, nd, nt, q=(), v=(), t=()):
        KTR.append({"ma": ma, "muc": muc, "noi_dung": nd, "nguyen_tac": nt, "lien_quan": {"quyen": [x["id"] for x in q], "vai_tro": list(v), "tai_nguyen": list(t)}})
    by_vt = collections.defaultdict(list)
    for q in hieu_luc:
        by_vt[q["vai_tro"]].append(q)
    kieu_pv = lambda k: (PV.get(k) or {}).get("kieu", k)
    for vk, qs in by_vt.items():
        for rk in {q["tai_nguyen"] for q in qs}:
            pd = [q for q in qs if q["tai_nguyen"] == rk and loai(rk, q["hanh_dong"]) in BK.LOAI_DUYET]
            lap = [q for q in qs if q["tai_nguyen"] == rk and (hd_cua(rk, q["hanh_dong"])["nhom"] == "them_moi" or loai(rk, q["hanh_dong"]) == "gui_duyet")]
            if pd and lap and not all(any(tu_duyet(d) for d in q["dieu_kien"]) for q in pd):
                kt("SOD-01", "canh_bao", f"«{VT[vk]['ten']}» vừa lập / gửi duyệt vừa phê duyệt, trả lại «{TN[rk]['ten']}» mà chưa có điều kiện người duyệt khác người lập.",
                   ["NT-03"], pd + lap, [vk], [rk])
        if VT[vk]["loai_pham_vi"] == "toan_he_thong":
            mang = {TN[q["tai_nguyen"]].get("mang", q["tai_nguyen"]) for q in qs if TN[q["tai_nguyen"]].get("loai") != "tep"
                    and (hd_cua(q["tai_nguyen"], q["hanh_dong"])["nhom"] in GHI or loai(q["tai_nguyen"], q["hanh_dong"]) in BK.LOAI_NHAP)}
            if len(mang) >= 4:
                kt("LP-01", "canh_bao", f"«{VT[vk]['ten']}» (toàn hệ thống) có quyền ghi ở {len(mang)} mảng: {', '.join(sorted(mang))}. Xem lại đặc quyền tối thiểu.", ["NT-02"], [], [vk])
        if VT[vk].get("nhom") == "lanh_dao":
            ghi = [q for q in qs if hd_cua(q["tai_nguyen"], q["hanh_dong"])["nhom"] in GHI or loai(q["tai_nguyen"], q["hanh_dong"]) in BK.LOAI_NHAP]
            if ghi:
                kt("LD-01", "goi_y", f"Vai trò lãnh đạo «{VT[vk]['ten']}» có {len(ghi)} quyền nhập liệu (thêm, sửa, xoá, nhập). Lãnh đạo thường chỉ xem, duyệt.", ["NT-21"], ghi, [vk])
        tq = VT[vk].get("tham_quyen")
        if tq in ("de_nghi", "xu_ly"):
            pd = [q for q in qs if loai(q["tai_nguyen"], q["hanh_dong"]) in ("phe_duyet", "xac_nhan")]
            if pd:
                ai = "phòng, ban không có con dấu" if tq == "de_nghi" else "trợ lý, nhân viên"
                kt("TQ-01", "canh_bao", f"«{VT[vk]['ten']}» thuộc cấp {ai} nhưng có quyền phê duyệt {len(pd)} tài nguyên. "
                   "Chỉ cấp có con dấu phê duyệt; cấp này xem xét, đề nghị lên cấp trên (gửi duyệt) hoặc trả lại.", ["CD-05", "NT-14"], pd, [vk])
        elif tq and tq != "phe_duyet":
            kt("TQ-02", "loi", f"«{VT[vk]['ten']}»: `tham_quyen` = `{tq}` không hợp lệ (dùng phe_duyet, de_nghi, xu_ly).", ["CD-05"], [], [vk])
        if VT[vk].get("nhom") == "quan_tri":
            nv = [q for q in qs if TN[q["tai_nguyen"]].get("loai") != "he_thong"]
            if nv:
                kt("KT-20", "canh_bao", f"Vai trò quản trị «{VT[vk]['ten']}» có {len(nv)} quyền trên dữ liệu nghiệp vụ. Quản trị hệ thống không kế thừa quyền nghiệp vụ.", ["NT-22"], nv, [vk])
    for q in hieu_luc:
        v, h = VT[q["vai_tro"]], hd_cua(q["tai_nguyen"], q["hanh_dong"])
        if v["loai_pham_vi"] != "toan_he_thong" and h["muc"] == "ban_ghi" and not q["pham_vi"]:
            kt("PV-01", "loi", f"«{v['ten']}» – {h['ten']} – «{TN[q['tai_nguyen']]['ten']}»: vai trò theo đơn vị nhưng chưa có phạm vi bản ghi (tài nguyên chưa có quan hệ về nơi gán vai trò).", ["NT-12"], [q], [q["vai_tro"]], [q["tai_nguyen"]])
        p = PV.get(q["pham_vi"])
        if p and p.get("quan_he"):
            rel = qh_cua(p, q["tai_nguyen"])
            if rel and rel != "(gan_truc_tiep)" and rel not in {r["key"] for r in TN[q["tai_nguyen"]].get("quan_he", [])}:
                kt("PV-02", "loi", f"Phạm vi «{p['ten']}» cần quan hệ `{rel}` trên «{TN[q['tai_nguyen']]['ten']}» nhưng tài nguyên chưa khai báo.", ["NT-12"], [q], [], [q["tai_nguyen"]])
        if v["loai_pham_vi"] == "theo_don_vi" and (h["nhom"] in GHI or h.get("loai") in BK.LOAI_NHAP) and kieu_pv(q["pham_vi"]) in ("don_vi_minh_va_cap_duoi", "don_vi_minh_va_cap_duoi_truc_tiep") and v.get("gan_tren") != q["tai_nguyen"]:
            kt("KT-07", "canh_bao", f"«{v['ten']}» – {h['ten']} – «{TN[q['tai_nguyen']]['ten']}»: quyền ghi lan xuống cấp dưới. Cấp trên xem, không sửa thay cấp dưới.", ["NT-13"], [q], [q["vai_tro"]], [q["tai_nguyen"]])
        if h["nhom"] == "duyet" and h.get("loai") not in ("tiep_nhan", "tu_choi_tiep_nhan") and not co_dk(q, "trang_thai"):
            kt("DK-01", "goi_y", f"«{v['ten']}» – {h['ten']} – «{TN[q['tai_nguyen']]['ten']}» chưa có điều kiện trạng thái (chỉ duyệt khi chờ duyệt).", ["NT-15"], [q], [q["vai_tro"]], [q["tai_nguyen"]])
    for rk, t in TN.items():
        if t.get("tu_cong") and t["hanh_dong"]:
            kt("CONG-01", "canh_bao", f"«{t['ten']}» là cây đơn vị lấy từ Cổng, nhưng đặc tả khai {len(t['hanh_dong'])} hành động trên đó. Quyền trên cây đơn vị do Cổng quản lý; phân hệ chỉ dùng cây làm nơi gán vai trò.", ["NT-05"], [], [], [rk])
        for h in t["hanh_dong"]:
            if h.get("rieng"):
                kt("KEY-02", "goi_y", f"«{t['ten']}»: hành động `{h['key']}` ({h['ten']}) chưa phân loại được (xem, sửa, duyệt…), quy định kế thừa không áp cho hành động này. Ghi `loai` (key loại trong references/bo-key.md) hoặc `nhom`, `muc` trong đặc tả.", ["NT-06"], [], [], [rk])
            if BK.tach_gop(h["key"]) and not h.get("tach_tu"):
                kt("KEY-03", "canh_bao", f"«{t['ten']}»: hành động `{h['key']}` gộp nhiều thao tác ({', '.join(BK.tach_gop(h['key']))}). Tách thành từng hành động, ghi `tach_tu: \"{h['key']}\"`.", ["NT-06"], [], [], [rk])
            if not any(q["tai_nguyen"] == rk and q["hanh_dong"] == h["key"] for q in hieu_luc):
                kt("HD-01", "goi_y", f"Hành động «{h['ten']}» của «{t['ten']}» chưa giao cho vai trò nào.", ["NT-01"], [], [], [rk])
    if LOG_KEY:
        gom = collections.defaultdict(list)
        for (loai, cu, moi), n in LOG_KEY.items():
            gom[loai].append(f"{cu} → {moi}")
        kt("KEY-01", "goi_y", "Đặc tả dùng key cũ / bí danh (hoặc xem_ds, xem_ct: gộp thành `xem` theo ngoại lệ), công cụ đã quy về key chuẩn; sửa đặc tả cho khớp: " + "; ".join(f"{l}: {', '.join(sorted(set(x)))}" for l, x in gom.items()), ["NT-06"])
    for rk in mac_dinh_tt:
        kt("KT-14", "goi_y", f"«{TN[rk]['ten']}» có luồng gửi duyệt nhưng chưa khai báo `vong_doi`; điều kiện trạng thái đang dùng giá trị mặc định DRAFT, RETURNED, PENDING.", ["NT-15"], [], [], [rk])
    for vk, v in VT.items():
        if vk not in by_vt:
            kt("VT-01", "canh_bao", f"Vai trò «{v['ten']}» chưa có quyền nào.", ["NT-09"], [], [vk])
    for ma, nd, q in XUNG:
        kt(ma, "canh_bao", f"«{VT[q['vai_tro']]['ten']}» – {hd_cua(q['tai_nguyen'], q['hanh_dong'])['ten']} – «{TN[q['tai_nguyen']]['ten']}»: {nd}", ["NT-04"], [q], [q["vai_tro"]], [q["tai_nguyen"]])
    for nhom in ("bo_qua", "tai_nguyen", "hanh_dong", "tac_nhan", "theo_cap_duyet", "loc_vai_tro", "bo_sung", "pham_vi", "dieu_kien"):
        for r in Q.get(nhom, []):
            if not DUNG[(nhom, r.get("id") or id(r))]:
                kt("QT-01", "goi_y", f"Quy tắc {nhom} {r.get('id', '(không id)')} không khớp giao dịch hay quyền nào: kiểm tra mẫu, key, hoặc xoá quy tắc.", ["NT-04"])
    if chua_tn:
        kt("GD-01", "canh_bao", f"{sum(chua_tn.values())} giao dịch chưa xác định được tài nguyên, thuộc các usecase: " + "; ".join(f"«{u}» ({n})" for u, n in chua_tn.most_common()), ["NT-05"])
    if chua_hd:
        kt("GD-02", "canh_bao", f"{sum(chua_hd.values())} giao dịch chưa xác định được hành động: " + "; ".join(f"«{t}» ({rk})" for (rk, t) in list(chua_hd)[:40]), ["NT-06"])
    if chua_tac:
        kt("GD-03", "canh_bao", "Tác nhân chưa ánh xạ sang vai trò: " + "; ".join(f"«{t}» ({n} giao dịch)" for t, n in chua_tac.most_common()), ["NT-10"])
    for x in LOI:
        kt("DT-01", "loi", x, ["NT-04"])

    # ---------- 9. câu mô tả theo vai trò cho BA ----------
    def cum_pv(q, v):
        cay = thuong(TN[v["gan_tren"]]["ten"]).replace(" (từ cổng)", "") if v.get("gan_tren") in TN else "cấp"
        if q["pham_vi"] == "danh_sach":
            if loai(q["tai_nguyen"], q["hanh_dong"]) in ("xuat", "xuat_file", "tai_xuong_ds"):
                return "danh_sach", "(chỉ gồm các bản ghi được xem)"
            return "danh_sach", f"cho {cay} mình" if v["loai_pham_vi"] == "theo_don_vi" else ""
        kieu = kieu_pv(q["pham_vi"])
        if v.get("gan_tren") == q["tai_nguyen"] and kieu in ("don_vi_minh", "don_vi_minh_va_cap_duoi", "don_vi_minh_va_cap_duoi_truc_tiep"):
            cau = {"don_vi_minh": f"— chính {cay} mình", "don_vi_minh_va_cap_duoi": f"— {cay} mình và mọi {cay} cấp dưới", "don_vi_minh_va_cap_duoi_truc_tiep": f"— {cay} mình và {cay} trực thuộc trực tiếp"}[kieu]
        else:
            cau = {"toan_he_thong": "trên toàn hệ thống", "don_vi_minh": f"của {cay} mình", "don_vi_minh_va_cap_duoi": f"của {cay} mình và mọi {cay} cấp dưới",
                   "don_vi_minh_va_cap_duoi_truc_tiep": f"của {cay} mình và các {cay} trực thuộc trực tiếp", "cap_duyet": f"đang chờ {cay} mình duyệt",
                   "do_minh_lap": "do chính mình lập, kể cả khi đã chuyển sang đơn vị khác" if q["vai_tro"] == "nguoi_lap_ban_ghi" else "do chính mình lập",
                   "duoc_giao": "được giao cho mình xử lý"
                   }.get(kieu, f"phạm vi «{(PV.get(q['pham_vi']) or {}).get('ten', q['pham_vi'])}»" if q["pham_vi"] else "(chưa xác định phạm vi)")
        return q["pham_vi"] or "", cau

    def gom_quy_tac(qs):
        seen, rs = set(), []
        for q in qs:
            for r in q["quy_tac"]:
                if r["loai"] in ("tai_nguyen", "hanh_dong") or (r["id"], r["loai"]) in seen:
                    continue
                seen.add((r["id"], r["loai"])); rs.append(r)
        return rs

    CAU = []
    def them_cau(vk, rk, loai, ngu, pv_key, dks, qs, noi_dung):
        thu_tu = list(TN[rk]["_hd"])
        qs = sorted(qs, key=lambda q: thu_tu.index(q["hanh_dong"]))
        tin = [q["tin_cay"] for q in qs]
        rs = gom_quy_tac(qs)
        CAU.append({"key": "c:" + "|".join([vk, rk, loai, ngu, pv_key, ",".join(dks)]), "vai_tro": vk, "tai_nguyen": rk, "loai": loai, "nguon": ngu,
                    "noi_dung": noi_dung, "quyen": [q["khoa"] for q in qs], "tin_cay": min(tin, key=lambda x: RANK.get(x, 2)) if tin else "cao",
                    "ke_thua": [] if loai == "khong_duoc" else sorted({r["id"] for r in rs if r["loai"] == "ke_thua"}), "quy_tac": rs})

    verbs = lambda qs: noi([thuong(hd_cua(q["tai_nguyen"], q["hanh_dong"])["ten"]) for q in sorted(qs, key=lambda q: list(TN[q["tai_nguyen"]]["_hd"]).index(q["hanh_dong"]))])
    for vk, v in VT.items():
        nhom, rang, bo = OD(), OD(), OD()
        for q in out_q:
            if q["vai_tro"] != vk:
                continue
            rk = q["tai_nguyen"]
            if q["trang_thai"] == "bo":
                bo.setdefault(rk, []).append(q); continue
            pv_key, cum = cum_pv(q, v)
            thuong_dk = [d for d in q["dieu_kien"] if not tu_duyet(d)]
            nhom.setdefault((rk, NGUON[q["trang_thai"]], pv_key, tuple(thuong_dk)), (cum, []))[1].append(q)
            for d in q["dieu_kien"]:
                if tu_duyet(d):
                    rang.setdefault((rk, "ke_thua" if DK[d].get("tu_sinh") else "ai_them"), []).append(q)
        thu = {"ba": 0, "ke_thua": 1, "ai_them": 2}
        for (rk, ngu, pv_key, dks), (cum, qs) in sorted(nhom.items(), key=lambda x: (list(TN).index(x[0][0]), thu[x[0][1]])):
            dk_cau = noi([DK[d].get("dien_giai") or thuong(DK[d]["ten"]) for d in dks])
            them_cau(vk, rk, "duoc", ngu, pv_key, list(dks), qs,
                     f"Được {verbs(qs)} «{TN[rk]['ten']}» {cum}".rstrip() + (f", chỉ khi {dk_cau}" if dk_cau else "") + ".")
        for (rk, ngu), qs in rang.items():
            them_cau(vk, rk, "rang_buoc", ngu, "", [], qs, f"Không được {verbs(qs)} «{TN[rk]['ten']}» do chính mình lập.")
        for rk, qs in bo.items():
            nb = nguon_chu([n for q in qs for r in q["quy_tac"] if r["loai"] in ("loc_vai_tro", "theo_cap_duyet") for n in r.get("nguon", [])])
            them_cau(vk, rk, "khong_duoc", "nguon_bo", "", [], qs, f"Không được {verbs(qs)} «{TN[rk]['ten']}»" + (f" (theo {nb})." if nb else "."))

    dem_kt = collections.Counter()
    for q in hieu_luc:
        for r in q["quy_tac"]:
            if r["loai"] == "ke_thua":
                dem_kt[r["id"]] += 1

    # ---------- 10. ghi ----------
    for vk, v in VT.items():
        v["tac_nhan_tai_lieu"] = [{"tac_nhan": r["tac_nhan"], "quy_tac": r.get("id", ""), "ly_do": r.get("ly_do", ""), "tin_cay": r.get("tin_cay", "trung_binh")}
                                  for r in Q.get("tac_nhan", []) if vk in r["vai_tro"]]
        v["so_giao_dich"] = sum(1 for g in GD if any(vk in tac.get(t, {}).get("vai_tro", []) for t in g["tac_nhan"]))
    for p in PV.values():
        p.setdefault("co_che", BK.PHAM_VI.get(p.get("kieu"), ("", "ReBAC"))[1])
    for t in TN.values():
        t.pop("_hd", None)
    tk = collections.Counter(q["trang_thai"] for q in out_q)
    # câu hỏi «Thiếu nguồn» sinh từ mục thiếu nguồn; id ổn định theo nội dung để ra_soat.json giữ được câu trả lời
    co_id = {c.get("id") for c in S.get("cau_hoi", [])}
    # gom: một câu hỏi cho một (loại thiếu, vai trò, tài nguyên), liệt kê các hành động
    nhom_ng = OD()
    for t in THIEU.values():
        lt = "pham_vi" if t["loai"] == "pham_vi" else t["ma"]
        nhom_ng.setdefault((lt, t["vai_tro"] or "", t["tai_nguyen"] or ""), []).append(t)
    CH_NG = []
    for (lt, vk, rk), ts in nhom_ng.items():
        gid = "NG-" + hashlib.sha1("|".join((lt, vk, rk)).encode()).hexdigest()[:6].upper()
        for t in ts:
            t["cau_hoi"] = gid
        ten_v, ten_t = (VT[vk]["ten"] if vk in VT else ""), (TN[rk]["ten"] if rk in TN else "")
        hds = noi([thuong(t["ten_hanh_dong"]) for t in ts if t.get("ten_hanh_dong")])
        if len(ts) == 1 or not hds:
            nd = ts[0]["noi_dung"]
        elif lt == "pham_vi":
            nd = f"Tài liệu chưa nêu «{ten_v}» được {hds} «{ten_t}» trên những bản ghi nào (phạm vi)."
        elif lt == "KT-14":
            nd = f"Tài liệu chưa nêu «{ten_v}» {hds} «{ten_t}» khi bản ghi ở trạng thái nào."
        elif lt == "KT-13":
            nd = f"Tài liệu không nêu người lập có được tự {hds} bản ghi do mình lập hay không («{ten_v}», «{ten_t}»)."
        elif lt == "KT-15":
            nd = f"Tài liệu chưa nêu «{ten_v}» {hds} «{ten_t}» khi bản ghi đã bị khoá được hay không."
        elif lt == "KT-01":
            nd = f"«{ten_v}» làm được việc trên «{ten_t}» nhưng tài liệu không nêu được {hds} bản ghi đó."
        else:
            nd = " ".join(t["noi_dung"] for t in ts)
        if gid in co_id:
            continue
        CH_NG.append({"id": gid, "nhom": "Thiếu nguồn", "luc": "truoc_thiet_ke", "tu_sinh": True, "ma": lt,
                      "noi_dung": nd + " BA cho biết theo tài liệu hoặc nghiệp vụ thực tế; câu trả lời được ghi «BA chốt» làm nguồn.",
                      "lien_quan": {k: [x] for k, x in (("vai_tro", vk), ("tai_nguyen", rk)) if x}})
    out = {"phien_ban": 4, "bo_key": "bo_key.py (tiếng Việt không dấu)", "phan_he": S.get("phan_he", {}), "nguon": [{k: n[k] for k in ("id", "ten", "loai")} for n in nguon],
           "nguyen_tac": S.get("nguyen_tac_ap_dung", []), "tai_nguyen": list(TN.values()), "vai_tro": list(VT.values()),
           "pham_vi": list(PV.values()), "dieu_kien": list(DK.values()), "quyen": out_q, "giao_dich": GDX, "kiem_tra": KTR,
           "cau_hoi": S.get("cau_hoi", []) + CH_NG, "cau_mo_ta": CAU, "thieu_nguon": list(THIEU.values()),
           "che_do": "suy_ra" if SR.get("bat") else "chi_theo_nguon", "suy_ra": SR,
           "ke_thua": {"ap_dung": [{"ma": m, "ten": KT[m][0], "nguyen_tac": KT[m][1], "so_quyen": dem_kt[m]} for m in KT if dem_kt[m]],
                       "khong_ap_dung": KA},
           "thong_ke": {"giao_dich": len(GDX), "giao_dich_anh_xa": sum(1 for g in GDX if g["trang_thai"] == "anh_xa"),
                        "giao_dich_bo_qua": sum(1 for g in GDX if g["trang_thai"] == "bo_qua"),
                        "giao_dich_ngoai_he_thong": sum(1 for g in GDX if g["trang_thai"] == "ngoai_he_thong"), "giao_dich_chua_anh_xa": sum(1 for g in GDX if g["trang_thai"] == "chua_anh_xa"),
                        "quyen_giu": tk["giu"], "quyen_bo": tk["bo"], "quyen_them": tk["them"], "quyen_ke_thua": tk["ke_thua"], "cau_mo_ta": len(CAU),
                        "thieu_nguon": len(THIEU),
                        "quyen_suy_ra": sum(1 for q in out_q if q.get("trang_thai") == "giu" and any(BK.la_suy_ra(r.get("nguon")) for r in q.get("quy_tac", [])))}}
    with open(os.path.join(wd, "thiet_ke_phan_quyen.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    km = collections.Counter(k["muc"] for k in KTR)
    hoi = [c for c in out["cau_hoi"] if not c.get("tra_loi")]
    L = [f"# Báo cáo thiết kế phân quyền — {out['phan_he'].get('ten', '')}", "",
         f"- Giao dịch: {len(GDX)} (ánh xạ {out['thong_ke']['giao_dich_anh_xa']}, bỏ qua {out['thong_ke']['giao_dich_bo_qua']}, ngoài hệ thống {out['thong_ke']['giao_dich_ngoai_he_thong']}, chưa ánh xạ {out['thong_ke']['giao_dich_chua_anh_xa']}).",
         f"- {len(TN)} tài nguyên · {len(VT)} vai trò · {len(PV)} phạm vi · {len(DK)} điều kiện.",
         (f"- Chế độ suy ra (mặc định, {SR.get('ngay', '')}; nguồn dùng: {SR.get('nguon_dung') or 'toàn bộ tài liệu'}): quyền {tk['giu']} theo tài liệu / BA chốt / AI suy ra"
          f" (trong đó {out['thong_ke']['quyen_suy_ra']} có phần AI suy ra) · {tk['bo']} bỏ · {len(THIEU)} mục thiếu nguồn." if SR.get("bat") else
          f"- Chế độ chỉ theo nguồn: quyền {tk['giu']} theo tài liệu / BA chốt · {tk['bo']} bỏ theo tài liệu / BA chốt · {len(THIEU)} mục thiếu nguồn (không đưa vào thiết kế, đã thành câu hỏi NG-…)."),
         f"- {len(CAU)} câu mô tả cho BA rà soát; {len(hoi)} câu hỏi cho BA chưa có trả lời.",
         f"- Kiểm tra: {km['loi']} lỗi · {km['canh_bao']} cảnh báo · {km['goi_y']} gợi ý.", "", "## Thiếu nguồn (câu hỏi cho BA)", ""]
    L += [f"- {c['id']} [{c['ma']}]: {c['noi_dung']}" for c in CH_NG] or ["- Không có."]
    if SR.get("bat"):
        L += ["", "## AI suy ra (BA rà soát trong bản xem trước)", ""]
        L += [f"- {c['id']} [{c.get('nhom', '')}]: {c['noi_dung']} → AI chọn: {c.get('phuong_an_ap_dung', '')}"
              + (f" (phương án khác: {c['phuong_an_khac']})" if c.get("phuong_an_khac") else "") for c in S.get("cau_hoi", []) if c.get("suy_ra")] or ["- Không có."]
    L += ["", "## Bước làm ngoài hệ thống (không phân quyền)", ""]
    L += [f"- {g['id']} [{g['vt']}] {g['ten']} — {', '.join(g['tac_nhan'])}" for g in GDX if g["trang_thai"] == "ngoai_he_thong"] or ["- Không có."]
    L += ["", "## Kiểm tra", ""]
    for k in sorted(KTR, key=lambda x: ("loi", "canh_bao", "goi_y").index(x["muc"])):
        L.append(f"- [{k['muc']}] {k['ma']} ({', '.join(k['nguyen_tac'])}): {k['noi_dung']}")
    with open(os.path.join(wd, "bao_cao_thiet_ke.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print(f"{len(TN)} tài nguyên · {len(VT)} vai trò · quyền theo nguồn {tk['giu']}" + (f" (có phần AI suy ra {out['thong_ke']['quyen_suy_ra']})" if SR.get("bat") else "") + f", bỏ theo nguồn {tk['bo']} · thiếu nguồn {len(THIEU)} · {len(CAU)} câu mô tả · giao dịch chưa ánh xạ {out['thong_ke']['giao_dich_chua_anh_xa']}")
    print(f"kiểm tra: {km['loi']} lỗi · {km['canh_bao']} cảnh báo · {km['goi_y']} gợi ý → thiet_ke_phan_quyen.json, bao_cao_thiet_ke.md")
    for k in KTR:
        if k["muc"] != "goi_y":
            print(f"  [{k['muc']}] {k['ma']}: {k['noi_dung'][:220]}")


if __name__ == "__main__":
    main()
