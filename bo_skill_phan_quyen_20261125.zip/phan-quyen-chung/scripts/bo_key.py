# -*- coding: utf-8 -*-
"""Bộ key chuẩn (tiếng Việt không dấu) dùng chung cho mọi công cụ: đặc tả, ma trận Excel, JSON import, DSL playground.

Hành động: KHÔNG gộp, không đổi key. Key hành động giữ đúng như tài liệu; bảng HANH_DONG chỉ để phân loại
(loai_hanh_dong) và gợi ý key. Ngoại lệ duy nhất (GOP_NGOAI_LE): xem danh sách và xem chi tiết (xem_ds, xem_ct…) gộp thành `xem`.
Phạm vi, quan hệ, thuộc tính, trạng thái vẫn có bí danh quy về key chuẩn.
Tài liệu cho người đọc: references/bo-key.md (giữ đồng bộ với tệp này).

  python -I bo_key.py            in bảng key chuẩn (dạng markdown) để đối chiếu với references/bo-key.md
"""
import re
import unicodedata

# LOẠI hành động: key loại → (tên tiếng Việt, mức, nhóm, cách viết cùng nghĩa).
# KHÔNG GỘP hành động: key hành động trong thiết kế giữ đúng như tài liệu ghi (xem_ds, tim_kiem, tao_moi…);
# bảng này chỉ dùng để PHÂN LOẠI (biết một key là xem, sửa, duyệt… để áp quy định kế thừa) và gợi ý key khi tài liệu không đặt key.
# Mỗi thao tác khác nghĩa là một loại riêng (xem ≠ tìm kiếm ≠ tra cứu; nhập liệu ≠ nhập Excel; trả lại ≠ từ chối…).
# Ngoại lệ (áp cho mọi phân hệ): xem danh sách và xem chi tiết là MỘT hành động `xem` (GOP_NGOAI_LE).
HANH_DONG = {
    'xem': ('Xem (danh sách và chi tiết)', 'ban_ghi', 'xem', ['view', 'read', 'list', 'get']),
    'tim_kiem': ('Tìm kiếm', 'ban_ghi', 'xem', ['search', 'tim_kiem_nhanh', 'tim_kiem_nang_cao']),
    'tra_cuu': ('Tra cứu', 'ban_ghi', 'xem', ['lookup']),
    'loc': ('Lọc', 'ban_ghi', 'xem', ['filter']),
    'xem_lich_su': ('Xem lịch sử', 'ban_ghi', 'xem', ['history', 'view_history']),
    'xem_nhay_cam': ('Xem thông tin nhạy cảm', 'ban_ghi', 'xem', ['view_sensitive', 'xem_thong_tin_nhay_cam']),
    'them_moi': ('Thêm mới', 'danh_sach', 'them_moi', ['create', 'them', 'tao', 'tao_moi', 'lap', 'add', 'new', 'insert']),
    'tai_len': ('Tải lên', 'danh_sach', 'them_moi', ['upload']),
    'khai_bao': ('Khai báo', 'danh_sach', 'them_moi', ['declare']),
    'nhap_lieu': ('Nhập liệu', 'danh_sach', 'them_moi', ['data_entry']),
    'chinh_sua': ('Chỉnh sửa', 'ban_ghi', 'chinh_sua', ['update', 'sua', 'cap_nhat', 'edit', 'modify']),
    'xoa': ('Xoá', 'ban_ghi', 'xoa', ['delete', 'remove']),
    'khoi_phuc': ('Khôi phục', 'ban_ghi', 'xoa', ['restore']),
    'gui_duyet': ('Gửi duyệt', 'ban_ghi', 'vong_doi', ['submit', 'gui_phe_duyet', 'trinh', 'send_for_approval']),
    'gui': ('Gửi', 'ban_ghi', 'vong_doi', ['send']),
    'phe_duyet': ('Phê duyệt', 'ban_ghi', 'duyet', ['approve', 'duyet']),
    'xac_nhan': ('Xác nhận', 'ban_ghi', 'duyet', ['confirm']),
    'tu_choi': ('Từ chối', 'ban_ghi', 'duyet', ['reject', 'tu_choi_duyet', 'loai_bo']),
    'tra_lai': ('Trả lại', 'ban_ghi', 'duyet', ['return']),
    'yeu_cau_chinh_sua': ('Yêu cầu chỉnh sửa, bổ sung', 'ban_ghi', 'duyet', ['request_change']),
    'tiep_nhan': ('Tiếp nhận', 'ban_ghi', 'duyet', ['receive', 'phe_duyet_tiep_nhan', 'accept']),
    'tu_choi_tiep_nhan': ('Từ chối tiếp nhận', 'ban_ghi', 'duyet', ['decline_receipt']),
    'khoa': ('Khoá', 'ban_ghi', 'vong_doi', ['lock', 'khoa_so', 'khoa_du_lieu']),
    'mo_khoa': ('Mở khoá', 'ban_ghi', 'vong_doi', ['unlock']),
    'sao_chep': ('Sao chép', 'ban_ghi', 'them_moi', ['copy', 'duplicate', 'clone']),
    'xuat': ('Xuất danh sách', 'danh_sach', 'xuat_nhap', ['export', 'xuat_ds', 'xuat_excel', 'export_ds', 'xuat_danh_sach']),
    'xuat_file': ('Xuất tệp', 'danh_sach', 'xuat_nhap', ['export_file']),
    'nhap': ('Nhập danh sách', 'danh_sach', 'xuat_nhap', ['import', 'nhap_ds', 'nhap_excel', 'import_ds', 'nhap_danh_sach']),
    'trich_luc': ('Trích lục', 'ban_ghi', 'xuat_nhap', ['xuat_trich_luc']),
    'in': ('In', 'ban_ghi', 'xuat_nhap', ['print']),
    'chia_tach': ('Chia tách', 'ban_ghi', 'vong_doi', ['split']),
    'sap_nhap': ('Sáp nhập', 'ban_ghi', 'vong_doi', ['merge']),
    'giai_the': ('Giải thể', 'ban_ghi', 'vong_doi', ['dissolve']),
    'chia_se': ('Chia sẻ', 'ban_ghi', 'khac', ['share']),
    'phan_hoi': ('Phản hồi', 'ban_ghi', 'khac', ['feedback']),
    'di_chuyen': ('Di chuyển', 'ban_ghi', 'chinh_sua', ['move']),
    'tai_xuong': ('Tải xuống tệp', 'ban_ghi', 'xuat_nhap', ['download']),
    'tai_xuong_ds': ('Tải xuống danh sách', 'danh_sach', 'xuat_nhap', ['download_list']),
    'danh_gia': ('Đánh giá, xếp loại', 'ban_ghi', 'chinh_sua', ['evaluate', 'xep_loai']),
    'giao_xu_ly': ('Giao xử lý', 'ban_ghi', 'vong_doi', ['assign', 'phan_cong']),
    'gan_vai_tro': ('Gán vai trò', 'ban_ghi', 'khac', ['assign_role', 'phan_quyen']),
}
# key tài liệu gộp nhiều thao tác: phải tách thành từng hành động (ghi «tach_tu» = key gốc của tài liệu)
GOP_SAN = {
    'lock_unlock': ['khoa', 'mo_khoa'], 'khoa_mo_khoa': ['khoa', 'mo_khoa'],
    'phe_duyet_tu_choi': ['phe_duyet', 'tu_choi'], 'duyet_tu_choi': ['phe_duyet', 'tu_choi'],
    'xuat_nhap': ['xuat', 'nhap'], 'import_export': ['nhap', 'xuat'],
}
# NGOẠI LỆ GỘP DUY NHẤT: các key xem danh sách / xem chi tiết đều là hành động `xem` (đổi key khi chuẩn hoá, báo KEY-01)
GOP_NGOAI_LE = {k: 'xem' for k in ('xem_ds', 'xem_ct', 'xem_danh_sach', 'xem_chi_tiet', 'view_list', 'view_detail', 'xem_dsach', 'xem_chitiet')}
# tập loại dùng trong quy định kế thừa (lap_thiet_ke.py)
LOAI_XEM_BAN_GHI = ('xem',)                                    # KT-01, KT-03: làm được / lập được bản ghi thì xem được bản ghi đó
LOAI_DUYET = ('phe_duyet', 'xac_nhan', 'tu_choi', 'tra_lai', 'yeu_cau_chinh_sua')   # KT-08, KT-13, KT-14 (chờ duyệt)
LOAI_SOAN = ('chinh_sua', 'xoa', 'gui_duyet')                  # KT-14 (đang soạn)
LOAI_SUA_XOA = ('chinh_sua', 'xoa')                            # KT-15 (chưa khoá)
LOAI_NHAP = ('nhap',)                                          # quyền ghi hàng loạt (LD-01, LP-01, KT-07)
NHOM = {
    'xem': ['view'],
    'them_moi': ['create', 'tao'],
    'chinh_sua': ['update', 'sua'],
    'xoa': ['delete'],
    'vong_doi': ['lifecycle'],
    'duyet': ['approval'],
    'xuat_nhap': ['bulk'],
    'khac': ['other'],
}
MUC = {
    'danh_sach': ['list'],
    'ban_ghi': ['record'],
}
# kiểu phạm vi: key → (tên, cơ chế, bí danh). ReBAC = theo quan hệ cây đơn vị; ABAC = so thuộc tính bản ghi với người dùng
PHAM_VI = {
    'toan_he_thong': ('Toàn hệ thống', 'RBAC', ['all', 'toan_bo']),
    'danh_sach': ('Mức danh sách', 'RBAC', ['list', 'muc_danh_sach']),
    'don_vi_minh': ('Đơn vị mình', 'ReBAC', ['own_unit']),
    'don_vi_minh_va_cap_duoi_truc_tiep': ('Đơn vị mình và cấp dưới trực tiếp', 'ReBAC', ['unit_and_children', 'cap_duoi_truc_tiep']),
    'don_vi_minh_va_cap_duoi': ('Đơn vị mình và mọi cấp dưới', 'ReBAC', ['unit_and_descendants', 'toan_bo_cap_duoi', 'don_vi_va_cap_duoi']),
    'cap_duyet': ('Đang chờ đơn vị mình duyệt', 'ReBAC', ['approval_unit']),
    'do_minh_lap': ('Do chính mình lập', 'ABAC', ['own_record', 'cua_minh']),
    'duoc_giao': ('Được giao cho mình', 'ABAC', ['assigned']),
}
# quan hệ chuẩn: key → (ý nghĩa, bí danh)
QUAN_HE = {
    'cap_tren': ('Đơn vị cấp trên (trên cây đơn vị)', ['parent']),
    'thuoc_don_vi': ('Đơn vị sở hữu bản ghi', ['owner_unit']),
    'thuoc_to_chuc': ('Tổ chức (cây thứ hai, ví dụ hội) sở hữu bản ghi', ['owner_org']),
    'don_vi_quan_ly': ('Đơn vị quản lý tổ chức', ['managing_unit']),
    'cap_duyet': ('Đơn vị (cây đơn vị) đang phải duyệt bản ghi', ['approval_unit']),
    'cap_duyet_to_chuc': ('Tổ chức (cây thứ hai, ví dụ hội) đang phải duyệt bản ghi', ['approval_org']),
    'noi_di': ('Nơi chuyển đi', ['source_unit']),
    'noi_den': ('Nơi chuyển đến', ['target_unit']),
}
# thuộc tính chuẩn: key → (kiểu, ý nghĩa, bí danh)
THUOC_TINH = {
    'trang_thai': ('chuoi', 'Trạng thái vòng đời', ['status']),
    'nguoi_lap': ('chuoi', 'Người lập bản ghi', ['created_by', 'nguoi_tao']),
    'da_khoa': ('dung_sai', 'Bản ghi đã bị khoá', ['locked']),
    'nguoi_duoc_giao': ('chuoi', 'Người được giao xử lý', ['assignee', 'nguoi_xu_ly']),
}
# nhóm trạng thái vòng đời (khoá của vong_doi) và giá trị trạng thái chuẩn
VONG_DOI = {
    'dang_soan': ['draft', 'nhap'],
    'cho_duyet': ['pending'],
    'da_duyet': ['approved'],
}
TRANG_THAI = {
    'DU_THAO': ['DRAFT', 'NHAP'],
    'BI_TRA_LAI': ['RETURNED', 'BI_TU_CHOI', 'TRA_LAI', 'REJECTED'],
    'CHO_DUYET': ['PENDING', 'PENDING_APPROVAL', 'PENDING_APP'],
    'DA_DUYET': ['APPROVED'],
    'DA_KHOA': ['LOCKED'],
}
VONG_DOI_MAC_DINH = {'dang_soan': ['DU_THAO', 'BI_TRA_LAI'], 'cho_duyet': ['CHO_DUYET'], 'da_duyet': ['DA_DUYET']}
# điều kiện do quy định kế thừa tự sinh
DIEU_KIEN_TU_SINH = {"khong_tu_duyet": ["not_self_approval"], "dang_soan": ["draft"], "cho_duyet": ["pending"], "chua_khoa": ["not_locked"]}
# tài nguyên chung: cây đơn vị do Cổng quản lý, dùng chung mọi phân hệ
CAY_CONG = {'key': 'don_vi', 'ten': 'Đơn vị (từ Cổng)', 'bi_danh': ['unit']}

# Bước làm ngoài hệ thống (mọi phân hệ): bước quy trình mà tài liệu ghi làm ngoài hệ thống / phân hệ /
# phần mềm không cho quyền nào; mọi công cụ tạo giao dịch đánh dấu `ngoai_he_thong`, lap_thiet_ke.py luôn bỏ qua.
MAU_NGOAI_HE_THONG = re.compile(
    r"ngoài\s+(hệ\s+thống|phân\s+hệ|phần\s+mềm|chương\s+trình|ứng\s+dụng)"
    r"|không\s+(thực\s+hiện|làm|thao\s+tác)\s+trên\s+(hệ\s+thống|phân\s+hệ|phần\s+mềm|chương\s+trình|ứng\s+dụng)"
    r"|(thực\s+hiện|làm)\s+(thủ\s+công\s+)?bên\s+ngoài", re.I)


def ngoai_he_thong(*van_ban):
    """Đoạn câu của tài liệu cho biết bước làm ngoài hệ thống (rỗng nếu không có)."""
    for v in van_ban:
        m = MAU_NGOAI_HE_THONG.search(str(v or ""))
        if m:
            return m.group(0)
    return ""


# Chế độ suy ra (mặc định): đặc tả có "suy_ra": {"bat": true}; `/ra-soat-phan-quyen chi-nguon …` tắt cho một lần rà soát.
# Quy tắc, vai trò AI suy ra có một mục nguồn bắt đầu bằng SUY_RA, kèm các ô tài liệu làm căn cứ.
SUY_RA = "AI suy ra"


def la_suy_ra(nguon):
    """Danh sách nguồn có mục «AI suy ra …» không."""
    return any(str(x.get("vt", "") if isinstance(x, dict) else x).strip().startswith(SUY_RA) for x in (nguon or []))

def _bang(d, i=None):
    out = {}
    for k, v in d.items():
        out[k] = k
        for a in (v if isinstance(v, list) else v[i] if i is not None else v):
            out[a] = k
    return out


BD_HD = _bang(HANH_DONG, 3)
BD_NHOM, BD_MUC = _bang(NHOM), _bang(MUC)
BD_PV = _bang(PHAM_VI, 2)
BD_QH, BD_TT = _bang(QUAN_HE, 1), _bang(THUOC_TINH, 2)
BD_VD, BD_TTH = _bang(VONG_DOI), _bang(TRANG_THAI)


def khong_dau(s):
    s = unicodedata.normalize("NFD", str(s)).replace("đ", "d").replace("Đ", "D")
    s = "".join(c for c in s if unicodedata.category(c) != "Mn").lower()
    return re.sub(r"[^a-z0-9]+", "_", s).strip("_")


def hanh_dong(k, tien_to=False):
    """Chuẩn hoá CÁCH VIẾT key hành động (không dấu, chữ thường, nối «_»), KHÔNG đổi sang key khác,
    trừ ngoại lệ GOP_NGOAI_LE: xem_ds, xem_ct (xem danh sách, xem chi tiết) → `xem`.
    «tim_kiem», «tao_moi», «sua»… giữ nguyên. tien_to giữ để tương thích, không dùng."""
    if k is None or not isinstance(k, str) or k.startswith("@") or k == "*":
        return k
    k2 = k if re.fullmatch(r"[a-z0-9_]+", k) else khong_dau(k)
    return GOP_NGOAI_LE.get(k2, k2)


def loai_hanh_dong(k):
    """Loại chuẩn của một key hành động (để áp quy định kế thừa), hoặc None nếu không phân loại được.
    Tìm theo key loại, cách viết cùng nghĩa, rồi theo tiền tố dài nhất (phe_duyet_cap_phong → phe_duyet)."""
    if not k:
        return None
    k2 = hanh_dong(k)
    if k2 in BD_HD:
        return BD_HD[k2]
    for a in sorted(BD_HD, key=len, reverse=True):
        if k2.startswith(a + "_"):
            return BD_HD[a]
    return None


def thong_tin_hanh_dong(k):
    """(tên, mức, nhóm, loại) mặc định của một key hành động theo loại của nó; không phân loại được → (key, ban_ghi, khac, None)."""
    lo = loai_hanh_dong(k)
    if lo:
        t, m, n, _ = HANH_DONG[lo]
        return t, m, n, lo
    return k, 'ban_ghi', 'khac', None


def tach_gop(k):
    """Các loại thao tác mà một key tài liệu gộp lại (lock_unlock → [khoa, mo_khoa]); không gộp → []."""
    return GOP_SAN.get(hanh_dong(k), [])


def nhom(k):
    return BD_NHOM.get(k, k)


def muc(k):
    return BD_MUC.get(k, k)


def pham_vi(k):
    return BD_PV.get(k, k)


def quan_he(k):
    return BD_QH.get(k, k)


def thuoc_tinh(k):
    return BD_TT.get(k, k)


def vong_doi(k):
    return BD_VD.get(k, k)


def trang_thai(v):
    return BD_TTH.get(v, v) if isinstance(v, str) else v


if __name__ == "__main__":
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    print("| Key loại | Tên | Mức | Nhóm | Cách viết cùng nghĩa (chỉ để phân loại) |\n|---|---|---|---|---|")
    for k, (t, m, n, a) in HANH_DONG.items():
        print(f"| `{k}` | {t} | {m} | {n} | {', '.join(a)} |")
