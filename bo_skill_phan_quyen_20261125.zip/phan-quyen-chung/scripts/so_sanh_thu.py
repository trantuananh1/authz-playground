# -*- coding: utf-8 -*-
"""So thiết kế (DSL đã xuất) với ma trận phân quyền Excel của BA, bằng người dùng và hồ sơ thử (bước 9 của ra-soat-phan-quyen).

  python -I so_sanh_thu.py <thu_muc_lam_viec>

Cần <lv>/so_sanh.json (AI lập một lần cho mỗi ma trận, xem SKILL.md của ra-soat-phan-quyen, bước 9) và <lv>/du_lieu_thu.json (cây, hồ sơ thử;
du_lieu_thu.py tạo). Mỗi cột vai trò của ma trận có một hoặc nhiều người dùng thử, gán vai trò thiết kế tại nút cây.
Một ô «thiết kế cho» khi CÓ người dùng của cột làm được thao tác trên ÍT NHẤT MỘT hồ sơ thử (theo phạm vi và điều kiện đã áp;
hồ sơ thử cần thuộc tính trạng thái, loại… theo giá trị CSDL). Dòng ma trận gộp nhiều thao tác (ví dụ phê duyệt gồm từ chối, phân công) so đủ các thao tác.

Ghi vào <lv>/so_sanh/:
- ket_qua.json  — từng ô: giá trị ma trận, thao tác thiết kế, người dùng / hồ sơ / vai trò DSL cấp quyền;
- lech.md       — dữ liệu cho AI viết giai_thich.json (chỉ theo nguồn);
- so_sanh.dsl   — DSL chính thức + dữ liệu thử + assert theo ma trận (Tests: đạt = khớp, hỏng = lệch);
- kiem_bo_danh_gia.dsl — assert mọi (người dùng, thao tác, hồ sơ) theo bộ đánh giá: nạp lên playground phải đạt hết.

so_sanh.json:
  {"excel": "...xlsx", "sheet": "...", "ten_ma_tran": "Update 02", "tai_nguyen": "<key tài nguyên thiết kế>",
   "dong_nhom": 6, "dong_tieu_de": 7, "dong_dau": 8, "dong_cuoi": 20, "cot_hanh_dong": "E", "cot_vai_tro": "J:Y",
   "dong": {"<key dòng ma trận>": ["<hành động thiết kế>", ...]},   (tuỳ chọn; mặc định: trùng key, xem_ds/xem_ct → xem,
                                                                     lock_unlock → khoa, mo_khoa)
   "ten_ngan": {"J": "Thủ trưởng"},                                      (tuỳ chọn, tên cột ngắn trên lưới)
   "loc_ho_so": {"<key dòng ma trận>": {"<thuộc tính>": "<giá trị CSDL>"}},  (tuỳ chọn; dòng ma trận tách theo loại hồ sơ,
                                                                     ví dụ xem_ds_loai_a: chỉ xét hồ sơ thử có thuộc tính đó)
Ô ma trận ghi «x» hoặc «x*» (có quyền kèm điều kiện) đều tính là có quyền.
   "nguoi": {"J": [{"key": "...", "mo_ta": "...", "vai_tro": [["<vai trò>", "<nút cây> | null"]], "ly_do": "<nguồn>"}]}}
Cây, người dùng, hồ sơ và cách ghép cột với vai trò là dữ liệu thử do AI dựng, không phải nguồn; ly_do ghi nguồn.
"""
import collections, json, os, re, sys

import openpyxl

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dieu_kien as DKM  # noqa: E402
from openpyxl.utils import column_index_from_string, get_column_letter

sys.stdout.reconfigure(encoding="utf-8")
T = "@mac_dinh"
GOP = {"xem_ds": ["xem"], "xem_ct": ["xem"], "xem_danh_sach": ["xem"], "xem_chi_tiet": ["xem"], "lock_unlock": ["khoa", "mo_khoa"]}


def doc_dsl(txt):
    res, vai_chung, userset, resset, permit = {}, {}, {}, {}, []
    cur = None
    for raw in txt.splitlines():
        line = raw.split("//", 1)[0].rstrip()
        if not line.strip():
            continue
        m = re.match(r'\s*resource (\w+) "[^"]*" \{', line)
        if m:
            cur = m.group(1); res[cur] = {"actions": [], "relations": {}, "roles": {}, "derive": []}; continue
        if cur and line.strip() == "}":
            cur = None; continue
        if cur:
            s = line.strip()
            if s.startswith("actions "):
                res[cur]["actions"] = [a.strip() for a in s[8:].split(",")]
            elif s.startswith("relations "):
                for k, v in re.findall(r"(\w+): (\w+)", s):
                    res[cur]["relations"][k] = v
            elif s.startswith("role "):
                mm = re.match(r"role (\w+)(?:: (.*))?$", s)
                res[cur]["roles"][mm.group(1)] = [a.strip() for a in (mm.group(2) or "").split(",") if a.strip()]
            elif s.startswith("derive "):
                mm = re.match(r"derive (\w+) from (\w+)#(\w+) via (\w+)$", s)
                res[cur]["derive"].append(mm.groups())
            continue
        s = line.strip()
        m = re.match(r'role (\w+) "[^"]*": (.*)$', s)
        if m:
            vai_chung[m.group(1)] = [tuple(x.strip().split(":")) for x in m.group(2).split(",")]; continue
        m = re.match(r'userset (\w+) "[^"]*" where (.*)$', s)
        if m:
            userset[m.group(1)] = DKM.doc_dieu_kien(m.group(2)); continue
        m = re.match(r'resourceset (\w+) "[^"]*" on (\w+) where (.*)$', s)
        if m:
            resset[m.group(1)] = (m.group(2), DKM.doc_dieu_kien(m.group(3))); continue
        m = re.match(r"permit (\w+) to (\w+): (.*)$", s)
        if m:
            permit.append((m.group(1), m.group(2), [a.strip() for a in m.group(3).split(",")])); continue
    return res, vai_chung, userset, resset, permit


class DanhGia:
    def __init__(self, dsl, inst, rel, gan, user_attr):
        self.res, self.vai_chung, self.userset, self.resset, self.permit = dsl
        self.inst, self.rel, self.gan, self.ua = inst, rel, gan, user_attr   # inst: key → (loại, thuộc tính); rel: (key, quan hệ) → key
        self.memo = {}

    def giu(self, u, vai, k, dang=()):
        """u giữ vai trò `vai` trên bản ghi k (gán trực tiếp hoặc qua derive)."""
        key = (u, vai, k)
        if key in self.memo:
            return self.memo[key]
        if key in dang:
            return False
        ok = (u, vai, k) in self.gan
        loai = self.inst[k][0]
        if not ok:
            for r, t, s, via in self.res[loai]["derive"]:
                if r != vai:
                    continue
                y = self.rel.get((k, via))
                if y and self.inst[y][0] == t and self.giu(u, s, y, dang + (key,)):
                    ok = True; break
        self.memo[key] = ok
        return ok

    def duoc(self, u, a, k):
        """(được, [đường cấp quyền])."""
        loai, tt = self.inst[k]
        duong = []
        for vai, acts in self.res[loai]["roles"].items():
            if a in acts and self.giu(u, vai, k):
                duong.append(vai)
        for vai, ds in self.vai_chung.items():
            if (u, vai, None) in self.gan and (loai, a) in ds:
                duong.append(vai)
        for us, rs, acts in self.permit:
            if a not in acts:
                continue
            rl, bt = self.resset[rs]
            if rl == loai and DKM.danh_gia(self.userset[us], self.ua[u], {}) and DKM.danh_gia(bt, self.ua[u], tt):
                duong.append(f"permit {us} → {rs}")
        return bool(duong), duong


def gt(v):
    return "true" if v is True else "false" if v is False else f'"{v}"'


def cot_ds(spec):
    out = []
    for phan in (spec if isinstance(spec, list) else [spec]):
        a, _, b = phan.partition(":")
        i, j = column_index_from_string(a), column_index_from_string(b or a)
        out += [get_column_letter(k) for k in range(i, j + 1)]
    return out


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    lv = sys.argv[1]
    CH = json.load(open(os.path.join(lv, "so_sanh.json"), encoding="utf-8"))
    DT = json.load(open(os.path.join(lv, "du_lieu_thu.json"), encoding="utf-8"))
    D = json.load(open(os.path.join(lv, "thiet_ke_phan_quyen.json"), encoding="utf-8"))
    RK = CH["tai_nguyen"]
    TN = {t["key"]: t for t in D["tai_nguyen"]}
    # cây nơi gán vai trò: cây Cổng «don_vi» hoặc cây riêng của phân hệ (ví dụ cây Viện kiểm sát, CD-09)
    CAY_DV = "don_vi" if "don_vi" in TN else next((t["key"] for t in D["tai_nguyen"] if t.get("loai") == "cay"
                                                   and any(r.get("toi") == t["key"] for r in t.get("quan_he", []))), "don_vi")
    thu_muc = os.path.join(lv, "playground_theo_mang")
    ung = [os.path.join(thu_muc, f) for f in sorted(os.listdir(thu_muc))] if os.path.isdir(thu_muc) else []
    p_dsl = next((p for p in ung if re.search(rf"^resource {RK} ", open(p, encoding="utf-8").read(), re.M)), os.path.join(lv, "playground.dsl"))
    goc = open(p_dsl, encoding="utf-8").read()
    dsl = doc_dsl(goc)
    act_tn = dsl[0][RK]["actions"]
    p_x = CH["excel"] if os.path.isabs(CH["excel"]) else os.path.join(lv, CH["excel"])
    ws = next(w for w in openpyxl.load_workbook(p_x, data_only=True).worksheets if w.title == CH["sheet"])
    COT = cot_ds(CH["cot_vai_tro"])
    tieu_de = {c: " ".join(str(ws[f"{c}{CH['dong_tieu_de']}"].value or "").split()) for c in COT}
    nhom = []
    if CH.get("dong_nhom"):   # nhóm cột theo dòng nhóm (ô gộp)
        r0 = CH["dong_nhom"]
        gop = [(rg.min_col, rg.max_col) for rg in ws.merged_cells.ranges if rg.min_row <= r0 <= rg.max_row]
        cur = None
        for c in COT:
            ci = column_index_from_string(c)
            a1 = next((a for a, b in gop if a <= ci <= b), ci)
            ten = " ".join(str(ws.cell(r0, a1).value or "").split()) or "Khác"
            if cur and cur["ten"] == ten:
                cur["cot"].append(c)
            else:
                cur = {"ten": ten, "cot": [c]}
                nhom.append(cur)
    else:
        nhom = [{"ten": CH.get("ten_ma_tran", "Ma trận"), "cot": list(COT)}]
    ten_ngan = {c: (CH.get("ten_ngan") or {}).get(c) or (re.sub(r"\(.*", "", tieu_de[c]).strip() or c)[:22] for c in COT}

    # dòng ma trận → hành động thiết kế; các dòng cùng tập hành động gộp thành một ô so
    O_SO, BO = collections.OrderedDict(), []
    for r in range(CH["dong_dau"], CH["dong_cuoi"] + 1):
        k = str(ws[f"{CH['cot_hanh_dong']}{r}"].value or "").strip()
        if not k:
            continue
        acts = (CH.get("dong") or {}).get(k) or GOP.get(k) or ([k] if k in act_tn else [])
        acts = [a for a in acts if a in act_tn]
        if not acts:
            BO.append(f"{CH['cot_hanh_dong']}{r} «{k}»")
            continue
        loc = (CH.get("loc_ho_so") or {}).get(k) or {}
        o = "+".join(acts) + ("|" + ",".join(f"{a}={x}" for a, x in sorted(loc.items())) if loc else "")
        O_SO.setdefault(o, {"hanh_dong": acts, "dong": [], "loc": loc})["dong"].append(r)
    TEN_HD = {h["key"]: h.get("ten", h["key"]) for t in D["tai_nguyen"] if t["key"] == RK for h in t["hanh_dong"]}
    for o, v in O_SO.items():
        v["ten"] = ", ".join(TEN_HD.get(a, a) for a in v["hanh_dong"]) + (
            " — chỉ hồ sơ " + ", ".join(f"{a} = {x}" for a, x in sorted(v["loc"].items())) if v["loc"] else "")

    # cây, hồ sơ thử (từ du_lieu_thu.json)
    CAY = DT["cay"]
    ten_dv = {k: t for k, t, _ in CAY}
    p_qh = os.path.join(lv, "quan_he_theo_dieu_kien.json")
    QH = [m for m in (json.load(open(p_qh, encoding="utf-8")) if os.path.exists(p_qh) else []) if m["tai_nguyen"] == RK]
    QH_TEN = {m["quan_he"] for m in QH}
    HO_SO = (DT.get("ho_so") or {}).get(RK) or [
        {"key": f"hs_cua_{n}", "mo_ta": f"Hồ sơ thuộc {ten_dv[n]}",
         "quan_he": {q: n for q, toi in dsl[0][RK]["relations"].items() if toi == CAY_DV and q not in QH_TEN}, "thuoc_tinh": {}}
        for n in DT.get("ban_ghi_tai", []) if n in ten_dv]
    NGUOI = []
    for c in COT:
        for n in (CH.get("nguoi") or {}).get(c, []):
            NGUOI.append((c, n["key"], n.get("mo_ta", ""), [tuple(x) for x in n.get("vai_tro", [])], n.get("ly_do", "")))
    if not NGUOI:
        sys.exit("so_sanh.json chưa có «nguoi»: ghép mỗi cột ma trận với người dùng thử và vai trò thiết kế.")
    inst = {k: (CAY_DV, {}) for k, _, _ in CAY}
    lap = (DT.get("nguoi_lap") or {}).get(RK)
    u_lap = next((u for _, u, _, vts, _ in NGUOI if any(v == lap for v, _ in vts)), None)
    abac = sorted({a for m in re.finditer(rf"resourceset \w+ \"[^\"]*\" on {RK} where (.*)", goc)
                   for a in re.findall(r"resource\.(\w+) == user\.\w+", m.group(1))})
    for h in HO_SO:
        tt = {a: u_lap for a in abac if u_lap}
        tt.update(h.get("thuoc_tinh") or {})
        h["_tt"] = tt
        inst[h["key"]] = (RK, tt)
        qh = {q: n for q, n in (h.get("quan_he") or {}).items() if q not in QH_TEN}   # quan hệ theo điều kiện: chỉ ghi khi hồ sơ thoả
        qh.update({m["quan_he"]: qh[m["quan_he_goc"]] for m in QH if m["quan_he_goc"] in qh and DKM.danh_gia(DKM.doc_dieu_kien(m["dieu_kien_dsl"]), {}, tt)})
        h["quan_he"] = qh
    rel = {(k, "cap_tren"): cha for k, _, cha in CAY if cha}
    rel.update({(h["key"], q): dv for h in HO_SO for q, dv in (h.get("quan_he") or {}).items()})
    gan, ua = set(), {}
    for c, u, mo, vts, ly in NGUOI:
        ua[u] = {"trang_thai": "DANG_HOAT_DONG", "ma_nguoi_dung": u, "vai_tro_chung": [vt for vt, dv in vts if dv is None]}
        for vt, dv in vts:
            gan.add((u, vt, dv))
            if dv is not None and f"{vt}__quyen_chung" in dsl[1]:
                gan.add((u, f"{vt}__quyen_chung", None))
    # vai trò trên bản ghi (xuat_json.py ghi vai_tro_tren_ban_ghi.json): người lập / người được giao giữ vai trò gốc nhận vai trò trên bản ghi
    p_bg = os.path.join(lv, "vai_tro_tren_ban_ghi.json")
    BG = [m for m in (json.load(open(p_bg, encoding="utf-8")) if os.path.exists(p_bg) else []) if m["tai_nguyen"] == RK]
    GAN_BG = []
    cha = {k: c for k, _, c in CAY}
    def to_tien(n):
        out = []
        while cha.get(n):
            n = cha[n]; out.append(n)
        return out
    for m in BG:   # có điều kiện: chỉ gán khi hồ sơ thoả (xét với chính người được gán); «theo_pham_vi»: người giữ vai trò gốc theo phạm vi
        for h in HO_SO:
            for c, u, mo, vts, ly in NGUOI:
                if m.get("dieu_kien_dsl") and not DKM.danh_gia(DKM.doc_dieu_kien(m["dieu_kien_dsl"]), ua[u], h["_tt"]):
                    continue
                if m.get("cach_gan") == "theo_pham_vi":
                    n = h["key"] if m["quan_he"] == "(chinh_ban_ghi)" else (h.get("quan_he") or {}).get(m["quan_he"])
                    noi = {dv for vt, dv in vts if vt == m["vai_tro"] and dv}
                    kp = m.get("kieu_pham_vi")
                    ok = n is not None and (n in noi or (kp == "don_vi_minh_va_cap_duoi" and noi & set(to_tien(n)))
                                            or (kp == "don_vi_minh_va_cap_duoi_truc_tiep" and cha.get(n) in noi))
                    if ok:
                        gan.add((u, m["vai_tro_ban_ghi"], h["key"]))
                        GAN_BG.append(f"assign {u} {m['vai_tro_ban_ghi']} on {RK}:{h['key']}  // giữ {m['vai_tro']} theo phạm vi qua {m['quan_he']}, thoả điều kiện")
                elif str(h["_tt"].get(m["thuoc_tinh"])) == u and any(vt == m["vai_tro"] for vt, _ in vts):
                    gan.add((u, m["vai_tro_ban_ghi"], h["key"]))
                    GAN_BG.append(f"assign {u} {m['vai_tro_ban_ghi']} on {RK}:{h['key']}  // {m['thuoc_tinh']} là mình, giữ vai trò {m['vai_tro']}")
    DG = DanhGia(dsl, inst, rel, gan, ua)
    # thêm mới / nhập (xuat_json.py ghi kiem_khi_tao.json): kiểm trên nút cây mà hồ sơ mới gắn vào, biến thể theo điều kiện xét trên dữ liệu hồ sơ
    p_tao = os.path.join(lv, "kiem_khi_tao.json")
    TAO = collections.defaultdict(list)
    for m in (json.load(open(p_tao, encoding="utf-8")) if os.path.exists(p_tao) else []):
        if m["tai_nguyen"] == RK:
            TAO[m["hanh_dong"]].append(m)

    def duoc(u, a, h):
        if a not in TAO:
            return DG.duoc(u, a, h["key"])
        duong = []
        for m in TAO[a]:
            if m.get("dieu_kien_dsl") and not DKM.danh_gia(DKM.doc_dieu_kien(m["dieu_kien_dsl"]), ua[u], h["_tt"]):
                continue
            noi = (h.get("quan_he") or {}).get(m["quan_he"]) if m["kiem_tren"] else h["key"]
            if noi is not None and noi in inst:
                ok, d = DG.duoc(u, m["hanh_dong_dsl"], noi)
                if ok:
                    duong += [f"{x} ({m['hanh_dong_dsl']} trên {noi})" for x in d]
        return bool(duong), duong
    bang = {(u, a, h["key"]): duoc(u, a, h) for _, u, *_ in NGUOI for a in act_tn for h in HO_SO}
    HS = {h["key"]: h for h in HO_SO}

    def dong_assert(u, a, hk, ok, chu_thich=""):
        """Câu assert cho playground; thêm mới / nhập: assert biến thể trên nút cây mà hồ sơ gắn vào."""
        ct = f"  // {chu_thich}" if chu_thich else ""
        if a not in TAO:
            return f"assert {u} {'can' if ok else 'cannot'} {a} {RK}:{hk} {T}{ct}"
        h = HS[hk]
        ds = [m for m in TAO[a] if not m.get("dieu_kien_dsl") or DKM.danh_gia(DKM.doc_dieu_kien(m["dieu_kien_dsl"]), ua[u], h["_tt"])]
        if not ds:
            return f"// {u} {a} {hk}: dữ liệu hồ sơ không thoả biến thể nào → ứng dụng không cho tạo (không có câu kiểm){ct}"
        m = ds[0]
        noi = (h.get("quan_he") or {}).get(m["quan_he"]) if m["kiem_tren"] else hk
        dich = f"{CAY_DV}:{noi}" if m["kiem_tren"] else f"{RK}:{hk}"
        return f"assert {u} {'can' if ok else 'cannot'} {m['hanh_dong_dsl']} {dich} {T}{ct}"

    ket_qua = []
    for c in COT:
        nd = [n for n in NGUOI if n[0] == c]
        for o, v in O_SO.items():
            o_mt = [f"{c}{r}" for r in v["dong"]]
            co = any(str(ws[x].value or "").strip().lower() in ("x", "x*") for x in o_mt)
            hs_o = [h for h in HO_SO if all(str(h["_tt"].get(a)) == str(x) for a, x in v["loc"].items())]
            ct = {}
            for a in v["hanh_dong"]:
                chung = [{"nguoi": u, "ho_so": h["key"], "duong": bang[(u, a, h["key"])][1]}
                         for _, u, *_ in nd for h in hs_o if bang[(u, a, h["key"])][0]]
                ct[a] = {"duoc": bool(chung), "chung": chung}
            tk = [a for a in v["hanh_dong"] if ct[a]["duoc"]]
            khop = all(ct[a]["duoc"] for a in v["hanh_dong"]) if co else not tk
            ket_qua.append({"cot": c, "tieu_de": tieu_de[c], "o_so": o, "ten": v["ten"], "o_u02": o_mt, "u02": co,
                            "ho_so_xet": [h["key"] for h in hs_o],
                            "hanh_dong": v["hanh_dong"], "thiet_ke_duoc": tk, "khop": khop, "chi_tiet": ct})

    ss = os.path.join(lv, "so_sanh")
    os.makedirs(ss, exist_ok=True)
    mt = CH.get("ten_ma_tran", CH["sheet"])
    # ---- DSL so sánh và DSL kiểm bộ đánh giá ----
    L = ["", f"// ========== SO SÁNH VỚI MA TRẬN «{mt}» — DỮ LIỆU THỬ (AI dựng, không phải nguồn) ==========",
         "// Người dùng = cột ma trận; assert = ô ma trận (x → can, trống → cannot) trên cặp (người dùng của cột, hồ sơ) đại diện.",
         "// Tests: đạt = khớp, hỏng = lệch. Điều kiện theo thuộc tính hồ sơ xét qua thuộc tính hồ sơ thử (luật permit, quan hệ theo điều kiện); quyền nới rộng không xét điều kiện.", ""]
    L += [f'user {u} "{c}: {mo}" {{ trang_thai: "DANG_HOAT_DONG", ma_nguoi_dung: "{u}"'
          + (", vai_tro_chung: [" + ", ".join(f'"{vt}"' for vt, dv in vts if dv is None) + "]" if any(dv is None for _, dv in vts) else "") + " }"
          for c, u, mo, vts, _ in NGUOI]
    L += [""] + [f"instance {CAY_DV}:{k} {T}  // {t}" for k, t, _ in CAY] + [f"relate {CAY_DV}:{cha} cap_tren {CAY_DV}:{k}" for k, _, cha in CAY if cha]
    for h in HO_SO:
        tt = h["_tt"]
        L.append(f"instance {RK}:{h['key']} {T}" + (" { " + ", ".join(f"{a}: {gt(x)}" for a, x in tt.items()) + " }" if tt else "")
                 + f"  // {h.get('mo_ta', '')}")
        L += [f"relate {CAY_DV}:{dv} {q} {RK}:{h['key']}" for q, dv in (h.get("quan_he") or {}).items()]
    L.append("")
    for c, u, mo, vts, ly in NGUOI:
        L.append(f"// {c} {u}: {ly}")
        for vt, dv in vts:
            if dv is None:
                if vt in dsl[1]:
                    L.append(f"assign {u} {vt} {T}")
            else:
                if f"{vt}__quyen_chung" in dsl[1]:
                    L.append(f"assign {u} {vt}__quyen_chung {T}")
                L.append(f"assign {u} {vt} on {CAY_DV}:{dv}  // {ten_dv.get(dv, dv)}")
    L += sorted(set(GAN_BG))
    K = list(L)
    L += ["", "// ---- kiểm tra theo ma trận ----"]
    for kq in ket_qua:
        nd = [n for n in NGUOI if n[0] == kq["cot"]]
        if not nd:
            continue
        for a in kq["hanh_dong"]:
            ct = kq["chi_tiet"][a]
            u, hs = (ct["chung"][0]["nguoi"], ct["chung"][0]["ho_so"]) if ct["duoc"] else (nd[0][1], (kq["ho_so_xet"] or [HO_SO[0]["key"]])[0])
            L.append(dong_assert(u, a, hs, kq["u02"], f"{', '.join(kq['o_u02'])}: {'x' if kq['u02'] else 'trống'}"))
    open(os.path.join(ss, "so_sanh.dsl"), "w", encoding="utf-8").write(goc.rstrip("\n") + "\n" + "\n".join(L) + "\n")
    K += ["", "// ---- kiểm bộ đánh giá: playground phải đạt hết ----"]
    K += [dong_assert(u, a, h, ok) for (u, a, h), (ok, _) in bang.items()]
    open(os.path.join(ss, "kiem_bo_danh_gia.dsl"), "w", encoding="utf-8").write(goc.rstrip("\n") + "\n" + "\n".join(K) + "\n")

    lech = [k for k in ket_qua if not k["khop"]]
    json.dump({"phan_he": D.get("phan_he", {}).get("ten", ""), "ten_ma_tran": mt,
               "tieu_de_trang": CH.get("tieu_de_trang") or f"Lệch {mt} – {TN[RK]['ten']}",
               "gioi_thieu": CH.get("gioi_thieu") or f"Đối chiếu thiết kế phân quyền đã xác nhận với ma trận «{CH['sheet']}» cho «{TN[RK]['ten']}».",
               "cach_so": CH.get("cach_so") or ("Mỗi cột ma trận ứng với một hoặc nhiều người dùng thử được gán vai trò thiết kế; một ô «thiết kế cho» "
                                               "khi có người dùng của cột làm được thao tác trên ít nhất một hồ sơ thử. Cây, người dùng, hồ sơ thử do AI dựng "
                                               "để chạy phép so, không dùng làm nguồn; điều kiện theo thuộc tính hồ sơ xét qua thuộc tính hồ sơ thử (khai «ho_so» theo giá trị CSDL), quyền nới rộng không xét điều kiện."),
               "nhom_cot": nhom, "ten_ngan": ten_ngan, "cot": tieu_de, "dong_bo_qua": BO,
               "nguoi": [{"cot": c, "key": u, "mo_ta": mo, "vai_tro": vts, "ly_do": ly} for c, u, mo, vts, ly in NGUOI],
               "don_vi": [{"key": k, "ten": t, "cap_tren": cha} for k, t, cha in CAY],
               "ho_so": [{"key": h["key"], "mo_ta": h.get("mo_ta", ""), "thuoc_tinh": h["_tt"], "quan_he": h.get("quan_he", {})} for h in HO_SO],
               "ket_qua": ket_qua}, open(os.path.join(ss, "ket_qua.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    # ---- dữ liệu cho AI viết giải thích ----
    M = [f"# Ô lệch giữa thiết kế và ma trận «{mt}» — dữ liệu cho bước giải thích", "",
         "Cây, người dùng, hồ sơ thử do AI dựng (không phải nguồn). Giải thích chỉ theo tài liệu nguồn và câu BA chốt.", "",
         "## Người dùng thử theo cột", ""]
    for c, u, mo, vts, ly in NGUOI:
        vt_txt = ", ".join(f"{v} @ {d or 'toàn hệ thống'}" for v, d in vts) or "(không có vai trò thiết kế)"
        M.append(f"- Cột {c} «{tieu_de[c]}» → {u}: {mo} — vai trò: {vt_txt} — {ly}")
    M += ["", "## Hồ sơ thử", ""] + [f"- {h['key']}: {h.get('mo_ta', '')}" for h in HO_SO]
    M += ["", "## Ô lệch", ""]
    for i, k in enumerate(lech, 1):
        M.append(f"### L{i:02d} — cột {k['cot']} ({k['tieu_de']}) · {k['ten']} · ô {', '.join(k['o_u02'])} · o_so={k['o_so']}")
        M.append(f"- Ma trận: {'x' if k['u02'] else 'trống'}; thiết kế cho: {', '.join(k['thiet_ke_duoc']) or 'không'}")
        for a, ct in k["chi_tiet"].items():
            if ct["duoc"]:
                M.append(f"  - {a}: " + "; ".join(f"{x['nguoi']} trên {x['ho_so']} [{', '.join(x['duong'])}]" for x in ct["chung"][:3]))
            else:
                M.append(f"  - {a}: không người dùng nào của cột được")
        M.append("")
    open(os.path.join(ss, "lech.md"), "w", encoding="utf-8").write("\n".join(M) + "\n")
    print(f"so_sanh/: {len(NGUOI)} người dùng, {len(HO_SO)} hồ sơ thử; so {len(ket_qua)} ô: khớp {len(ket_qua) - len(lech)}, lệch {len(lech)}"
          + (f"; bỏ qua dòng {', '.join(BO)}" if BO else ""))
    try:
        ghi_trai_phang_theo_thiet_ke(lv, CH, p_x, ket_qua, NGUOI, D, RK, mt)
    except Exception as loi:   # không chặn phép so vì bản Excel
        print(f"  cảnh báo: chưa ghi được bản trải phẳng theo thiết kế: {loi}")


def ghi_trai_phang_theo_thiet_ke(lv, CH, p_x, ket_qua, NGUOI, D, RK, mt):
    """Bản trải phẳng theo thiết kế: chép sheet baseline (giữ khung, định dạng), mỗi ô so được điền theo thiết kế
    («x» có quyền, «x*» có quyền kèm điều kiện, trống không có). Ô thiết kế cho mà baseline không có: nền xanh; baseline có
    mà thiết kế không cho: nền đỏ nhạt; ghi chú ô nêu giá trị baseline và tóm tắt giải thích (so_sanh/giai_thich.json)."""
    from openpyxl.comments import Comment
    from openpyxl.styles import PatternFill, Font
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from xac_nhan import TK
    T = TK(lv)
    HL = [q for q in T.hieu_luc() if q["tai_nguyen"] == RK]
    vt_cot = collections.defaultdict(set)
    for c, u, mo, vts, ly in NGUOI:
        vt_cot[c] |= {v for v, _ in vts}
    TN = {t["key"]: t for t in D["tai_nguyen"]}
    TEN_HD = {h["key"]: h.get("ten", h["key"]) for h in TN[RK]["hanh_dong"]}

    def sao(c, acts, loc):
        """True khi mọi quyền cấp cho cột này đều kèm điều kiện ngoài phần tách dòng (loc)."""
        co, deu = False, True
        for q in HL:
            if q["vai_tro"] not in vt_cot[c] or q["hanh_dong"] not in acts:
                continue
            co = True
            con = False
            for k in q.get("dieu_kien", []):
                bt = T.DK.get(k, {}).get("bieu_thuc") or []
                if any(not (b.get("trai", "").startswith("resource.") and b["trai"][9:] in loc) for b in bt):
                    con = True
            deu = deu and con
        return co and deu

    def mo_ta(c, acts):
        out = []
        for q in HL:
            if q["vai_tro"] in vt_cot[c] and q["hanh_dong"] in acts:
                pv = T.PV.get(q.get("pham_vi") or "", {}).get("ten") or q.get("pham_vi") or ""
                dk = "; ".join(T.DK.get(k, {}).get("ten", k) for k in q.get("dieu_kien", []))
                x = f"{T.VT.get(q['vai_tro'], {}).get('ten', q['vai_tro'])}: {TEN_HD.get(q['hanh_dong'], q['hanh_dong'])} — {pv}" + (f" — khi {dk}" if dk else "")
                if x not in out:
                    out.append(x)
        return out

    ss = os.path.join(lv, "so_sanh")
    gtp = os.path.join(ss, "giai_thich.json")
    GT = {(g["cot"], g["o_so"]): g for g in (json.load(open(gtp, encoding="utf-8")).get("o_lech", []) if os.path.exists(gtp) else [])}
    wb = openpyxl.load_workbook(p_x)
    for w in list(wb.worksheets):
        if w.title != CH["sheet"]:
            del wb[w.title]
    ws = wb[CH["sheet"]]
    XANH, DO = PatternFill("solid", fgColor="E2EFDA"), PatternFill("solid", fgColor="FCE4D6")
    so = collections.Counter()
    for kq in ket_qua:
        c, acts = kq["cot"], kq["hanh_dong"]
        loc = (CH.get("loc_ho_so") or {}).get(str(ws[f"{CH['cot_hanh_dong']}{int(re.sub(r'[A-Z]+', '', kq['o_u02'][0]))}"].value or "").strip()) or {}
        tk = bool(kq["thiet_ke_duoc"]) and len(kq["thiet_ke_duoc"]) == len(acts)
        v = ("x*" if sao(c, acts, loc) else "x") if tk else ""
        for o in kq["o_u02"]:
            cell = ws[o]
            goc = str(cell.value or "").strip()
            cell.value = v or None
            ghi = mo_ta(c, acts) if tk else []
            if kq["khop"]:
                so["khop"] += 1
            else:
                so["them" if tk else "bo"] += 1
                cell.fill = XANH if tk else DO
                g = GT.get((c, kq["o_so"]), {})
                ghi = [f"Baseline: {goc or 'trống'} — thiết kế: {v or 'không cấp'}"] + (g.get("tom_tat_note") or []) + ghi
            if ghi:
                cm = Comment("\n".join(ghi)[:2000], "AI thiết kế phân quyền")
                cm.width, cm.height = 420, min(80 + 16 * len(ghi) * 2, 400)
                cell.comment = cm
    r = (CH["dong_cuoi"] or ws.max_row) + 2
    ws.cell(r, 2, f"Bản trải phẳng theo thiết kế (khung sheet «{CH['sheet']}»): x = có quyền, x* = có quyền kèm điều kiện; "
                  f"nền xanh = thiết kế cho mà baseline không có ({so['them']} ô), nền đỏ = baseline có mà thiết kế không cho ({so['bo']} ô). "
                  "Rê chuột vào ô để xem vai trò, phạm vi, điều kiện và giải thích. Dòng không so giữ nguyên giá trị baseline.").font = Font(italic=True)
    nhap = os.path.exists(os.path.join(lv, "BAN_NHAP_CHUA_XAC_NHAN.txt"))
    p = os.path.join(ss, f"trai_phang_theo_thiet_ke{'_NHAP' if nhap else ''}.xlsx")
    ws.title = (("NHAP " if nhap else "") + ws.title)[:31]
    wb.save(p)
    print(f"  bản trải phẳng theo thiết kế: {p} · khớp {so['khop']} · thiết kế thêm {so['them']} · thiết kế không cho {so['bo']}")


if __name__ == "__main__":
    main()
