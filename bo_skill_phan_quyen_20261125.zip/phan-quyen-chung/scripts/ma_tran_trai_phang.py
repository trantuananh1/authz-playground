# -*- coding: utf-8 -*-
"""Sinh bảng phân quyền trải phẳng (dòng = tài nguyên × hành động, cột = chức danh theo cấp, ô «x» / «x*») từ thiết kế,
theo KHUNG của một sheet trải phẳng có sẵn (của nghiệp vụ khác hoặc bản cũ) khi BA không cung cấp ma trận cho nghiệp vụ này.

  python -I ma_tran_trai_phang.py khung <tệp.xlsx> <sheet>
        in cấu trúc sheet khung (dòng tiêu đề, nhóm cột, ô gộp, cột chức danh) để AI lập <lv>/ma_tran_trai_phang.json
  python -I ma_tran_trai_phang.py lap <lv> [--nhap] [--khong-ghi-chu]
        → <lv>/ma_tran_trai_phang/<ten>.xlsx (sheet khung viết lại phần dữ liệu + sheet «Cột – vai trò»), ma_tran.html (trang
        Artifact), ma_tran.md. Cần BA đã xác nhận bản xem trước; --nhap: bản nháp để BA rà khi rà soát (tên tệp có «_NHAP»).

Ô tính thẳng từ QUYỀN HIỆU LỰC của thiết kế (cùng nguồn với JSON import và DSL, DSL tự kiểm 0 lệch so với thiết kế):
ô «x» khi một vai trò thiết kế ghép với cột có quyền đó không kèm điều kiện; «x*» khi mọi quyền đó đều kèm điều kiện (trạng thái,
khoá, loại…); trống khi không vai trò nào của cột có quyền. Dòng tách theo giá trị thuộc tính (ví dụ theo loại bản ghi): quyền có
điều kiện trái với giá trị của dòng thì không tính; điều kiện khớp đúng giá trị dòng thì không làm ô thành «x*».
Ghi chú (comment) mỗi ô có quyền: vai trò cấp, phạm vi (bản ghi nào), điều kiện (khi nào). Đây là thiết kế trình bày theo khung
quen thuộc, KHÔNG phải nguồn và không dùng để so ngược với thiết kế.

<lv>/ma_tran_trai_phang.json (AI lập; ô, cột theo chữ cái của sheet khung):
{
 "khung": {"excel": "<tệp khung .xlsx>", "sheet": "<tên>", "dong_nhom": 6, "dong_tieu_de": 7, "dong_dau": 8, "dong_cuoi": 30,
           "cot_vai_tro": "J:Y"},
 "cot": {"tai_nguyen": "B", "ten_tai_nguyen": "C", "thuoc_tinh": "D", "hanh_dong": "E", "mo_ta": "G", "ghi_chu": "I"},
        (cột thông tin của dòng; cột khung khác để trống. «ghi_chu» nhận tóm tắt phạm vi, điều kiện của dòng)
 "cot_vai_tro": {"J": {"vai_tro": ["<vai trò thiết kế>", ...], "ly_do": "<nguồn: tầng việc, quy tắc gán, câu BA chốt>"}, ...},
        (cột không ghép được vai trò nào: "vai_tro": [], ghi ly_do; hoặc liệt kê ở "bo_cot" để xoá cột)
 "bo_cot": ["P", "Q", "R"],                 (tuỳ chọn: xoá cột chức danh không có trong nghiệp vụ này)
 "tieu_de_cot": {"J": "<tên chức danh mới>"}, "ghi_o": {"A1": "Bảng phân quyền trải phẳng – <nghiệp vụ>"},   (tuỳ chọn)
 "tai_nguyen": ["<key>", ...],              (tuỳ chọn; mặc định mọi tài nguyên có hành động, theo thứ tự thiết kế)
 "tach": {"<tài nguyên>": {"thuoc_tinh": "loai_ho_so", "gia_tri": {"LOAI_A": "loại A", "LOAI_B": "loại B"},
                            "hanh_dong": ["xem", "tao_moi"]}},   (tuỳ chọn: tách dòng theo giá trị chuẩn của thuộc tính)
 "bang_vai_tro": {"dong_dau": 3, "dong_cuoi": 4, "cot": {"stt": "A", "key": "B", "ten": "C"}},
        (tuỳ chọn: viết lại bảng vai trò hệ thống ở phần đầu sheet khung từ Bảng 1 của ba_bang.json)
 "ten": "<tên tệp ra không dấu>"
}
"""
import argparse, collections, copy, html, json, os, re, sys

import openpyxl
from openpyxl.utils import column_index_from_string as ci, get_column_letter as cl

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bo_key as BK  # noqa: E402
from xac_nhan import TK, doc  # noqa: E402
from doi_chieu_ba_bang import Sheet, cf  # noqa: E402

TEN_PV = {"toan_he_thong": "Toàn hệ thống", "danh_sach": "Mức danh sách"}


def cot_ds(spec):
    out = []
    for phan in (spec if isinstance(spec, list) else [spec]):
        a, _, b = phan.partition(":")
        out += [cl(k) for k in range(ci(a), ci(b or a) + 1)]
    return out


# ======================================================================================== xem khung
def lenh_khung(tep, sheet):
    ws = openpyxl.load_workbook(tep, data_only=True)[sheet]
    print(f"sheet «{sheet}»: {ws.max_row} dòng × {ws.max_column} cột; cố định ô {ws.freeze_panes}")
    print("ô gộp:", ", ".join(sorted(str(m) for m in ws.merged_cells.ranges)))
    for r in range(1, min(ws.max_row, 60) + 1):
        o = [(c.coordinate, cf(c.value)[:40]) for c in ws[r] if cf(c.value)]
        if o:
            print(r, o)


# ======================================================================================== tính ô
class MaTran:
    def __init__(self, lv):
        self.lv = lv
        self.CH = doc(os.path.join(lv, "ma_tran_trai_phang.json"))
        if not self.CH:
            sys.exit(f"Chưa có {lv}/ma_tran_trai_phang.json — chạy «khung» để xem sheet khung rồi lập tệp cấu hình (khuôn ở đầu script).")
        self.T = TK(lv)
        D = self.D = self.T.D
        self.TN = {t["key"]: t for t in D["tai_nguyen"]}
        self.VT = {v["key"]: v for v in D["vai_tro"]}
        self.Q = collections.defaultdict(list)          # (tài nguyên, hành động) → [quyền hiệu lực]
        for q in self.T.hieu_luc():
            self.Q[(q["tai_nguyen"], q["hanh_dong"])].append(q)
        cv = self.CH.get("cot_vai_tro") or {}
        # chấp nhận cả khuôn «nguoi» của so_sanh.json: {"J": [{"vai_tro": [["vt", "nút"]], "ly_do"}]}
        if not cv and self.CH.get("nguoi"):
            cv = {c: {"vai_tro": sorted({v[0] for n in ds for v in n.get("vai_tro", [])}), "ly_do": "; ".join(n.get("ly_do", "") for n in ds)}
                  for c, ds in self.CH["nguoi"].items()}
        self.CV = cv
        sai = sorted({v for x in cv.values() for v in x.get("vai_tro", []) if v not in self.VT})
        if sai:
            sys.exit("cot_vai_tro nhắc vai trò không có trong thiết kế: " + ", ".join(sai))

    def dk_ten(self, k):
        return self.T.DK.get(k, {}).get("ten", k)

    def pv_ten(self, k):
        return self.T.PV.get(k or "", {}).get("ten") or TEN_PV.get(k, k or "")

    def hop_dong(self, q, loc):
        """(quyền áp được cho dòng, còn điều kiện ngoài phần tách dòng)."""
        con = []
        for k in q.get("dieu_kien", []):
            bt = self.T.DK.get(k, {}).get("bieu_thuc") or []
            phan_loc = [b for b in bt if b.get("trai", "").startswith("resource.") and b["trai"][9:] in loc]
            for b in phan_loc:
                gt, ph = loc[b["trai"][9:]], b.get("phai")
                ok = {"bang": gt == ph, "khac": gt != ph, "thuoc": gt in (ph if isinstance(ph, list) else [ph])}.get(b.get("phep"), True)
                if not ok:
                    return False, False
            if len(phan_loc) < len(bt):
                con.append(k)
        return True, bool(con)

    def dong(self):
        ds = self.CH.get("tai_nguyen") or [t["key"] for t in self.D["tai_nguyen"] if t.get("hanh_dong")]
        out = []
        for rk in ds:
            t = self.TN[rk]
            tach = (self.CH.get("tach") or {}).get(rk) or {}
            for h in t["hanh_dong"]:
                if tach and (not tach.get("hanh_dong") or h["key"] in tach["hanh_dong"]):
                    for gt, nhan in tach["gia_tri"].items():
                        out.append({"tn": rk, "hd": h["key"], "key": f"{h['key']}_{BK.khong_dau(nhan)}", "ten": f"{h.get('ten', h['key'])} – {nhan}",
                                    "loc": {tach["thuoc_tinh"]: gt}})
                else:
                    out.append({"tn": rk, "hd": h["key"], "key": h["key"], "ten": h.get("ten", h["key"]), "loc": {}})
        return out

    def o(self, d, c):
        """Ô của dòng d ở cột c: ('x' | 'x*' | '', [mô tả quyền])."""
        vts = set((self.CV.get(c) or {}).get("vai_tro", []))
        co, sao, mo = False, True, []
        for q in self.Q.get((d["tn"], d["hd"]), []):
            if q["vai_tro"] not in vts:
                continue
            ok, con_dk = self.hop_dong(q, d["loc"])
            if not ok:
                continue
            co = True
            sao = sao and con_dk
            dk = "; ".join(self.dk_ten(k) for k in q.get("dieu_kien", []))
            mo.append(f"{self.VT[q['vai_tro']]['ten']}: {self.pv_ten(q.get('pham_vi'))}" + (f" — khi {dk}" if dk else ""))
        return ("x*" if sao else "x") if co else "", mo


# ======================================================================================== ghi Excel, trang, md
def xoa_cot(ws, chu):
    """Xoá các cột (chữ cái), dời ô gộp và độ rộng cột theo."""
    xoa = sorted({ci(c) for c in chu})
    if not xoa:
        return
    lui = lambda c: c - sum(1 for x in xoa if x < c)
    rong = {ci(k): v.width for k, v in ws.column_dimensions.items() if v.width}
    gop = []
    for m in list(ws.merged_cells.ranges):
        ws.unmerge_cells(str(m))
        cs = [c for c in range(m.min_col, m.max_col + 1) if c not in xoa]
        if cs:
            gop.append((m.min_row, lui(cs[0]), m.max_row, lui(cs[-1])))
    for c in reversed(xoa):
        ws.delete_cols(c)
    for k in list(ws.column_dimensions.keys()):
        del ws.column_dimensions[k]
    for c, w in rong.items():
        if c not in xoa:
            ws.column_dimensions[cl(lui(c))].width = w
    for a, b, c, d in gop:
        if c > a or d > b:
            ws.merge_cells(start_row=a, start_column=b, end_row=c, end_column=d)


def lap(lv, nhap, khong_ghi_chu):
    M = MaTran(lv)
    CH, K = M.CH, M.CH["khung"]
    if not nhap and not M.T.da_xac_nhan():
        sys.exit("BA chưa xác nhận bản xem trước (hoặc thiết kế đã đổi sau khi xác nhận). Khi rà soát dùng --nhap.")
    p_k = K["excel"] if os.path.isabs(K["excel"]) else os.path.join(lv, K["excel"])
    wb = openpyxl.load_workbook(p_k)
    if K["sheet"] not in wb.sheetnames:
        sys.exit(f"{p_k} không có sheet «{K['sheet']}».")
    for w in list(wb.worksheets):
        if w.title != K["sheet"]:
            del wb[w.title]
    ws = wb[K["sheet"]]
    COT = [c for c in cot_ds(K["cot_vai_tro"])]
    COTD = [c for c in COT if c not in (CH.get("bo_cot") or [])]
    chua_ghep = [c for c in COTD if c not in M.CV]
    if chua_ghep:
        sys.exit("Cột chức danh chưa ghép vai trò (ghi vào cot_vai_tro, vai_tro: [] nếu không có, hoặc bo_cot): " + ", ".join(chua_ghep))
    tieu_de = {c: cf((CH.get("tieu_de_cot") or {}).get(c) or ws[f"{c}{K['dong_tieu_de']}"].value) for c in COT}
    nhom = {}
    if K.get("dong_nhom"):
        gop = [(m.min_col, m.max_col) for m in ws.merged_cells.ranges if m.min_row <= K["dong_nhom"] <= m.max_row]
        for c in COT:
            a = next((x for x, y in gop if x <= ci(c) <= y), ci(c))
            nhom[c] = cf(ws.cell(K["dong_nhom"], a).value)

    DONG = M.dong()
    cot = {f: ci(c) for f, c in (CH.get("cot") or {}).items()}
    S = Sheet(ws, False)
    on = lambda v, gc="": {"v": v, "loai": None, "ghi_chu": "" if khong_ghi_chu else gc, "giau": None}
    rows, gop_moi, bang = [], [], []
    for rk in dict.fromkeys(d["tn"] for d in DONG):
        t = M.TN[rk]
        ds = [d for d in DONG if d["tn"] == rk]
        i0 = len(rows)
        tt = "\n".join(f"{x['key']}: {x.get('kieu', '')}" + (f" ({', '.join(x['gia_tri'].values())})" if x.get("gia_tri") else "")
                       for x in t.get("thuoc_tinh", []))
        for j, d in enumerate(ds):
            o = {}
            if j == 0:
                for f, v in (("tai_nguyen", rk), ("ten_tai_nguyen", t["ten"]), ("thuoc_tinh", tt)):
                    if f in cot:
                        o[cot[f]] = on(v)
            if "hanh_dong" in cot:
                o[cot["hanh_dong"]] = on(d["key"])
            if "mo_ta" in cot:
                o[cot["mo_ta"]] = on(d["ten"])
            tom, hang = [], {}
            for c in COTD:
                v, mo = M.o(d, c)
                hang[c] = (v, mo)
                o[ci(c)] = on(v, "\n".join(mo))
                tom += [x for x in mo if x not in tom]
            if "ghi_chu" in cot:
                o[cot["ghi_chu"]] = on("\n".join(tom))
            o["_giu"] = set()
            rows.append((K["dong_dau"], o))
            bang.append((d, hang))
        for f in ("tai_nguyen", "ten_tai_nguyen", "thuoc_tinh"):
            if f in cot and len(ds) > 1:
                gop_moi.append((cot[f], cot[f], i0, i0 + len(ds) - 1))
    S.thay_vung(K["dong_dau"], K["dong_cuoi"], rows, gop_moi)
    for c, ten in (CH.get("tieu_de_cot") or {}).items():
        ws[f"{c}{K['dong_tieu_de']}"] = ten
    for o, v in (CH.get("ghi_o") or {}).items():
        ws[o] = v
    bv = CH.get("bang_vai_tro")
    B1 = (doc(os.path.join(lv, "ba_bang.json"), {}) or {}).get("vai_tro_he_thong", [])
    if bv and B1:
        n_cu = bv["dong_cuoi"] - bv["dong_dau"] + 1
        if len(B1) > n_cu:
            print(f"cảnh báo: Bảng 1 có {len(B1)} vai trò, khung chỉ có {n_cu} dòng — ghi {n_cu} dòng đầu")
        for i in range(n_cu):
            for f, c in bv["cot"].items():
                v = B1[i] if i < len(B1) else None
                ws[f"{c}{bv['dong_dau'] + i}"] = (f"{i + 1}." if f == "stt" else v.get(f, "")) if v else None
    xoa_cot(ws, CH.get("bo_cot") or [])
    ws.title = (("NHAP " if nhap else "") + ws.title)[:31]
    # sheet ghép cột
    s = wb.create_sheet("Cột – vai trò")
    for j, h in enumerate(["Cột khung", "Nhóm", "Chức danh (cột)", "Vai trò thiết kế", "Căn cứ ghép"], 1):
        s.cell(1, j, h).font = openpyxl.styles.Font(bold=True)
    for i, c in enumerate(COTD, 2):
        x = M.CV.get(c, {})
        for j, v in enumerate([c, nhom.get(c, ""), tieu_de[c], ", ".join(f"{k} ({M.VT[k]['ten']})" for k in x.get("vai_tro", [])) or "— (không có vai trò)",
                               x.get("ly_do", "")], 1):
            s.cell(i, j, v).alignment = openpyxl.styles.Alignment(wrap_text=True, vertical="top")
    for j, w in enumerate((10, 26, 34, 60, 70), 1):
        s.column_dimensions[cl(j)].width = w
    r = len(COTD) + 3
    s.cell(r, 1, "Bảng sinh từ thiết kế phân quyền" + (" (BẢN NHÁP, BA chưa xác nhận)" if nhap else " đã được BA xác nhận")
           + "; ô x = có quyền, x* = có quyền kèm điều kiện (xem ghi chú ô và cột ghi chú của dòng). Không phải nguồn: không dùng để so ngược với thiết kế.")
    thu = os.path.join(lv, "ma_tran_trai_phang")
    os.makedirs(thu, exist_ok=True)
    ten = CH.get("ten") or BK.khong_dau(M.D.get("phan_he", {}).get("ten", "phan_he"))[:40]
    p = os.path.join(thu, f"{ten}{'_NHAP' if nhap else ''}.xlsx")
    wb.active = 0
    wb.save(p)

    # trang Artifact + md
    e = lambda x: html.escape(str(x or ""))
    nh = collections.OrderedDict()
    for c in COTD:
        nh.setdefault(nhom.get(c) or "", []).append(c)
    so = collections.Counter(v for _, hang in bang for v, _ in hang.values())
    P = ['<title>Phân quyền trải phẳng</title>',
         '<style>:root{--bg:#fff;--fg:#1f2328;--mu:#59636e;--bd:#d1d9e0;--x:#dafbe1;--xs:#fff8c5;--hd:#f6f8fa}'
         '@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#0d1117;--fg:#e6edf3;--mu:#9198a1;--bd:#3d444d;--x:#12361f;--xs:#3a2f06;--hd:#151b23}}'
         ':root[data-theme="dark"]{--bg:#0d1117;--fg:#e6edf3;--mu:#9198a1;--bd:#3d444d;--x:#12361f;--xs:#3a2f06;--hd:#151b23}'
         'body{background:var(--bg);color:var(--fg);font:14px/1.45 system-ui,sans-serif;margin:0;padding:16px}'
         'h1{font-size:20px;margin:0 0 4px}.sub{color:var(--mu);margin:0 0 12px}.wrap{overflow:auto;max-width:100%;border:1px solid var(--bd);border-radius:8px}'
         'table{border-collapse:collapse;font-size:12.5px}th,td{border:1px solid var(--bd);padding:4px 6px;vertical-align:top}'
         'thead th{background:var(--hd);position:sticky;top:0}td.ten{min-width:220px;position:sticky;left:0;background:var(--bg)}'
         'td.o{text-align:center;min-width:44px;font-weight:600;cursor:help}td.x{background:var(--x)}td.xs{background:var(--xs)}'
         'th.c{writing-mode:vertical-rl;transform:rotate(180deg);white-space:nowrap;max-height:200px;font-weight:500}</style>',
         f'<h1>Phân quyền trải phẳng – {e(M.D.get("phan_he", {}).get("ten", ""))}</h1>',
         f'<p class="sub">{"Bản nháp để rà soát (BA chưa xác nhận). " if nhap else ""}Khung lấy từ sheet «{e(K["sheet"])}»; ô tính từ thiết kế. '
         f'x = có quyền ({so.get("x", 0)} ô), x* = có quyền kèm điều kiện ({so.get("x*", 0)} ô). Rê chuột vào ô để xem vai trò, phạm vi, điều kiện.</p>',
         '<div class="wrap"><table><thead><tr><th rowspan="2">Tài nguyên</th><th rowspan="2">Hành động</th>']
    P += [f'<th colspan="{len(cs)}">{e(n)}</th>' for n, cs in nh.items()]
    P.append("</tr><tr>" + "".join(f'<th class="c" title="{e(", ".join(M.CV.get(c, {}).get("vai_tro", [])))}">{e(tieu_de[c])}</th>' for cs in nh.values() for c in cs) + "</tr></thead><tbody>")
    for d, hang in bang:
        P.append(f'<tr><td>{e(M.TN[d["tn"]]["ten"])}</td><td class="ten">{e(d["ten"])} <small>({e(d["key"])})</small></td>')
        for cs in nh.values():
            for c in cs:
                v, mo = hang[c]
                P.append(f'<td class="o {"x" if v == "x" else "xs" if v else ""}" title="{e(chr(10).join(mo))}">{e(v)}</td>')
        P.append("</tr>")
    P.append("</tbody></table></div>")
    P.append('<h2 style="font-size:16px">Cột – vai trò</h2><div class="wrap"><table><thead><tr><th>Chức danh</th><th>Vai trò thiết kế</th><th>Căn cứ ghép</th></tr></thead><tbody>')
    for c in COTD:
        x = M.CV.get(c, {})
        P.append(f'<tr><td>{e(tieu_de[c])}</td><td>{e(", ".join(M.VT[k]["ten"] for k in x.get("vai_tro", [])) or "—")}</td><td>{e(x.get("ly_do"))}</td></tr>')
    P.append("</tbody></table></div>")
    open(os.path.join(thu, "ma_tran.html"), "w", encoding="utf-8").write("\n".join(P) + "\n")
    L = [f"# Phân quyền trải phẳng – {M.D.get('phan_he', {}).get('ten', '')}{' (BẢN NHÁP)' if nhap else ''}", "",
         "| Tài nguyên | Hành động | " + " | ".join(tieu_de[c].split("\n")[0][:24] for c in COTD) + " |",
         "|---|---|" + "---|" * len(COTD)]
    for d, hang in bang:
        L.append(f"| {M.TN[d['tn']]['ten']} | {d['ten']} | " + " | ".join(hang[c][0] for c in COTD) + " |")
    open(os.path.join(thu, "ma_tran.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
    print(f"Đã ghi {p}, ma_tran.html, ma_tran.md: {len(bang)} dòng × {len(COTD)} cột · x {so.get('x', 0)} · x* {so.get('x*', 0)}"
          + (f" · xoá cột {', '.join(CH['bo_cot'])}" if CH.get("bo_cot") else ""))
    khong = [c for c in COTD if not M.CV.get(c, {}).get("vai_tro")]
    if khong:
        print("  cột không có vai trò (để trống cả cột):", ", ".join(khong))
    vt_dung = {v for x in M.CV.values() for v in x.get("vai_tro", [])}
    thieu = [k for k in M.VT if k not in vt_dung and any(q["vai_tro"] == k for qs in M.Q.values() for q in qs)]
    if thieu:
        print("  vai trò thiết kế có quyền nhưng không cột nào ghép:", ", ".join(thieu))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("lenh", choices=["khung", "lap"])
    ap.add_argument("a")
    ap.add_argument("b", nargs="?")
    ap.add_argument("--nhap", action="store_true")
    ap.add_argument("--khong-ghi-chu", action="store_true")
    x = ap.parse_args()
    if x.lenh == "khung":
        lenh_khung(x.a, x.b)
    else:
        lap(x.a, x.nhap, x.khong_ghi_chu)


if __name__ == "__main__":
    main()
