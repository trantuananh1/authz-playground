# -*- coding: utf-8 -*-
"""Mẫu Excel đầu vào chung cho mọi phân hệ: BA khai vai trò, tài nguyên, hành động và ai được làm gì.

  python -I mau_excel.py tao <tệp_ra.xlsx>                 sinh mẫu trống (danh sách chọn lấy từ bo_key.py)
  python -I mau_excel.py doc <thu_muc_lam_viec> <tệp.xlsx>  đọc mẫu đã điền → dac_ta.json, giao_dich_excel.json

Sheet của mẫu: «Hướng dẫn», «1. Phân hệ», «2. Vai trò», «3. Tài nguyên», «4. Hành động», «5. Phân quyền», «6. Ngoại lệ»,
«Danh mục» (ẩn, nguồn danh sách chọn). Dữ liệu bắt đầu từ dòng DONG_DAU; dòng TIEU_DE ghi tên cột, dòng MA ghi mã cột (ẩn).

Lệnh `doc`:
- Kiểm tra: ô bắt buộc, mã trùng, mã sai dạng (tự sinh mã từ tên nếu trống), tham chiếu tới vai trò / tài nguyên / hành động
  chưa khai, giá trị ngoài danh sách chọn, ô phân quyền khác «x». Lỗi ghi kèm địa chỉ ô.
- Ghi phần cấu trúc của dac_ta.json (phan_he, tai_nguyen, vai_tro, ánh xạ tên gọi tác nhân, phạm vi ngoại lệ) và đánh dấu
  `tu_excel`. Chạy lại sau khi BA sửa Excel chỉ thay phần `tu_excel`; phần AI viết (loc_vai_tro, bo_sung, dieu_kien, cau_hoi,
  ke_thua, mo_rong) giữ nguyên. AI bổ sung trường cho tài nguyên / vai trò qua `mo_rong.tai_nguyen.<key>` / `mo_rong.vai_tro.<key>`.
- Ghi giao_dich_excel.json: mỗi ô «x» một giao dịch đã xác định sẵn vai trò, tài nguyên, hành động (lap_thiet_ke.py dùng thẳng).
- Ghi bao_cao_excel.md; thoát mã 1 nếu có lỗi.
"""
import collections, json, os, re, shutil, sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bo_key as BK  # noqa: E402

TIEU_DE, MA, DONG_DAU = 3, 4, 5
SO_DONG = 400
SH = {"hd": "Hướng dẫn", "ph": "1. Phân hệ", "vt": "2. Vai trò", "tn": "3. Tài nguyên", "hdg": "4. Hành động",
      "pq": "5. Phân quyền", "nl": "6. Ngoại lệ", "dm": "Danh mục"}

# vị trí trên cây đơn vị: tên lấy đúng từ tài liệu «Kiến thức nghiệp vụ CTĐ-CTCT» (luồng triển khai nhiệm vụ bước 1–12,
# lưu ý thẩm quyền có / không có con dấu, bảng vai trò công tác quần chúng); cách gán theo cay-don-vi-ctd-ctct.md CD-01…CD-05.
# Không thêm vị trí mà tài liệu không nêu; vai trò ngoài cây ghi nơi gán ở cột «Gán trên».
VI_TRI = collections.OrderedDict([
    ("Chủ nhiệm, Phó Chủ nhiệm Tổng cục Chính trị", dict(loai="toan_he_thong", gan=None, nhom="lanh_dao", tq="phe_duyet")),
    ("Thủ trưởng Cục, Ban, Viện trực thuộc TCCT", dict(loai="toan_he_thong", gan=None, nhom="lanh_dao", tq="phe_duyet")),
    ("Trợ lý Cục, Ban, Viện trực thuộc TCCT", dict(loai="toan_he_thong", gan=None, nhom="chuyen_vien", tq="xu_ly")),
    ("Thủ trưởng đơn vị", dict(loai="theo_don_vi", gan="don_vi", nhom="lanh_dao", tq="phe_duyet")),
    ("Thủ trưởng cơ quan chính trị (Chủ nhiệm, Phó Chủ nhiệm chính trị)", dict(loai="theo_don_vi", gan="don_vi", nhom="lanh_dao", tq="phe_duyet")),
    ("Thủ trưởng phòng, ban thuộc cơ quan chính trị", dict(loai="theo_don_vi", gan="don_vi", nhom="lanh_dao", tq="de_nghi")),
    ("Trợ lý, nhân viên", dict(loai="theo_don_vi", gan="don_vi", nhom="chuyen_vien", tq="xu_ly")),
    ("Chức danh trong tổ chức quần chúng (Đoàn thanh niên, Hội phụ nữ, Công đoàn)", dict(loai="theo_don_vi", gan="cay_to_chuc", nhom=None, tq=None)),
    ("Không có trong cây đơn vị (ghi nơi gán ở cột «Gán trên»)", dict(loai=None, gan="theo_cot", nhom=None, tq=None)),
])
# 5 cấp của cây CTĐ-CTCT, chép theo sơ đồ cấp trong tài liệu «Kiến thức nghiệp vụ CTĐ-CTCT». Cột «Cấp» nhận cả cách ghi của tài liệu phân hệ.
CAP = ["Cấp 1 — Tổng cục Chính trị",
       "Cấp 2 — Đơn vị trực thuộc BQP",
       "Cấp 3 — Cục đầu mối trực thuộc BQP; Vùng; Lữ đoàn; Sư đoàn, BCH QS tỉnh, thành phố trực thuộc TW (và tương đương)",
       "Cấp 4 — Trung đoàn và cấp tương đương",
       "Cấp 5 — Tiểu đoàn, đại đội và tương đương (phân đội)"]
LOAI_TN = collections.OrderedDict([
    ("Dữ liệu nghiệp vụ", "du_lieu"), ("Danh mục dùng chung", "du_lieu"), ("Hồ sơ người", "du_lieu"),
    ("Thư mục, tệp", "tep"), ("Cây tổ chức quần chúng", "cay"), ("Cơ sở trực thuộc (trường, điểm…)", "du_lieu"),
    ("Dữ liệu hệ thống (tài khoản, cấu hình)", "he_thong")])
THUOC_VE = ["Đơn vị", "Tổ chức quần chúng", "Tài nguyên cha (ghi mã ở cột bên)", "Không thuộc đơn vị nào (dùng chung)"]
LUONG = ["Không gửi duyệt", "Duyệt theo cây đơn vị", "Duyệt theo cây tổ chức quần chúng", "Duyệt trên cả hai cây"]
PV_NL = collections.OrderedDict([
    ("Toàn hệ thống (toàn quân)", "toan_he_thong"), ("Đơn vị mình", "don_vi_minh"),
    ("Đơn vị mình và mọi cấp dưới", "don_vi_minh_va_cap_duoi"), ("Đơn vị mình và cấp dưới trực tiếp", "don_vi_minh_va_cap_duoi_truc_tiep"),
    ("Hồ sơ đang chờ đơn vị mình duyệt", "cap_duyet"), ("Bản ghi do chính mình lập", "do_minh_lap"), ("Bản ghi được giao cho mình", "duoc_giao")])
TEN_PV = {"toan_he_thong": "Toàn quân", "don_vi_minh": "Đơn vị mình", "don_vi_minh_va_cap_duoi": "Đơn vị mình và mọi đơn vị cấp dưới",
          "don_vi_minh_va_cap_duoi_truc_tiep": "Đơn vị mình và cấp dưới trực tiếp", "cap_duyet": "Hồ sơ đang chờ đơn vị mình xem xét, phê duyệt",
          "do_minh_lap": "Bản ghi do chính mình lập", "duoc_giao": "Bản ghi được giao cho mình"}
# cột hành động có sẵn ở sheet «5. Phân quyền» (gợi ý; không gộp, trừ ngoại lệ: xem danh sách + xem chi tiết = «xem»; tìm kiếm là cột riêng).
# Khi đọc, mọi cột mang mã của một hành động khai ở sheet «4. Hành động» đều là cột hành động: BA thêm cột cho key riêng của tài liệu.
COT_HD = ["xem", "tim_kiem", "xem_nhay_cam", "them_moi", "chinh_sua", "xoa", "gui_duyet", "phe_duyet", "tu_choi",
          "tiep_nhan", "tu_choi_tiep_nhan", "khoa", "mo_khoa", "xuat", "nhap", "giao_xu_ly"]
CO_KHONG = ["Có", "Không"]

# cột của từng sheet: (mã cột, tiêu đề, độ rộng, bắt buộc, danh sách chọn)
COT = {
    "vt": [("ma", "Mã vai trò", 26, False, None), ("ten", "Tên vai trò *", 34, True, None), ("vi_tri", "Vị trí trên cây đơn vị *", 40, True, "vi_tri"),
           ("cap", "Cấp", 28, False, "cap"), ("gan_tren", "Gán trên: mã cây tổ chức quần chúng / mã tài nguyên / don_vi / toan_he_thong (khi vị trí cần)", 30, False, None),
           ("mang", "Mảng phụ trách (nếu chỉ phụ trách một phần)", 28, False, None), ("ten_khac", "Tên gọi khác trong tài liệu (cách nhau dấu ;)", 40, False, None),
           ("mo_ta", "Mô tả chức trách", 46, False, None), ("nguon", "Nguồn (mục, trang tài liệu)", 22, False, None)],
    "tn": [("ma", "Mã tài nguyên", 26, False, None), ("ten", "Tên tài nguyên *", 34, True, None), ("mang", "Mảng nghiệp vụ *", 22, True, None),
           ("loai", "Loại", 30, False, "loai_tn"), ("thuoc_ve", "Thuộc về *", 30, True, "thuoc_ve"), ("cha", "Mã tài nguyên cha / cây tổ chức", 26, False, None),
           ("luong", "Luồng duyệt", 30, False, "luong"), ("nhay_cam", "Thông tin nhạy cảm (mô tả; trống = không có)", 36, False, None),
           ("mo_ta", "Mô tả", 40, False, None), ("nguon", "Nguồn (mục, trang tài liệu)", 22, False, None)],
    "hdg": [("ma", "Mã hành động *", 24, True, None), ("ten", "Tên hành động *", 30, True, None), ("muc", "Mức *", 14, True, "muc"),
            ("nhom", "Nhóm *", 14, True, "nhom"), ("loai", "Loại (Gợi ý / Tài liệu)", 14, False, None), ("y_nghia", "Ý nghĩa; cách viết cùng nghĩa (chỉ để phân loại, không đổi key)", 70, False, None)],
    "pq": [("tai_nguyen", "Tài nguyên (mã) *", 26, True, "ds_tn"), ("vai_tro", "Vai trò (mã) *", 26, True, "ds_vt")]
          + [(k, BK.HANH_DONG[k][0], 10, False, "x") for k in COT_HD]
          + [("khac", "Hành động khác (mã, cách nhau dấu phẩy)", 30, False, None), ("nguon", "Nguồn (mục, trang tài liệu)", 22, False, None),
             ("ghi_chu", "Ghi chú", 30, False, None)],
    "nl": [("vai_tro", "Vai trò (mã) *", 26, True, "ds_vt"), ("tai_nguyen", "Tài nguyên (mã) *", 26, True, "ds_tn"),
           ("hanh_dong", "Hành động (mã, cách nhau dấu phẩy; trống = mọi hành động trên bản ghi)", 34, False, None),
           ("pham_vi", "Phạm vi (bản ghi nào) theo tài liệu", 34, False, "pv_nl"), ("dieu_kien", "Điều kiện thêm (viết bằng lời)", 40, False, None),
           ("ly_do", "Lý do / nguồn *", 40, True, None)],
}
PHAN_HE = [("ten", "Tên phân hệ *"), ("ma", "Mã phân hệ"), ("co_quan", "Cơ quan chủ quản (Cục, Ban thuộc TCCT)"),
           ("nganh", "Thuộc ngành CTĐ-CTCT (Có / Không)"), ("mo_ta", "Mô tả ngắn"), ("tai_lieu", "Tài liệu nghiệp vụ căn cứ"),
           ("nguoi_lap", "Người lập"), ("ngay", "Ngày lập")]

HUONG_DAN = [
    ("Mẫu đầu vào thiết kế phân quyền — dùng chung cho mọi phân hệ", "h1"),
    ("BA khai: AI LÀ AI (vai trò), DỮ LIỆU GÌ (tài nguyên), AI ĐƯỢC LÀM GÌ (đánh «x»), TRÊN BẢN GHI NÀO và KHI NÀO (sheet 6). "
     "Skill CHỈ THEO NGUỒN: không tự thêm quyền xem đi kèm, không tự đặt phạm vi, không tự thêm ràng buộc trạng thái hay «không tự duyệt». "
     "Chỗ nào chưa khai, skill hỏi lại BA (câu hỏi «Thiếu nguồn»).", ""),
    ("Thứ tự điền", "h2"),
    ("1. Phân hệ: tên, cơ quan chủ quản.", ""),
    ("2. Vai trò: mỗi dòng một chức trách. Chọn «Vị trí trên cây đơn vị» để skill biết vai trò gán ở đâu và có thẩm quyền gì "
     "(thủ trưởng có con dấu thì phê duyệt; chỉ huy phòng, ban không có con dấu thì xem xét, đề nghị; trợ lý soạn, xử lý). "
     "Thủ trưởng đơn vị và thủ trưởng cơ quan chính trị là hai vai trò khác nhau. Cán bộ cơ quan chính trị chọn vị trí theo chức trách, "
     "không cần ghi phòng nào: phạm vi tính từ đơn vị mà cơ quan chính trị trực thuộc.", ""),
    ("3. Tài nguyên: mỗi loại dữ liệu người dùng thao tác (không tách theo trạng thái, không tách danh sách / chi tiết). "
     "«Thuộc về» cho biết bản ghi thuộc đơn vị, thuộc tổ chức quần chúng hay thuộc một tài nguyên cha. "
     "Không khai cây đơn vị: cây đơn vị lấy từ Cổng. Cây tổ chức quần chúng (đoàn, hội, công đoàn) thì khai, loại «Cây tổ chức quần chúng».", ""),
    ("4. Hành động: có sẵn danh sách gợi ý. Tài liệu đặt key riêng (xem_ds, tim_kiem…) thì thêm dòng đúng key đó, Loại «Tài liệu». "
     "Mỗi thao tác một hành động, không gộp: xem danh sách, xem chi tiết, tìm kiếm là ba hành động; khoá và mở khoá là hai.", ""),
    ("5. Phân quyền: mỗi dòng một cặp tài nguyên × vai trò; đánh «x» vào cột hành động vai trò đó được làm. "
     "Hành động của tài liệu thêm thành cột mới (ghi mã ở dòng mã cột) hoặc ghi ở cột «Hành động khác». Chỉ đánh điều tài liệu nghiệp vụ nêu, kể cả quyền xem "
     "(được sửa, duyệt không tự được xem: tài liệu nêu xem thì đánh «x» cột xem).", ""),
    ("6. Phạm vi, điều kiện: với mỗi quyền trên bản ghi (xem, sửa, duyệt…), ghi phạm vi tài liệu nêu (đơn vị mình, đơn vị mình và cấp dưới, "
     "hồ sơ chờ mình duyệt, do mình lập…) và điều kiện (trạng thái, đợt đang mở…), kèm vị trí tài liệu ở cột «Lý do / nguồn». "
     "Tài liệu không nêu thì để trống: skill không tự chọn mà hỏi lại BA. Vai trò toàn hệ thống (cơ quan chủ quản thuộc TCCT) không cần ghi phạm vi.", ""),
    ("Bóc tách từ tài liệu", "h2"),
    ("Chỉ ghi điều tài liệu nêu, mỗi dòng ghi vị trí trong tài liệu ở cột «Nguồn». Ô tài liệu không nêu thì để trống và ghi câu hỏi ở cột «Mô tả» / «Ghi chú»; "
     "không tự chọn thay. Tác nhân nhóm (ví dụ «Lãnh đạo, chỉ huy, trợ lý … các cấp») giữ nguyên tên nếu tài liệu không nói gồm những ai. "
     "Hai nguồn trong tài liệu nói khác nhau thì ghi cả hai và tô vàng dòng đó.", ""),
    ("Quy ước", "h2"),
    ("Cột có dấu * là bắt buộc. Mã để trống thì skill tự sinh từ tên (chữ thường không dấu, nối bằng _). "
     "Ô phân quyền chỉ nhận «x». Không đổi tên sheet, không xoá dòng tiêu đề và dòng mã cột (dòng 4, đã ẩn).", ""),
]


def ten_chon():
    return {"vi_tri": list(VI_TRI), "cap": CAP, "loai_tn": list(LOAI_TN), "thuoc_ve": THUOC_VE, "luong": LUONG,
            "pv_nl": list(PV_NL), "muc": list(BK.MUC), "nhom": list(BK.NHOM), "co_khong": CO_KHONG, "x": ["x"]}


# ======================================================================= tạo mẫu
def tao(ra):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.utils import get_column_letter as L

    wb = Workbook()
    nen = PatternFill("solid", fgColor="1F4E79"); chu = Font(bold=True, color="FFFFFF")
    nen2 = PatternFill("solid", fgColor="DDEBF7"); vien = Border(*(Side(style="thin", color="B4C6E7"),) * 4)
    boc = Alignment(wrap_text=True, vertical="top")

    ws = wb.active; ws.title = SH["hd"]
    ws.column_dimensions["A"].width = 130
    for i, (t, kieu) in enumerate(HUONG_DAN, 1):
        c = ws.cell(i, 1, t); c.alignment = boc
        c.font = Font(bold=True, size=14, color="1F4E79") if kieu == "h1" else Font(bold=True, size=12, color="1F4E79") if kieu == "h2" else Font(size=11)

    # danh mục (ẩn)
    dm = wb.create_sheet(SH["dm"])
    vung = {}
    for j, (k, ds) in enumerate(ten_chon().items(), 1):
        dm.cell(1, j, k).font = Font(bold=True)
        for i, v in enumerate(ds, 2):
            dm.cell(i, j, v)
        vung[k] = f"'{SH['dm']}'!${L(j)}$2:${L(j)}${len(ds) + 1}"
    dm.sheet_state = "hidden"
    vung["ds_vt"] = f"'{SH['vt']}'!$A${DONG_DAU}:$A${DONG_DAU + SO_DONG}"
    vung["ds_tn"] = f"'{SH['tn']}'!$A${DONG_DAU}:$A${DONG_DAU + SO_DONG}"

    def bang(key, ghi_chu):
        ws = wb.create_sheet(SH[key])
        cot = COT[key]
        ws.cell(1, 1, SH[key]).font = Font(bold=True, size=13, color="1F4E79")
        ws.cell(2, 1, ghi_chu).font = Font(italic=True, color="595959")
        for j, (ma, td, w, bb, ds) in enumerate(cot, 1):
            c = ws.cell(TIEU_DE, j, td); c.fill = nen; c.font = chu; c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center"); c.border = vien
            ws.cell(MA, j, ma)
            ws.column_dimensions[L(j)].width = w
            if ds:
                dv = DataValidation(type="list", formula1=f"={vung[ds]}", allow_blank=True, showErrorMessage=ds not in ("ds_vt", "ds_tn", "cap"))
                dv.error, dv.errorTitle = "Chọn giá trị trong danh sách", "Giá trị không hợp lệ"
                ws.add_data_validation(dv); dv.add(f"{L(j)}{DONG_DAU}:{L(j)}{DONG_DAU + SO_DONG}")
        ws.row_dimensions[TIEU_DE].height = 48
        ws.row_dimensions[MA].hidden = True
        ws.freeze_panes = ws.cell(DONG_DAU, 3 if key == "pq" else 2)
        for i in range(DONG_DAU, DONG_DAU + 30):
            for j in range(1, len(cot) + 1):
                ws.cell(i, j).border = vien
                if key == "pq" and 3 <= j < 3 + len(COT_HD):
                    ws.cell(i, j).alignment = Alignment(horizontal="center")
        return ws

    ph = wb.create_sheet(SH["ph"], 1)
    ph.cell(1, 1, SH["ph"]).font = Font(bold=True, size=13, color="1F4E79")
    ph.column_dimensions["A"].width = 44; ph.column_dimensions["B"].width = 70; ph.column_dimensions["C"].width = 14
    for i, (ma, td) in enumerate(PHAN_HE, DONG_DAU - 2):
        ph.cell(i, 1, td).fill = nen2; ph.cell(i, 1).font = Font(bold=True); ph.cell(i, 2).border = vien; ph.cell(i, 3, ma).font = Font(color="BFBFBF")
    dv = DataValidation(type="list", formula1=f"={vung['co_khong']}", allow_blank=True)
    ph.add_data_validation(dv); dv.add(f"B{DONG_DAU - 2 + 3}")

    bang("vt", "Mỗi dòng một vai trò (chức trách). Mã để trống thì skill tự sinh từ tên.")
    bang("tn", "Mỗi dòng một loại dữ liệu người dùng thao tác. Không khai cây đơn vị (lấy từ Cổng).")
    w = bang("hdg", "Danh sách gợi ý (Loại = Gợi ý). Tài liệu đặt key riêng thì thêm dòng đúng key của tài liệu (Loại = Tài liệu). Mỗi thao tác một dòng, không gộp; key gồm nhiều thao tác (khoá/mở khoá) thì tách.")
    for i, (k, (t, m, n, bd)) in enumerate(BK.HANH_DONG.items(), DONG_DAU):
        for j, v in enumerate([k, t, m, n, "Gợi ý", "Cùng nghĩa: " + ", ".join(bd)], 1):
            c = w.cell(i, j, v); c.fill = nen2; c.border = vien
    bang("pq", "Mỗi dòng một cặp tài nguyên × vai trò; đánh «x» vào hành động vai trò được làm. Chỉ đánh điều tài liệu nêu.")
    bang("nl", "Phạm vi, điều kiện theo tài liệu cho quyền trên bản ghi. Tài liệu không nêu thì để trống; skill hỏi lại BA, không tự chọn.")
    order = [SH[k] for k in ("hd", "ph", "vt", "tn", "hdg", "pq", "nl", "dm")]
    wb._sheets = [wb[n] for n in order]
    wb.save(ra)
    print(f"{ra}: mẫu trống, {len(VI_TRI)} vị trí, {len(BK.HANH_DONG)} hành động chuẩn, {len(COT_HD)} cột hành động ở sheet «{SH['pq']}»")


# ======================================================================= đọc mẫu
def doc_mau(wd, tep):
    from openpyxl import load_workbook
    from openpyxl.utils import get_column_letter as L
    wb = load_workbook(tep, data_only=True)
    LOI, CB, VIEC = [], [], []
    cf = lambda v: re.sub(r"\s+", " ", str(v)).strip() if v is not None else ""
    for k in ("ph", "vt", "tn", "hdg", "pq"):
        if SH[k] not in wb.sheetnames:
            sys.exit(f"Thiếu sheet «{SH[k]}». Dùng mẫu sinh bởi: mau_excel.py tao")

    def dong(key):
        ws = wb[SH[key]]
        ma_cot = {cf(ws.cell(MA, j).value): j for j in range(1, ws.max_column + 1) if cf(ws.cell(MA, j).value)}
        out = []
        for i in range(DONG_DAU, ws.max_row + 1):
            r = {m: cf(ws.cell(i, j).value) for m, j in ma_cot.items()}
            if any(r.values()):
                r["_o"] = lambda m, i=i: f"{SH[key]}!{L(ma_cot[m])}{i}"
                r["_dong"] = i
                out.append(r)
        return out, ma_cot

    def ma_hop_le(r, key, nhan):
        m = r.get("ma") or ""
        if not m:
            m = BK.khong_dau(r.get("ten", ""))
            if m:
                CB.append(f"{r['_o']('ma')}: mã {nhan} trống, tự sinh «{m}» từ tên")
        elif not re.fullmatch(r"[a-z][a-z0-9_]*", m):
            m2 = BK.khong_dau(m)
            CB.append(f"{r['_o']('ma')}: mã «{m}» không đúng dạng chữ thường không dấu, dùng «{m2}»")
            m = m2
        return m

    def bat_buoc(r, key):
        for ma, td, _, bb, _ in COT[key]:
            if bb and not r.get(ma):
                LOI.append(f"{r['_o'](ma)}: thiếu «{td.rstrip(' *')}»")

    def trong_ds(r, ma, ds, nhan):
        v = r.get(ma)
        if v and v not in ds:
            LOI.append(f"{r['_o'](ma)}: «{v}» không có trong danh sách {nhan}")
            return None
        return v

    # ---- phân hệ
    ws = wb[SH["ph"]]
    PH = {cf(ws.cell(i, 3).value): cf(ws.cell(i, 2).value) for i in range(1, ws.max_row + 1) if cf(ws.cell(i, 3).value)}
    if not PH.get("ten"):
        LOI.append(f"{SH['ph']}!B{DONG_DAU - 2}: thiếu tên phân hệ")

    # ---- tài nguyên
    TN = collections.OrderedDict()
    dtn, _ = dong("tn")
    for r in dtn:
        bat_buoc(r, "tn")
        k = ma_hop_le(r, "tn", "tài nguyên")
        if not k:
            continue
        if k == BK.CAY_CONG["key"]:
            LOI.append(f"{r['_o']('ma')}: «{k}» là cây đơn vị lấy từ Cổng, không khai trong mẫu"); continue
        if k in TN:
            LOI.append(f"{r['_o']('ma')}: mã tài nguyên «{k}» trùng dòng {TN[k]['_dong']}"); continue
        loai = trong_ds(r, "loai", LOAI_TN, "Loại")
        trong_ds(r, "thuoc_ve", THUOC_VE, "Thuộc về"); trong_ds(r, "luong", LUONG, "Luồng duyệt")
        if not r.get("loai"):
            CB.append(f"{r['_o']('loai')}: chưa ghi loại tài nguyên, coi là «Dữ liệu nghiệp vụ»")
        TN[k] = dict(r, key=k, loai_k=LOAI_TN.get(loai, "du_lieu"))
    cay_tc = [k for k, t in TN.items() if t["loai_k"] == "cay"]

    def cay_cua(t, o):
        c = t.get("cha")
        if c:
            if c not in TN or TN[c]["loai_k"] != "cay":
                LOI.append(f"{o}: «{c}» không phải tài nguyên loại «Cây tổ chức quần chúng»"); return None
            return c
        if len(cay_tc) == 1:
            return cay_tc[0]
        LOI.append(f"{o}: " + ("chưa khai cây tổ chức quần chúng" if not cay_tc else f"có {len(cay_tc)} cây tổ chức, ghi mã cây ở cột «Mã tài nguyên cha / cây tổ chức»"))
        return None

    # ---- vai trò
    VT = collections.OrderedDict()
    dvt, _ = dong("vt")
    for r in dvt:
        bat_buoc(r, "vt")
        k = ma_hop_le(r, "vt", "vai trò")
        if not k:
            continue
        if k in VT:
            LOI.append(f"{r['_o']('ma')}: mã vai trò «{k}» trùng dòng {VT[k]['_dong']}"); continue
        vi = trong_ds(r, "vi_tri", VI_TRI, "Vị trí trên cây đơn vị")
        if r.get("cap") and r["cap"] not in CAP:
            CB.append(f"{r['_o']('cap')}: cấp «{r['cap']}» ghi theo tài liệu phân hệ, không thuộc 5 cấp của cây CTĐ-CTCT; giữ nguyên làm nhãn")
        VT[k] = dict(r, key=k)
        if not vi:
            continue
        cfg = VI_TRI[vi]
        gan = None
        if cfg["gan"] == "don_vi":
            gan = BK.CAY_CONG["key"]
        elif cfg["gan"] == "cay_to_chuc":
            g = r.get("gan_tren")
            if g and (g not in TN or TN[g]["loai_k"] != "cay"):
                LOI.append(f"{r['_o']('gan_tren')}: «{g}» không phải cây tổ chức quần chúng đã khai")
            gan = g if g in TN else (cay_tc[0] if len(cay_tc) == 1 and not g else None)
            if not gan and not g:
                LOI.append(f"{r['_o']('gan_tren')}: vị trí tổ chức quần chúng cần mã cây tổ chức" + (" (chưa khai cây nào)" if not cay_tc else ""))
        elif cfg["gan"] == "theo_cot":
            g = (r.get("gan_tren") or "").strip()
            cfg = dict(cfg)
            if BK.khong_dau(g) in ("toan_he_thong", "toan_quan"):
                cfg["loai"] = "toan_he_thong"
            elif g in TN or g == BK.CAY_CONG["key"]:
                cfg["loai"], gan = "theo_don_vi", g
            else:
                cfg["loai"] = "theo_don_vi"
                LOI.append(f"{r['_o']('gan_tren')}: «{VT[k]['ten']}» không có trong cây đơn vị; cần ghi nơi gán (don_vi, toan_he_thong hoặc mã tài nguyên)"
                           + (f" — «{g}» chưa khai" if g else " — tài liệu chưa nêu, hỏi BA"))
        VT[k]["_cfg"], VT[k]["_gan"] = cfg, gan

    # ---- hành động
    HDG = collections.OrderedDict((k, {"key": k, "ten": v[0], "muc": v[1], "nhom": v[2], "chuan": True}) for k, v in BK.HANH_DONG.items())
    dhd, _ = dong("hdg")
    for r in dhd:
        if r.get("loai") in ("Gợi ý", "Chuẩn") or (r.get("ma") in BK.HANH_DONG and not r.get("loai")):
            continue
        bat_buoc(r, "hdg")
        k = ma_hop_le(r, "hdg", "hành động")
        if not k:
            continue
        # key tài liệu giữ nguyên, không quy về key khác (không gộp); loại chuẩn chỉ để áp quy định kế thừa.
        # Ngoại lệ: xem_ds, xem_ct (xem danh sách, xem chi tiết) là hành động «xem» có sẵn.
        if BK.hanh_dong(k) != k:
            CB.append(f"{r['_o']('ma')}: «{k}» gộp vào hành động «{BK.hanh_dong(k)}» (ngoại lệ: xem danh sách và xem chi tiết là một quyền xem)"); continue
        trong_ds(r, "muc", BK.MUC, "Mức"); trong_ds(r, "nhom", BK.NHOM, "Nhóm")
        ten0, muc0, nhom0, lo = BK.thong_tin_hanh_dong(k)
        HDG[k] = {"key": k, "ten": r.get("ten") or ten0, "muc": r.get("muc") or muc0, "nhom": r.get("nhom") or nhom0, "chuan": False,
                  "loai": lo, "y_nghia": r.get("y_nghia", "")}
        if BK.tach_gop(k):
            LOI.append(f"{r['_o']('ma')}: «{k}» gộp nhiều thao tác ({', '.join(BK.tach_gop(k))}); tách mỗi thao tác một dòng")
        elif not lo and not r.get("nhom"):
            CB.append(f"{r['_o']('ma')}: «{k}» chưa phân loại được (xem, sửa, duyệt…); ghi «Nhóm», «Mức» để skill áp quy định kế thừa")

    def hanh_dong_cua(v, o):
        k = BK.hanh_dong(v)
        if k in HDG:
            if k != v:
                CB.append(f"{o}: «{v}» quy về hành động chuẩn «{k}»")
            return k
        LOI.append(f"{o}: hành động «{v}» chưa khai ở sheet «{SH['hdg']}»")
        return None

    # ---- phân quyền
    GD, cap_da = [], {}
    dpq, ma_cot = dong("pq")
    ws_pq = wb[SH["pq"]]
    for r in dpq:
        bat_buoc(r, "pq")
        rk, vk = r.get("tai_nguyen"), r.get("vai_tro")
        if rk and rk not in TN:
            LOI.append(f"{r['_o']('tai_nguyen')}: tài nguyên «{rk}» chưa khai ở sheet «{SH['tn']}»"); continue
        if vk and vk not in VT:
            LOI.append(f"{r['_o']('vai_tro')}: vai trò «{vk}» chưa khai ở sheet «{SH['vt']}»"); continue
        if not (rk and vk):
            continue
        if (rk, vk) in cap_da:
            CB.append(f"{SH['pq']} dòng {r['_dong']}: cặp {rk} × {vk} đã có ở dòng {cap_da[(rk, vk)]}; gộp hai dòng")
        cap_da.setdefault((rk, vk), r["_dong"])
        acts = []
        for m in [m for m in ma_cot if BK.hanh_dong(m) in HDG and m not in ("tai_nguyen", "vai_tro", "khac", "nguon", "ghi_chu")]:   # mọi cột mang mã hành động đã khai
            a, v = BK.hanh_dong(m), r.get(m)
            if not v:
                continue
            if v.lower() != "x":
                LOI.append(f"{r['_o'](m)}: ô phân quyền chỉ nhận «x», đang ghi «{v}»"); continue
            if all(x[0] != a for x in acts):
                acts.append((a, r["_o"](m)))
        for v in re.split(r"[,;]", r.get("khac") or ""):
            if cf(v):
                k = hanh_dong_cua(cf(v), r["_o"]("khac"))
                if k:
                    acts.append((k, r["_o"]("khac")))
        if not acts:
            CB.append(f"{SH['pq']} dòng {r['_dong']}: {rk} × {vk} chưa đánh hành động nào")
        for a, o in acts:
            GD.append({"id": f"XL{len(GD) + 1}", "nguon": "X1", "vt": o, "muc": TN[rk].get("mang", ""), "usecase": TN[rk]["ten"],
                       "ten": f"{HDG[a]['ten']} «{TN[rk]['ten']}»", "mo_ta": " · ".join(x for x in (r.get("nguon"), r.get("ghi_chu")) if x),
                       "tac_nhan": [VT[vk]["ten"]], "vai_tro": [vk], "tai_nguyen": rk, "hanh_dong": a})

    # hành động mỗi tài nguyên = mọi hành động được đánh cho nó + hành động mà quy tắc bổ sung có nguồn (bo_sung) nhắc tới
    p_dt = os.path.join(wd, "dac_ta.json")
    S = json.load(open(p_dt, encoding="utf-8")) if os.path.exists(p_dt) else {}
    hd_tn = collections.defaultdict(list)
    for g in GD:
        if g["hanh_dong"] not in hd_tn[g["tai_nguyen"]]:
            hd_tn[g["tai_nguyen"]].append(g["hanh_dong"])
    for r in (S.get("quy_tac") or {}).get("bo_sung", []):
        for rk in ([r["tai_nguyen"]] if isinstance(r.get("tai_nguyen"), str) else r.get("tai_nguyen") or []):
            for a in r.get("hanh_dong", []):
                a = BK.hanh_dong(a)
                if rk in TN and a in HDG and a not in hd_tn[rk]:
                    hd_tn[rk].append(a)
                    CB.append(f"«{TN[rk]['ten']}»: thêm hành động «{a}» vì quy tắc bổ sung {r.get('id', '')} nhắc tới (Excel chưa đánh cho vai trò nào)")

    # ---- ngoại lệ
    QPV, PVD = [], collections.OrderedDict()
    if SH["nl"] in wb.sheetnames:
        dnl, _ = dong("nl")
        for r in dnl:
            bat_buoc(r, "nl")
            vk, rk = r.get("vai_tro"), r.get("tai_nguyen")
            if vk not in VT or rk not in TN:
                LOI.append(f"{SH['nl']} dòng {r['_dong']}: vai trò hoặc tài nguyên chưa khai ({vk} × {rk})"); continue
            acts = [hanh_dong_cua(cf(x), r["_o"]("hanh_dong")) for x in re.split(r"[,;]", r.get("hanh_dong") or "") if cf(x)]
            acts = [x for x in acts if x]
            pv = trong_ds(r, "pham_vi", PV_NL, "Phạm vi")
            if pv:
                kieu = PV_NL[pv]
                if kieu != "toan_he_thong":
                    PVD.setdefault(kieu, {"key": kieu, "ten": TEN_PV[kieu], "kieu": kieu, "tu_excel": True,
                                          **({"bieu_thuc": [{"trai": "resource.nguoi_lap" if kieu == "do_minh_lap" else "resource.nguoi_duoc_giao",
                                                             "phep": "bang", "phai": "user.ma_nguoi_dung"}]} if kieu in ("do_minh_lap", "duoc_giao") else {})})
                QPV.append({"id": f"XL-PV-{len(QPV) + 1}", "vai_tro": vk, "tai_nguyen": rk, "hanh_dong": acts or "@ban_ghi", "pham_vi": kieu,
                            "uu_tien": 10, "ly_do": f"{r['_o']('pham_vi')}: {r.get('ly_do', '')}", "nguyen_tac": [], "tin_cay": "cao", "tu_excel": True,
                            **({"ap_dung_toan_he_thong": True} if VT[vk].get("_cfg", {}).get("loai") == "toan_he_thong" else {})})
            if r.get("dieu_kien"):
                VIEC.append(f"{r['_o']('dieu_kien')}: viết điều kiện «{r['dieu_kien']}» cho {vk} × {rk}"
                            + (f" ({', '.join(acts)})" if acts else "") + f" vào dac_ta.json (dieu_kien + quy_tac.dieu_kien). Lý do: {r.get('ly_do', '')}")

    # ---- dựng phần cấu trúc của đặc tả
    tn_out = []
    for k, t in TN.items():
        if not hd_tn.get(k) and t["loai_k"] != "cay":
            CB.append(f"{SH['tn']} dòng {t['_dong']}: tài nguyên «{k}» chưa có quyền nào ở sheet «{SH['pq']}»")
        qh = []
        tv = t.get("thuoc_ve")
        if t["loai_k"] == "cay":
            qh += [{"key": "cap_tren", "toi": k, "y_nghia": "Tổ chức cấp trên"}, {"key": "don_vi_quan_ly", "toi": BK.CAY_CONG["key"], "y_nghia": "Đơn vị quản lý tổ chức"}]
        elif tv == "Đơn vị":
            qh.append({"key": "thuoc_don_vi", "toi": BK.CAY_CONG["key"], "y_nghia": "Đơn vị sở hữu bản ghi"})
        elif tv == "Tổ chức quần chúng":
            c = cay_cua(t, t["_o"]("cha"))
            if c:
                qh.append({"key": "thuoc_to_chuc", "toi": c, "y_nghia": f"{TN[c]['ten']} sở hữu bản ghi"})
        elif tv and tv.startswith("Tài nguyên cha"):
            c = t.get("cha")
            if c not in TN:
                LOI.append(f"{t['_o']('cha')}: «Thuộc về» là tài nguyên cha nhưng mã cha «{c}» chưa khai")
            else:
                qh.append({"key": f"thuoc_{c}", "toi": c, "y_nghia": f"Thuộc {TN[c]['ten']}"})
        if tv and tv.startswith("Không thuộc") and t["loai_k"] != "cay":
            # dữ liệu dùng chung (danh mục, hệ thống): vai trò được cấp làm việc trên toàn bộ (M-05, NT-24)
            QPV.append({"id": f"XL-PV-{len(QPV) + 1}", "vai_tro": "*", "tai_nguyen": k, "hanh_dong": "*", "pham_vi": "toan_he_thong", "uu_tien": 5,
                        "ly_do": f"{t['_o']('thuoc_ve')}: dữ liệu dùng chung, không thuộc đơn vị nào", "nguyen_tac": ["NT-24"], "tin_cay": "cao", "tu_excel": True})
        lg = t.get("luong") or "Không gửi duyệt"
        if lg in ("Duyệt theo cây đơn vị", "Duyệt trên cả hai cây"):
            qh.append({"key": "cap_duyet", "toi": BK.CAY_CONG["key"], "y_nghia": "Đơn vị đang phải xem xét, duyệt"})
        if lg in ("Duyệt theo cây tổ chức quần chúng", "Duyệt trên cả hai cây"):
            c = cay_cua(t, t["_o"]("luong"))
            if c:
                qh.append({"key": "cap_duyet_to_chuc", "toi": c, "y_nghia": "Tổ chức đang phải xem xét, duyệt"})
        hd = []
        for a in hd_tn.get(k, []):
            h = HDG[a]
            if h["chuan"]:
                hd.append({"key": a, "nhay_cam": True} if BK.loai_hanh_dong(a) == "xem_nhay_cam" else a)
            else:
                hd.append({"key": a, "ten": h["ten"], "muc": h["muc"], "nhom": h["nhom"]})
        if t.get("nhay_cam") and not any(BK.loai_hanh_dong(x) == "xem_nhay_cam" for x in hd_tn.get(k, [])):
            CB.append(f"{t['_o']('nhay_cam')}: «{t['ten']}» có thông tin nhạy cảm nhưng chưa vai trò nào được đánh «Xem thông tin nhạy cảm»")
        tn = {"key": k, "ten": t["ten"], "mo_ta": " ".join(x for x in (t.get("mo_ta"), f"Nhạy cảm: {t['nhay_cam']}." if t.get("nhay_cam") else "") if x),
              "loai": t["loai_k"], "mang": t.get("mang") or "Khác", "quan_he": qh, "hanh_dong": hd, "tu_excel": True,
              "co_so": {"loai": "tai_lieu", "nguon": [{"vt": t["_o"]("ten"), "trich": t.get("nguon") or t["ten"]}], "ly_do": "Khai trong mẫu Excel", "tin_cay": "cao"}}
        if lg != "Không gửi duyệt" and any(BK.loai_hanh_dong(x) in ("gui_duyet",) + BK.LOAI_DUYET for x in hd_tn.get(k, [])):
            tn["vong_doi"] = dict(BK.VONG_DOI_MAC_DINH)
        if lg != "Không gửi duyệt" and not any(BK.loai_hanh_dong(x) in ("gui_duyet",) + BK.LOAI_DUYET for x in hd_tn.get(k, [])):
            CB.append(f"{t['_o']('luong')}: «{t['ten']}» khai luồng duyệt nhưng chưa ai được gửi duyệt / phê duyệt / trả lại")
        if lg == "Không gửi duyệt" and any(BK.loai_hanh_dong(x) == "phe_duyet" for x in hd_tn.get(k, [])):
            CB.append(f"{t['_o']('luong')}: «{t['ten']}» có quyền phê duyệt nhưng «Luồng duyệt» chưa chọn cây duyệt; phạm vi duyệt sẽ theo đơn vị mình")
        tn_out.append(tn)
    vt_out, tac_out = [], []
    for k, v in VT.items():
        cfg = v.get("_cfg") or {}
        o = {"key": k, "ten": v["ten"], "mo_ta": v.get("mo_ta", ""), "loai_pham_vi": cfg.get("loai", "theo_don_vi"),
             "cap": v.get("cap") or "", "vi_tri": v.get("vi_tri", ""), "tu_excel": True,
             "co_so": {"loai": "tai_lieu", "nguon": [{"vt": v["_o"]("ten"), "trich": v.get("nguon") or v["ten"]}], "ly_do": "Khai trong mẫu Excel", "tin_cay": "cao"}}
        if cfg.get("loai") == "theo_don_vi" and v.get("_gan"):
            o["gan_tren"] = v["_gan"]
        if cfg.get("nhom"):
            o["nhom"] = cfg["nhom"]
        if cfg.get("tq"):
            o["tham_quyen"] = cfg["tq"]
        if v.get("mang"):
            o["mang_phu_trach"] = v["mang"]
            VIEC.append(f"{v['_o']('mang')}: «{v['ten']}» chỉ phụ trách «{v['mang']}» — cân nhắc quy tắc loc_vai_tro (NT-10) cho các mảng khác")
        vt_out.append(o)
        for ten in [v["ten"]] + [cf(x) for x in (v.get("ten_khac") or "").split(";") if cf(x)]:
            tac_out.append({"id": f"XL-TA-{len(tac_out) + 1}", "tac_nhan": ten, "vai_tro": [k], "ly_do": "Tên gọi khai trong mẫu Excel",
                            "nguyen_tac": ["CD-10"] if ten != v["ten"] else [], "tin_cay": "cao", "tu_excel": True})

    # ---- ghi
    os.makedirs(wd, exist_ok=True)
    MR = S.get("mo_rong") or {}

    def tron(o, mr):
        for k2, v2 in (mr or {}).items():
            if k2 == "quan_he":
                o["quan_he"] = o.get("quan_he", []) + [x for x in v2 if x["key"] not in {y["key"] for y in o.get("quan_he", [])}]
            else:
                o[k2] = v2
        return o
    tn_out = [tron(t, (MR.get("tai_nguyen") or {}).get(t["key"])) for t in tn_out]
    vt_out = [tron(v, (MR.get("vai_tro") or {}).get(v["key"])) for v in vt_out]
    S["phan_he"] = {"ten": PH.get("ten", ""), "ma": PH.get("ma", ""), "mo_ta": PH.get("mo_ta", ""), "co_quan_chu_quan": PH.get("co_quan", ""),
                    "nganh_ctd_ctct": PH.get("nganh", "Có") != "Không", "tu_excel": True}
    S.setdefault("nguyen_tac_ap_dung", [])
    giu = lambda ds: [x for x in ds if not x.get("tu_excel")]
    S["tai_nguyen"] = tn_out + giu(S.get("tai_nguyen", []))
    S["vai_tro"] = vt_out + giu(S.get("vai_tro", []))
    S["pham_vi"] = list(PVD.values()) + [p for p in giu(S.get("pham_vi", [])) if p["key"] not in PVD]
    S.setdefault("dieu_kien", [])
    Q = S.setdefault("quy_tac", {})
    for nhom in ("bo_qua", "tai_nguyen", "hanh_dong", "theo_cap_duyet", "loc_vai_tro", "bo_sung", "dieu_kien"):
        Q.setdefault(nhom, [])
    Q["tac_nhan"] = tac_out + giu(Q.get("tac_nhan", []))
    Q["pham_vi"] = QPV + giu(Q.get("pham_vi", []))
    S.setdefault("ke_thua", {"khong_ap_dung": []})
    S.setdefault("cau_hoi", [])
    S.setdefault("mo_rong", {"tai_nguyen": {}, "vai_tro": {}})
    with open(p_dt, "w", encoding="utf-8") as f:
        json.dump(S, f, ensure_ascii=False, indent=1)
    with open(os.path.join(wd, "giao_dich_excel.json"), "w", encoding="utf-8") as f:
        json.dump(GD, f, ensure_ascii=False, indent=1)
    p_ng = os.path.join(wd, "nguon.json")
    NG = [n for n in (json.load(open(p_ng, encoding="utf-8")) if os.path.exists(p_ng) else []) if n["id"] != "X1"]
    NG.append({"id": "X1", "tep": os.path.abspath(tep), "ten": os.path.basename(tep), "loai": "excel_mau"})
    with open(p_ng, "w", encoding="utf-8") as f:
        json.dump(NG, f, ensure_ascii=False, indent=1)

    B = [f"# Đọc mẫu Excel — {PH.get('ten', '')}", "", f"Tệp: `{os.path.basename(tep)}`", "",
         f"- {len(TN)} tài nguyên ({len(cay_tc)} cây tổ chức quần chúng), {len(VT)} vai trò, {sum(1 for h in HDG.values() if not h['chuan'])} hành động riêng.",
         f"- {len(GD)} ô «x» → {len(GD)} giao dịch (`giao_dich_excel.json`); {len(QPV)} ngoại lệ phạm vi.",
         f"- **{len(LOI)} lỗi**, {len(CB)} cảnh báo, {len(VIEC)} việc AI cần làm.", ""]
    for tieu, ds in (("Lỗi (sửa trong Excel rồi đọc lại)", LOI), ("Cảnh báo", CB), ("Việc AI cần làm trong dac_ta.json", VIEC)):
        if ds:
            B += [f"## {tieu}", ""] + [f"- {x}" for x in ds] + [""]
    B += ["## Vai trò", "", "| Mã | Tên | Vị trí | Gán tại | Thẩm quyền |", "|---|---|---|---|---|"]
    for v in vt_out:
        B.append(f"| `{v['key']}` | {v['ten']} | {v.get('vi_tri', '')} | {v.get('gan_tren') or 'toàn hệ thống'} | {v.get('tham_quyen', '—')} |")
    with open(os.path.join(wd, "bao_cao_excel.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(B) + "\n")
    print(f"{len(TN)} tài nguyên · {len(VT)} vai trò · {len(GD)} quyền đánh «x» · {len(QPV)} ngoại lệ phạm vi → dac_ta.json, giao_dich_excel.json, bao_cao_excel.md")
    print(f"{len(LOI)} lỗi · {len(CB)} cảnh báo · {len(VIEC)} việc AI cần làm")
    for x in LOI[:15]:
        print("  LỖI", x)
    for x in VIEC[:10]:
        print("  VIỆC", x)
    return 1 if LOI else 0


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "tao":
        tao(sys.argv[2])
    elif len(sys.argv) >= 4 and sys.argv[1] == "doc":
        sys.exit(doc_mau(sys.argv[2], sys.argv[3]))
    else:
        sys.exit(__doc__)
