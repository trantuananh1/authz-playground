# -*- coding: utf-8 -*-
"""Điều kiện ABAC dùng chung cho xuat_json.py, xuat_dsl.py, du_lieu_thu.py, so_sanh_thu.py.

JSON import (khuôn condition_sets): mệnh đề {"left": "resource.x" | "user.x", "operator": …, "right": …}
  EQUALS, NOT_EQUALS, EQUALS_REF (so với user.…) có trong file JSON mẫu; IN, CONTAINS cần hệ đích xác nhận.
DSL playground (cú pháp đã thử trên playground): resource.x == "v", resource.x != "v", resource.x == user.y,
  resource.x in ["a", "b"], user.x contains "v"; các mệnh đề nối bằng `and`, các nhóm nối bằng `or`.
"""
import json
import re

OP_DAC_TA = {"bang": "EQUALS", "khac": "NOT_EQUALS", "thuoc": "IN", "chua": "CONTAINS"}
OP_DSL = {"EQUALS": "==", "EQUALS_REF": "==", "NOT_EQUALS": "!=", "NOT_EQUALS_REF": "!=", "IN": "in", "CONTAINS": "contains"}
OP_MAU = {"EQUALS", "EQUALS_REF", "NOT_EQUALS"}          # toán tử có trong file JSON mẫu của hệ đích
# NOT_EQUALS_REF (so khác với user.…): có trong mã sinh Rego của VAuthz (PolicyGenerateService), chưa có trong file JSON mẫu
VAI_TRO_CHUNG = "user.vai_tro_chung"                     # thuộc tính người dùng: danh sách key vai trò toàn hệ thống đang giữ


def la_tham_chieu(v):
    return isinstance(v, str) and v.startswith("user.")


def json_menh_de(trai, phep, phai):
    if la_tham_chieu(phai) and phep in ("bang", "khac"):
        op = "EQUALS_REF" if phep == "bang" else "NOT_EQUALS_REF"
    else:
        op = OP_DAC_TA.get(phep, phep)
    return {"left": trai, "operator": op, "right": phai}


def json_dieu_kien(menh_de):
    """Một nhóm mệnh đề (VÀ) → khối conditions của condition_sets."""
    return {"all_of": None, "any_of": [{"all_of": list(menh_de), "any_of": None}]}


def gia_tri_dsl(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, list):
        return "[" + ", ".join(gia_tri_dsl(x) for x in v) + "]"
    return '"' + str(v).replace("\\", "\\\\").replace('"', "'") + '"'


def dsl_menh_de(m):
    op = m["operator"]
    phai = m["right"] if op in ("EQUALS_REF", "NOT_EQUALS_REF") else gia_tri_dsl(m["right"])
    return f"{m['left']} {OP_DSL.get(op, op)} {phai}"


def dsl_dieu_kien(cond):
    """Khối conditions (JSON) → biểu thức sau `where` của DSL."""
    nhom = [" and ".join(dsl_menh_de(m) for m in g.get("all_of") or []) for g in cond.get("any_of") or []]
    if cond.get("all_of"):
        nhom = [" and ".join(dsl_menh_de(m) for m in cond["all_of"])] + nhom
    return " or ".join(x for x in nhom if x)


_MD = re.compile(r'(user|resource)\.(\w+)\s+(==|!=|in|contains)\s+(user\.\w+|\[[^\]]*\]|"(?:[^"\\]|\\.)*"|true|false|-?\d+(?:\.\d+)?)')


def doc_dieu_kien(txt):
    """Biểu thức sau `where` → [[(bên, thuộc tính, phép, giá trị | ("ref", thuộc tính user)), …] (VÀ), …] (HOẶC)."""
    out = []
    for nhom in re.split(r"\s+or\s+", txt.strip()):
        md = []
        for ben, at, op, ph in _MD.findall(nhom):
            v = ("ref", ph[5:]) if ph.startswith("user.") else json.loads(ph)
            md.append((ben, at, op, v))
        if md:
            out.append(md)
    return out


def _bang(a, b):
    if a is None or b is None:
        return False
    return a == b or str(a).lower() == str(b).lower()


def danh_gia(bt, ua, ra):
    """Đánh giá biểu thức đã đọc với thuộc tính người dùng ua và thuộc tính bản ghi ra."""
    def ok(ben, at, op, v):
        trai = (ra if ben == "resource" else ua).get(at)
        phai = ua.get(v[1]) if isinstance(v, tuple) else v
        if op == "==":
            return _bang(trai, phai)
        if op == "!=":
            return trai is not None and not _bang(trai, phai)
        if op == "in":
            return any(_bang(trai, x) for x in (phai or []))
        if op == "contains":
            return isinstance(trai, list) and any(_bang(x, phai) for x in trai)
        return False
    return any(all(ok(*m) for m in nhom) for nhom in bt)
