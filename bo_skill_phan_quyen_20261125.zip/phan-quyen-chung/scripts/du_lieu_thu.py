# -*- coding: utf-8 -*-
"""Sinh tệp DSL thử để xem trực quan trên playground (tab Matrix): mỗi vai trò một người dùng.

  python -I du_lieu_thu.py <thu_muc_lam_viec>

Đọc các tệp DSL chính thức (playground_theo_mang/*.dsl, do xuat_dsl.py ghi) và thiet_ke_phan_quyen.json, ghi
playground_thu/<mảng>_thu.dsl = DSL chính thức + DỮ LIỆU THỬ:
- cây đơn vị thử theo tên cấp thật của cây CTĐ-CTCT (references/cay-don-vi-ctd-ctct.md): mỗi đơn vị có nhánh nội bộ
  (cơ quan chính trị → phòng) và nhánh cấp dưới; thêm một đơn vị ngang cấp để thấy chỗ KHÔNG được;
- mỗi vai trò thiết kế một người dùng (key = key vai trò), gán tại nút ghi trong du_lieu_thu.json;
- mỗi tài nguyên dữ liệu một hồ sơ thử tại từng nút ghi ở «ban_ghi_tai» (mọi quan hệ tới cây trỏ về nút đó),
  thuộc tính ABAC (người lập, người được giao…) đặt bằng người dùng của vai trò ghi ở «nguoi_lap».
Không có assert: tệp chỉ để xem ma trận ai được làm gì trên hồ sơ nào. Tệp DSL chính thức không đổi.

du_lieu_thu.json (tự tạo lần đầu, AI sửa theo `cap` của từng vai trò rồi chạy lại):
  {"cay": [[key, tên, cấp trên], ...], "ban_ghi_tai": [nút, ...],
   "gan": {"<vai trò>": [nút, ...]}, "nguoi_lap": {"<tài nguyên>": "<vai trò>"},
   "ho_so": {"<tài nguyên>": [{"key": "hs_…", "mo_ta": "…", "quan_he": {"<quan hệ>": "<nút>"}, "thuoc_tinh": {…}}]}}
«ho_so» (tuỳ chọn) khai từng hồ sơ thử theo tình huống nghiệp vụ (ai lập, đang chờ ai duyệt, nơi tiếp nhận…), đặt key
theo tình huống; không khai thì mỗi nút ở «ban_ghi_tai» một hồ sơ hs_cua_<nút>, mọi quan hệ tới cây trỏ về nút đó.
Cây, người dùng, hồ sơ là dữ liệu thử do AI dựng, không phải nguồn.
"""
import glob, json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dieu_kien as DKM  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
T = "@mac_dinh"
CAY_MAC_DINH = [
    ["tcct", "Tổng cục Chính trị", None],
    ["quan_khu_1", "Quân khu 1", "tcct"],
    ["cuc_ct_qk1", "Cục Chính trị Quân khu 1", "quan_khu_1"],
    ["phong_qk1", "Một phòng của Cục Chính trị Quân khu 1", "cuc_ct_qk1"],
    ["su_doan_346", "Sư đoàn 346", "quan_khu_1"],
    ["trung_doan_246", "Trung đoàn 246", "su_doan_346"],
    ["quan_khu_2", "Quân khu 2 (ngang cấp Quân khu 1)", "tcct"],
]
BAN_GHI_MAC_DINH = ["quan_khu_1", "cuc_ct_qk1", "phong_qk1", "su_doan_346", "trung_doan_246", "quan_khu_2"]
LAP = ("them_moi", "tao_moi", "gui_duyet", "gui_phe_duyet", "import", "nhap")


def doc_dsl(txt):
    res, cur = {}, None
    vai_chung, us_vt = set(), set()   # us_vt: vai trò toàn hệ thống cấp qua userset «người giữ vai trò» (user.vai_tro_chung)
    abac_attr = {}   # tài nguyên → [thuộc tính bản ghi so với user]
    for raw in txt.splitlines():
        line = raw.split("//", 1)[0].rstrip()
        m = re.match(r'\s*resource (\w+) "[^"]*" \{', line)
        if m:
            cur = m.group(1); res[cur] = {"rel": {}, "roles": [], "attrs": {}}; continue
        if cur and line.strip() == "}":
            cur = None; continue
        s = line.strip()
        if cur:
            if s.startswith("relations "):
                res[cur]["rel"] = dict(re.findall(r"(\w+): (\w+)", s))
            elif s.startswith("attributes "):
                res[cur]["attrs"] = dict(re.findall(r"(\w+): (\w+)", s))
            elif s.startswith("role "):
                res[cur]["roles"].append(re.match(r"role (\w+)", s).group(1))
            continue
        m = re.match(r'role (\w+) "', s)
        if m:
            vai_chung.add(m.group(1))
        m = re.match(r"userset nguoi_giu_(\w+) ", s)
        if m:
            us_vt.add(m.group(1))
        m = re.match(r"resourceset \w+ \"[^\"]*\" on (\w+) where (.*)$", s)
        if m:
            for at in re.findall(r"resource\.(\w+) == user\.\w+", m.group(2)):
                abac_attr.setdefault(m.group(1), []).append(at)
    return res, vai_chung, abac_attr, us_vt


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    lv = sys.argv[1]
    D = json.load(open(os.path.join(lv, "thiet_ke_phan_quyen.json"), encoding="utf-8"))
    VT = {v["key"]: v for v in D["vai_tro"]}
    TN = {t["key"]: t for t in D["tai_nguyen"]}
    # cây nơi gán vai trò: cây Cổng «don_vi», hoặc cây riêng của phân hệ (ví dụ cây Viện kiểm sát, CD-09)
    cay_dv = "don_vi" if "don_vi" in TN else next((k for k, t in TN.items() if t.get("loai") == "cay"
                                                   and any(r.get("toi") == k for r in t.get("quan_he", []))), "don_vi")
    BG = json.load(open(os.path.join(lv, "vai_tro_tren_ban_ghi.json"), encoding="utf-8")) if os.path.exists(os.path.join(lv, "vai_tro_tren_ban_ghi.json")) else []
    VT_BG = {m["vai_tro"] for m in BG}
    p_qh = os.path.join(lv, "quan_he_theo_dieu_kien.json")
    QH = json.load(open(p_qh, encoding="utf-8")) if os.path.exists(p_qh) else []   # ghi quan hệ theo điều kiện khi hồ sơ thử thoả
    QH_TEN = {(m["tai_nguyen"], m["quan_he"]) for m in QH}

    def qh_them(rk, quan_he, tt):
        """Quan hệ theo điều kiện mà hồ sơ thử (thuộc tính tt) thoả: {quan hệ: nút của quan hệ gốc}."""
        return {m["quan_he"]: quan_he[m["quan_he_goc"]] for m in QH if m["tai_nguyen"] == rk and m["quan_he_goc"] in quan_he
                and DKM.danh_gia(DKM.doc_dieu_kien(m["dieu_kien_dsl"]), {}, tt)}
    p_ch = os.path.join(lv, "du_lieu_thu.json")
    if os.path.exists(p_ch):
        CH = json.load(open(p_ch, encoding="utf-8"))
    else:
        CH = {}
    CH.setdefault("cay", CAY_MAC_DINH)
    CH.setdefault("ban_ghi_tai", BAN_GHI_MAC_DINH)
    gan = CH.setdefault("gan", {})
    for k, v in VT.items():
        if v.get("loai_pham_vi") == "theo_don_vi" and k not in gan:
            gan[k] = ["quan_khu_1"]
    lap = CH.setdefault("nguoi_lap", {})
    for rk in TN:
        if rk in lap:
            continue
        ung = [q["vai_tro"] for q in D["quyen"] if q["tai_nguyen"] == rk and q["trang_thai"] != "bo" and q["hanh_dong"] in LAP
               and VT.get(q["vai_tro"], {}).get("loai_pham_vi") == "theo_don_vi"]
        if ung:
            lap[rk] = ung[0]
    json.dump(CH, open(p_ch, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    ten_nut = {k: t for k, t, _ in CH["cay"]}
    nut_ok = set(ten_nut)
    os.makedirs(os.path.join(lv, "playground_thu"), exist_ok=True)
    tep = sorted(glob.glob(os.path.join(lv, "playground_theo_mang", "*.dsl"))) or [os.path.join(lv, "playground.dsl")]
    for p in tep:
        goc = open(p, encoding="utf-8").read()
        res, vai_chung, abac_attr, us_vt = doc_dsl(goc)
        L = ["", "// ================= DỮ LIỆU THỬ (AI dựng để xem trực quan, không phải nguồn) =================",
             "// Mỗi vai trò thiết kế một người dùng (key = key vai trò). Tab Matrix: chọn người dùng để xem được làm gì trên hồ sơ nào.",
             ("// Cây đơn vị theo tên cấp thật của cây CTĐ-CTCT; Quân khu 2 là đơn vị ngang cấp để thấy chỗ không được." if cay_dv == "don_vi"
              else f"// Cây thử «{TN.get(cay_dv, {}).get('ten', cay_dv)}» theo du_lieu_thu.json; có một đơn vị ngang cấp để thấy chỗ không được."),
             f"// Nơi gán vai trò, nơi đặt hồ sơ, người lập: {os.path.basename(p_ch)}.", ""]
        nguoi = []
        for k, v in VT.items():
            lp = v.get("loai_pham_vi")
            if lp == "theo_ban_ghi":
                continue
            if lp == "toan_he_thong" and k not in vai_chung and k not in us_vt:
                continue
            if lp == "theo_don_vi" and not any(k in r["roles"] for r in res.values()) and k not in vai_chung                     and f"{k}__quyen_chung" not in vai_chung and k not in VT_BG:
                continue
            noi = "toàn hệ thống" if lp == "toan_he_thong" else ", ".join(ten_nut.get(n, n) for n in gan.get(k, []))
            nguoi.append(k)
            L.append(f'user {k} "{v["ten"]} — {noi}" {{ trang_thai: "DANG_HOAT_DONG", ma_nguoi_dung: "{k}"'
                     + (f', vai_tro_chung: ["{k}"]' if k in us_vt else "") + " }")
        if not nguoi:
            continue
        co_cay = cay_dv in res
        if co_cay:
            L += ["", "// ---- cây đơn vị thử ----"] + [f"instance {cay_dv}:{k} {T}  // {t}" for k, t, _ in CH["cay"]]
            L += [f"relate {cay_dv}:{cha} cap_tren {cay_dv}:{k}" for k, _, cha in CH["cay"] if cha]
        # cây riêng khác (tổ chức quần chúng…): một nút mỗi cây, gắn vào Quân khu 1 nếu có quan hệ tới đơn vị
        cay_khac = {rk: f"{rk}_1" for rk in res if TN.get(rk, {}).get("loai") == "cay" and rk != cay_dv}
        for rk, inst in cay_khac.items():
            L.append(f"instance {rk}:{inst} {T}  // {TN[rk]['ten']} (thử)")
            for rel, toi in res[rk]["rel"].items():
                if toi == cay_dv and co_cay:
                    L.append(f"relate {cay_dv}:quan_khu_1 {rel} {rk}:{inst}")
        L += ["", "// ---- hồ sơ thử ----"]
        ban_ghi, TT, QHS = {}, {}, {}   # QHS: (tài nguyên, hồ sơ) → quan hệ gốc tới cây (để gán vai trò trên bản ghi theo phạm vi)
        for rk, r in res.items():
            if rk == cay_dv or rk in cay_khac:
                continue
            u_lap = lap.get(rk) if lap.get(rk) in nguoi else (nguoi[0] if nguoi else None)
            khai = (CH.get("ho_so") or {}).get(rk)
            if khai:   # hồ sơ thử khai theo tình huống: {"key", "mo_ta", "quan_he": {quan hệ: nút}, "thuoc_tinh": {...}}
                for h in khai:
                    k = h["key"]
                    ban_ghi[(rk, h["key"])] = k
                    at = {a: u_lap for a in abac_attr.get(rk, []) if u_lap}
                    at.update(h.get("thuoc_tinh") or {})
                    TT[(rk, k)] = at
                    tt = (" { " + ", ".join(f"{a}: " + ("true" if v is True else "false" if v is False else f'"{v}"') for a, v in at.items()) + " }") if at else ""
                    L.append(f"instance {rk}:{k} {T}{tt}  // {h.get('mo_ta', '')}")
                    qh = {q: n for q, n in (h.get("quan_he") or {}).items() if (rk, q) not in QH_TEN}
                    QHS[(rk, k)] = dict(qh)
                    qh.update(qh_them(rk, qh, at))
                    for rel, n in qh.items():
                        if r["rel"].get(rel) == cay_dv and n in nut_ok:
                            L.append(f"relate {cay_dv}:{n} {rel} {rk}:{k}")
                continue
            nut = [n for n in CH["ban_ghi_tai"] if n in nut_ok] if any(t == cay_dv for t in r["rel"].values()) else [None]
            for n in nut:
                k = f"hs_cua_{n}" if n else f"{rk}_1"
                ban_ghi[(rk, n)] = k
                at = {a: u_lap for a in abac_attr.get(rk, []) if u_lap}
                TT[(rk, k)] = at
                tt = (" { " + ", ".join(f'{a}: "{v}"' for a, v in at.items()) + " }") if at else ""
                L.append(f"instance {rk}:{k} {T}{tt}  // {TN.get(rk, {}).get('ten', rk)} — " + (f"thuộc {ten_nut[n]}" if n else "không gắn đơn vị"))
                goc_qh = {rel: n for rel, toi in r["rel"].items() if toi == cay_dv and n and (rk, rel) not in QH_TEN}
                QHS[(rk, k)] = dict(goc_qh)
                for rel, nn in {**goc_qh, **qh_them(rk, goc_qh, at)}.items():
                    L.append(f"relate {cay_dv}:{nn} {rel} {rk}:{k}")
                for rel, toi in r["rel"].items():
                    if toi in cay_khac:
                        L.append(f"relate {toi}:{cay_khac[toi]} {rel} {rk}:{k}")
        for (rk, n), k in list(ban_ghi.items()):   # tài nguyên con trỏ tới bản ghi cha cùng nút
            for rel, toi in res[rk]["rel"].items():
                if toi in res and toi != cay_dv and toi not in cay_khac and (toi, n) in ban_ghi:
                    L.append(f"relate {toi}:{ban_ghi[(toi, n)]} {rel} {rk}:{k}")
        L += ["", "// ---- gán vai trò ----"]
        for k in nguoi:
            v = VT[k]
            if v.get("loai_pham_vi") == "toan_he_thong":
                if k in vai_chung:
                    L.append(f"assign {k} {k} {T}")
                continue
            if k in vai_chung:
                L.append(f"assign {k} {k} {T}")
            if f"{k}__quyen_chung" in vai_chung:
                L.append(f"assign {k} {k}__quyen_chung {T}")
            cay_gan = v.get("gan_tren") or cay_dv
            for n in gan.get(k, []):
                if cay_gan == cay_dv and n in nut_ok and k in res.get(cay_dv, {}).get("roles", []):
                    L.append(f"assign {k} {k} on {cay_dv}:{n}  // {ten_nut[n]}")
                elif cay_gan in cay_khac:
                    L.append(f"assign {k} {k} on {cay_gan}:{cay_khac[cay_gan]}")
        # vai trò trên bản ghi (xuat_json.py ghi vai_tro_tren_ban_ghi.json): ứng dụng gán cho người lập / người được giao giữ vai trò gốc
        # có điều kiện (dieu_kien_dsl): chỉ gán khi hồ sơ thoả; «theo_pham_vi»: gán cho người giữ vai trò gốc theo phạm vi và thoả điều kiện với chính mình
        cha = {k: c for k, _, c in CH["cay"]}
        def to_tien(n):
            out = []
            while cha.get(n):
                n = cha[n]; out.append(n)
            return out
        for m in BG:
            vk = m["vai_tro"]
            ua = {"ma_nguoi_dung": vk, "trang_thai": "DANG_HOAT_DONG", "vai_tro_chung": [vk] if vk in us_vt else []}
            for (rk, k), at in TT.items():
                if rk != m["tai_nguyen"] or vk not in nguoi or m["vai_tro_ban_ghi"] not in res.get(rk, {}).get("roles", {}):
                    continue
                if m.get("dieu_kien_dsl") and not DKM.danh_gia(DKM.doc_dieu_kien(m["dieu_kien_dsl"]), ua, at):
                    continue
                if m.get("cach_gan") == "theo_pham_vi":
                    n = k if m["quan_he"] == "(chinh_ban_ghi)" else QHS.get((rk, k), {}).get(m["quan_he"])
                    kp = m.get("kieu_pham_vi")
                    noi = set(gan.get(vk, []))
                    ok = n is not None and (n in noi or (kp == "don_vi_minh_va_cap_duoi" and noi & set(to_tien(n)))
                                            or (kp == "don_vi_minh_va_cap_duoi_truc_tiep" and cha.get(n) in noi))
                    if ok:
                        L.append(f"assign {vk} {m['vai_tro_ban_ghi']} on {rk}:{k}  // có vai trò {vk} theo phạm vi qua {m['quan_he']} và thoả: {m.get('ten_dieu_kien', '')}")
                elif str(at.get(m["thuoc_tinh"])) == vk:
                    L.append(f"assign {vk} {m['vai_tro_ban_ghi']} on {rk}:{k}  // {m['thuoc_tinh']} là mình, giữ vai trò {vk}"
                             + (f", hồ sơ thoả: {m.get('ten_dieu_kien', '')}" if m.get("dieu_kien_dsl") else ""))
        ra = os.path.join(lv, "playground_thu", os.path.basename(p)[:-4] + "_thu.dsl")
        open(ra, "w", encoding="utf-8").write(goc.rstrip("\n") + "\n" + "\n".join(L) + "\n")
        print(f"{os.path.relpath(ra, lv)}: {len(nguoi)} người dùng, {len(ban_ghi)} hồ sơ thử")
        if (us_vt or QH) and not CH.get("ho_so"):
            print("  lưu ý: có quyền theo điều kiện hồ sơ (permit nguoi_giu_…, quan hệ theo điều kiện); hồ sơ thử mặc định không có thuộc tính nên các quyền này không hiện"
                  " trên Matrix — khai «ho_so» kèm «thuoc_tinh» (trạng thái, loại…) trong du_lieu_thu.json rồi chạy lại")
    print(f"cấu hình: {os.path.relpath(p_ch, lv)} (sửa nơi gán từng vai trò theo `cap` rồi chạy lại)")


if __name__ == "__main__":
    main()
