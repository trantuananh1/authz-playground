# -*- coding: utf-8 -*-
"""Xuất thiết kế phân quyền thành JSON import (khuôn resources / roles / condition_sets / … của hệ phân quyền).

  python -I xuat_json.py <thu_muc_lam_viec> [--chi-da-duyet]

Đọc thiet_ke_phan_quyen.json và ra_soat.json (nếu có). Quyền hiệu lực = «theo tài liệu» + «theo quy định kế thừa» + «AI thêm»,
đảo theo ý kiến «không đồng ý» của người rà soát (ý kiến trên từng quyền, hoặc trên câu mô tả chứa quyền đó).
--chi-da-duyet: chỉ xuất đề xuất AI đã được đồng ý. Ý kiến không còn mục tương ứng được báo, không bị bỏ qua im lặng.
Ghi: phan_quyen_import.json, vai_tro_tren_ban_ghi.json, bao_cao_xuat_json.md

Điều kiện: khuôn import chỉ có luật CẤP THÊM quyền (condition_set_rules = userset × resourceset), không có luật thu hẹp.
- Quyền toàn hệ thống có điều kiện chỉ xét thuộc tính bản ghi → luật cấp thêm: userset «người giữ vai trò»
  (user.vai_tro_chung chứa key vai trò) × resourceset «hồ sơ thoả điều kiện»; không gán thẳng cho vai trò chung.
- Quyền «người lập / người được giao» (vai trò theo bản ghi) có điều kiện → gộp điều kiện vào resourceset của luật.
- Quyền cấp qua vai trò trên tài nguyên có điều kiện chỉ so thuộc tính bản ghi với hằng → QUAN HỆ THEO ĐIỀU KIỆN
  <quan hệ>__<điều kiện> (derive không đặt được điều kiện): ứng dụng chỉ ghi quan hệ khi hồ sơ thoả, gỡ khi hết thoả;
  ghi quan_he_theo_dieu_kien.json.
- Còn lại (điều kiện chưa áp được): KHÔNG CẤP, không nới rộng; báo cáo nêu lý do và cách sửa thiết kế.
- Giá trị trong điều kiện đổi sang giá trị CSDL theo `gia_tri` của thuộc tính (ví dụ DU_THAO → DRAFT).
"""
import argparse, collections, json, os, re, sys, unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bo_key as BK  # noqa: E402
import dieu_kien as DKM  # noqa: E402
import ha_muc as HM  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
OD = collections.OrderedDict
KIEU = {"chuoi": "string", "so": "number", "ngay": "time", "dung_sai": "bool", "danh_sach": "array"}


def doc(p, md=None):
    if not os.path.exists(p):
        return md
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("thu_muc"); ap.add_argument("--chi-da-duyet", action="store_true")
    a = ap.parse_args()
    D = doc(os.path.join(a.thu_muc, "thiet_ke_phan_quyen.json"))
    RS = (doc(os.path.join(a.thu_muc, "ra_soat.json"), {"muc": {}}) or {}).get("muc", {})
    TN = {t["key"]: t for t in D["tai_nguyen"]}
    VT = {v["key"]: v for v in D["vai_tro"]}
    PV = {p["key"]: p for p in D["pham_vi"]}
    DK = {d["key"]: d for d in D["dieu_kien"]}
    BC = collections.defaultdict(list)
    CAU = {c["key"]: c for c in D.get("cau_mo_ta", [])}
    cau_cua = {k: c for c in CAU.values() for k in c["quyen"]}
    QK = {q["khoa"] for q in D["quyen"]}

    # ---------- ý kiến không còn mục tương ứng (đổi key, lập lại thiết kế) ----------
    con = lambda k: (k in QK or k in CAU or k.startswith("xn:") or (k.startswith("vt:") and k[3:] in VT)
                     or (k.startswith("ch:") and k[3:] in {c.get("id") for c in D.get("cau_hoi", [])}))
    mo_coi = [(k, m) for k, m in RS.items() if not con(k)]
    for k, m in mo_coi:
        BC["Ý kiến rà soát không còn mục tương ứng — cần người rà soát xem lại"].append(f"{m.get('nhan') or k} · {m.get('ket_qua') or 'ghi chú'} · {m.get('ghi_chu', '')}".strip(" ·"))

    # ---------- quyền hiệu lực ----------
    hl = []
    for q in D["quyen"]:
        c = cau_cua.get(q["khoa"])
        kq = RS.get(q["khoa"], {}).get("ket_qua") or (RS.get(c["key"], {}).get("ket_qua") if c else None)
        t = q["trang_thai"]
        if kq == "khong_dong_y" and t in ("giu", "ke_thua"):
            BC["Không đồng ý với quyền theo tài liệu / theo quy định chung — AI cần sửa đặc tả (vẫn xuất như hiện tại)"].append(
                f"{VT[q['vai_tro']]['ten']} · {TN[q['tai_nguyen']]['ten']}:{q['hanh_dong']}" + (f" — {RS.get(c['key'], {}).get('ghi_chu', '')}" if c else ""))
        if kq == "khong_dong_y":
            t = {"them": "bo", "bo": "giu"}.get(t, t)
        if t == "them" and a.chi_da_duyet and kq != "dong_y":
            BC["Đề xuất AI chưa được đồng ý (bỏ vì --chi-da-duyet)"].append(f"{q['vai_tro']} · {q['tai_nguyen']}:{q['hanh_dong']}")
            continue
        if t != "bo":
            hl.append(q)
    # KT-02: quyền xuất danh sách có điều kiện → quyền trên từng bản ghi theo phạm vi xem của chính vai trò (ha_muc.py)
    hl, HA = HM.ha_muc(hl, D, lambda k: (PV.get(k) or {}).get("kieu") or k or "toan_he_thong")

    # ---------- tài nguyên ----------
    R = OD()
    for t in D["tai_nguyen"]:
        R[t["key"]] = OD([("key", t["key"]), ("name", t["ten"]), ("description", t.get("mo_ta") or t["ten"]), ("group", False), ("urn", None),
                          ("actions", OD((h["key"], OD([("key", h["key"]), ("name", h["ten"]), ("description", None), ("attributes", None)])) for h in t["hanh_dong"])),
                          ("attributes", OD((x["key"], OD([("key", x["key"]), ("type", KIEU.get(x.get("kieu"), "string")), ("description", x.get("y_nghia"))])) for x in t.get("thuoc_tinh", []))),
                          ("roles", OD()),
                          ("relations", OD((r["key"], OD([("resource", r["toi"]), ("name", r["key"]), ("description", r.get("y_nghia"))])) for r in t.get("quan_he", [])))])
    G = OD()

    def g_role(k):
        v = VT[k]
        return G.setdefault(k, OD([("key", k), ("name", v["ten"]), ("description", v.get("mo_ta") or ""), ("permissions", []), ("resource", None), ("grantedTo", None)]))

    def r_role(rk, k, ten, mo_ta):
        return R[rk]["roles"].setdefault(k, OD([("key", k), ("name", ten), ("description", mo_ta), ("permissions", []), ("resource", rk), ("grantedTo", None)]))

    def cap(ro, perm):
        if perm and perm not in ro["permissions"]:
            ro["permissions"].append(perm)

    def nhan(ro, role, on, rel):
        g = ro["grantedTo"] or OD([("users_with_role", [])])
        e = OD([("role", role), ("on_resource", on), ("linked_by_relation", rel)])
        if e not in g["users_with_role"]:
            g["users_with_role"].append(e)
        ro["grantedTo"] = g

    def rel_toi(rk, dich):
        """Quan hệ của rk trỏ tới dich (ưu tiên quan hệ không phải parent)."""
        ds = [r["key"] for r in TN[rk].get("quan_he", []) if r["toi"] == dich]
        ds.sort(key=lambda k: k == "cap_tren")
        return ds[0] if ds else None

    def cay_cap_tren(rk):
        return next((r["key"] for r in TN[rk].get("quan_he", []) if r["toi"] == rk), None)

    def cau_noi(vk, g, xuong):
        """Vai trò cầu nối trên cây g: người có vk ở nút cha nhận ở nút con (xuong='truc_tiep' | 'tat_ca')."""
        ct = cay_cap_tren(g)
        if not ct:
            return None
        k = f"{vk}__o_{slug(TN[g]['ten'])}_cap_tren" + ("" if xuong == "tat_ca" else "_truc_tiep")
        ro = r_role(g, k, f"{VT[vk]['ten']} – ở {TN[g]['ten'].split(' (')[0].lower()} cấp trên{'' if xuong == 'tat_ca' else ' trực tiếp'}",
                    f"Người có vai trò {vk} ở {TN[g]['ten']} cấp trên ({'mọi cấp' if xuong == 'tat_ca' else 'trực tiếp'}) nhận vai trò này ở nút cấp dưới")
        nhan(ro, vk, g, ct)
        if xuong == "tat_ca":
            nhan(ro, k, g, ct)
        return k

    def slug(s):
        """Tên tiếng Việt → key không dấu, bỏ phần trong ngoặc: «Phòng nghiệp vụ (cấp 2)» → phong_nghiep_vu."""
        s = s.split(" (")[0].lower().replace("đ", "d")
        s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
        return "_".join(re.findall(r"[a-z0-9]+", s))

    def ten_pham_vi(vk, pk, kieu, g):
        """Key vai trò trên tài nguyên, đọc ra ngay phạm vi: <vai trò>__don_vi_minh_va_cap_duoi, <vai trò>__cap_duyet…"""
        p = PV.get(pk) or {}
        chuan = pk == kieu or pk.startswith(kieu + "__") or p.get("tu_sinh")
        if not chuan:
            return f"{vk}__{slug(p.get('ten') or pk)}"   # phạm vi riêng của đặc tả: theo tên phạm vi («Hội nơi chuyển đến»…)
        c = slug(TN[g]["ten"]) if g in TN else "don_vi"
        return {"don_vi_minh_va_cap_duoi": f"{vk}__{c}_minh_va_cap_duoi", "don_vi_minh_va_cap_duoi_truc_tiep": f"{vk}__{c}_minh_va_cap_duoi_truc_tiep",
                "don_vi_minh": f"{vk}__{c}_minh", "cap_duyet": f"{vk}__cap_duyet"}.get(kieu, f"{vk}__{slug(p.get('ten') or pk)}")

    # ---------- điều kiện: giá trị CSDL, mệnh đề JSON, điều kiện xuất được thành tập hồ sơ ----------
    GT = {(t["key"], x["key"]): x.get("gia_tri") or {} for t in D["tai_nguyen"] for x in t.get("thuoc_tinh", [])}
    HDT = {(t["key"], h["key"]): h for t in D["tai_nguyen"] for h in t["hanh_dong"]}

    def doi_gt(rk, trai, phai):
        """Giá trị chuẩn → giá trị trong CSDL theo thuoc_tinh.gia_tri (ví dụ DU_THAO → DRAFT)."""
        m = GT.get((rk, trai[len("resource."):]), {}) if trai.startswith("resource.") else {}
        if not m:
            return phai
        if isinstance(phai, list):
            return [m.get(x, x) for x in phai]
        return m.get(phai, phai) if isinstance(phai, str) and not DKM.la_tham_chieu(phai) else phai

    def menh_de(rk, dks):
        return [DKM.json_menh_de(b["trai"], b["phep"], doi_gt(rk, b["trai"], b["phai"])) for d in dks for b in DK[d].get("bieu_thuc", [])]

    def ap_duoc(dks, ref=True):
        """Điều kiện chỉ xét thuộc tính bản ghi (so với hằng, hoặc bằng / khác user.… khi ref) → xuất được thành resourceset;
        ref=False: chỉ so với hằng (không phụ thuộc người hỏi) → dùng được cho quan hệ theo điều kiện."""
        if not dks or any(not (DK.get(d) or {}).get("bieu_thuc") for d in dks):
            return False
        return all(b["trai"].startswith("resource.") and b["phep"] in ("bang", "khac", "thuoc")
                   and not (DKM.la_tham_chieu(b["phai"]) and (b["phep"] not in ("bang", "khac") or not ref)) for d in dks for b in DK[d]["bieu_thuc"])

    def ten_dk(dks):
        return " + ".join(DK[d]["ten"] for d in dks if d in DK)

    # ---------- dựng quyền ----------
    # Nguyên tắc: không quyền nào rộng hơn thiết kế. Điều kiện áp được → hệ phân quyền áp; không áp được → KHÔNG CẤP (KC),
    # báo cáo nêu lý do để sửa thiết kế (thiếu, không thừa).
    can_dk = collections.defaultdict(list)
    ABAC, ABAC_VT = [], []      # ABAC_VT: quyền toàn hệ thống có điều kiện → luật cấp thêm theo vai trò
    KC = []                     # quyền không cấp vì không áp được: (q, nhãn, lý do)
    REL_DK = collections.defaultdict(set)   # (tài nguyên, quan hệ phạm vi) → các bộ điều kiện của quyền đi qua quan hệ đó
    QHDK = OD()                             # (tài nguyên, quan hệ theo điều kiện) → mô tả cho ứng dụng: ghi khi nào, quyền nào đi qua
    BG = OD()   # (tài nguyên, vai trò trên bản ghi) → ứng dụng gán (người lập / người được giao; hoặc từng người theo phạm vi + điều kiện)
    TAO = []    # quyền thêm mới / nhập: kiểm trên nút cây nơi bản ghi mới gắn vào, hoặc biến thể theo điều kiện
    CACH = []   # mỗi quyền hiệu lực: cách áp + quyền DSL thực hiện (xuat_dsl.py, du_lieu_thu.py, so_sanh_thu.py đọc)
    TEN_ABAC = {"do_minh_lap": "bản ghi do mình lập", "duoc_giao": "bản ghi được giao cho mình"}
    LY_KHONG_AP = "điều kiện chưa có biểu thức, hoặc có phép so chưa áp được (chỉ áp được: thuộc tính bản ghi so với hằng, bằng / khác user.…)"

    def ghi(q, cach, quyen=(), ghi_chu=""):
        CACH.append(OD([("vai_tro", q["vai_tro"]), ("tai_nguyen", q["tai_nguyen"]), ("hanh_dong", q["hanh_dong"]), ("pham_vi", q["pham_vi"]),
                        ("dieu_kien", list(q["dieu_kien"])), ("cach", cach), ("quyen_dsl", list(quyen)), ("ghi_chu", ghi_chu)]))

    def khong_cap(q, nhan_q, ly_do):
        KC.append((q, nhan_q, ly_do)); ghi(q, "khong_cap", ghi_chu=ly_do)

    def them_hanh_dong(rk, act, ten):
        R[rk]["actions"].setdefault(act, OD([("key", act), ("name", ten), ("description", None), ("attributes", None)]))

    for lo, q0, ly in HA:   # xuất danh sách của vai trò không có quyền xem (ha_muc.py): không cấp
        if lo == "khong_cap":
            khong_cap(q0, f"{VT[q0['vai_tro']]['ten']} · {TN[q0['tai_nguyen']]['ten']}:{q0['hanh_dong']}", ly)
    for q in hl:
        vk, rk, hd = q["vai_tro"], q["tai_nguyen"], q["hanh_dong"]
        v, perm, p = VT[vk], f"{q['tai_nguyen']}:{q['hanh_dong']}", PV.get(q["pham_vi"]) or {}
        nhan_q = f"{v['ten']} · {TN[rk]['ten']}:{hd}"
        dks = tuple(d for d in q["dieu_kien"] if d in DK)
        if dks:
            can_dk[ten_dk(dks)].append(nhan_q)
        kieu = p.get("kieu") or q["pham_vi"]
        muc_ds = "danh_sach" in (kieu, q["pham_vi"])
        lo_ds = HM.loai_muc_ds(HDT, rk, hd) if muc_ds or (HDT.get((rk, hd), {}).get("muc") or BK.thong_tin_hanh_dong(hd)[1]) == "danh_sach" else None
        ten_h = HDT.get((rk, hd), {}).get("ten", hd)
        # thêm mới / nhập của vai trò theo đơn vị: kiểm trên nút cây nơi bản ghi mới gắn vào (đơn vị mình, NT-07)
        if lo_ds == "tao" and v.get("loai_pham_vi") == "theo_don_vi":
            g = v.get("gan_tren")
            ds_rel = [r["key"] for r in TN[rk].get("quan_he", []) if r["toi"] == g and r["key"] != "cap_tren"] if g in TN else []
            rel = next((k for k in ("thuoc_don_vi", "thuoc_to_chuc") if k in ds_rel), ds_rel[0] if ds_rel else None)   # đơn vị sở hữu bản ghi
            if not rel:
                khong_cap(q, nhan_q, f"tài nguyên không có quan hệ tới «{TN.get(g, {}).get('ten', g)}» (nơi gán vai trò) để kiểm bản ghi mới thuộc đơn vị nào"); continue
            if dks and not ap_duoc(dks):
                khong_cap(q, nhan_q, LY_KHONG_AP); continue
            act = f"{rk}__{hd}" + ("".join("__" + d for d in dks))
            them_hanh_dong(g, act, f"{ten_h} «{TN[rk]['ten']}»" + (f" — khi {ten_dk(dks).lower()}" if dks else ""))
            cap(r_role(g, vk, v["ten"], "Gán trực tiếp trên bản ghi"), f"{g}:{act}")
            TAO.append(OD([("vai_tro", vk), ("tai_nguyen", rk), ("hanh_dong", hd), ("kiem_tren", g), ("quan_he", rel), ("hanh_dong_dsl", act), ("dieu_kien", list(dks))]))
            ghi(q, "tao_tren_cay", [f"{g}:{act}"], f"kiểm trên {g} mà bản ghi mới gắn vào qua quan hệ {rel}"); continue
        chung = kieu in ("toan_he_thong", "danh_sach") or q["pham_vi"] in ("toan_he_thong", "danh_sach")
        if chung:
            if not dks:
                cap(g_role(vk), perm); ghi(q, "vai_tro_chung", [perm]); continue
            if lo_ds == "tao":          # vai trò toàn hệ thống thêm mới có điều kiện: biến thể hành động, ứng dụng kiểm theo dữ liệu nhập
                if not ap_duoc(dks):
                    khong_cap(q, nhan_q, LY_KHONG_AP); continue
                act = hd + "".join("__" + d for d in dks)
                them_hanh_dong(rk, act, f"{ten_h} — khi {ten_dk(dks).lower()}")
                cap(g_role(vk), f"{rk}:{act}")
                TAO.append(OD([("vai_tro", vk), ("tai_nguyen", rk), ("hanh_dong", hd), ("kiem_tren", None), ("quan_he", None), ("hanh_dong_dsl", act), ("dieu_kien", list(dks))]))
                ghi(q, "bien_the", [f"{rk}:{act}"]); continue
            if not muc_ds and ap_duoc(dks):
                ABAC_VT.append((vk, rk, perm, dks, nhan_q)); ghi(q, "luat_cap_them", [perm]); continue
            khong_cap(q, nhan_q, LY_KHONG_AP if not muc_ds else "quyền mức danh sách không đọc, không ghi bản ghi mà có điều kiện theo bản ghi"); continue
        if kieu in ("do_minh_lap", "duoc_giao"):
            if v.get("loai_pham_vi") == "theo_ban_ghi":
                # ABAC: mọi tài khoản đang hoạt động × bản ghi thoả biểu thức (created_by / assignee = user.ma_nguoi_dung)
                if dks and not ap_duoc(dks):
                    khong_cap(q, nhan_q, LY_KHONG_AP); continue
                ABAC.append((rk, perm, nhan_q, q["pham_vi"], kieu, vk, dks)); ghi(q, "luat_nguoi_lap", [perm]); continue
            if dks and not ap_duoc(dks):
                khong_cap(q, nhan_q, LY_KHONG_AP); continue
            # Vai trò theo đơn vị có quyền «trên bản ghi mình lập / được giao»: vai trò trên bản ghi, ứng dụng gán cho đúng người lập /
            # người được giao khi người đó giữ vai trò vk; có điều kiện → vai trò riêng <…>__<điều kiện>, CHỈ GÁN khi bản ghi thoả.
            bt = p.get("bieu_thuc") or []
            attr = (bt[0].get("trai", "") if bt else "").replace("resource.", "") or ("nguoi_lap" if kieu == "do_minh_lap" else "nguoi_duoc_giao")
            kbg = ten_pham_vi(vk, q["pham_vi"], kieu, rk) + "".join("__" + d for d in dks)
            ro = r_role(rk, kbg, f"{v['ten']} – {(p.get('ten') or TEN_ABAC[kieu]).lower()}" + (f" – khi {ten_dk(dks).lower()}" if dks else ""),
                        f"Vai trò trên bản ghi: ứng dụng gán cho người có {attr} là mình và đang giữ vai trò «{v['ten']}»"
                        + (f", CHỈ khi bản ghi thoả: {ten_dk(dks)}; gỡ khi hết thoả" if dks else " (khi tạo / khi giao bản ghi)") + "; gỡ khi người đó thôi giữ vai trò.")
            cap(ro, perm)
            BG.setdefault((rk, kbg), OD([("tai_nguyen", rk), ("vai_tro_ban_ghi", kbg), ("vai_tro", vk), ("cach_gan", "theo_thuoc_tinh"), ("thuoc_tinh", attr),
                                         ("pham_vi", q["pham_vi"]), ("dieu_kien", list(dks)), ("quyen", [])]))["quyen"].append(q["hanh_dong"])
            BC["Vai trò trên bản ghi do ứng dụng gán (người lập / người được giao, theo vai trò đang giữ)"].append(f"{nhan_q} → {rk}#{kbg}")
            ghi(q, "vai_tro_ban_ghi", [perm], kbg); continue
        g = v.get("gan_tren")
        qhm = p.get("quan_he") or {}
        rel = qhm.get(rk, qhm.get("*")) if isinstance(qhm, dict) else qhm
        if not g and rel and v["loai_pham_vi"] == "toan_he_thong":
            g = next((r["toi"] for r in TN[rk].get("quan_he", []) if r["key"] == rel), None)
            if g:
                BC[f"Vai trò toàn hệ thống cần gán thêm trên một nút của «{TN[g]['ten']}» để dùng phạm vi theo quan hệ"].append(f"{nhan_q} → gán {vk} trên nút tương ứng (ví dụ nút cấp cao nhất)")
        if not g or not rel:
            khong_cap(q, nhan_q, "thiếu nơi gán vai trò hoặc quan hệ của phạm vi"); continue
        # Điều kiện trên quyền cấp qua vai trò trên tài nguyên:
        # - chỉ so thuộc tính bản ghi với hằng → QUAN HỆ THEO ĐIỀU KIỆN <quan hệ>__<điều kiện> (ứng dụng ghi khi hồ sơ thoả, gỡ khi hết thoả);
        # - có so với người hỏi (khác / bằng user.…), hoặc quyền ngay trên cây / gán trực tiếp → VAI TRÒ TRÊN BẢN GHI THEO NGƯỜI:
        #   ứng dụng gán cho từng người đang có quyền theo phạm vi VÀ thoả điều kiện (xét với chính người đó), gỡ khi hết thoả.
        rel_dk, theo_nguoi = None, False
        if dks:
            if rk != g and rel != "(gan_truc_tiep)" and ap_duoc(dks, ref=False):
                rel_dk = f"{rel}__{'__'.join(dks)}"
            elif ap_duoc(dks):
                theo_nguoi = True
            else:
                khong_cap(q, nhan_q, LY_KHONG_AP); continue
        if rk != g:
            REL_DK[(rk, rel)].add(dks)
        xuong = {"don_vi_minh_va_cap_duoi": "tat_ca", "don_vi_minh_va_cap_duoi_truc_tiep": "truc_tiep"}.get(kieu)
        if theo_nguoi:
            r_role(g, vk, v["ten"], "Gán trực tiếp trên bản ghi")
            kbg = ten_pham_vi(vk, q["pham_vi"], kieu, g) + "".join("__" + d for d in dks)
            ro = r_role(rk, kbg, f"{v['ten']} – {(p.get('ten') or q['pham_vi']).lower()} – khi {ten_dk(dks).lower()}",
                        f"Vai trò trên bản ghi theo người: ứng dụng gán cho từng người đang có vai trò «{v['ten']}» theo phạm vi «{p.get('ten') or q['pham_vi']}» "
                        f"(qua quan hệ {rel}) VÀ thoả: {ten_dk(dks)} (xét với chính người đó); gỡ khi hết thoả hoặc thôi giữ vai trò.")
            cap(ro, perm)
            BG.setdefault((rk, kbg), OD([("tai_nguyen", rk), ("vai_tro_ban_ghi", kbg), ("vai_tro", vk), ("cach_gan", "theo_pham_vi"), ("cay", g),
                                         ("quan_he", "(chinh_ban_ghi)" if rk == g and rel != "(gan_truc_tiep)" else rel), ("kieu_pham_vi", kieu), ("pham_vi", q["pham_vi"]), ("dieu_kien", list(dks)), ("quyen", [])]))["quyen"].append(hd)
            ghi(q, "vai_tro_ban_ghi_theo_nguoi", [perm], kbg); continue
        if rel == "(gan_truc_tiep)" and rk == g:
            cap(r_role(g, vk, v["ten"], "Gán trực tiếp trên bản ghi"), perm); ghi(q, "noi_rong" if dks else "vai_tro_tren_tai_nguyen", [perm]); continue
        if rk == g and rel == cay_cap_tren(g):          # chính cây: mình + cấp dưới
            cap(r_role(g, vk, v["ten"], "Gán trực tiếp trên bản ghi"), perm)
            k = cau_noi(vk, g, xuong or "truc_tiep")
            if k:
                cap(R[g]["roles"][k], perm)
            ghi(q, "noi_rong" if dks else "vai_tro_tren_tai_nguyen", [perm]); continue
        dich = next((r["toi"] for r in TN[rk].get("quan_he", []) if r["key"] == rel), None)
        if not dich:
            khong_cap(q, nhan_q, f"tài nguyên thiếu quan hệ {rel} của phạm vi"); continue
        r_role(g, vk, v["ten"], "Gán trực tiếp trên bản ghi")
        nguon = [(vk, g)]
        if xuong:
            k = cau_noi(vk, g, xuong)
            if k:
                nguon.append((k, g))
        if dich != g:                                    # hai bước: tài nguyên → dich → nơi gán
            lk = rel_toi(dich, g)
            if not lk:
                khong_cap(q, nhan_q, f"không nối được tới nơi gán vai trò ({rk} →{rel}→ {dich} ↛ {g})"); continue
            bk = f"{vk}__o_{slug(TN[g]['ten'])}_quan_ly" + ("_hoac_cap_tren" if xuong else "")
            gt = TN[g]["ten"].split(" (")[0].lower()
            br = r_role(dich, bk, f"{v['ten']} – ở {gt} quản lý" + (" hoặc cấp trên" if xuong else ""),
                        f"Người có vai trò {vk} ở {TN[g]['ten']} quản lý bản ghi này qua quan hệ {lk}" + (", hoặc ở cấp trên của nơi đó" if xuong else ""))
            for nk, ng in nguon:
                nhan(br, nk, ng, lk)
            ct = cay_cap_tren(dich)
            if xuong and ct:
                nhan(br, bk, dich, ct)
            nguon = [(bk, dich)]
        key2 = ten_pham_vi(vk, q["pham_vi"], kieu, g)
        cay_ten = TN[g]["ten"].split(" (")[0].lower() if g in TN else "đơn vị"
        ten_pv = {"don_vi_minh_va_cap_duoi": f"{cay_ten} mình và mọi cấp dưới", "don_vi_minh_va_cap_duoi_truc_tiep": f"{cay_ten} mình và cấp dưới trực tiếp",
                  "don_vi_minh": f"{cay_ten} mình", "cap_duyet": "đang chờ cấp mình duyệt"}.get(kieu) if key2.split("__", 1)[1] != slug(p.get("ten") or q["pham_vi"]) else None
        ten_ro = f"{v['ten']} – {ten_pv or p.get('ten', q['pham_vi']).lower()}"
        if rel_dk:
            key2 += "__" + "__".join(dks)
            ten_ro += f" – khi {ten_dk(dks).lower()}"
            goc = R[rk]["relations"][rel]
            R[rk]["relations"].setdefault(rel_dk, OD([("resource", goc["resource"]), ("name", rel_dk),
                                                       ("description", f"{goc.get('description') or rel} — CHỈ GHI khi hồ sơ thoả: {ten_dk(dks)}; gỡ khi hết thoả")]))
            QHDK.setdefault((rk, rel_dk), OD([("tai_nguyen", rk), ("quan_he", rel_dk), ("quan_he_goc", rel), ("toi", goc["resource"]),
                                              ("dieu_kien", list(dks)), ("ten_dieu_kien", ten_dk(dks)), ("quyen", [])]))["quyen"].append(OD([("vai_tro", vk), ("hanh_dong", hd)]))
        ro = r_role(rk, key2, ten_ro, p.get("mo_ta", ""))
        cap(ro, perm)
        for nk, ng in nguon:
            nhan(ro, nk, ng, rel_dk or rel)
        ghi(q, "quan_he_theo_dieu_kien" if rel_dk else ("noi_rong" if dks else "vai_tro_tren_tai_nguyen"), [perm], key2)

    # ---------- tập điều kiện (định nghĩa) và luật cấp thêm ----------
    CS, CSR, DA_AP = [], [], []

    def them_cs(key, ten, mo_ta, loai, rk, md):
        if not any(c["key"] == key for c in CS):
            CS.append(OD([("key", key), ("name", ten), ("description", mo_ta), ("type", loai)] + ([("resource", rk)] if rk else [])
                         + [("conditions", DKM.json_dieu_kien(OD(m) for m in md))]))
        return key

    def them_luat(us, perm, rs):
        r = OD([("user_set", us), ("permission", perm), ("resource_set", rs)])
        if r not in CSR:
            CSR.append(r)

    for d in D["dieu_kien"]:     # định nghĩa từng điều kiện trên từng tài nguyên dùng nó (hệ đích / ứng dụng dùng để chặn)
        for rk in sorted({q["tai_nguyen"] for q in hl if d["key"] in q["dieu_kien"]}):
            them_cs(f"{d['key']}__{rk}", f"{d['ten']} – {TN[rk]['ten']}", d.get("mo_ta"), "resourceset", rk, menh_de(rk, [d["key"]]))
    # quyền toàn hệ thống có điều kiện: người giữ vai trò (user.vai_tro_chung chứa key) × hồ sơ thoả điều kiện
    for vk, rk, perm, dks, nhan_q in ABAC_VT:
        us = them_cs(f"nguoi_giu_{vk}", f"Người giữ vai trò «{VT[vk]['ten']}»",
                     f"Người dùng có {DKM.VAI_TRO_CHUNG} chứa «{vk}» (hệ đích đồng bộ danh sách vai trò toàn hệ thống của tài khoản)",
                     "userset", None, [DKM.json_menh_de(DKM.VAI_TRO_CHUNG, "chua", vk)])
        rs = them_cs(f"tap_{rk}__" + "__".join(dks), f"{TN[rk]['ten']} — {ten_dk(dks).lower()}", "Hồ sơ thoả: " + ten_dk(dks), "resourceset", rk, menh_de(rk, dks))
        them_luat(us, perm, rs)
        DA_AP.append(f"{nhan_q} — người giữ vai trò × hồ sơ thoả «{ten_dk(dks)}» (`{us}` → `{rs}`)")
    if ABAC_VT:
        BC["Vai trò toàn hệ thống cấp qua thuộc tính người dùng: hệ đích ghi key vai trò vào user.vai_tro_chung (không chỉ gán vai trò)"] += sorted(
            {f"{VT[x[0]]['ten']} → `{x[0]}`" for x in ABAC_VT})
    if ABAC:
        them_cs("tai_khoan_hoat_dong", "Tài khoản đang hoạt động", "Mọi người dùng có user.trang_thai = DANG_HOAT_DONG", "userset", None,
                [DKM.json_menh_de("user.trang_thai", "bang", "DANG_HOAT_DONG")])
        MAC = {"do_minh_lap": [{"trai": "resource.nguoi_lap", "phep": "bang", "phai": "user.ma_nguoi_dung"}], "duoc_giao": [{"trai": "resource.nguoi_duoc_giao", "phep": "bang", "phai": "user.ma_nguoi_dung"}]}
        for rk, perm, nhan_q, pk, kieu, vk, dk_ap in ABAC:
            p = PV.get(pk) or {}
            bt = p.get("bieu_thuc") or MAC.get(p.get("kieu", pk), MAC["do_minh_lap"])
            md = [DKM.json_menh_de(b["trai"], b["phep"], b["phai"]) for b in bt] + menh_de(rk, dk_ap)
            rs = them_cs(f"tap_{rk}_{pk}" + "".join("__" + d for d in dk_ap), f"{TN[rk]['ten']} — {p.get('ten', pk).lower()}" + (f" — {ten_dk(dk_ap).lower()}" if dk_ap else ""),
                         p.get("mo_ta") or pk, "resourceset", rk, md)
            them_luat("tai_khoan_hoat_dong", perm, rs)
            if dk_ap:
                DA_AP.append(f"{nhan_q} — hồ sơ {p.get('ten', pk).lower()} thoả «{ten_dk(dk_ap)}» (`{rs}`)")
            BC["Luật ABAC (người lập, người được giao): ứng dụng ghi nguoi_lap / nguoi_duoc_giao; userset dùng user.trang_thai = DANG_HOAT_DONG"].append(nhan_q)
            if VT[vk].get("loai_pham_vi") != "theo_ban_ghi":
                BC["Luật ABAC áp cho mọi người thoả thuộc tính, không giới hạn theo vai trò — BA xác nhận"].append(nhan_q)
    for (rk, rel_dk), m in QHDK.items():   # điều kiện ghi quan hệ (giá trị CSDL), để ứng dụng và tệp thử dùng
        m["dieu_kien_json"] = DKM.json_dieu_kien(OD(x) for x in menh_de(rk, m["dieu_kien"]))
        m["dieu_kien_dsl"] = DKM.dsl_dieu_kien(m["dieu_kien_json"])
        for x in m["quyen"]:
            DA_AP.append(f"{VT[x['vai_tro']]['ten']} · {TN[rk]['ten']}:{x['hanh_dong']} — qua quan hệ `{rel_dk}` (ứng dụng chỉ ghi khi hồ sơ thoả «{m['ten_dieu_kien']}»)")
    for (rk, kbg), m in BG.items():        # vai trò trên bản ghi có điều kiện: ứng dụng chỉ gán khi thoả (giá trị CSDL)
        if m.get("dieu_kien"):
            m["ten_dieu_kien"] = ten_dk(m["dieu_kien"])
            m["dieu_kien_json"] = DKM.json_dieu_kien(OD(x) for x in menh_de(rk, m["dieu_kien"]))
            m["dieu_kien_dsl"] = DKM.dsl_dieu_kien(m["dieu_kien_json"])
            for hd in m["quyen"]:
                DA_AP.append(f"{VT[m['vai_tro']]['ten']} · {TN[rk]['ten']}:{hd} — qua vai trò trên bản ghi `{kbg}` "
                             f"(ứng dụng chỉ gán khi thoả «{m['ten_dieu_kien']}»" + (", xét với chính người được gán)" if m["cach_gan"] == "theo_pham_vi" else ")"))
    for m in TAO:                          # thêm mới / nhập có điều kiện: ứng dụng kiểm biến thể theo dữ liệu nhập
        if m["dieu_kien"]:
            m["dieu_kien_json"] = DKM.json_dieu_kien(OD(x) for x in menh_de(m["tai_nguyen"], m["dieu_kien"]))
            m["dieu_kien_dsl"] = DKM.dsl_dieu_kien(m["dieu_kien_json"])
            DA_AP.append(f"{VT[m['vai_tro']]['ten']} · {TN[m['tai_nguyen']]['ten']}:{m['hanh_dong']} — biến thể `{m['hanh_dong_dsl']}`, kiểm khi dữ liệu nhập thoả «{ten_dk(m['dieu_kien'])}»")
    for c in CS:
        for g in c["conditions"]["any_of"]:
            for m in g["all_of"]:
                if m["operator"] not in DKM.OP_MAU:
                    BC["Toán tử chưa có trong file JSON mẫu (cần hệ đích xác nhận)"].append(f"{m['operator']} ({m['left']})")

    # ---------- giá trị trạng thái: điều kiện dùng key chuẩn, CSDL ghi giá trị khác ----------
    for t in D["tai_nguyen"]:
        for x in t.get("thuoc_tinh", []):
            if x.get("gia_tri"):
                continue
            dung = {v for d in DK.values() if any(d["key"] in q["dieu_kien"] and q["tai_nguyen"] == t["key"] for q in hl)
                    for b in d.get("bieu_thuc", []) if b["trai"] == "resource." + x["key"]
                    for v in (b["phai"] if isinstance(b["phai"], list) else [b["phai"]]) if isinstance(v, str) and not DKM.la_tham_chieu(v)}
            csdl = {c for c in re.findall(r"\b[A-Z][A-Z0-9_]{2,}\b", x.get("y_nghia") or "") if not re.fullmatch(r"[A-Z]{1,3}\d+", c)}   # bỏ địa chỉ ô (D15)
            khac = sorted(dung - csdl)
            if dung and csdl and khac:
                goi_y = ", ".join(f"{v} → " + ("/".join(sorted(c for c in csdl if BK.trang_thai(c) == v)) or "?") for v in khac)
                BC["Giá trị trong điều kiện khác giá trị ghi trong mô tả trường (CSDL): khai `gia_tri` cho thuộc tính rồi lập lại thiết kế, nếu không điều kiện không bao giờ thoả"].append(
                    f"{t['ten']} · `{x['key']}`: điều kiện dùng {', '.join(khac)}; mô tả trường ghi {', '.join(sorted(csdl))} (gợi ý theo bí danh: {goi_y})")

    out = OD([("resources", list(R.values())), ("roles", list(G.values())), ("condition_sets", CS), ("condition_set_rules", CSR),
              ("project_detail", OD([("appVersion", None), ("versionDescription", None), ("icon", None), ("color", None), ("path", (D.get("phan_he") or {}).get("ma")), ("userManual", [])])),
              ("resource_menus", []), ("resource_instances", []), ("users", []), ("role_assignments", []), ("relationship_tuples", [])])
    with open(os.path.join(a.thu_muc, "phan_quyen_import.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    with open(os.path.join(a.thu_muc, "vai_tro_tren_ban_ghi.json"), "w", encoding="utf-8") as f:
        json.dump(list(BG.values()), f, ensure_ascii=False, indent=2)
    with open(os.path.join(a.thu_muc, "quan_he_theo_dieu_kien.json"), "w", encoding="utf-8") as f:
        json.dump(list(QHDK.values()), f, ensure_ascii=False, indent=2)
    with open(os.path.join(a.thu_muc, "kiem_khi_tao.json"), "w", encoding="utf-8") as f:
        json.dump(TAO, f, ensure_ascii=False, indent=2)
    with open(os.path.join(a.thu_muc, "cach_ap.json"), "w", encoding="utf-8") as f:
        json.dump(CACH, f, ensure_ascii=False, indent=1)
    err = kiem_tra(out)
    nr = sum(len(x["roles"]) for x in R.values())
    so_dk = sum(1 for q in hl if any(d in DK for d in q["dieu_kien"]))
    L = [f"# Báo cáo xuất JSON import — {(D.get('phan_he') or {}).get('ten', '')}", "",
         f"- {len(hl)} quyền hiệu lực → {len(R)} tài nguyên, {len(G)} vai trò chung (RBAC), {nr} vai trò trên tài nguyên (ReBAC, gồm vai trò cầu nối), {len(CS)} tập điều kiện, {len(CSR)} luật ABAC cấp quyền.",
         f"- Quyền có điều kiện: {so_dk}; áp trong hệ phân quyền: {len(DA_AP)} (luật cấp thêm, quan hệ / vai trò trên bản ghi theo điều kiện, biến thể khi tạo); không quyền nào bị nới rộng.",
         f"- **Không cấp vì chưa áp được: {len(KC)}** (thiếu so với thiết kế, không bao giờ thừa; sửa thiết kế rồi xuất lại — mục «Quyền không cấp»).",
         f"- Kiểm tra tham chiếu: {len(err)} lỗi." + ("" if not err else "\n" + "\n".join("  - " + e for e in err)), "",
         "Khuôn import chỉ có luật **cấp thêm** quyền (`condition_set_rules` = nhóm người dùng × tập hồ sơ), không có luật **thu hẹp** quyền của một vai trò. "
         "Vì vậy công cụ không bao giờ cấp một quyền rộng hơn thiết kế: mỗi quyền hoặc được hệ phân quyền áp đủ phạm vi và điều kiện, hoặc không cấp. "
         "Cách áp từng quyền: `cach_ap.json`.", "",
         "## Lưu ý cho đội phát triển khi gọi kiểm quyền", "",
         "- Hệ phân quyền ưu tiên thuộc tính gửi kèm yêu cầu kiểm quyền hơn thuộc tính đã lưu (mã sinh Rego của VAuthz: `input` → `custom` → `stored`). "
         "Với bản ghi đã có, **không gửi `resource.attributes` / `user.attributes`** trong yêu cầu kiểm quyền, và không chuyển tiếp thuộc tính do máy khách gửi lên; "
         "chỉ backend gọi hệ phân quyền.",
         "- Mọi API đọc, sửa, xoá, chuyển trạng thái đều kiểm `(người dùng, hành động, bản ghi)`; danh sách, tìm kiếm, tệp xuất chỉ gồm bản ghi được hành động tương ứng.",
         "- Khi đổi trạng thái: gỡ quan hệ / vai trò trên bản ghi cũ **trước**, ghi cái mới **sau** (trạng thái trung gian luôn ít quyền hơn).", ""]
    if QHDK:
        L += [f"## Quan hệ theo điều kiện ({len(QHDK)}): ứng dụng ghi, gỡ theo trạng thái hồ sơ", "",
              "Hệ phân quyền không đặt được điều kiện trên đường kế thừa vai trò (`derive`), nên quyền có điều kiện đi qua một **quan hệ riêng**. "
              "Ứng dụng ghi quan hệ này (cùng đơn vị với quan hệ gốc) **chỉ khi hồ sơ thoả điều kiện**, và **gỡ ngay khi hồ sơ hết thoả** "
              "(đổi trạng thái, khoá, đổi loại…). Quan hệ gốc vẫn ghi như cũ cho các quyền không có điều kiện. "
              "Chi tiết cho đội phát triển: `quan_he_theo_dieu_kien.json`.", "",
              "| Tài nguyên | Quan hệ ứng dụng ghi | Trỏ tới (như quan hệ gốc) | Ghi khi hồ sơ thoả | Quyền đi qua |", "|---|---|---|---|---|"]
        for (rk, rel_dk), m in QHDK.items():
            q_txt = "; ".join(f"{VT[x['vai_tro']]['ten']}: {x['hanh_dong']}" for x in m["quyen"])
            L.append(f"| {TN[rk]['ten']} | `{rel_dk}` | `{m['quan_he_goc']}` → {TN.get(m['toi'], {}).get('ten', m['toi'])} | {m['ten_dieu_kien']} (`{m['dieu_kien_dsl']}`) | {q_txt} |")
        L.append("")
    ha = [(q, qx) for lo, q, qx in HA if lo == "ha"]
    if ha:
        ten_pv_q = lambda k: (PV.get(k) or {}).get("ten") or (BK.PHAM_VI.get(k) or (k,))[0]
        L += [f"## Quyền xuất danh sách hạ xuống mức bản ghi ({len(ha)}): theo phạm vi xem của chính vai trò", "",
              "Quyền xuất danh sách không để ở vai trò chung (vai trò chung cấp trên **mọi** hồ sơ, kể cả hồ sơ ngoài phạm vi và không thoả điều kiện). "
              "Theo KT-02 tệp xuất chỉ gồm hồ sơ người dùng được xem, nên quyền xuất được cấp **trên từng hồ sơ**, cùng đường với quyền xem của vai trò, "
              "điều kiện = điều kiện xem + điều kiện xuất. Đội phát triển: **tệp xuất = các hồ sơ người dùng được quyền xuất** "
              "(lấy danh sách hồ sơ được hành động này từ hệ phân quyền, hoặc kiểm từng hồ sơ); nút xuất hiển thị theo menu của ứng dụng.", "",
              "| Vai trò · tài nguyên:hành động | Điều kiện áp | Theo phạm vi xem |", "|---|---|---|"]
        L += [f"| {VT[q['vai_tro']]['ten']} · {TN[q['tai_nguyen']]['ten']}:{q['hanh_dong']} | {ten_dk([d for d in q['dieu_kien'] if d in DK])} | "
              f"{ten_pv_q(q['pham_vi'])} (quyền {qx['hanh_dong']}) |" for q, qx in [(dict(q0, pham_vi=qx["pham_vi"], dieu_kien=list(dict.fromkeys(
                  [d for d in qx["dieu_kien"] if d in DK] + [d for d in q0["dieu_kien"] if d in DK]))), qx) for q0, qx in ha]]
        L.append("")
    if TAO:
        L += [f"## Thêm mới, nhập danh sách ({len(TAO)}): kiểm trước khi tạo", "",
              "Lúc thêm mới chưa có bản ghi, nên quyền không để ở vai trò chung (sẽ tạo được bản ghi cho **mọi** đơn vị). "
              "Vai trò theo đơn vị: ứng dụng kiểm hành động trong cột «Hành động kiểm» **trên nút cây mà bản ghi mới sẽ gắn vào** qua quan hệ ghi ở cột «Quan hệ» "
              "(ví dụ đơn vị lập), lấy từ dữ liệu sắp ghi, không lấy từ máy khách. Có điều kiện: hành động là biến thể `<…>__<điều kiện>`; "
              "ứng dụng chỉ kiểm biến thể khi dữ liệu sắp ghi thoả điều kiện ở cột cuối (không thoả biến thể nào → không được tạo). "
              "Nhập danh sách: kiểm cho từng dòng. Chi tiết: `kiem_khi_tao.json`.", "",
              "| Vai trò · tài nguyên:hành động | Hành động kiểm | Kiểm trên | Quan hệ | Dữ liệu nhập phải thoả |", "|---|---|---|---|---|"]
        L += [f"| {VT[m['vai_tro']]['ten']} · {TN[m['tai_nguyen']]['ten']}:{m['hanh_dong']} | `{m['hanh_dong_dsl']}` | "
              f"{TN[m['kiem_tren']]['ten'] + ' (nút bản ghi mới gắn vào)' if m['kiem_tren'] else 'vai trò chung'} | {('`' + m['quan_he'] + '`') if m['quan_he'] else '—'} | "
              f"{(ten_dk(m['dieu_kien']) + ' (`' + m['dieu_kien_dsl'] + '`)') if m['dieu_kien'] else '—'} |" for m in TAO]
        L.append("")
    tn_bg = [m for m in BG.values() if m.get("dieu_kien")]
    if tn_bg:
        L += [f"## Vai trò trên bản ghi theo điều kiện ({len(tn_bg)}): ứng dụng gán, gỡ theo bản ghi và người", "",
              "«theo_thuoc_tinh»: gán cho người lập / người được giao (đang giữ vai trò gốc) **chỉ khi bản ghi thoả điều kiện**, gỡ khi hết thoả. "
              "«theo_pham_vi»: điều kiện có so với người hỏi (ví dụ không tự duyệt) nên không đi qua quan hệ được; ứng dụng gán cho **từng người** "
              "đang có vai trò gốc theo phạm vi (qua quan hệ ghi ở cột «Phạm vi») **và** thoả điều kiện khi xét với chính người đó; "
              "tính lại khi bản ghi đổi thuộc tính, đổi quan hệ, hoặc khi gán / gỡ vai trò gốc. Chi tiết: `vai_tro_tren_ban_ghi.json`.", "",
              "| Tài nguyên | Vai trò trên bản ghi | Cách gán | Vai trò gốc | Phạm vi | Điều kiện | Quyền |", "|---|---|---|---|---|---|---|"]
        L += [f"| {TN[m['tai_nguyen']]['ten']} | `{m['vai_tro_ban_ghi']}` | {m['cach_gan']} | {VT[m['vai_tro']]['ten']} | "
              f"{(PV.get(m['pham_vi']) or {}).get('ten', m['pham_vi'])}" + (f" (quan hệ `{m['quan_he']}`)" if m.get("quan_he") else f" (thuộc tính `{m.get('thuoc_tinh')}`)")
              + f" | {m['ten_dieu_kien']} (`{m['dieu_kien_dsl']}`) | {', '.join(m['quyen'])} |" for m in tn_bg]
        L.append("")
    if KC:
        L += [f"## Quyền không cấp ({len(KC)}): chưa áp được, sửa thiết kế rồi xuất lại", "",
              "Các quyền dưới đây **không được cấp** trong tệp import (người dùng sẽ thiếu quyền, không bao giờ thừa). "
              "Sửa theo lý do: viết biểu thức cho điều kiện (`dieu_kien[].bieu_thuc`), thêm quan hệ còn thiếu, hoặc hỏi BA.", "",
              "| Vai trò · tài nguyên:hành động | Phạm vi | Điều kiện | Lý do |", "|---|---|---|---|"]
        L += [f"| {n} | {(PV.get(q['pham_vi']) or {}).get('ten', q['pham_vi'])} | {ten_dk([d for d in q['dieu_kien'] if d in DK]) or '—'} | {ly} |" for q, n, ly in KC]
        L.append("")
    if DA_AP:
        L += [f"## Điều kiện đã áp trong hệ phân quyền ({len(DA_AP)})", ""] + [f"- {x}" for x in DA_AP] + [""]
    dung_tt = sorted({(x, c.get("resource") or "") for c in CS for g in c["conditions"]["any_of"] for m in g["all_of"]
                      for x in [m["left"]] + ([m["right"]] if DKM.la_tham_chieu(m["right"]) else [])})
    if dung_tt:
        mo = {("resource." + x["key"], t["key"]): x.get("y_nghia") or "" for t in D["tai_nguyen"] for x in t.get("thuoc_tinh", [])}
        L += ["## Thuộc tính ứng dụng phải đồng bộ sang hệ phân quyền (đúng key dưới đây, không dùng tên cột CSDL)", ""]
        L += [f"- `{l}`" + (f" ({TN[rk]['ten']}): {mo.get((l, rk))}" if rk and mo.get((l, rk)) else "") for l, rk in dung_tt]
        L.append("")
    for k, ds in BC.items():
        L += ["", f"## {k} ({len(set(ds))})", ""] + [f"- {x}" for x in sorted(set(ds))[:60]]
    with open(os.path.join(a.thu_muc, "bao_cao_xuat_json.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    if mo_coi:
        print(f"  CẢNH BÁO: {len(mo_coi)} ý kiến rà soát không còn mục tương ứng — xem bao_cao_xuat_json.md")
    print(f"{len(hl)} quyền → {len(R)} tài nguyên · {len(G)} vai trò chung · {nr} vai trò trên tài nguyên · {len(CS)} tập điều kiện · kiểm tra {len(err)} lỗi")
    print(f"  điều kiện: {so_dk} quyền có điều kiện · {len(DA_AP)} áp · {len(KC)} không cấp vì chưa áp được (xem bao_cao_xuat_json.md)")
    for q, n, ly in KC[:10]:
        print("  KHÔNG CẤP", n, "—", ly)
    for k in BC:
        if k.startswith("Giá trị trong điều kiện khác"):
            print("  CẢNH BÁO:", k.split(":")[0], f"({len(BC[k])})")
    for e in err[:10]:
        print("  LỖI", e)


def kiem_tra(d):
    err = []
    R = {r["key"]: r for r in d["resources"]}
    GR = {r["key"] for r in d["roles"]}
    def perm(p, w):
        rk, _, a = p.partition(":")
        if rk not in R or a not in R[rk]["actions"]:
            err.append(f"{w}: quyền {p} không tồn tại")
    for k, r in R.items():
        for rel in r["relations"].values():
            if rel["resource"] not in R:
                err.append(f"{k}: quan hệ {rel['name']} trỏ tài nguyên lạ")
        for rk, ro in r["roles"].items():
            for p in ro["permissions"]:
                perm(p, f"{k}#{rk}")
                if not p.startswith(k + ":"):
                    err.append(f"{k}#{rk}: quyền {p} thuộc tài nguyên khác")
            for g in (ro.get("grantedTo") or {}).get("users_with_role", []):
                rel = r["relations"].get(g["linked_by_relation"])
                if not rel:
                    err.append(f"{k}#{rk}: không có quan hệ {g['linked_by_relation']}")
                elif rel["resource"] != g["on_resource"]:
                    err.append(f"{k}#{rk}: quan hệ {g['linked_by_relation']} trỏ {rel['resource']}, không phải {g['on_resource']}")
                if g["role"] not in R.get(g["on_resource"], {}).get("roles", {}):
                    err.append(f"{k}#{rk}: {g['role']} không phải vai trò trên {g['on_resource']}")
    for g in d["roles"]:
        for p in g["permissions"]:
            perm(p, "vai trò " + g["key"])
    cs = {c["key"]: c for c in d["condition_sets"]}
    for r in d["condition_set_rules"]:
        perm(r["permission"], "luật ABAC")
        if cs.get(r["user_set"], {}).get("type") != "userset" or cs.get(r["resource_set"], {}).get("type") != "resourceset":
            err.append(f"luật ABAC {r}: userset / resourceset không tồn tại")
    return err


if __name__ == "__main__":
    main()
