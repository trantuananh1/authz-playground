# -*- coding: utf-8 -*-
"""Mẫu đầu vào chuẩn 3 bảng (mọi phân hệ): Bảng 1 vai trò hệ thống, Bảng 2 tài nguyên – thuộc tính – hành động –
vai trò tài nguyên – hành động được phép, Bảng 3 quan hệ giữa tài nguyên. Skill chỉ dùng 3 bảng này cùng tài liệu BA gửi.

  python -I ba_bang.py tao <tệp_ra.xlsx>                       sinh mẫu trống (sheet «Phân quyền» + «Hướng dẫn»)
  python -I ba_bang.py tim <tệp.xlsx>                           liệt kê sheet có đủ Bảng 1, 2, 3 (JSON)
  python -I ba_bang.py doc <thu_muc_lam_viec> <tệp.xlsx> [--sheet <tên>]
        đọc 3 bảng → <lv>/ba_bang.json, <lv>/ba_bang.md (mỗi giá trị kèm ô «<sheet>!<ô>» để làm nguồn);
        Bảng 4 trở đi và các sheet khác không đọc ở đây (skill đọc cả tệp bằng trich_xuat.py); bảng vai trò riêng «… hành động
        được phép của vai trò» được đọc như cột vai trò của Bảng 2. Thoát mã 1 nếu không tìm thấy đủ 3 bảng.

Nhận bảng theo tiêu đề ở cột A: «Bảng 1 …» (vai trò), «Bảng 2 …» (tài nguyên), «Bảng 3 …» (quan hệ); dòng ngay sau là dòng tên cột,
cột xác định theo tên cột (không theo vị trí cố định). Ô gộp: giá trị nằm ở ô đầu, các dòng sau của cùng tài nguyên để trống.
Một ô ghi «key (mô tả)»; thuộc tính ghi «key (KIỂU)»; hành động được phép ghi danh sách key cách nhau bởi dấu phẩy.
"""
import json, os, re, sys

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bo_key as BK  # noqa: E402
cf = lambda s: re.sub(r"\s+", " ", str(s if s is not None else "")).strip()
MAU_BANG = re.compile(r"^\s*bảng\s*(\d+)\b", re.I)
# tên cột → trường (so khớp không phân biệt hoa thường, theo cụm từ)
COT = {
    1: [("key", r"key\s*vai\s*trò|mã\s*vai\s*trò"), ("ten", r"tên\s*vai\s*trò"), ("tang_viec", r"tầng\s*việc|chức\s*danh|gồm")],
    2: [("key", r"key\s*tài\s*nguyên|mã\s*tài\s*nguyên"), ("ten", r"tên\s*tài\s*nguyên"), ("thuoc_tinh", r"thuộc\s*tính"),
        ("hanh_dong", r"^hành\s*động(?!.*được\s*phép)"), ("vai_tro", r"^vai\s*trò"), ("duoc_phep", r"được\s*phép")],
    3: [("chu_the", r"chủ\s*thể|tài\s*nguyên\s*nguồn"), ("quan_he", r"quan\s*hệ"), ("dich", r"đích")],
}
TIEU_DE_BANG = {1: "Bảng 1: Danh sách vai trò hệ thống", 2: "Bảng 2: Danh sách tài nguyên và vai trò tài nguyên",
                3: "Bảng 3: Danh sách mối quan hệ giữa tài nguyên"}
TEN_COT = {1: ["STT", "Key vai trò (để trống: AI đặt)", "Tên vai trò", "Gồm các tầng việc / chức danh (tang_viec)", "Ghi chú"],
           2: ["STT", "Key tài nguyên (để trống: AI đặt)", "Tên tài nguyên", "Thuộc tính (Key thuộc tính: Loại thuộc tính)", "Hành động (Key và mô tả)",
               "Vai trò (Key và mô tả)", "Hành động được phép của vai trò"],
           3: ["Tài nguyên chủ thể", "Loại quan hệ (key và mô tả)", "Tài nguyên đích"]}


def key_mo_ta(s):
    """«key (mô tả)», «key: mô tả», «key» → (key, mô tả); ô chỉ có tên (không có key) → ("", cả ô).
    Key là một cụm chữ thường không dấu, số, «_» (ví dụ `xem_ds`, `xoa`, `ho_so_can_bo`)."""
    s = cf(s)
    for mau in (r"^([a-z0-9_]+)\s*\((.*)\)\s*$", r"^([a-z0-9_]+)\s*[:\-–]\s*(.+)$", r"^([a-z0-9_]+)()$"):
        m = re.match(mau, s)
        if m:
            return m.group(1), cf(m.group(2))
    return "", s


def ten_goc(s):
    """Phần tên trước dấu ngoặc đầu tiên: «Nhập danh sách (gồm tải file mẫu)» → «Nhập danh sách»."""
    return cf(re.split(r"\(", cf(s), 1)[0]) or cf(s)


def trong_ngoac(s):
    m = re.search(r"\((.*)\)", cf(s))
    return cf(m.group(1)) if m else ""


def dat_key(ten, da_co, toi_da=40):
    """Key do AI đặt khi sheet không ghi key: tên trước ngoặc, bỏ dấu, chữ thường, nối «_», tối đa 40 ký tự, không trùng."""
    k = BK.khong_dau(ten_goc(ten)) or "khong_ten"
    if len(k) > toi_da:
        k = k[:toi_da].rsplit("_", 1)[0] or k[:toi_da]
    goc, i = k, 2
    while k in da_co:
        k, i = f"{goc}_{i}", i + 1
    da_co.add(k)
    return k


def tim_bang(ws):
    """{số bảng: dòng tiêu đề} theo ô cột A (hoặc ô đầu dòng có chữ)."""
    out = {}
    for r in range(1, ws.max_row + 1):
        for c in range(1, min(ws.max_column, 3) + 1):
            v = ws.cell(r, c).value
            if isinstance(v, str):
                m = MAU_BANG.match(v)
                if m:
                    out.setdefault(int(m.group(1)), r)
                    break
    return out


def ghep_hanh_dong(t, ds):
    """Ghép danh sách «hành động được phép» (đã tách theo dấu phẩy) với hành động của tài nguyên t.
    Theo key, theo tên (bỏ dấu), theo phần tên trước ngoặc; cuối cùng gần đúng (một mảnh là đầu hoặc nằm trong đúng MỘT tên hành động).
    → (key đã ghép, mảnh không ghép được, [(mảnh, key)] ghép gần đúng)."""
    keys = {h["key"] for h in t["hanh_dong"]}
    theo = {}
    for h in t["hanh_dong"]:
        for nhan in (h["key"], h["mo_ta"], ten_goc(h["mo_ta"])):
            if nhan:
                theo.setdefault(BK.khong_dau(nhan), h["key"])
    ten_day = {h["key"]: BK.khong_dau(h["mo_ta"] or h["key"]) for h in t["hanh_dong"]}

    def khop(a, mot_manh):
        # nhiều mảnh ghép lại thì phải khớp nguyên tên; chỉ một mảnh mới được khớp theo phần tên trước ngoặc
        return a if a in keys else (theo.get(BK.khong_dau(a)) or (theo.get(BK.khong_dau(ten_goc(a))) if mot_manh else None))

    ra, la, gan = [], [], []
    i = 0
    # tên hành động có thể chứa dấu phẩy («Xem trước, xuất Word …»): ghép cụm dài nhất các mảnh liền nhau trước
    while i < len(ds):
        for j in range(len(ds), i, -1):
            kh = khop(", ".join(ds[i:j]), j == i + 1)
            if kh:
                if kh not in ra:
                    ra.append(kh)
                i = j
                break
        else:
            a = BK.khong_dau(ds[i])
            ung = [k for k, ten in ten_day.items() if len(a) >= 6 and (ten.startswith(a) or a in ten)] if a else []
            if len(ung) == 1:
                if ung[0] not in ra:
                    ra.append(ung[0])
                gan.append((ds[i], ung[0]))
            else:
                la.append(ds[i])
            i += 1
    return ra, la, gan


def tim_bang_vai_tro(ws):
    """Bảng «… hành động được phép của vai trò» đặt riêng (thường cạnh Bảng 2, không có cột tài nguyên): (dòng tiêu đề, cột vai trò, cột được phép)."""
    for r in range(1, ws.max_row + 1):
        for c in range(1, ws.max_column + 1):
            v = ws.cell(r, c).value
            if isinstance(v, str) and MAU_BANG.match(v) and re.search(r"được\s*phép", v, re.I) and re.search(r"vai\s*trò", v, re.I):
                cv = cd = None
                for cc in range(c, ws.max_column + 1):
                    h = cf(ws.cell(r + 1, cc).value).casefold()
                    if cv is None and re.match(r"^vai\s*trò", h):
                        cv = cc
                    elif cd is None and re.search(r"được\s*phép", h):
                        cd = cc
                if cv and cd:
                    return r, cv, cd
    return None


def la_mau(ws):
    b = tim_bang(ws)
    if not all(k in b for k in (1, 2, 3)):
        return False
    t = lambda k: cf(ws.cell(b[k], 1).value or "").casefold()
    if not ("vai trò" in t(1) and "tài nguyên" in t(2) and "quan hệ" in t(3)):
        return False
    # dòng ngay sau tiêu đề phải là dòng tên cột của bảng (tránh nhận nhầm sheet hướng dẫn)
    c1, c2 = cot_cua(ws, b[1] + 1, 1), cot_cua(ws, b[2] + 1, 2)
    return bool({"key", "ten"} & set(c1)) and bool({"key", "ten"} & set(c2)) and ("vai_tro" in c2 or tim_bang_vai_tro(ws) is not None) and len(cot_cua(ws, b[3] + 1, 3)) >= 2


def cot_cua(ws, r_tieu_de, so):
    cols = {}
    for c in range(1, ws.max_column + 1):
        h = cf(ws.cell(r_tieu_de, c).value).casefold()
        if not h:
            continue
        for f, mau in COT[so]:
            if f not in cols and re.search(mau, h, re.I):
                cols[f] = c
                break
    return cols


def doc_sheet(ws, ten_sheet):
    B = tim_bang(ws)
    ket_thuc = lambda so: min([r for k, r in B.items() if r > B[so]] + [ws.max_row + 1])
    o = lambda r, c: f"{ten_sheet}!{get_column_letter(c)}{r}"
    val = lambda r, c: cf(ws.cell(r, c).value) if c else ""
    la_key = lambda k: bool(k) and re.fullmatch(r"[a-z0-9_]+", k) is not None
    CB, TU_DAT = [], []          # cảnh báo; key do AI đặt (sheet không ghi key)

    def lay_key(o_key, ten, da_co, loai, noi):
        """Key ghi ở sheet thì giữ; không có thì đặt từ tên (tu_dat=True)."""
        if o_key:
            da_co.add(o_key)
            return o_key, False
        k = dat_key(ten, da_co)
        TU_DAT.append({"loai": loai, "ten": ten, "key": k, "o": noi})
        return k, True

    # Bảng 1
    vt, k1 = [], set()
    h1 = B[1] + 1
    c1 = cot_cua(ws, h1, 1)
    for r in range(h1 + 1, ket_thuc(1)):
        k, t = val(r, c1.get("key")), val(r, c1.get("ten"))
        if not (k or t):
            continue
        khac = {get_column_letter(c): cf(ws.cell(r, c).value) for c in range(1, ws.max_column + 1)
                if c not in c1.values() and c > 1 and cf(ws.cell(r, c).value)}
        noi = o(r, c1.get("key") or c1.get("ten") or 2)
        key, td = lay_key(k if la_key(k) else "", t or k, k1, "vai trò hệ thống", noi)
        vt.append({"key": key, "key_tu_dat": td, "ten": t or k, "tang_viec": val(r, c1.get("tang_viec")), "ghi_chu": " | ".join(khac.values()), "o": noi, "dong": r})
    # Bảng 2
    tn, cur, k2 = [], None, set()
    h2 = B[2] + 1
    c2 = cot_cua(ws, h2, 2)
    BR = tim_bang_vai_tro(ws)
    for f in (("hanh_dong",) if BR else ("hanh_dong", "vai_tro", "duoc_phep")):
        if f not in c2:
            CB.append(f"Bảng 2 (dòng {h2}): không thấy cột «{f}» theo tên cột")
    for r in range(h2 + 1, ket_thuc(2)):
        k, t = val(r, c2.get("key")), val(r, c2.get("ten"))
        if k or t:
            noi = o(r, c2.get("key") or c2.get("ten"))
            key, td = lay_key(k if la_key(k) else "", t or k, k2, "tài nguyên", noi)
            cur = {"key": key, "key_tu_dat": td, "ten": t or k, "o": noi, "thuoc_tinh": [], "hanh_dong": [], "vai_tro": [],
                   "_k_tt": set(), "_k_hd": set(), "_k_vt": set()}
            tn.append(cur)
        if cur is None:
            continue
        x = val(r, c2.get("thuoc_tinh"))
        if x:
            kk, kieu = key_mo_ta(x)
            key, td = lay_key(kk, ten_goc(x), cur["_k_tt"], f"thuộc tính của «{cur['ten']}»", o(r, c2["thuoc_tinh"]))
            cur["thuoc_tinh"].append({"key": key, "key_tu_dat": td, "ten": kk or ten_goc(x), "kieu": kieu if kk else trong_ngoac(x),
                                      "nguyen_van": x, "o": o(r, c2["thuoc_tinh"])})
        x = val(r, c2.get("hanh_dong"))
        if x:
            kk, mo = key_mo_ta(x)
            key, td = lay_key(kk, mo or x, cur["_k_hd"], f"hành động của «{cur['ten']}»", o(r, c2["hanh_dong"]))
            cur["hanh_dong"].append({"key": key, "key_tu_dat": td, "mo_ta": mo, "o": o(r, c2["hanh_dong"])})
        x = val(r, c2.get("vai_tro"))
        if x:
            kk, mo = key_mo_ta(x)
            key, td = lay_key(kk, mo or x, cur["_k_vt"], f"vai trò tài nguyên của «{cur['ten']}»", o(r, c2["vai_tro"]))
            dp = [cf(a) for a in re.split(r"[,;\n]", val(r, c2.get("duoc_phep"))) if cf(a)]
            cur["vai_tro"].append({"key": key, "key_tu_dat": td, "mo_ta": mo, "hanh_dong_goc": dp, "hanh_dong": [], "o": o(r, c2["vai_tro"]),
                                   "o_hanh_dong": o(r, c2["duoc_phep"]) if c2.get("duoc_phep") else ""})
    # bảng vai trò – hành động được phép đặt riêng: mỗi vai trò ghép với tài nguyên có nhiều hành động khớp nhất; hoà thì theo vị trí dòng
    GHEP_RIENG = {}
    if BR:
        rt, cv, cd = BR
        dong_tn = sorted((int(re.search(r"(\d+)$", t["o"]).group(1)), t) for t in tn)
        r = rt + 2
        while r <= ws.max_row and (val(r, cv) or val(r, cd)):
            x, dp = val(r, cv), [cf(a) for a in re.split(r"[,;\n]", val(r, cd)) if cf(a)]
            diem = [(len(ghep_hanh_dong(t, dp)[0]), t) for t in tn]
            cao = max(d for d, _ in diem) if diem else 0
            ung = [t for d, t in diem if d == cao and cao > 0]
            theo_dong = next((t for rr, t in reversed(dong_tn) if rr <= r), tn[0] if tn else None)
            t = ung[0] if len(ung) == 1 else (theo_dong if theo_dong in ung or not ung else ung[0])
            if t is None:
                break
            kk, mo = key_mo_ta(x)
            key, td = lay_key(kk, mo or x, t["_k_vt"], f"vai trò tài nguyên của «{t['ten']}»", o(r, cv))
            t["vai_tro"].append({"key": key, "key_tu_dat": td, "mo_ta": mo, "hanh_dong_goc": dp, "hanh_dong": [], "o": o(r, cv),
                                 "o_hanh_dong": o(r, cd), "bang_rieng": True})
            GHEP_RIENG.setdefault((t["ten"], "theo tên hành động được phép" if len(ung) == 1 else "theo vị trí dòng (khớp như nhau)"), []).append(f"«{mo or x}» ({o(r, cv)})")
            r += 1
    for (ten, cach), ds in GHEP_RIENG.items():
        CB.append(f"Bảng vai trò riêng (không ghi tài nguyên): {len(ds)} vai trò ghép với «{ten}» {cach}: {', '.join(ds)} — AI kiểm, BA rà")
    GAN = {}
    for t in tn:
        for f in ("_k_tt", "_k_hd", "_k_vt"):
            t.pop(f)
        for v in t["vai_tro"]:
            v["hanh_dong"], la, gan = ghep_hanh_dong(t, v["hanh_dong_goc"])
            for a, k in gan:
                GAN.setdefault((a.casefold(), k), []).append(v["mo_ta"] or v["key"])
            if la:
                CB.append(f"Bảng 2 {v['o_hanh_dong'] or v['o']}: vai trò «{v['mo_ta'] or v['key']}» của «{t['ten']}» được phép «{', '.join(la)}» nhưng không khớp hành động nào của tài nguyên")
        if not t["vai_tro"]:
            CB.append(f"Bảng 2 {t['o']}: tài nguyên «{t['ten']}» chưa có vai trò tài nguyên nào")
    for (a, k), vs in GAN.items():
        CB.append(f"Hành động được phép «{a}» ghép gần đúng với `{k}` ({len(vs)} vai trò) — AI kiểm")
    # Bảng 3
    qh, k3 = [], set()
    h3 = B[3] + 1
    c3 = cot_cua(ws, h3, 3)
    theo_ten = {}
    for t in tn:
        for nhan in (t["ten"], t["key"]):
            theo_ten[BK.khong_dau(nhan)] = t["key"]
    for r in range(h3 + 1, ket_thuc(3)):
        a, q, d = val(r, c3.get("chu_the")), val(r, c3.get("quan_he")), val(r, c3.get("dich"))
        if not (a or q or d):
            continue
        kk, mo = key_mo_ta(q)
        noi = f"{ten_sheet}!A{r}:{get_column_letter(max(c3.values()) if c3 else 3)}{r}"
        key, td = lay_key(kk, mo or q, k3, "quan hệ", noi)
        ak, dk = theo_ten.get(BK.khong_dau(a)), theo_ten.get(BK.khong_dau(d))
        if not ak or not dk:
            CB.append(f"Bảng 3 dòng {r}: «{a}» hoặc «{d}» không khớp tên / key tài nguyên nào ở Bảng 2")
        qh.append({"chu_the": a, "chu_the_key": ak, "key": key, "key_tu_dat": td, "mo_ta": mo, "dich": d, "dich_key": dk, "o": noi})
    bo = [f"Bảng {k} (dòng {r}): không đọc ở đây — đọc qua trich_xuat.py cùng các sheet khác" for k, r in sorted(B.items()) if k > 3]
    return {"sheet": ten_sheet, "dong_bang": B, "bang_vai_tro_rieng": ({"dong_tieu_de": BR[0], "cot_vai_tro": BR[1], "cot_duoc_phep": BR[2]} if BR else None), "vai_tro_he_thong": vt, "tai_nguyen": tn, "quan_he": qh, "key_tu_dat": TU_DAT, "canh_bao": CB, "bo_qua": bo}


def ghi_md(d, p):
    L = [f"# Mẫu 3 bảng — {d['tep']} › sheet «{d['sheet']}»", "",
         "3 bảng của sheet dưới đây; ghi `nguon` bằng đúng ô trong ngoặc vuông. Các sheet khác của tệp đọc qua trich_xuat.py.", ""]
    L += ["## Bảng 1 — vai trò hệ thống", ""]
    L += [f"- [{v['o']}] `{v['key']}` {v['ten']} — tầng việc / chức danh: {v['tang_viec'] or '—'}" + (f" — ghi chú: {v['ghi_chu']}" if v["ghi_chu"] else "") for v in d["vai_tro_he_thong"]] or ["- (trống)"]
    L += ["", "## Bảng 2 — tài nguyên", ""]
    for t in d["tai_nguyen"]:
        L += [f"### [{t['o']}] `{t['key']}` {t['ten']}", ""]
        L += ["- Thuộc tính: " + (", ".join(f"`{x['key']}` ({x['kieu']}) [{x['o']}]" for x in t["thuoc_tinh"]) or "—")]
        L += ["- Hành động:"] + [f"  - [{h['o']}] `{h['key']}` {h['mo_ta']}" for h in t["hanh_dong"]]
        L += ["- Vai trò tài nguyên → hành động được phép:"] + [f"  - [{v['o']}] `{v['key']}` {v['mo_ta']} → {', '.join(v['hanh_dong']) or '—'} [{v['o_hanh_dong']}]" for v in t["vai_tro"]]
        L.append("")
    L += ["## Bảng 3 — quan hệ", ""]
    L += [f"- [{q['o']}] {q['chu_the']} —`{q['key']}` ({q['mo_ta']})→ {q['dich']}" for q in d["quan_he"]] or ["- (trống)"]
    L += ["", "## Key do AI đặt (sheet không ghi key)", "",
          "Đặt từ tên: phần trước ngoặc, bỏ dấu, chữ thường, nối «_». Phân hệ có quy ước đặt key riêng thì AI sửa theo quy ước đó trong đặc tả.", ""]
    L += [f"- [{x['o']}] {x['loai']}: «{x['ten']}» → `{x['key']}`" for x in d.get("key_tu_dat", [])] or ["- Không có (sheet đã ghi key)."]
    L += ["", "## Cảnh báo", ""] + ([f"- {x}" for x in d["canh_bao"]] or ["- Không có."])
    L += ["", "## Đọc ở chỗ khác (trich_xuat.py)", ""] + ([f"- {x}" for x in d["bo_qua"]] or ["- Không có."])
    open(p, "w", encoding="utf-8").write("\n".join(L) + "\n")


def tao(p):
    wb = openpyxl.Workbook()
    ws = wb.active; ws.title = "Phân quyền"
    dam, nen = Font(bold=True), PatternFill("solid", fgColor="DDEBF7")
    r = 1
    for so, so_dong in ((1, 6), (2, 20), (3, 8)):
        ws.cell(r, 1, TIEU_DE_BANG[so]).font = Font(bold=True, size=12)
        r += 1
        for i, h in enumerate(TEN_COT[so], 1):
            c = ws.cell(r, i, h); c.font = dam; c.fill = nen; c.alignment = Alignment(wrap_text=True, vertical="top")
        r += so_dong + 2
    for i, w in enumerate((8, 24, 30, 34, 34, 34, 40), 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    hd = wb.create_sheet("Hướng dẫn")
    for i, s in enumerate([
        "Mẫu đầu vào phân quyền — 3 bảng (dùng chung mọi phân hệ)",
        "Giữ nguyên dòng tiêu đề «Bảng 1 / 2 / 3» và dòng tên cột; thêm dòng dữ liệu ngay dưới tên cột. Có thể chèn thêm dòng.",
        "Bảng 1: mỗi dòng một vai trò hệ thống (tên, các tầng việc / chức danh thuộc vai trò, ghi chú). Cột key có thể để trống: AI đặt key từ tên.",
        "Bảng 2: mỗi tài nguyên một khối dòng. Dòng đầu ghi key và tên tài nguyên; các dòng dưới để trống cột key, tên.",
        "  - Thuộc tính: mỗi ô một thuộc tính, dạng «key (KIỂU)», ví dụ «status (ENUM)»; ghi giá trị trong CSDL nếu có, ví dụ «status (ENUM: DRAFT, APPROVED)».",
        "  - Hành động: mỗi ô một hành động, dạng «key (mô tả)» hoặc chỉ ghi tên; mỗi thao tác một hành động.",
        "  - Vai trò: mỗi ô một vai trò trên tài nguyên, dạng «key (mô tả)» hoặc chỉ ghi tên; cột cuối liệt kê hành động được phép (key hoặc đúng tên ở cột Hành động), cách nhau bởi dấu phẩy.",
        "  - Cây đơn vị (nếu dùng) khai như một tài nguyên; quyền xem cây do Cổng quản lý.",
        "Bảng 3: mỗi dòng một quan hệ: tài nguyên chủ thể, «key (mô tả)» của quan hệ, tài nguyên đích (ghi đúng tên ở Bảng 2).",
        "Ai giữ vai trò nào, phạm vi, điều kiện: skill suy ra từ 3 bảng và tài liệu nghiệp vụ gửi kèm (quy trình, bảng chức năng), đánh dấu «AI suy ra» để BA rà trên bản xem trước.",
    ], 1):
        hd.cell(i, 1, s).font = Font(bold=(i == 1))
    hd.column_dimensions["A"].width = 140
    wb.save(p)
    print(f"Đã tạo {p}")


def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(2)
    lenh = sys.argv[1]
    if lenh == "tao":
        tao(sys.argv[2]); return
    if lenh == "tim":
        wb = openpyxl.load_workbook(sys.argv[2], data_only=True)
        print(json.dumps([ws.title for ws in wb.worksheets if la_mau(ws)], ensure_ascii=False)); return
    if lenh == "doc":
        lv, tep = sys.argv[2], sys.argv[3]
        sh = sys.argv[sys.argv.index("--sheet") + 1] if "--sheet" in sys.argv else None
        wb = openpyxl.load_workbook(tep, data_only=True)
        ds = [ws for ws in wb.worksheets if (ws.title == sh if sh else la_mau(ws))]
        if not ds:
            print(f"Không thấy sheet có đủ Bảng 1, 2, 3{' tên «' + sh + '»' if sh else ''} trong {tep}"); sys.exit(1)
        if len(ds) > 1:
            print("Nhiều sheet có đủ 3 bảng, chọn bằng --sheet: " + json.dumps([w.title for w in ds], ensure_ascii=False)); sys.exit(1)
        d = doc_sheet(ds[0], ds[0].title)
        d["tep"] = os.path.basename(tep)
        d["duong_dan"] = os.path.abspath(tep)   # để doi_chieu_ba_bang.py chép lại tệp gốc khi xuất Excel cuối
        d["sheet_khac"] = [w.title for w in wb.worksheets if w.title != ds[0].title]
        os.makedirs(lv, exist_ok=True)
        json.dump(d, open(os.path.join(lv, "ba_bang.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        ghi_md(d, os.path.join(lv, "ba_bang.md"))
        print(f"sheet «{d['sheet']}»: {len(d['vai_tro_he_thong'])} vai trò hệ thống · {len(d['tai_nguyen'])} tài nguyên · "
              f"{sum(len(t['vai_tro']) for t in d['tai_nguyen'])} vai trò tài nguyên · {len(d['quan_he'])} quan hệ · {len(d['key_tu_dat'])} key do AI đặt · {len(d['canh_bao'])} cảnh báo"
              f" · bỏ qua {len(d['bo_qua'])} bảng khác, {len(d['sheet_khac'])} sheet khác → ba_bang.json, ba_bang.md")
        for x in d["canh_bao"]:
            print("  cảnh báo:", x)
        return
    print(__doc__); sys.exit(2)


if __name__ == "__main__":
    main()
