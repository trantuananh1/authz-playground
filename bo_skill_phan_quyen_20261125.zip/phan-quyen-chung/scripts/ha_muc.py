# -*- coding: utf-8 -*-
"""Chuẩn bị quyền mức danh sách trước khi xuất (dùng chung cho xuat_json.py và xuat_dsl.py).

Mục tiêu: không quyền nào được cấp rộng hơn thiết kế. Quyền mức danh sách (NT-07) nếu để ở vai trò chung thì
hệ phân quyền trả «được» cho MỌI bản ghi, nên chia theo loại:

- «doc» (xuất danh sách, xuất tệp, tải xuống danh sách dữ liệu): theo KT-02 tệp xuất chỉ gồm bản ghi được xem →
  HẠ xuống mức bản ghi, theo đúng phạm vi xem của chính vai trò đó trên tài nguyên đó; điều kiện = điều kiện xem ∪
  điều kiện xuất. Áp cho mọi quyền xuất, có hay không có điều kiện. Vai trò không có quyền xem trên tài nguyên:
  KHÔNG CẤP (tệp xuất của vai trò này luôn rỗng theo KT-02), báo cáo nêu.
- «tao» (thêm mới, nhập danh sách): chưa có bản ghi → xuat_json.py kiểm trên nút cây nơi bản ghi mới gắn vào
  (vai trò theo đơn vị) hoặc biến thể hành động theo điều kiện (vai trò toàn hệ thống).
- «khac» (tải tệp mẫu…): không đọc, không ghi dữ liệu bản ghi → giữ ở vai trò chung.
"""
import bo_key as BK

LOAI_XUAT_DS = ("xuat", "xuat_file", "tai_xuong_ds")


def _h(HD, rk, hd):
    return HD.get((rk, hd)) or {}


def loai_muc_ds(HD, rk, hd):
    """Loại của một hành động mức danh sách: «doc» | «tao» | «khac»."""
    h = _h(HD, rk, hd)
    lo = h.get("loai") or BK.loai_hanh_dong(hd)
    tach = BK.loai_hanh_dong(h.get("tach_tu") or "") if h.get("tach_tu") else None
    if lo in ("xuat", "xuat_file"):
        return "doc"
    if lo == "tai_xuong_ds":
        return "khac" if tach in BK.LOAI_NHAP else "doc"      # tải tệp mẫu tách từ «nhập danh sách»: không có dữ liệu bản ghi
    nhom = h.get("nhom") or (BK.HANH_DONG.get(lo) or (None, None, None))[2]
    if nhom == "them_moi" or lo in BK.LOAI_NHAP:
        return "tao"
    return "khac"


def ha_muc(HL, D, kieu_pv):
    """HL: quyền hiệu lực. kieu_pv(k): kiểu phạm vi. Trả (HL mới, [ghi chú]).
    Quyền đã hạ mang `ha_muc` = {"tu": phạm vi cũ, "theo_xem": khoá quyền xem làm căn cứ}.
    Ghi chú: ("ha", q, q_xem) | ("khong_cap", q, lý do)."""
    HD = {(t["key"], h["key"]): h for t in D["tai_nguyen"] for h in t["hanh_dong"]}
    DK = {d["key"] for d in D.get("dieu_kien", [])}
    xem = {}
    for q in HL:
        if (_h(HD, q["tai_nguyen"], q["hanh_dong"]).get("loai") or BK.loai_hanh_dong(q["hanh_dong"])) in BK.LOAI_XEM_BAN_GHI \
                and kieu_pv(q["pham_vi"]) != "danh_sach":
            xem.setdefault((q["vai_tro"], q["tai_nguyen"]), []).append(q)
    out, ghi = [], []
    for q in HL:
        if not (kieu_pv(q["pham_vi"]) == "danh_sach" and loai_muc_ds(HD, q["tai_nguyen"], q["hanh_dong"]) == "doc"):
            out.append(q); continue
        dks = [d for d in q["dieu_kien"] if d in DK]
        ds = xem.get((q["vai_tro"], q["tai_nguyen"]), [])
        if not ds:
            ghi.append(("khong_cap", q, "vai trò không có quyền xem trên tài nguyên (KT-02: tệp xuất chỉ gồm bản ghi được xem)")); continue
        da = set()
        for qx in ds:
            dk = list(dict.fromkeys([d for d in qx["dieu_kien"] if d in DK] + dks))
            k = (qx["pham_vi"], tuple(dk))
            if k in da:
                continue
            da.add(k)
            out.append(dict(q, pham_vi=qx["pham_vi"], dieu_kien=dk, ha_muc={"tu": q["pham_vi"], "theo_xem": qx.get("khoa")}))
            ghi.append(("ha", q, qx))
    return out, ghi
