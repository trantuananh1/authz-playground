# -*- coding: utf-8 -*-
"""Đối chiếu thiết kế phân quyền với mẫu 3 bảng BA gửi, và xuất Excel cuối giữ đúng định dạng 3 bảng, tô màu chỗ thay đổi.

  python -I doi_chieu_ba_bang.py anh-xa   <lv>
        lập / bổ sung <lv>/anh_xa_ba_bang.json: mỗi tài nguyên, thuộc tính, hành động, vai trò tài nguyên (Bảng 2) và quan hệ
        (Bảng 3) ứng với key nào của thiết kế. Mục đã ghi tay được giữ nguyên. Mục công cụ chưa ghép được ghi `null` và liệt kê
        để AI điền: key thiết kế (hoặc danh sách key), "" / [] nghĩa là thiết kế bỏ mục đó có chủ ý. Thoát mã 1 khi còn mục `null`.
  python -I doi_chieu_ba_bang.py thay-doi <lv>
        → <lv>/thay_doi.json, <lv>/thay_doi.md: danh sách thay đổi của thiết kế so với 3 bảng (thêm, sửa, bỏ, kèm căn cứ,
        đánh dấu AI suy ra). xac_nhan.py xem-truoc đọc thay_doi.json để hiện mục «So với 3 bảng đầu vào». Không cần xác nhận.
  python -I doi_chieu_ba_bang.py excel    <lv> [--tep <xlsx gốc>] [--ra <tệp ra>] [--ban-sach] [--chua-xac-nhan]
        chép tệp Excel gốc, viết lại Bảng 2, Bảng 3 (và key AI đặt ở Bảng 1) của sheet 3 bảng theo thiết kế ĐÃ XÁC NHẬN,
        giữ nguyên tên cột, thứ tự cột, kiểu ô, ô gộp; Bảng 4 trở đi và các sheet khác giữ nguyên (dời xuống nếu cần).
        Tô màu: xanh = thêm, vàng = sửa (đổi key, tách, đổi hành động được phép), đỏ gạch ngang = bỏ; ô thay đổi có ghi chú
        (comment) nêu bản gốc và căn cứ. Thêm sheet «Thay đổi» (kèm chú thích màu) và «Phạm vi, điều kiện».
        → <lv>/<tên tệp gốc>_phan_quyen_cuoi.xlsx. --ban-sach: thêm bản không màu, không ghi chú, không dòng bỏ
        (<…>_phan_quyen_cuoi_ban_sach.xlsx) để đưa thẳng vào tài liệu. --chua-xac-nhan: chỉ để thử, tên tệp có «_NHAP».

Quyền trong Excel là quyền hiệu lực của thiết kế (đã áp ý kiến rà soát), cùng nguồn với JSON import và DSL.
Ô «Hành động được phép» chỉ ghi key hành động cách nhau bởi dấu phẩy, nên bản cuối vẫn đọc lại được bằng ba_bang.py.
"""
import argparse, collections, copy, json, os, re, shutil, sys

import openpyxl
from openpyxl.cell.rich_text import CellRichText, TextBlock
from openpyxl.cell.text import InlineFont
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bo_key as BK  # noqa: E402
import ba_bang as BB  # noqa: E402
from xac_nhan import TK, doc, ghi_json  # noqa: E402

MAU = {"them": "E2EFDA", "sua": "FFF2CC", "bo": "FCE4D6"}
CHU_DO, CHU_XANH = "C00000", "00804A"
TEN_LOAI = {"them": "Thêm", "sua": "Sửa", "bo": "Bỏ"}
KIEU_EXCEL = {"chuoi": "STRING", "so": "NUMBER", "dung_sai": "BOOLEAN", "ngay": "DATE", "danh_sach": "LIST"}
cf = BB.cf


def nhac(k, s):
    """Chuỗi s có nhắc key k như một từ riêng (không phải một phần của key khác)."""
    return bool(k) and re.search(rf"(?<![a-z0-9_]){re.escape(k)}(?![a-z0-9_])", str(s or "")) is not None


def la_suy_ra(nguon):
    return any(str(n.get("vt", "") if isinstance(n, dict) else n).startswith(BK.SUY_RA) for n in (nguon or []))


def mo_ta_ngan(s, toi_da=70):
    s = re.sub(r"^\s*AI suy ra\s*:\s*", "", cf(s))
    s = re.split(r"\s\(|\s[–-]\s|;", s, 1)[0] if len(s) > toi_da else s
    return s[:toi_da]


# ======================================================================================== ánh xạ
def lap_anh_xa(lv, in_ra=True):
    B = doc(os.path.join(lv, "ba_bang.json"))
    D = doc(os.path.join(lv, "thiet_ke_phan_quyen.json"))
    if not B:
        sys.exit(f"Chưa có {lv}/ba_bang.json — đầu vào không phải mẫu 3 bảng, hoặc chưa chạy ba_bang.py doc.")
    if not D:
        sys.exit(f"Chưa có {lv}/thiet_ke_phan_quyen.json — chạy lap_thiet_ke.py trước.")
    p = os.path.join(lv, "anh_xa_ba_bang.json")
    cu = doc(p, {}) or {}
    TN = {t["key"]: t for t in D["tai_nguyen"]}
    keys_b1 = {v["key"] for v in B.get("vai_tro_he_thong", [])}
    co_quyen = collections.defaultdict(set)
    for q in D["quyen"]:
        co_quyen[q["tai_nguyen"]].add(q["vai_tro"])
    M = {k: dict(cu.get(k, {})) for k in ("tai_nguyen", "thuoc_tinh", "hanh_dong", "vai_tro", "quan_he")}

    def dat(muc, k, gt):
        if k not in M[muc] or M[muc][k] is None:
            M[muc][k] = gt

    for t in B["tai_nguyen"]:
        if t["key"] in TN:
            g = t["key"]
        else:
            ds = [d["key"] for d in D["tai_nguyen"] if nhac(t["key"], d.get("mo_ta"))]
            ds = ds or [d["key"] for d in D["tai_nguyen"] if BK.khong_dau(d["ten"]).startswith(BK.khong_dau(t["ten"]))]
            g = ds[0] if len(ds) == 1 else None
        dat("tai_nguyen", t["key"], g)
        d = TN.get(M["tai_nguyen"][t["key"]] or "")
        if not d or not d.get("hanh_dong"):
            continue                      # tài nguyên bỏ, hoặc cây đơn vị lấy từ Cổng: giữ nguyên khối, không cần ghép chi tiết
        for a in t["thuoc_tinh"]:
            g = next((x["key"] for x in d.get("thuoc_tinh", []) if x["key"] == a["key"]), None)
            g = g or next((x["key"] for x in d.get("thuoc_tinh", []) if nhac(a["key"], x.get("y_nghia"))), None)
            g = g or next((x["key"] for x in d.get("thuoc_tinh", []) if a["key"] in BK.THUOC_TINH.get(x["key"], ("", "", []))[2]), None)
            dat("thuoc_tinh", f"{t['key']}.{a['key']}", g or "")      # thuộc tính không dùng trong điều kiện: giữ nguyên dòng
        for h in t["hanh_dong"]:
            g = [x["key"] for x in d["hanh_dong"] if x["key"] == h["key"] or x.get("tach_tu") == h["key"]]
            if not g and h["key"] in ("xem_ds", "xem_ct") and any(x["key"] == "xem" for x in d["hanh_dong"]):
                g = ["xem"]
            dat("hanh_dong", f"{t['key']}.{h['key']}", g or None)
        for v in t["vai_tro"]:
            ung = [r for r in D["vai_tro"] if r["key"] in co_quyen[d["key"]]]
            g = [r["key"] for r in ung if r["key"] == v["key"]]
            g = g or [r["key"] for r in ung if re.search(rf"vai trò\s+`?{re.escape(v['key'])}`?(?![a-z0-9_])",
                                                         " ".join([r.get("mo_ta", ""), (r.get("co_so") or {}).get("ly_do", "")]))]
            if not g and v["key"] not in keys_b1:
                g = [r["key"] for r in ung if nhac(v["key"], r.get("mo_ta"))]
            dat("vai_tro", f"{t['key']}.{v['key']}", g or None)
    qh_tk = [(t["key"], q) for t in D["tai_nguyen"] for q in t.get("quan_he", []) if "__" not in q["key"]]
    for q in B["quan_he"]:
        cap = {M["tai_nguyen"].get(q.get("chu_the_key") or ""), M["tai_nguyen"].get(q.get("dich_key") or "")}
        ds = [(tk, x) for tk, x in qh_tk if x["key"] == q["key"] or nhac(q["key"], x.get("y_nghia"))]
        ds = [c for c in ds if {c[0], c[1]["toi"]} == cap] or ds
        dat("quan_he", q["key"], f"{ds[0][0]}.{ds[0][1]['key']}" if len(ds) == 1 else None)

    chua = [f"{muc}: {k}" for muc, m in M.items() for k, g in m.items() if g is None]
    M["_huong_dan"] = ("Key mẫu 3 bảng → key thiết kế. tai_nguyen: key; thuoc_tinh «tn.key»: key ('' = không dùng trong phân quyền, giữ nguyên dòng); "
                       "hanh_dong «tn.key»: [key] ([] = bỏ); vai_tro «tn.key»: [vai trò thiết kế] ([] = bỏ); quan_he: «tn_thiet_ke.key» ('' = bỏ). "
                       "null = công cụ chưa ghép được, AI điền. Mục ghi tay được giữ khi chạy lại anh-xa.")
    M["chua_ghep"] = chua
    ghi_json(p, M)
    if in_ra:
        print(f"anh_xa_ba_bang.json: {sum(len(m) for k, m in M.items() if isinstance(m, dict))} mục · {len(chua)} chưa ghép")
        for x in chua:
            print("  chưa ghép:", x)
    return M, chua


# ======================================================================================== kế hoạch thay đổi
class KeHoach:
    """Dựng nội dung mới của Bảng 1–3 (theo dòng, kèm loại thay đổi) và danh sách thay đổi."""

    def __init__(self, lv):
        self.lv = lv
        self.B = doc(os.path.join(lv, "ba_bang.json"))
        self.M, self.chua = lap_anh_xa(lv, in_ra=False)
        self.T = TK(lv)
        D = self.D = self.T.D
        self.TN = {t["key"]: t for t in D["tai_nguyen"]}
        self.VT = {v["key"]: v for v in D["vai_tro"]}
        self.HL = self.T.hieu_luc()
        self.QHL = collections.defaultdict(list)     # (vai trò, tài nguyên) → [quyền hiệu lực]
        for q in self.HL:
            self.QHL[(q["vai_tro"], q["tai_nguyen"])].append(q)
        self.KHL = {q["khoa"] for q in self.HL}
        self.QALL = {(q["vai_tro"], q["tai_nguyen"], q["hanh_dong"]): q for q in D["quyen"]}
        self.TD = []                                   # thay đổi
        self.b1, self.b2, self.b3 = [], [], []

    # ---------- tiện ích ----------
    def o(self, x):
        return x.get("o", "") if isinstance(x, dict) else ""

    def ghi(self, bang, loai, muc, tai_nguyen, o, cu, moi, can_cu="", suy_ra=False):
        self.TD.append({"bang": bang, "loai": loai, "muc": muc, "tai_nguyen": tai_nguyen, "o": o, "cu": cu, "moi": moi,
                        "can_cu": can_cu, "suy_ra": bool(suy_ra)})

    def hd_hl(self, vt, tn):
        """Hành động hiệu lực của vai trò trên tài nguyên, theo thứ tự hành động của thiết kế."""
        co = {q["hanh_dong"] for q in self.QHL[(vt, tn)]}
        return [h["key"] for h in self.TN[tn]["hanh_dong"] if h["key"] in co]

    def can_cu_quyen(self, vt, tn, hd):
        q = self.QALL.get((vt, tn, hd))
        if not q:
            return "Không có trong thiết kế đã xác nhận", False
        if self.T.ket_qua(q) == "khong_dong_y":
            return "BA không đồng ý khi rà soát bản xem trước", False
        if q["khoa"] not in self.KHL and q.get("trang_thai") == "bo":
            qt = next((r for r in q.get("quy_tac", []) if r.get("loai") in ("loc_vai_tro", "theo_cap_duyet")), None)
            return (qt or {}).get("ly_do", "Bỏ theo tài liệu / BA chốt"), la_suy_ra((qt or {}).get("nguon"))
        qt = [r for r in q.get("quy_tac", []) if r.get("loai") in ("bo_sung", "hanh_dong", "tac_nhan")]
        sr = any(la_suy_ra(r.get("nguon")) for r in q.get("quy_tac", []))
        ba = [n for r in q.get("quy_tac", []) for n in r.get("nguon", []) if str(n).startswith("BA chốt")]
        ly = (qt[0]["ly_do"] if qt else "") or "Theo tài liệu"
        return (f"{ly} ({', '.join(sorted(set(ba)))})" if ba else ly), sr

    @staticmethod
    def o_moi(v, loai=None, ghi_chu="", giau=None):
        """Một ô của dòng mới: giá trị, loại thay đổi (them/sua/bo/None), ghi chú; giau: danh sách (chữ, loại) cho rich text."""
        return {"v": v, "loai": loai, "ghi_chu": ghi_chu, "giau": giau}

    # ---------- Bảng 1 ----------
    def bang_1(self):
        for v in self.B.get("vai_tro_he_thong", []):
            dong = {"dong": v.get("dong"), "o": {}}
            if v.get("key_tu_dat"):
                dong["o"]["key"] = self.o_moi(v["key"], "sua", f"Bảng gốc để trống key; AI đặt key «{v['key']}» từ tên «{v['ten']}».")
                self.ghi(1, "sua", "key vai trò hệ thống", "", v["o"], "", v["key"], "AI đặt key từ tên", True)
            self.b1.append(dong)

    # ---------- Bảng 2 ----------
    def bang_2(self):
        da_ghep = set()
        for t in self.B["tai_nguyen"]:
            dk = self.M["tai_nguyen"].get(t["key"])
            d = self.TN.get(dk or "")
            if d:
                da_ghep.add(d["key"])
            self.b2.append(self.khoi(t, d))
        for d in self.D["tai_nguyen"]:
            if d["key"] not in da_ghep and d.get("hanh_dong"):
                self.b2.append(self.khoi(None, d))

    def khoi(self, t, d):
        """Một khối tài nguyên của Bảng 2: {goc: dòng đầu / số dòng gốc, dong: [ {truong: ô} ]}."""
        K = {"tn": t, "d": d, "dong_tn": {}, "tt": [], "hd": [], "vt": []}
        ten_tn = (t or d)["ten"]
        if t is None:                                   # tài nguyên thiết kế thêm
            K["dong_tn"] = {"key": self.o_moi(d["key"], "them", f"Tài nguyên thiết kế thêm: {d.get('mo_ta', '')}"),
                            "ten": self.o_moi(d["ten"], "them")}
            self.ghi(2, "them", "tài nguyên", d["ten"], "", "", d["key"], d.get("mo_ta", ""))
            goc_tt, goc_hd, goc_vt = [], [], []
        else:
            goc_tt, goc_hd, goc_vt = t["thuoc_tinh"], t["hanh_dong"], t["vai_tro"]
        if t is not None and d is None:                 # thiết kế bỏ tài nguyên
            ly = "Thiết kế không có tài nguyên này (anh_xa_ba_bang.json ghi bỏ)"
            K["dong_tn"] = {"key": self.o_moi(t["key"], "bo", ly), "ten": self.o_moi(t["ten"], "bo")}
            K["tt"] = [self.o_moi(a["nguyen_van"], "bo") for a in goc_tt]
            K["hd"] = [self.o_moi(self.nhan_goc(h), "bo") for h in goc_hd]
            K["vt"] = [(self.o_moi(self.nhan_goc(v), "bo"), self.o_moi(", ".join(v["hanh_dong"]), "bo")) for v in goc_vt]
            self.ghi(2, "bo", "tài nguyên", t["ten"], t["o"], t["key"], "", ly)
            return K
        if t is not None and d["key"] != t["key"]:
            gc = f"Bảng gốc: {t['key']}. Thiết kế dùng key «{d['key']}»" + (" (cây đơn vị lấy từ Cổng)." if d.get("tu_cong") else ".")
            K["dong_tn"]["key"] = self.o_moi(d["key"], "sua", gc)
            self.ghi(2, "sua", "key tài nguyên", ten_tn, t["o"], t["key"], d["key"], gc)
        if t is not None and not d.get("hanh_dong"):    # cây đơn vị lấy từ Cổng: giữ nguyên các dòng
            K["giu_nguyen"] = True
            return K
        # thuộc tính
        dung = set()
        for a in goc_tt:
            g = self.M["thuoc_tinh"].get(f"{t['key']}.{a['key']}") or ""
            if g and g != a["key"]:
                x = next(x for x in d["thuoc_tinh"] if x["key"] == g)
                kieu = a.get("kieu") or KIEU_EXCEL.get(x.get("kieu"), "")
                gc = f"Bảng gốc: {a['nguyen_van']}. Thiết kế dùng key «{g}»: {x.get('y_nghia', '')}"
                K["tt"].append(self.o_moi(f"{g} ({kieu})" if kieu else g, "sua", gc))
                self.ghi(2, "sua", "thuộc tính", ten_tn, a["o"], a["nguyen_van"], g, x.get("y_nghia", ""))
            else:
                K["tt"].append(self.o_moi(a["nguyen_van"]))
            if g:
                dung.add(g)
        for x in d.get("thuoc_tinh", []):
            if x["key"] not in dung:
                gc = f"Thuộc tính thiết kế thêm: {x.get('y_nghia', '')}"
                K["tt"].append(self.o_moi(f"{x['key']} ({KIEU_EXCEL.get(x.get('kieu'), x.get('kieu', ''))})", "them", gc))
                self.ghi(2, "them", "thuộc tính", ten_tn, "", "", x["key"], x.get("y_nghia", ""), BK.SUY_RA in x.get("y_nghia", ""))
        # hành động
        HD = {h["key"]: h for h in d["hanh_dong"]}
        da = set()
        for h in goc_hd:
            g = self.M["hanh_dong"].get(f"{t['key']}.{h['key']}") or []
            moi = [k for k in g if k in HD and k not in da]
            if not g:
                ly = "Thiết kế bỏ hành động này (anh_xa_ba_bang.json)"
                K["hd"].append(self.o_moi(self.nhan_goc(h), "bo", ly))
                self.ghi(2, "bo", "hành động", ten_tn, h["o"], h["key"], "", ly)
                continue
            if not moi:                                 # đã gộp vào hành động hiện ở dòng trên (xem_ds + xem_ct → xem)
                ly = f"Gộp vào «{', '.join(g)}» (xem danh sách và xem chi tiết là một hành động)"
                K["hd"].append(self.o_moi(self.nhan_goc(h), "bo", ly))
                self.ghi(2, "sua", "hành động", ten_tn, h["o"], h["key"], ", ".join(g), ly)
                continue
            for k in moi:
                da.add(k)
                if moi == [h["key"]] and len(g) == 1:
                    K["hd"].append(self.o_moi(self.nhan_goc(h)))
                    continue
                gop = [x["key"] for x in goc_hd if k in (self.M["hanh_dong"].get(f"{t['key']}.{x['key']}") or [])]
                ly = (f"Tách từ «{h['key']}» ({h['mo_ta']}): mỗi thao tác một hành động" if HD[k].get("tach_tu") == h["key"] or len(g) > 1
                      else f"Gộp {', '.join(gop)} thành «{k}»" if len(gop) > 1 else f"Bảng gốc: {h['key']}. Thiết kế dùng key «{k}»")
                K["hd"].append(self.o_moi(f"{k} ({HD[k]['ten']})", "them" if k != moi[0] and len(moi) > 1 else "sua", ly))
                self.ghi(2, "sua", "hành động", ten_tn, h["o"], h["key"], k, ly)
        for k, h in HD.items():
            if k not in da:
                ly = "Hành động thiết kế thêm"
                K["hd"].append(self.o_moi(f"{k} ({h['ten']})", "them", ly))
                self.ghi(2, "them", "hành động", ten_tn, "", "", k, ly)
        # vai trò tài nguyên
        da_vt = set()
        for v in goc_vt:
            g = self.M["vai_tro"].get(f"{t['key']}.{v['key']}") or []
            goc_map = []
            for x in v["hanh_dong"]:
                for k in self.M["hanh_dong"].get(f"{t['key']}.{x}") or []:
                    if k not in goc_map:
                        goc_map.append(k)
            if not g:
                ly = "Thiết kế không có vai trò tương ứng (anh_xa_ba_bang.json ghi bỏ)"
                K["vt"].append((self.o_moi(self.nhan_goc(v), "bo", ly), self.o_moi(", ".join(v["hanh_dong"]), "bo")))
                self.ghi(2, "bo", "vai trò tài nguyên", ten_tn, v["o"], v["key"], "", ly)
                continue
            for i, rk in enumerate(g):
                if rk in da_vt:
                    ly = f"Gộp vào vai trò «{rk}» ở dòng trên"
                    K["vt"].append((self.o_moi(self.nhan_goc(v), "bo", ly), self.o_moi(", ".join(v["hanh_dong"]), "bo")))
                    self.ghi(2, "sua", "vai trò tài nguyên", ten_tn, v["o"], v["key"], rk, ly)
                    continue
                da_vt.add(rk)
                K["vt"].append(self.dong_vai_tro(d, rk, v, goc_map, "them" if i > 0 else None))
        for rk in [r["key"] for r in self.D["vai_tro"] if self.QHL.get((r["key"], d["key"]))]:
            if rk not in da_vt:
                K["vt"].append(self.dong_vai_tro(d, rk, None, [], "them"))
        return K

    def dong_vai_tro(self, d, rk, v, goc_map, loai_tach):
        r = self.VT[rk]
        ten_tn = d["ten"]
        sr = la_suy_ra((r.get("co_so") or {}).get("nguon"))
        nguoi = r.get("mo_ta", "")
        if v is None:
            c_vt = self.o_moi(f"{rk} ({r['ten']})", "them", f"Vai trò thiết kế thêm. Người giữ: {nguoi}")
            self.ghi(2, "them", "vai trò tài nguyên", ten_tn, "", "", rk, nguoi, sr)
        elif rk == v["key"]:
            c_vt = self.o_moi(self.nhan_goc(v))
        else:
            loai = loai_tach or "sua"
            gc = f"Bảng gốc: {self.nhan_goc(v)}. " + ("Tách thành nhiều vai trò thiết kế. " if loai == "them" else "") + f"Người giữ: {nguoi}"
            c_vt = self.o_moi(f"{rk} ({r['ten']})", loai, gc)
            self.ghi(2, loai, "vai trò tài nguyên", ten_tn, v["o"], v["key"], rk, nguoi, sr)
        moi = self.hd_hl(rk, d["key"])
        them = [k for k in moi if k not in goc_map]
        bo = [k for k in goc_map if k not in moi]
        if v is None:
            c_hd = self.o_moi(", ".join(moi), "them")
            return (c_vt, c_hd)
        moi_dong = c_vt["loai"] == "them"           # dòng tách thêm: cả hai ô tô xanh
        if not them and not bo:
            if goc_map == v["hanh_dong"]:           # cùng key: giữ nguyên chữ của ô gốc
                return (c_vt, self.o_moi(", ".join(v["hanh_dong_goc"]), "them" if moi_dong else None))
            return (c_vt, self.o_moi(", ".join(moi), "them" if moi_dong else "sua",
                                     f"Bảng gốc: {', '.join(v['hanh_dong_goc'])}. Đổi key hành động theo cột Hành động (tách / gộp)."))
        dong_gc, giau = [f"Bảng gốc: {', '.join(v['hanh_dong_goc'])}."], []
        for k in moi:
            giau.append((k, "them" if k in them else None))
        for k in bo:
            giau.append((k, "bo"))
        for k in them:
            cc, s = self.can_cu_quyen(rk, d["key"], k)
            dong_gc.append(f"+ {k}: {cc}")
            self.ghi(2, "them", "hành động được phép", ten_tn, v.get("o_hanh_dong", ""), f"{rk}: —", f"{rk}: {k}", cc, s)
        for k in bo:
            cc, s = self.can_cu_quyen(rk, d["key"], k)
            dong_gc.append(f"− {k}: {cc}")
            self.ghi(2, "bo", "hành động được phép", ten_tn, v.get("o_hanh_dong", ""), f"{rk}: {k}", f"{rk}: —", cc, s)
        c_hd = self.o_moi(", ".join(moi), "them" if moi_dong else "sua", "\n".join(dong_gc), giau)
        return (c_vt, c_hd)

    @staticmethod
    def nhan_goc(x):
        return f"{x['key']} ({x['mo_ta']})" if x.get("mo_ta") else x["key"]

    # ---------- Bảng 3 ----------
    def bang_3(self):
        ten_b = {}
        for t in self.B["tai_nguyen"]:
            g = self.M["tai_nguyen"].get(t["key"])
            if g:
                ten_b.setdefault(g, t["ten"])
        ten = lambda k: ten_b.get(k) or self.TN.get(k, {}).get("ten", k)
        da, huong = set(), []
        for q in self.B["quan_he"]:
            g = self.M["quan_he"].get(q["key"]) or ""
            if not g:
                ly = "Thiết kế không dùng quan hệ này (anh_xa_ba_bang.json ghi bỏ)"
                self.b3.append({"goc": q, "o": {"chu_the": self.o_moi(q["chu_the"], "bo", ly), "quan_he": self.o_moi(self.nhan_goc(q), "bo"),
                                                "dich": self.o_moi(q["dich"], "bo")}})
                self.ghi(3, "bo", "quan hệ", "", q["o"], q["key"], "", ly)
                continue
            da.add(g)
            tk, rk = g.split(".", 1)
            x = next((x for x in self.TN[tk].get("quan_he", []) if x["key"] == rk), {"key": rk, "toi": tk, "y_nghia": ""})
            huong.append(self.M["tai_nguyen"].get(q.get("chu_the_key") or "") == x["toi"])
            if rk == q["key"]:
                self.b3.append({"goc": q, "o": {}})
            else:
                gc = f"Bảng gốc: {self.nhan_goc(q)}. Thiết kế dùng key «{rk}» (key chuẩn): {x.get('y_nghia', '')}"
                self.b3.append({"goc": q, "o": {"quan_he": self.o_moi(f"{rk} ({q['mo_ta']})" if q.get("mo_ta") else rk, "sua", gc)}})
                self.ghi(3, "sua", "quan hệ", "", q["o"], q["key"], rk, x.get("y_nghia", ""))
        cay_truoc = (sum(huong) >= len(huong) / 2) if huong else True
        for t in self.D["tai_nguyen"]:
            for x in t.get("quan_he", []):
                if "__" in x["key"] or f"{t['key']}.{x['key']}" in da:
                    continue
                a, b = (x["toi"], t["key"]) if cay_truoc else (t["key"], x["toi"])
                gc = f"Quan hệ thiết kế thêm: {x.get('y_nghia', '')}"
                self.b3.append({"goc": None, "o": {"chu_the": self.o_moi(ten(a), "them"), "dich": self.o_moi(ten(b), "them"),
                                                   "quan_he": self.o_moi(f"{x['key']} ({mo_ta_ngan(x.get('y_nghia', ''))})", "them", gc)}})
                self.ghi(3, "them", "quan hệ", t["ten"], "", "", x["key"], x.get("y_nghia", ""), BK.SUY_RA in x.get("y_nghia", ""))

    def lap(self):
        self.bang_1(); self.bang_2(); self.bang_3()
        return self

    # ---------- phạm vi, điều kiện ----------
    def pham_vi_dieu_kien(self):
        out = []
        for q in self.HL:
            r, tn = self.VT.get(q["vai_tro"], {}), self.TN.get(q["tai_nguyen"], {})
            h = next((x for x in tn.get("hanh_dong", []) if x["key"] == q["hanh_dong"]), {})
            pv = self.T.PV.get(q.get("pham_vi") or "", {}).get("ten") or {"toan_he_thong": "Toàn hệ thống", "danh_sach": "Mức danh sách"}.get(q.get("pham_vi"), q.get("pham_vi") or "")
            dk = "; ".join(self.T.DK.get(k, {}).get("ten", k) for k in q.get("dieu_kien", []))
            sr = any(la_suy_ra(x.get("nguon")) for x in q.get("quy_tac", []))
            out.append([q["vai_tro"], r.get("ten", ""), tn.get("ten", q["tai_nguyen"]), q["hanh_dong"], h.get("ten", ""), pv, dk,
                        "AI suy ra" if sr else "Theo tài liệu / BA chốt"])
        return out


def ghi_thay_doi(K):
    lv = K.lv
    so = collections.Counter(x["loai"] for x in K.TD)
    ghi_json(os.path.join(lv, "thay_doi.json"), {"tep": K.B.get("tep"), "sheet": K.B.get("sheet"), "so": dict(so),
                                                  "chua_ghep": K.chua, "thay_doi": K.TD})
    L = [f"# Thiết kế so với 3 bảng đầu vào — {K.B.get('tep')} › «{K.B.get('sheet')}»", "",
         f"Thêm {so.get('them', 0)} · sửa {so.get('sua', 0)} · bỏ {so.get('bo', 0)} · AI suy ra {sum(1 for x in K.TD if x['suy_ra'])}.", ""]
    if K.chua:
        L += ["**Chưa ghép được** (điền `anh_xa_ba_bang.json` rồi chạy lại): " + "; ".join(K.chua), ""]
    L += ["| Bảng | Loại | Mục | Tài nguyên | Ô gốc | Cũ | Mới | Căn cứ |", "|---|---|---|---|---|---|---|---|"]
    esc = lambda s: cf(s).replace("|", "\\|")
    for x in K.TD:
        L.append(f"| {x['bang']} | {TEN_LOAI[x['loai']]}{' · AI suy ra' if x['suy_ra'] else ''} | {x['muc']} | {esc(x['tai_nguyen'])} | "
                 f"{esc(x['o'])} | {esc(x['cu'])} | {esc(x['moi'])} | {esc(x['can_cu'])} |")
    open(os.path.join(lv, "thay_doi.md"), "w", encoding="utf-8").write("\n".join(L) + "\n")
    print(f"thay_doi.json, thay_doi.md: thêm {so.get('them', 0)} · sửa {so.get('sua', 0)} · bỏ {so.get('bo', 0)}"
          + (f" · {len(K.chua)} mục chưa ghép" if K.chua else ""))


# ======================================================================================== ghi Excel
class Sheet:
    def __init__(self, ws, sach):
        self.ws, self.sach = ws, sach

    def kieu(self, c, loai, ghi_chu, giau):
        if self.sach:
            return
        if loai:
            c.fill = PatternFill("solid", fgColor=MAU[loai])
        if loai == "bo":
            f = copy.copy(c.font); f.strike = True; f.color = CHU_DO; c.font = f
        if giau and isinstance(c.value, str):
            f = c.font
            rt = CellRichText()
            for i, (chu, lo) in enumerate(giau):
                if i:
                    rt.append(TextBlock(InlineFont(rFont=f.name, sz=f.sz), ", "))
                rt.append(TextBlock(InlineFont(rFont=f.name, sz=f.sz, b=lo is not None or f.b,
                                               color=CHU_XANH if lo == "them" else CHU_DO if lo == "bo" else None,
                                               strike=lo == "bo"), chu))
            c.value = rt
        if ghi_chu:
            cm = Comment(ghi_chu[:2000], "AI thiết kế phân quyền")
            cm.width, cm.height = 420, min(60 + 16 * (ghi_chu.count("\n") + len(ghi_chu) // 60), 400)
            c.comment = cm

    def thay_vung(self, r0, r1, dong_moi, gop_moi):
        """Thay các dòng r0..r1 (có thể r1 = r0 - 1: vùng trống) bằng dong_moi = [(dòng mẫu, {cột: ô})].
        Ô gộp trong vùng bị bỏ và gộp lại theo gop_moi = [(cột đầu, cột cuối, dòng đầu tương đối, dòng cuối tương đối)];
        ô gộp ở dưới vùng được dời theo."""
        ws = self.ws
        n_cu, n_moi = r1 - r0 + 1, len(dong_moi)
        delta = n_moi - n_cu
        mau = {}
        for r, _ in dong_moi:
            if r and r not in mau:
                mau[r] = {c: (copy.copy(ws.cell(r, c)._style), ws.cell(r, c).value, ws.cell(r, c).comment)
                          for c in range(1, ws.max_column + 1)}
        cao = {r: ws.row_dimensions[r].height for r in range(r0, r1 + 1)}
        duoi = []
        for m in list(ws.merged_cells.ranges):
            if m.max_row < r0:
                continue
            ws.unmerge_cells(str(m))
            if m.min_row > r1:
                duoi.append((m.min_col, m.min_row + delta, m.max_col, m.max_row + delta))
        if delta > 0:
            ws.insert_rows(r1 + 1, delta)
        elif delta < 0:
            ws.delete_rows(r0 + n_moi, -delta)
        for i, (r_mau, o) in enumerate(dong_moi):
            r = r0 + i
            ws.row_dimensions[r].height = cao.get(r_mau) if r_mau in cao else None
            for c in range(1, ws.max_column + 1):
                cell = ws.cell(r, c)
                st, gt, cm = mau.get(r_mau, {}).get(c, (None, None, None))
                if st is not None:
                    cell._style = copy.copy(st)
                cell.value, cell.comment = None, None
                if c in o:
                    x = o[c]
                    if x.get("loai") == "bo" and self.sach:
                        continue
                    if x.get("style") is not None:
                        cell._style = copy.copy(x["style"])
                    cell.value = x["v"]
                    self.kieu(cell, x.get("loai"), x.get("ghi_chu"), x.get("giau"))
                elif c in o.get("_giu", ()):
                    cell.value, cell.comment = gt, (copy.copy(cm) if cm else None)
        for c0, c1, a, b in gop_moi:
            if b > a or c1 > c0:
                ws.merge_cells(start_row=r0 + a, start_column=c0, end_row=r0 + b, end_column=c1)
        for c0, a, c1, b in duoi:
            ws.merge_cells(start_row=a, start_column=c0, end_row=b, end_column=c1)


def doi_ten(K, dong, bo_qua=()):
    """Mẫu không ghi key (chỉ ghi tên): ô «key (mô tả)» → «mô tả», danh sách key hành động → tên hành động; key thiết kế ghi vào ghi chú."""
    ten_hd = {h["key"]: h.get("ten") or h["key"] for t in K.D["tai_nguyen"] for h in t.get("hanh_dong", [])}
    for _, o in dong:
        for c, x in list(o.items()):
            if c == "_giu" or c in bo_qua or not isinstance(x, dict) or not isinstance(x.get("v"), str):
                continue
            if x.get("giau") is not None or (x["v"] and all(k.strip() in ten_hd for k in x["v"].split(","))):
                keys = [k.strip() for k in x["v"].split(",") if k.strip()]
                if keys and all(k in ten_hd for k in keys):
                    x["v"] = ", ".join(ten_hd[k] for k in keys)
                    if x.get("giau"):
                        x["giau"] = [(ten_hd.get(k, k), lo) for k, lo in x["giau"]]
                    x["ghi_chu"] = ((x.get("ghi_chu") or "") + ("\n" if x.get("ghi_chu") else "") + "Key: " + ", ".join(keys)) if x.get("loai") else x.get("ghi_chu", "")
                    continue
            m = re.match(r"^([a-z0-9_]+) \((.*)\)$", x["v"])
            if m:
                x["v"] = m.group(2)
                if x.get("loai"):
                    x["ghi_chu"] = (x.get("ghi_chu") or "") + ("\n" if x.get("ghi_chu") else "") + f"Key thiết kế: {m.group(1)}"


def vung_du_lieu(ws, r_tieu_de_cot, r_bang_sau, cot):
    """Dòng dữ liệu đầu và cuối (có chữ ở các cột của bảng) giữa dòng tên cột và tiêu đề bảng sau."""
    r_cuoi = r_tieu_de_cot
    for r in range(r_tieu_de_cot + 1, r_bang_sau):
        if any(cf(ws.cell(r, c).value) for c in cot):
            r_cuoi = r
    return r_tieu_de_cot + 1, r_cuoi


def xuat_excel(lv, tep, ra, sach, chua_xac_nhan):
    K = KeHoach(lv).lap()
    if K.chua:
        print("Còn mục chưa ghép giữa 3 bảng và thiết kế — điền anh_xa_ba_bang.json rồi chạy lại:")
        for x in K.chua:
            print("  ", x)
        sys.exit(1)
    if not chua_xac_nhan and not K.T.da_xac_nhan():
        sys.exit("BA chưa xác nhận bản xem trước (hoặc thiết kế đã đổi sau khi xác nhận): rà soát xong rồi mới xuất Excel cuối.")
    ghi_thay_doi(K)
    B = K.B
    tep = tep or B.get("duong_dan")
    if not tep or not os.path.exists(tep):
        for d in (lv, os.path.dirname(os.path.abspath(lv)), os.path.dirname(os.path.dirname(os.path.abspath(lv)))):
            p = os.path.join(d, B.get("tep", ""))
            if B.get("tep") and os.path.exists(p):
                tep = p
                break
        else:
            sys.exit(f"Không thấy tệp Excel gốc «{B.get('tep')}»: truyền --tep <đường dẫn>.")
    goc = os.path.splitext(os.path.basename(tep))[0]
    ra = ra or os.path.join(lv, f"{goc}_phan_quyen_cuoi{'_NHAP' if chua_xac_nhan else ''}.xlsx")
    for ban_sach in ([False, True] if sach else [False]):
        p = ra if not ban_sach else ra.replace(".xlsx", "_ban_sach.xlsx")
        ghi_mot(K, tep, p, ban_sach, chua_xac_nhan)
        print(f"Đã ghi {p}")


def ghi_mot(K, tep, p, sach, chua_xac_nhan):
    B = K.B
    wb = openpyxl.load_workbook(tep)
    if B["sheet"] not in wb.sheetnames:
        sys.exit(f"Tệp {tep} không có sheet «{B['sheet']}».")
    ws = wb[B["sheet"]]
    S = Sheet(ws, sach)
    BG = BB.tim_bang(ws)
    sau = lambda so: min([r for k, r in BG.items() if r > BG[so]] + [ws.max_row + 1])
    c2, c3, c1 = BB.cot_cua(ws, BG[2] + 1, 2), BB.cot_cua(ws, BG[3] + 1, 3), BB.cot_cua(ws, BG[1] + 1, 1)
    tat_ca = set(range(1, ws.max_column + 1))

    # --- Bảng 3 trước (ở dưới), để số dòng của Bảng 2 chưa đổi ---
    a3, b3 = vung_du_lieu(ws, BG[3] + 1, sau(3), list(c3.values()))
    r_goc_q = {}
    for q in B["quan_he"]:
        m = re.search(r"![A-Z]+(\d+)", q["o"])
        if m:
            r_goc_q[q["key"]] = int(m.group(1))
    mau3 = a3 if b3 >= a3 else BG[3] + 1
    dong3 = []
    for x in K.b3:
        q = x["goc"]
        r = r_goc_q.get(q["key"]) if q else None
        o = {c3[f]: v for f, v in x["o"].items() if f in c3}
        o["_giu"] = tat_ca - set(o) if r else set()
        dong3.append((r or mau3, o))
    khong_key = "key" not in c2
    if khong_key:
        doi_ten(K, dong3)
    S.thay_vung(a3, b3, dong3, [])

    # --- Bảng 2 ---
    a2, b2 = vung_du_lieu(ws, BG[2] + 1, BG[3], list(c2.values()))
    # bảng vai trò – hành động được phép đặt riêng (không nằm trong cột của Bảng 2): viết lại riêng, theo thứ tự tài nguyên
    BR = B.get("bang_vai_tro_rieng")
    rieng = set()
    if BR:
        rt, cv, cd = BR["dong_tieu_de"], BR["cot_vai_tro"], BR["cot_duoc_phep"]
        rieng = set(range(cv, cd + 1))
        o_goc = lambda r, c: (copy.copy(ws.cell(r, c)._style), ws.cell(r, c).value)
        BR_O = {"tieu_de": o_goc(rt, cv), "cot": [o_goc(rt + 1, cv), o_goc(rt + 1, cd)], "dong": [o_goc(rt + 2, cv), o_goc(rt + 2, cd)],
                "gop_tieu_de": any(m.min_row == rt and m.min_col == cv for m in ws.merged_cells.ranges)}
    gop_cu = [m for m in ws.merged_cells.ranges if a2 <= m.min_row <= b2 and not (rieng & set(range(m.min_col, m.max_col + 1)))]
    dong2, gop2 = [], []
    bat_dau = {}
    for t in B["tai_nguyen"]:
        m = re.search(r"!([A-Z]+)(\d+)", t["o"])
        bat_dau[t["key"]] = int(m.group(2)) if m else None
    dau_list = sorted(r for r in bat_dau.values() if r)
    for K2 in K.b2:
        t, d = K2["tn"], K2["d"]
        r_dau = bat_dau.get(t["key"]) if t else None
        r_het = (min([r for r in dau_list if r_dau and r > r_dau] + [b2 + 1]) - 1) if r_dau else None
        i0 = len(dong2)
        if K2.get("giu_nguyen"):
            for r in range(r_dau, r_het + 1):
                o = {}
                if r == r_dau and "key" in K2["dong_tn"]:
                    if "key" in c2:
                        o[c2["key"]] = K2["dong_tn"]["key"]
                    elif "ten" in c2:     # mẫu không có cột key: key thiết kế ghi ở ghi chú của ô tên
                        x = K2["dong_tn"]["key"]
                        o[c2["ten"]] = KeHoach.o_moi(t["ten"], x["loai"], x["ghi_chu"])
                o["_giu"] = tat_ca - set(o) - rieng
                dong2.append((r, o))
        else:
            n = max(1, len(K2["tt"]), len(K2["hd"]), len(K2["vt"]))
            if sach:
                n = max(1, len([x for x in K2["tt"] if x["loai"] != "bo"]), len([x for x in K2["hd"] if x["loai"] != "bo"]),
                        len([x for x in K2["vt"] if x[0]["loai"] != "bo"]))
                K2 = dict(K2, tt=[x for x in K2["tt"] if x["loai"] != "bo"], hd=[x for x in K2["hd"] if x["loai"] != "bo"],
                          vt=[x for x in K2["vt"] if x[0]["loai"] != "bo"])
            so_goc = (r_het - r_dau + 1) if r_dau else 0
            for i in range(n):
                r_mau = (r_dau + min(i, so_goc - 1)) if r_dau else (a2 if b2 >= a2 else BG[2] + 1)
                o = {}
                if i == 0:
                    for f in ("key", "ten"):
                        if f in K2["dong_tn"] and f in c2:
                            o[c2[f]] = K2["dong_tn"][f]
                        elif t is None and f in c2:
                            o[c2[f]] = K2["dong_tn"].get(f, KeHoach.o_moi(d["key" if f == "key" else "ten"], "them"))
                    if "key" not in c2 and "key" in K2["dong_tn"] and "ten" in c2 and c2["ten"] not in o:
                        x = K2["dong_tn"]["key"]
                        o[c2["ten"]] = KeHoach.o_moi((t or d)["ten"], x["loai"], x["ghi_chu"])
                if i < len(K2["tt"]) and "thuoc_tinh" in c2:
                    o[c2["thuoc_tinh"]] = K2["tt"][i]
                if i < len(K2["hd"]) and "hanh_dong" in c2:
                    o[c2["hanh_dong"]] = K2["hd"][i]
                if i < len(K2["vt"]):
                    if "vai_tro" in c2:
                        o[c2["vai_tro"]] = K2["vt"][i][0]
                    if "duoc_phep" in c2:
                        o[c2["duoc_phep"]] = K2["vt"][i][1]
                du_lieu = {c2.get(f) for f in ("thuoc_tinh", "hanh_dong", "vai_tro", "duoc_phep")}
                giu = set()
                if r_dau and i < so_goc:
                    giu = {c for c in tat_ca - set(o) if c not in du_lieu and (i == 0 or c not in (c2.get("key"), c2.get("ten")))}
                o["_giu"] = giu - rieng
                dong2.append((r_mau, o))
        n_khoi = len(dong2) - i0
        if r_dau:      # gộp lại các cột đã gộp theo khối ở bản gốc (STT, key, tên…)
            for m in gop_cu:
                if m.min_row == r_dau:
                    gop2.append((m.min_col, m.max_col, i0, i0 + n_khoi - 1 if m.max_row > m.min_row else i0))
        elif n_khoi > 1:
            for f in ("key", "ten"):
                if f in c2 and any(m.min_col == c2[f] and m.max_row > m.min_row for m in gop_cu):
                    gop2.append((c2[f], c2[f], i0, i0 + n_khoi - 1))
    if BR:
        vts = [x for K2 in K.b2 for x in K2["vt"] if not (sach and x[0]["loai"] == "bo")]
        rel = max(0, rt - a2)
        while len(dong2) < rel + 2 + len(vts):
            dong2.append((b2 if b2 >= a2 else a2, {"_giu": set()}))
        on = lambda st_gt, x=None: dict(x or {"v": st_gt[1], "loai": None, "ghi_chu": "", "giau": None}, style=st_gt[0])
        dong2[rel][1][cv] = on(BR_O["tieu_de"])
        dong2[rel + 1][1][cv], dong2[rel + 1][1][cd] = on(BR_O["cot"][0]), on(BR_O["cot"][1])
        for k, (c_vt, c_hd) in enumerate(vts):
            dong2[rel + 2 + k][1][cv], dong2[rel + 2 + k][1][cd] = on(BR_O["dong"][0], c_vt), on(BR_O["dong"][1], c_hd)
        if BR_O["gop_tieu_de"] and cd > cv:
            gop2.append((cv, cd, rel, rel))
    if khong_key:
        doi_ten(K, dong2, bo_qua={c2.get("thuoc_tinh")})
    S.thay_vung(a2, b2, dong2, gop2)

    # --- Bảng 1: chỉ điền key AI đặt ---
    for x in K.b1:
        if x["o"].get("key") and c1.get("key") and x.get("dong"):
            cell = ws.cell(x["dong"], c1["key"])
            cell.value = x["o"]["key"]["v"]
            S.kieu(cell, x["o"]["key"]["loai"], x["o"]["key"]["ghi_chu"], None)

    # --- sheet phụ ---
    vi_tri = wb.sheetnames.index(ws.title) + 1
    for ten, hang, tieu_de, rong in (
            ("Thay đổi", [[x["bang"], TEN_LOAI[x["loai"]] + (" · AI suy ra" if x["suy_ra"] else ""), x["muc"], x["tai_nguyen"], x["o"],
                           x["cu"], x["moi"], x["can_cu"]] for x in K.TD],
             ["Bảng", "Loại", "Mục", "Tài nguyên", "Ô gốc", "Cũ", "Mới", "Căn cứ"], (7, 18, 20, 22, 26, 30, 30, 80)),
            ("Phạm vi, điều kiện", K.pham_vi_dieu_kien(),
             ["Key vai trò", "Vai trò", "Tài nguyên", "Key hành động", "Hành động", "Phạm vi (bản ghi nào)", "Điều kiện (khi nào)", "Nguồn"],
             (24, 44, 22, 20, 36, 40, 44, 22))):
        if sach and ten == "Thay đổi":
            continue
        if ten in wb.sheetnames:
            del wb[ten]
        s = wb.create_sheet(ten, vi_tri)
        vi_tri += 1
        r = 1
        if ten == "Thay đổi":
            s.cell(1, 1, f"Thiết kế phân quyền so với 3 bảng của sheet «{B['sheet']}»"
                         + (" — BẢN NHÁP, BA CHƯA XÁC NHẬN" if chua_xac_nhan else "")).font = Font(bold=True, size=12)
            for i, (lo, y) in enumerate((("them", "Thêm (thiết kế thêm dòng, hành động, quyền)"),
                                         ("sua", "Sửa (đổi key, tách / gộp, đổi hành động được phép)"),
                                         ("bo", "Bỏ (thiết kế không giữ; chữ đỏ gạch ngang)")), 2):
                c = s.cell(i, 1, TEN_LOAI[lo]); c.fill = PatternFill("solid", fgColor=MAU[lo])
                if lo == "bo":
                    c.font = Font(strike=True, color=CHU_DO)
                s.cell(i, 2, y)
            s.cell(5, 1, "Trong ô «Hành động được phép»: chữ xanh đậm = hành động được thêm, chữ đỏ gạch ngang = hành động bị bỏ. "
                         "Rê chuột vào ô có dấu ghi chú để xem bản gốc và căn cứ.")
            r = 7
        for j, h in enumerate(tieu_de, 1):
            c = s.cell(r, j, h); c.font = Font(bold=True); c.fill = PatternFill("solid", fgColor="DDEBF7")
            c.alignment = Alignment(wrap_text=True, vertical="top")
        for row in hang:
            r += 1
            for j, v in enumerate(row, 1):
                s.cell(r, j, v).alignment = Alignment(wrap_text=True, vertical="top")
        for j, w in enumerate(rong, 1):
            s.column_dimensions[get_column_letter(j)].width = w
        s.freeze_panes = s.cell(8 if ten == "Thay đổi" else 2, 1)
    wb.active = wb.sheetnames.index(ws.title)
    for s in wb.worksheets:
        s.sheet_view.tabSelected = s.title == ws.title
    os.makedirs(os.path.dirname(os.path.abspath(p)), exist_ok=True)
    wb.save(p)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("lenh", choices=["anh-xa", "thay-doi", "excel"])
    ap.add_argument("lv")
    ap.add_argument("--tep")
    ap.add_argument("--ra")
    ap.add_argument("--ban-sach", action="store_true")
    ap.add_argument("--chua-xac-nhan", action="store_true")
    a = ap.parse_args()
    if a.lenh == "anh-xa":
        _, chua = lap_anh_xa(a.lv)
        sys.exit(1 if chua else 0)
    if a.lenh == "thay-doi":
        ghi_thay_doi(KeHoach(a.lv).lap())
        return
    xuat_excel(a.lv, a.tep, a.ra, a.ban_sach, a.chua_xac_nhan)


if __name__ == "__main__":
    main()
