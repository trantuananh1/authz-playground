# -*- coding: utf-8 -*-
"""Xác nhận thiết kế phân quyền với BA: liệt kê mục còn mở (hoi_dap.py ghi vào sheet Q&A), ghi câu trả lời, lập bản xem trước, ghi xác nhận.

  python -I xac_nhan.py cau-hoi    <lv>     in JSON các mục BA cần trả lời: câu hỏi còn mở, nhóm đề xuất AI chưa quyết
  python -I xac_nhan.py ghi        <lv> <muc> <ket_qua> [--ghi-chu "…"]
        muc     ch:<id câu hỏi> | nhom:<id nhóm> | c:<khoá câu mô tả> | q:<khoá quyền> | xem_truoc
        ket_qua dong_y | khong_dong_y | da_tra_loi
  python -I xac_nhan.py xem-truoc  <lv>     ghi xem_truoc.html (bản xem trước cho BA, mở bằng trình duyệt) và in phần tóm tắt
  python -I xac_nhan.py trang-thai <lv>     còn bao nhiêu mục mở; bản xem trước đã được xác nhận chưa

Ý kiến ghi vào <lv>/ra_soat.json (khoá ch:…, c:…, q:…); xuat_json.py, xuat_dsl.py đọc tệp này để áp.
Xác nhận bản xem trước gắn với dấu vết của thiết kế và ý kiến hiện tại: thiết kế hay ý kiến đổi thì phải xác nhận lại.
"""
import argparse, collections, datetime, hashlib, json, os, sys

sys.stdout.reconfigure(encoding="utf-8"); sys.stderr.reconfigure(encoding="utf-8")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bo_key as BK  # noqa: E402
KHOA_XN = "xn:xem_truoc"
TEN_PV = {"toan_he_thong": "Toàn hệ thống", "don_vi_minh": "Đơn vị mình", "don_vi_minh_va_cap_duoi": "Đơn vị mình và cấp dưới",
          "don_vi_minh_va_cap_duoi_truc_tiep": "Đơn vị mình và cấp dưới trực tiếp", "cap_duyet": "Khi chờ mình duyệt",
          "do_minh_lap": "Do mình lập", "duoc_giao": "Được giao cho mình", "danh_sach": "Danh sách"}
TEN_NGUON = {"ba": "Theo tài liệu / BA chốt", "nguon_bo": "Bỏ theo tài liệu / BA chốt",
             "ke_thua": "Theo quy định chung", "ai_them": "AI đề xuất thêm", "ai_bo": "AI đề xuất bỏ"}   # ba mục cuối: thiết kế cũ, trước chế độ chỉ theo nguồn


def doc(p, mac=None):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return mac


def ghi_json(p, d):
    with open(p, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=1)


class TK:
    """Thiết kế + ý kiến rà soát của một thư mục làm việc."""

    def __init__(self, lv):
        self.lv = lv
        self.D = doc(os.path.join(lv, "thiet_ke_phan_quyen.json"))
        if not self.D:
            sys.exit(f"Chưa có {lv}/thiet_ke_phan_quyen.json — chạy lap_thiet_ke.py trước.")
        self.RSF = doc(os.path.join(lv, "ra_soat.json"), {"muc": {}}) or {"muc": {}}
        self.RS = self.RSF.setdefault("muc", {})
        self.TN = {t["key"]: t for t in self.D["tai_nguyen"]}
        self.VT = {v["key"]: v for v in self.D["vai_tro"]}
        self.PV = {p["key"]: p for p in self.D["pham_vi"]}
        self.DK = {d["key"]: d for d in self.D["dieu_kien"]}
        self.CAU = {c["key"]: c for c in self.D.get("cau_mo_ta", [])}
        self.cau_cua = {k: c for c in self.CAU.values() for k in c["quyen"]}

    # ---------- nhóm đề xuất AI ----------
    def quy_tac_quyet_dinh(self, c):
        loai = "bo_sung" if c["nguon"] == "ai_them" else "loc_vai_tro"
        qt = c.get("quy_tac") or []
        r = next((r for r in qt if r["loai"] == loai), None) \
            or next((r for r in reversed(qt) if r["loai"] not in ("tai_nguyen", "hanh_dong", "tac_nhan", "ke_thua", "pham_vi")), None) \
            or (qt[-1] if qt else {"id": "?", "ly_do": "", "nguyen_tac": []})
        return r

    def nhom(self):
        G = collections.OrderedDict()
        for c in self.CAU.values():
            if c["nguon"] not in ("ai_them", "ai_bo"):
                continue
            r = self.quy_tac_quyet_dinh(c)
            gid = f"{c['nguon']}:{r['id']}"
            g = G.setdefault(gid, {"id": gid, "loai": TEN_NGUON[c["nguon"]], "quy_tac": r["id"], "ly_do": r.get("ly_do") or "",
                                   "nguyen_tac": r.get("nguyen_tac") or [], "cau": []})
            g["cau"].append(c["key"])
        for g in G.values():
            cs = [self.CAU[k] for k in g["cau"]]
            g["vai_tro"] = sorted({self.VT[c["vai_tro"]]["ten"] for c in cs})
            g["tai_nguyen"] = sorted({self.TN[c["tai_nguyen"]]["ten"] for c in cs})
            g["so_quyen"] = sum(len(c["quyen"]) for c in cs)
            g["vi_du"] = [f"{self.VT[c['vai_tro']]['ten']}: {c['noi_dung']}" for c in cs[:4]]
            kq = {self.RS.get(k, {}).get("ket_qua") for k in g["cau"]}
            g["da_quyet"] = (kq.pop() if len(kq) == 1 else "mot_phan") if kq != {None} and None not in kq else None
        return G

    def cau_hoi_mo(self):
        out = []
        for q in self.D.get("cau_hoi", []):
            if q.get("tra_loi") or self.RS.get(f"ch:{q['id']}", {}).get("ket_qua"):
                continue
            out.append({"muc": f"ch:{q['id']}", "nhom": q.get("nhom"), "noi_dung": q["noi_dung"],
                        "phuong_an_ap_dung": q.get("phuong_an_ap_dung"), "lien_quan": q.get("lien_quan")})
        return out

    # ---------- quyền hiệu lực (giống xuat_json.py) ----------
    def ket_qua(self, q):
        c = self.cau_cua.get(q["khoa"])
        return self.RS.get(q["khoa"], {}).get("ket_qua") or (self.RS.get(c["key"], {}).get("ket_qua") if c else None)

    def hieu_luc(self):
        out = []
        for q in self.D["quyen"]:
            t = q["trang_thai"]
            if self.ket_qua(q) == "khong_dong_y":
                t = {"them": "bo", "bo": "giu"}.get(t, t)
            if t != "bo":
                out.append(dict(q, trang_thai_hl=t))
        return out

    def dau_vet(self):
        h = hashlib.sha1()
        with open(os.path.join(self.lv, "thiet_ke_phan_quyen.json"), "rb") as f:
            h.update(f.read())
        h.update(json.dumps({k: v.get("ket_qua") for k, v in sorted(self.RS.items()) if not k.startswith("xn:")}, sort_keys=True).encode())
        return h.hexdigest()[:16]

    def da_xac_nhan(self):
        m = self.RS.get(KHOA_XN, {})
        return m.get("ket_qua") == "dong_y" and m.get("dau_vet") == self.dau_vet()

    def luu(self):
        ghi_json(os.path.join(self.lv, "ra_soat.json"), self.RSF)


def ten_pv(T, k):
    return T.PV[k]["ten"] if k in T.PV else TEN_PV.get(k, k or "")


def lenh_cau_hoi(T):
    G = T.nhom()
    mo = [g for g in G.values() if g["da_quyet"] in (None, "mot_phan")]
    out = {"cau_hoi_mo": T.cau_hoi_mo(),
           "nhom_de_xuat_chua_quyet": [{k: v for k, v in g.items() if k != "cau"} | {"muc": f"nhom:{g['id']}", "so_cau": len(g["cau"])} for g in mo],
           "so_nhom_da_quyet": len(G) - len(mo)}
    print(json.dumps(out, ensure_ascii=False, indent=1))


def lenh_ghi(T, muc, kq, ghi_chu):
    luc = datetime.datetime.now().isoformat(timespec="seconds")
    if muc == "xem_truoc":
        if kq not in ("dong_y", "khong_dong_y"):
            sys.exit("Bản xem trước chỉ nhận dong_y hoặc khong_dong_y.")
        T.RS[KHOA_XN] = {"loai": "xem_truoc", "nhan": "Bản xem trước phân quyền", "ket_qua": kq, "ghi_chu": ghi_chu,
                         "nguoi": "", "luc": luc, "dau_vet": T.dau_vet()}
        T.luu(); print(f"Đã ghi: bản xem trước — {kq}"); return
    if kq not in ("dong_y", "khong_dong_y", "da_tra_loi"):
        sys.exit("ket_qua phải là dong_y, khong_dong_y hoặc da_tra_loi.")
    if muc.startswith("nhom:"):
        G = T.nhom(); g = G.get(muc[5:])
        if not g:
            sys.exit(f"Không có nhóm {muc[5:]}. Các nhóm: {', '.join(G)}")
        for k in g["cau"]:
            T.RS[k] = {"loai": "cau", "nhan": T.CAU[k]["noi_dung"], "ket_qua": kq, "ghi_chu": ghi_chu, "nguoi": "", "luc": luc, "nhom": g["id"]}
        T.luu(); print(f"Đã ghi {len(g['cau'])} câu của nhóm {g['id']} — {kq}"); return
    if muc.startswith("ch:"):
        q = next((q for q in T.D.get("cau_hoi", []) if q["id"] == muc[3:]), None)
        if not q:
            sys.exit(f"Không có câu hỏi {muc[3:]}.")
        T.RS[muc] = {"loai": "cau_hoi", "nhan": f"{q['id']}: {q['noi_dung']}", "ket_qua": kq, "ghi_chu": ghi_chu, "nguoi": "", "luc": luc}
    elif muc.startswith("c:"):
        if muc not in T.CAU:
            sys.exit("Không có câu mô tả này.")
        T.RS[muc] = {"loai": "cau", "nhan": T.CAU[muc]["noi_dung"], "ket_qua": kq, "ghi_chu": ghi_chu, "nguoi": "", "luc": luc}
    elif muc.startswith("q:"):
        if muc not in {q["khoa"] for q in T.D["quyen"]}:
            sys.exit("Không có quyền này.")
        T.RS[muc] = {"loai": "quyen", "nhan": muc, "ket_qua": kq, "ghi_chu": ghi_chu, "nguoi": "", "luc": luc}
    else:
        sys.exit("muc phải bắt đầu bằng ch:, nhom:, c:, q: hoặc là xem_truoc.")
    T.luu(); print(f"Đã ghi: {muc} — {kq}")


LOAI_PV = {"toan_he_thong": "rong", "don_vi_minh_va_cap_duoi": "duoi", "don_vi_minh_va_cap_duoi_truc_tiep": "duoi",
           "don_vi_minh": "minh", "cap_duyet": "duyet", "do_minh_lap": "lap", "duoc_giao": "lap", "danh_sach": "ds"}
CSS = """
:root{--bg:#f5f7fa;--surface:#fff;--fg:#1c2530;--muted:#5d6876;--line:#dfe4ea;--head:#eef2f6;--accent:#1f5fa6;
--rong:#dbe9fb;--rong-fg:#163f70;--duoi:#d9f1ec;--duoi-fg:#0f5246;--minh:#e3f3d9;--minh-fg:#2f5a17;--duyet:#fbecd2;--duyet-fg:#7a4b06;
--lap:#ece6f8;--lap-fg:#4b3480;--ds:#eceff3;--ds-fg:#3d4752;--ai:#c2410c;--kt:#64748b}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--bg:#12161c;--surface:#1a2029;--fg:#e4e9f0;--muted:#9aa5b4;--line:#2d3542;--head:#222a35;--accent:#7fb2ec;
--rong:#1d3350;--rong-fg:#b9d6fb;--duoi:#173a35;--duoi-fg:#a6e3d6;--minh:#233a1c;--minh-fg:#c4e6ad;--duyet:#3d2e14;--duyet-fg:#f3d39c;
--lap:#2e2645;--lap-fg:#d4c6f5;--ds:#252c36;--ds-fg:#c3cbd5;--ai:#fb923c;--kt:#94a3b8;color-scheme:dark}}
:root[data-theme="dark"]{--bg:#12161c;--surface:#1a2029;--fg:#e4e9f0;--muted:#9aa5b4;--line:#2d3542;--head:#222a35;--accent:#7fb2ec;--rong:#1d3350;--rong-fg:#b9d6fb;--duoi:#173a35;--duoi-fg:#a6e3d6;--minh:#233a1c;--minh-fg:#c4e6ad;--duyet:#3d2e14;--duyet-fg:#f3d39c;--lap:#2e2645;--lap-fg:#d4c6f5;--ds:#252c36;--ds-fg:#c3cbd5;--ai:#fb923c;--kt:#94a3b8;color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.55 "Segoe UI",system-ui,-apple-system,Roboto,sans-serif;padding-block:24px 64px;padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}
.wrap{max-width:1400px;margin:0 auto}
h1{font-size:24px;margin:0 0 4px}h2{font-size:18px;margin:32px 0 10px}
.sub{color:var(--muted);margin:0 0 18px}
.cards{display:flex;flex-wrap:wrap;gap:10px;margin:14px 0}
.card{background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:10px 14px;min-width:130px}
.card b{display:block;font-size:22px;font-variant-numeric:tabular-nums}.card span{color:var(--muted);font-size:12.5px}
.note{background:var(--surface);border:1px solid var(--line);border-left:3px solid var(--accent);border-radius:6px;padding:10px 14px;margin:10px 0}
.box{background:var(--surface);border:1px solid var(--line);border-radius:8px;overflow:auto}
table{border-collapse:separate;border-spacing:0;width:100%}
th,td{padding:7px 10px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{background:var(--head);font-size:12.5px;color:var(--muted);font-weight:600}
.list td:first-child{font-weight:600;white-space:nowrap}
.tabs{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0 10px}
.tab{font:inherit;border:1px solid var(--line);background:var(--surface);color:var(--fg);border-radius:999px;padding:5px 14px;cursor:pointer}
.tab[aria-selected=true]{background:var(--accent);border-color:var(--accent);color:var(--bg)}
.tab:focus-visible,.chip:focus-within{outline:2px solid var(--accent);outline-offset:2px}
.legend{display:flex;flex-wrap:wrap;gap:8px 14px;font-size:12.5px;color:var(--muted);margin:6px 0 12px;align-items:center}
.sw{display:inline-block;width:14px;height:14px;border-radius:3px;vertical-align:-2px;margin-right:5px}
.filters{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 10px}
.chip{display:inline-flex;align-items:center;gap:5px;border:1px solid var(--line);background:var(--surface);border-radius:6px;padding:3px 8px;font-size:12.5px;cursor:pointer}
.mx{max-height:75vh}
.mx table{width:auto;min-width:100%}
.mx thead th{position:sticky;top:0;z-index:2;min-width:118px;max-width:150px;white-space:normal;line-height:1.3}
.mx th.rowh,.mx td.rowh{position:sticky;left:0;z-index:1;background:var(--surface);min-width:230px;max-width:260px;font-weight:600}
.mx thead th.rowh{z-index:3;background:var(--head)}
.mx td{min-width:118px;max-width:150px;font-size:12.5px;border-left:1px solid var(--line)}
.mx tr.grp td{background:var(--head);font-weight:700;color:var(--fg);position:sticky;left:0}
.pv{display:block;border-radius:5px;padding:3px 6px;margin:1px 0}
.pv small{display:block;opacity:.85;font-size:11.5px;line-height:1.3}
.rong{background:var(--rong);color:var(--rong-fg)}.duoi{background:var(--duoi);color:var(--duoi-fg)}.minh{background:var(--minh);color:var(--minh-fg)}
.duyet{background:var(--duyet);color:var(--duyet-fg)}.lap{background:var(--lap);color:var(--lap-fg)}.ds{background:var(--ds);color:var(--ds-fg)}
.tag{font-size:10.5px;font-weight:700;border-radius:3px;padding:0 4px;margin-left:4px;border:1px solid currentColor}
.tag.ai{color:var(--ai)}.tag.kt{color:var(--kt)}.tag.sr{color:var(--ai);border-style:dashed}
.qd-dong_y{color:var(--minh-fg)}.qd-khong_dong_y{color:var(--ai)}
@media (max-width:700px){body{padding-top:16px}h1{font-size:20px}}
"""
JS = """
const tabs=[...document.querySelectorAll('.tab')];
tabs.forEach(b=>b.addEventListener('click',()=>{tabs.forEach(x=>x.setAttribute('aria-selected',x===b));
document.querySelectorAll('.pane').forEach(p=>p.hidden=p.id!==b.dataset.p);}));
document.querySelectorAll('.chip input').forEach(cb=>cb.addEventListener('change',()=>{
document.querySelectorAll('[data-vt="'+cb.value+'"]').forEach(c=>c.hidden=!cb.checked);}));
"""


def lenh_xem_truoc(T):
    import html as H
    e = lambda s: H.escape(str(s or ""))
    D, ph = T.D, T.D.get("phan_he", {})
    HL = T.hieu_luc()
    G = T.nhom()
    so = collections.Counter(q["trang_thai_hl"] for q in HL)
    vt_dung = [v for v in D["vai_tro"] if any(q["vai_tro"] == v["key"] for q in HL)]
    tn_dl = [t for t in D["tai_nguyen"] if t.get("hanh_dong")]
    ch = D.get("cau_hoi", [])
    ch_chot = sum(1 for q in ch if q.get("tra_loi") or T.RS.get("ch:" + q["id"], {}).get("ket_qua"))
    g_quyet = sum(1 for g in G.values() if g["da_quyet"] not in (None, "mot_phan"))
    giu_bo = sum(1 for q in HL if q["trang_thai"] == "bo")
    ten_ngan = lambda v: v["ten"].split(" (")[0]

    def gan_o(v):
        if v["loai_pham_vi"] == "toan_he_thong":
            return "Toàn hệ thống"
        if v["loai_pham_vi"] == "theo_ban_ghi":
            return "Theo bản ghi"
        return "Từng «" + T.TN.get(v.get("gan_tren"), {}).get("ten", v.get("gan_tren", "")).split(" (")[0] + "»"

    def loai_pv(k):
        kieu = T.PV[k].get("kieu", k) if k in T.PV else k
        return LOAI_PV.get(kieu, "minh")

    def nhan_pv(k):
        return "Được" if (T.PV.get(k, {}).get("kieu", k) == "danh_sach") else ten_pv(T, k)

    # chế độ suy ra (mặc định): quyền có quy tắc ghi nguồn «AI suy ra …»
    SR = D.get("suy_ra") or {}
    la_sr = lambda q: any(BK.la_suy_ra(r.get("nguon")) for r in q.get("quy_tac", []))
    so_sr = sum(1 for q in HL if la_sr(q))
    ch_sr = [q for q in ch if q.get("suy_ra")]

    # ô ma trận
    o = collections.defaultdict(list)
    for q in HL:
        dk = " · ".join(T.DK[k]["ten"] for k in q.get("dieu_kien") or [] if k in T.DK)
        tag = {"them": '<span class="tag ai" title="AI đề xuất thêm">AI</span>', "ke_thua": '<span class="tag kt" title="Theo quy định chung">QĐ</span>'}.get(q["trang_thai_hl"], "")
        if la_sr(q):
            tag += '<span class="tag sr" title="Có phần AI suy ra từ tài liệu (xem mục «AI suy ra»)">Suy ra</span>'
        o[(q["tai_nguyen"], q["hanh_dong"], q["vai_tro"])].append(
            f'<span class="pv {loai_pv(q.get("pham_vi"))}">{e(nhan_pv(q.get("pham_vi")))}{tag}' + (f"<small>{e(dk)}</small>" if dk else "") + "</span>")

    ten_pd = ph.get("ten", "") if len(ph.get("ten", "")) <= 40 else (ph.get("ma") or "").upper()
    P = [f'<title>Phân quyền {e(ten_pd)}</title>', '<meta name="claude:viewport-fit-sides" content="cover">', f"<style>{CSS}</style>", '<div class="wrap">',
         f'<h1>Bản xem trước phân quyền</h1><p class="sub">{e(ph.get("ten", ""))} · đã áp mọi câu trả lời của BA.</p>'
         '<div class="note"><b>Cần sửa chỗ nào?</b> Bôi chọn chỗ đó trên trang, viết bình luận và chọn gửi cho Claude. AI sửa thiết kế, cập nhật trang này và trả lời trong bình luận. Khi không còn gì cần sửa, xác nhận trong cuộc trò chuyện để AI xuất tệp import và DSL theo bản mới nhất.</div>',
         '<div class="cards">'
         f'<div class="card"><b>{len(vt_dung)}</b><span>vai trò</span></div>'
         f'<div class="card"><b>{len(tn_dl)}</b><span>loại dữ liệu</span></div>'
         f'<div class="card"><b>{len(HL)}</b><span>quyền</span></div>'
         f'<div class="card"><b>{so.get("giu", 0) + giu_bo}</b><span>theo tài liệu / BA chốt</span></div>'
         + (f'<div class="card"><b>{so.get("ke_thua", 0)}</b><span>theo quy định chung</span></div>' if so.get("ke_thua") else "")
         + (f'<div class="card"><b>{so.get("them", 0)}</b><span>AI đề xuất thêm</span></div>' if so.get("them") else "")
         + (f'<div class="card"><b>{so_sr}</b><span>có phần AI suy ra</span></div>' if SR.get("bat") else "")
         + f'<div class="card"><b>{len(D.get("thieu_nguon", []))}</b><span>chưa có nguồn (không đưa vào)</span></div>'
         f'<div class="card"><b>{ch_chot}/{len(ch)}</b><span>câu hỏi đã chốt</span></div>'
         + (f'<div class="card"><b>{g_quyet}/{len(G)}</b><span>nhóm đề xuất đã quyết</span></div>' if G else "") + '</div>']

    # ma trận
    mang = collections.OrderedDict()
    for t in tn_dl:
        mang.setdefault(t.get("mang") or "Khác", []).append(t)
    P += ['<h2>Ai được làm gì</h2>',
          '<div class="legend">'
          '<span><i class="sw rong"></i>Toàn hệ thống</span><span><i class="sw duoi"></i>Đơn vị mình và cấp dưới</span>'
          '<span><i class="sw minh"></i>Đơn vị / tổ chức / trường mình</span><span><i class="sw duyet"></i>Khi hồ sơ chờ mình duyệt</span>'
          '<span><i class="sw lap"></i>Bản ghi do mình lập</span><span><i class="sw ds"></i>Được (thao tác trên danh sách)</span>'
          + ('<span><span class="tag ai">AI</span> AI đề xuất thêm</span>' if so.get("them") else "")
          + ('<span><span class="tag kt">QĐ</span> theo quy định chung</span>' if so.get("ke_thua") else "")
          + ('<span><span class="tag sr">Suy ra</span> có phần AI suy ra</span>' if so_sr else "") +
          '<span>Dòng chữ nhỏ là điều kiện. Ô trống là không được.</span></div>',
          '<div class="filters" aria-label="Hiện / ẩn vai trò">' + "".join(
              f'<label class="chip" title="{e(v["ten"])}"><input type="checkbox" value="{e(v["key"])}" checked>{e(ten_ngan(v))}</label>' for v in vt_dung) + "</div>",
          '<div class="tabs" role="tablist">' + "".join(
              f'<button class="tab" role="tab" data-p="m{i}" aria-selected="{"true" if i == 0 else "false"}">{e(m)}</button>' for i, m in enumerate(mang)) + "</div>"]
    for i, (m, ts) in enumerate(mang.items()):
        keys = {t["key"] for t in ts}
        cot = [v for v in vt_dung if any(q["vai_tro"] == v["key"] and q["tai_nguyen"] in keys for q in HL)]
        P.append(f'<div class="pane box mx" id="m{i}"{"" if i == 0 else " hidden"}><table><thead><tr><th class="rowh">Dữ liệu › thao tác</th>'
                 + "".join(f'<th data-vt="{e(v["key"])}" title="{e(v["ten"])}">{e(ten_ngan(v))}</th>' for v in cot) + "</tr></thead><tbody>")
        for t in ts:
            P.append(f'<tr class="grp"><td class="rowh" colspan="1">{e(t["ten"])}</td>' + "".join(f'<td data-vt="{e(v["key"])}"></td>' for v in cot) + "</tr>")
            for h in t["hanh_dong"]:
                hang = ["".join(o.get((t["key"], h["key"], v["key"]), [])) for v in cot]
                if any(hang):
                    P.append(f'<tr><td class="rowh">{e(h["ten"])}</td>' + "".join(f'<td data-vt="{e(v["key"])}">{c}</td>' for v, c in zip(cot, hang)) + "</tr>")
        P.append("</tbody></table></div>")

    # vai trò, dữ liệu
    P += ['<h2>Vai trò</h2><div class="box"><table class="list"><thead><tr><th>Vai trò</th><th>Cấp</th><th>Gán ở</th><th>Ứng với trong tài liệu</th></tr></thead><tbody>']
    for v in vt_dung:
        tl = ", ".join(sorted({x["tac_nhan"] for x in v.get("tac_nhan_tai_lieu", [])})) or ("AI tách ra" if (v.get("co_so") or {}).get("loai") == "de_xuat" else "Tự sinh")
        P.append(f'<tr><td>{e(v["ten"])}</td><td>{e(v.get("cap"))}</td><td>{e(gan_o(v))}</td><td>{e(tl)}</td></tr>')
    P += ["</tbody></table></div>", '<h2>Dữ liệu</h2><div class="box"><table class="list"><thead><tr><th>Dữ liệu</th><th>Mảng</th><th>Gắn với</th><th>Thao tác</th></tr></thead><tbody>']
    for t in tn_dl:
        qh = "<br>".join(e(r.get("y_nghia") or r["key"]) for r in t.get("quan_he", [])) or "—"
        P.append(f'<tr><td>{e(t["ten"])}</td><td>{e(t.get("mang"))}</td><td>{qh}</td><td>{e(", ".join(h["ten"] for h in t["hanh_dong"]))}</td></tr>')
    P.append("</tbody></table></div>")

    # ràng buộc
    rb = collections.defaultdict(set)
    for q in HL:
        for k in q.get("dieu_kien") or []:
            if k in T.DK:
                rb[k].add(T.TN[q["tai_nguyen"]]["ten"])
    if rb:
        P.append('<h2>Ràng buộc</h2><div class="box"><table class="list"><thead><tr><th>Ràng buộc</th><th>Ý nghĩa</th><th>Áp cho</th></tr></thead><tbody>')
        for k, ds in rb.items():
            P.append(f'<tr><td>{e(T.DK[k]["ten"])}</td><td>{e(T.DK[k].get("mo_ta"))}</td><td>{e(", ".join(sorted(ds)))}</td></tr>')
        P.append("</tbody></table></div>")

    # đề xuất AI
    if G:
        QD = {"dong_y": "Đồng ý", "khong_dong_y": "Không đồng ý", "mot_phan": "Một phần", None: "Chưa quyết"}
        P.append('<h2>Đề xuất của AI</h2><div class="box"><table class="list"><thead><tr><th>Quyết định</th><th>Đề xuất</th><th>Lý do</th><th>Vai trò</th></tr></thead><tbody>')
        for g in G.values():
            P.append(f'<tr><td class="qd-{e(g["da_quyet"])}">{QD[g["da_quyet"]]}</td><td>{e(g["loai"])} · {g["so_quyen"]} quyền</td><td>{e(g["ly_do"] or g["quy_tac"])}</td><td>{e(", ".join(g["vai_tro"]))}</td></tr>')
        P.append("</tbody></table></div>")

    # chưa có nguồn: quyền, phạm vi, điều kiện tài liệu chưa nêu (không đưa vào thiết kế)
    tn_ng = D.get("thieu_nguon", [])
    if tn_ng:
        P.append('<h2>Chưa có nguồn — không đưa vào thiết kế</h2><p class="sub">Tài liệu chưa nêu, nên thiết kế không tự thêm. BA trả lời câu hỏi cùng mã thì AI ghi «BA chốt» làm nguồn và lập lại.</p>'
                 '<div class="box"><table class="list"><thead><tr><th>Mã</th><th>Tài liệu chưa nêu</th><th>BA</th></tr></thead><tbody>')
        for t in [q for q in ch if q.get("tu_sinh")]:
            tl = T.RS.get("ch:" + t["id"], {}).get("ghi_chu") or ("Đã trả lời" if T.RS.get("ch:" + t["id"], {}).get("ket_qua") else "Chưa trả lời")
            P.append(f'<tr><td>{e(t["id"])}</td><td style="white-space:normal;font-weight:400">{e(t["noi_dung"])}</td><td>{e(tl)}</td></tr>')
        P.append("</tbody></table></div>")

    # bước làm ngoài hệ thống: tài liệu ghi làm ngoài hệ thống nên không phân quyền (mọi phân hệ)
    nht = [g for g in D.get("giao_dich", []) if g.get("trang_thai") == "ngoai_he_thong"]
    if nht:
        P.append('<h2>Bước làm ngoài hệ thống — không phân quyền</h2><p class="sub">Tài liệu ghi các bước này làm ngoài hệ thống, nên thiết kế không cấp quyền nào cho các bước này.</p>'
                 '<div class="box"><table class="list"><thead><tr><th>Bước</th><th>Người thực hiện</th><th>Vị trí</th></tr></thead><tbody>')
        for g in nht:
            P.append(f'<tr><td style="white-space:normal">{e(g["ten"])}<br><small>{e(g.get("muc"))}</small></td><td style="white-space:normal;font-weight:400">{e(", ".join(g["tac_nhan"]))}</td><td>{e(g["vt"])}</td></tr>')
        P.append("</tbody></table></div>")

    # AI suy ra: điểm tài liệu chưa nêu hoặc nói ngược nhau mà AI tự chốt (chế độ suy ra)
    if SR.get("bat"):
        P.append('<h2>AI suy ra — BA rà soát</h2><p class="sub">Chế độ suy ra (mặc định)'
                 + (f' ngày {e(SR.get("ngay"))}' if SR.get("ngay") else "") + (f'; nguồn dùng: {e(SR.get("nguon_dung"))}' if SR.get("nguon_dung") else "")
                 + f'. AI tự chốt các điểm dưới đây theo tài liệu; {so_sr} quyền có phần suy ra (nhãn «Suy ra» trong ma trận). BA không đồng ý điểm nào thì bình luận để sửa.</p>'
                 '<div class="box"><table class="list"><thead><tr><th>Mã</th><th>Tài liệu chưa nêu / nói ngược nhau</th><th>AI chọn</th><th>Phương án khác</th></tr></thead><tbody>')
        for q in ch_sr:
            P.append(f'<tr><td>{e(q["id"])}</td><td style="white-space:normal;font-weight:400">{e(q["noi_dung"])}</td>'
                     f'<td style="white-space:normal">{e(q.get("phuong_an_ap_dung"))}</td><td style="white-space:normal;font-weight:400">{e(q.get("phuong_an_khac") or "—")}</td></tr>')
        if not ch_sr:
            P.append('<tr><td colspan="4">Không có.</td></tr>')
        P.append("</tbody></table></div>")

    # so với mẫu 3 bảng đầu vào (khi đầu vào là mẫu 3 bảng): lập lại thay_doi.json theo thiết kế hiện tại
    if os.path.exists(os.path.join(T.lv, "ba_bang.json")):
        try:
            import doi_chieu_ba_bang as DC
            K = DC.KeHoach(T.lv).lap()
            DC.ghi_thay_doi(K)
            TDc, chua = K.TD, K.chua
        except Exception as loi:   # không chặn bản xem trước vì phần đối chiếu
            TDc, chua = [], [f"lỗi khi đối chiếu: {loi}"]
        so_td = collections.Counter(x["loai"] for x in TDc)
        P.append('<h2>So với 3 bảng đầu vào</h2><p class="sub">Những chỗ thiết kế khác Bảng 1–3 BA gửi: '
                 f'thêm {so_td.get("them", 0)}, sửa {so_td.get("sua", 0)}, bỏ {so_td.get("bo", 0)}. Excel cuối giữ đúng định dạng 3 bảng và tô màu đúng các chỗ này.</p>')
        if chua:
            P.append(f'<p class="sub">Chưa ghép được với thiết kế: {e("; ".join(chua))}.</p>')
        P.append('<div class="box"><table class="list"><thead><tr><th>Loại</th><th>Mục</th><th>Cũ</th><th>Mới</th><th>Căn cứ</th></tr></thead><tbody>')
        ten_loai = {"them": "Thêm", "sua": "Sửa", "bo": "Bỏ"}
        for x in TDc:
            P.append(f'<tr><td>{ten_loai[x["loai"]]}{" · Suy ra" if x["suy_ra"] else ""}</td><td>{e(x["muc"])}</td><td>{e(x["cu"]) or "—"}</td>'
                     f'<td>{e(x["moi"]) or "—"}</td><td style="white-space:normal;font-weight:400">{e(x["can_cu"])}</td></tr>')
        if not TDc:
            P.append('<tr><td colspan="5">Không có thay đổi.</td></tr>')
        P.append("</tbody></table></div>")

    # câu hỏi nghiệp vụ (không gồm câu «Thiếu nguồn» và điểm AI suy ra đã hiện ở trên)
    ch_bt =[q for q in ch if not q.get("tu_sinh") and not q.get("suy_ra")]
    if ch_bt:
        P.append('<h2>Câu hỏi nghiệp vụ</h2><div class="box"><table class="list"><thead><tr><th>Câu hỏi</th><th>Đang áp dụng</th></tr></thead><tbody>')
        for q in ch_bt:
            tl = q.get("tra_loi") or T.RS.get("ch:" + q["id"], {}).get("ghi_chu") or ""
            P.append(f'<tr><td style="white-space:normal;font-weight:400">{e(q["noi_dung"])}</td><td>{e(q.get("phuong_an_ap_dung"))}' + (f'<br><small>BA: {e(tl)}</small>' if tl else "") + "</td></tr>")
        P.append("</tbody></table></div>")
    P += ["</div>", f"<script>{JS}</script>"]

    p = os.path.join(T.lv, "xem_truoc.html")
    with open(p, "w", encoding="utf-8") as f:
        f.write("\n".join(P) + "\n")   # trang Artifact: khung Artifact tự bọc doctype / head
    print(f"Đã ghi {p}")
    print(f"{len(vt_dung)} vai trò · {len(tn_dl)} loại dữ liệu · {len(HL)} quyền (theo tài liệu / BA chốt {so.get('giu', 0) + giu_bo}; chưa có nguồn {len(D.get('thieu_nguon', []))})"
          f" · câu hỏi đã chốt {ch_chot}/{len(ch)} · nhóm đề xuất đã quyết {g_quyet}/{len(G)}")
    for v in vt_dung:
        print(f"- {v['ten']} · {v.get('cap', '')} · {gan_o(v)}")


def lenh_trang_thai(T):
    G = T.nhom()
    print(json.dumps({"cau_hoi_mo": len(T.cau_hoi_mo()),
                      "nhom_de_xuat_chua_quyet": sum(1 for g in G.values() if g["da_quyet"] in (None, "mot_phan")),
                      "da_xac_nhan_xem_truoc": T.da_xac_nhan()}, ensure_ascii=False))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("lenh", choices=["cau-hoi", "ghi", "xem-truoc", "trang-thai"])
    ap.add_argument("lv"); ap.add_argument("muc", nargs="?"); ap.add_argument("ket_qua", nargs="?")
    ap.add_argument("--ghi-chu", default="")
    a = ap.parse_args()
    T = TK(a.lv)
    if a.lenh == "cau-hoi":
        lenh_cau_hoi(T)
    elif a.lenh == "ghi":
        if not a.muc or not a.ket_qua:
            sys.exit("Cần muc và ket_qua.")
        lenh_ghi(T, a.muc, a.ket_qua, a.ghi_chu)
    elif a.lenh == "xem-truoc":
        lenh_xem_truoc(T)
    else:
        lenh_trang_thai(T)


if __name__ == "__main__":
    main()
