# -*- coding: utf-8 -*-
"""Sinh trang Artifact so thiết kế với ma trận phân quyền của BA (bước 9 của ra-soat-phan-quyen).

  python -I trang_so_sanh.py <thu_muc_lam_viec>

Đầu vào: <lv>/so_sanh/ket_qua.json (so_sanh_thu.py ghi) và, nếu có, <lv>/so_sanh/giai_thich.json do AI viết
(giải thích từng ô lệch chỉ theo nguồn; xem SKILL.md của ra-soat-phan-quyen, bước 9). Chưa có giải thích thì mỗi ô lệch ghi đường cấp quyền
mà bộ đánh giá DSL tìm được. Đầu ra: <lv>/so_sanh/so_sanh.html (nội dung trang Artifact).
"""
import html, json, os, sys

sys.stdout.reconfigure(encoding="utf-8")
LV = sys.argv[1] if len(sys.argv) > 1 else sys.exit(__doc__)
SS = os.path.join(LV, "so_sanh")
KQ = json.load(open(os.path.join(SS, "ket_qua.json"), encoding="utf-8"))
RA = os.path.join(SS, "so_sanh.html")
e = lambda s: html.escape(str(s or ""), quote=True)
MT = KQ.get("ten_ma_tran") or "ma trận BA"
TIEU_DE = KQ.get("tieu_de_trang") or f"Lệch {MT}"
def _cot_nhom():
    """Nhóm cột → danh sách cột. ket_qua.json mới ghi danh sách; bản cũ ghi chuỗi nối («HIJ…AA») thì tách theo thứ tự cột."""
    con, ra = list(KQ["cot"].keys()), []
    for n in KQ["nhom_cot"]:
        if isinstance(n["cot"], list):
            ra.append((n["ten"], list(n["cot"])))
            continue
        lay, chu = [], ""
        while con and chu != n["cot"]:
            chu += con[0]
            lay.append(con.pop(0))
        ra.append((n["ten"], lay))
    return ra


NHOM_COT = _cot_nhom()
TEN_NGAN = KQ["ten_ngan"]
LOAI = {"A": ("Khác ô nguồn", "a", f"Nguồn nêu rõ; thiết kế theo nguồn, {MT} khác."),
        "A_BA": ("Khác câu BA chốt", "c", f"Nguồn chưa đủ rõ; thiết kế theo câu BA đã chốt, {MT} khác."),
        "B": ("Nguồn mâu thuẫn", "b", "Các nguồn nói ngược nhau và chưa có câu chốt; cần BA chốt."),
        "C": ("Lệch khi cài đặt", "d", "Thiết kế và ma trận nói giống nhau; lệch phát sinh khi chuyển thiết kế sang hệ thống phân quyền, cần cấu hình lại khi cài đặt."),
        "?": ("Chưa giải thích", "c", "AI chưa viết giải thích cho ô này; dòng ghi đường cấp quyền bộ đánh giá tìm được.")}

_pgt = os.path.join(SS, "giai_thich.json")
GT = json.load(open(_pgt, encoding="utf-8")) if os.path.exists(_pgt) else {}
GT.setdefault("o_lech", [])
for k in ("viec_cho_ba", "sua_nguon", "khop_can_luu_y", "thay_doi"):
    GT.setdefault(k, [])
GT.setdefault("ngay", KQ.get("ngay", ""))
GT.setdefault("gioi_thieu", KQ.get("gioi_thieu", ""))
GT.setdefault("cach_so", KQ.get("cach_so", ""))
_co = {(g["cot"], g["o_so"]) for g in GT["o_lech"]}
for i, r in enumerate([r for r in KQ["ket_qua"] if not r["khop"]], 1):   # ô lệch chưa có giải thích
    if (r["cot"], r["o_so"]) in _co:
        continue
    duong = []
    for a, ct in r["chi_tiet"].items():
        if ct["duoc"]:
            x = ct["chung"][0]
            duong.append(f"{a}: người dùng thử «{x['nguoi']}» được trên hồ sơ «{x['ho_so']}» qua {', '.join(x['duong'])}")
        else:
            duong.append(f"{a}: thiết kế không cấp cho người dùng nào của cột trên hồ sơ thử nào")
    GT["o_lech"].append({"ma": f"L{i:02d}", "cot": r["cot"], "o_so": r["o_so"], "loai": "?", "tinh_huong": "",
                         "chuoi_suy_ra": duong, "tom_tat_note": [f"{MT} {'cho' if r['u02'] else 'không cho'}; thiết kế {'cho ' + ', '.join(r['thiet_ke_duoc']) if r['thiet_ke_duoc'] else 'không cho'}."],
                         "viec_cho_ba": "", "o_nguon": []})

rows = KQ["ket_qua"]
o_so = []
for r in rows:
    if r["o_so"] not in [x[0] for x in o_so]:
        o_so.append((r["o_so"], r["ten"]))
cot = list(KQ["cot"].keys())
by = {(r["cot"], r["o_so"]): r for r in rows}
gt = {(g["cot"], g["o_so"]): g for g in GT["o_lech"]}
lech = [r for r in rows if not r["khop"]]
dem_loai = {k: sum(1 for g in GT["o_lech"] if g["loai"] == k) for k in LOAI}
huong_tk = sum(1 for r in lech if not r["u02"])          # thiết kế cho, ma trận không
huong_u02 = len(lech) - huong_tk


def o_luoi(c, o):
    r = by[(c, o)]
    tk = bool(r["thiet_ke_duoc"]) if not r["u02"] else all(r["chi_tiet"][a]["duoc"] for a in r["hanh_dong"])
    tk_mot_phan = bool(r["thiet_ke_duoc"]) and not tk
    if r["khop"]:
        cls, ky, tip = ("ok-co", "●", "Cả hai cho") if r["u02"] else ("ok-khong", "", "Cả hai không cho")
    elif r["u02"]:
        cls, ky, tip = "u02", "▼", f"{MT} cho, thiết kế " + ("chỉ cho một phần" if tk_mot_phan else "không cho")
    else:
        cls, ky, tip = "tk", "▲", f"Thiết kế cho, {MT} không cho"
    ma = gt.get((c, o), {}).get("ma", "")
    nhan = f'{e(KQ["cot"][c])} · {e(r["ten"])}: {tip}'
    if r["khop"]:
        return f'<td class="cell {cls}" title="{nhan}"><span aria-label="{nhan}">{ky}</span></td>'
    return f'<td class="cell {cls}"><a href="#{e(ma)}" title="{nhan}" aria-label="{nhan}">{ky}</a></td>'


luoi = [f'<table class="grid"><thead><tr><th scope="col" class="corner">Thao tác \\ cột {e(MT)}</th>']
for ten, cs in NHOM_COT:
    for c in cs:
        luoi.append(f'<th scope="col" class="colh" title="{e(KQ["cot"][c])}"><span class="cn">{e(TEN_NGAN[c])}</span></th>')
luoi.append("</tr></thead><tbody>")
for o, ten in o_so:
    luoi.append(f'<tr><th scope="row" class="rowh">{e(ten)}</th>' + "".join(o_luoi(c, o) for _, cs in NHOM_COT for c in cs) + "</tr>")
luoi.append("</tbody></table>")


def dong_lech(g):
    r = by[(g["cot"], g["o_so"])]
    ten_loai, cls, _ = LOAI[g["loai"]]
    tk_txt = ("Được" if r["thiet_ke_duoc"] else "Không được") if not r["u02"] else ("Một phần" if r["thiet_ke_duoc"] else "Không được")
    tk_cls = "yes" if r["thiet_ke_duoc"] else "no"
    if r["u02"] and r["thiet_ke_duoc"]:
        tk_cls = "part"
    buoc = "".join(f"<li>{e(b)}</li>" for b in g["chuoi_suy_ra"])
    note = "\n".join(g["tom_tat_note"])
    ba = f'<p class="todo"><b>Việc cho BA:</b> {e(g["viec_cho_ba"])}</p>' if g.get("viec_cho_ba") else ""
    tinh_huong = f'<p class="ctx">{e(g["tinh_huong"])}</p>' if g.get("tinh_huong") else ""
    return (f'<tr id="{e(g["ma"])}" data-t="{cls}">'
            f'<td class="role">{e(g.get("ten_vai_tro") or KQ["cot"][g["cot"]])}</td>'
            f'<td class="act">{e(r["ten"])}</td>'
            f'<td class="dir"><span class="pill {"yes" if r["u02"] else "no"}">{"Được" if r["u02"] else "Không được"}</span></td>'
            f'<td class="dir"><span class="pill {tk_cls}">{tk_txt}</span></td>'
            f'<td class="type"><span class="badge {cls}">{e(ten_loai)}</span></td>'
            f'<td class="why">{tinh_huong}<ol class="chain">{buoc}</ol>{ba}'
            f'<div class="note"><div class="note-h"><span>Tóm tắt để note</span>'
            f'<button type="button" class="copy" data-note="{e(note)}" id="copy-{e(g["ma"])}">Chép</button></div>'
            f'<pre>{e(note)}</pre></div></td></tr>')


bang = []
for ten, cs in NHOM_COT:
    gs = [g for g in GT["o_lech"] if g["cot"] in cs]
    if not gs:
        continue
    gs.sort(key=lambda g: (cot.index(g["cot"]), [x[0] for x in o_so].index(g["o_so"])))
    bang.append(f'<tr class="grp"><td colspan="6">{e(ten)}</td></tr>')
    bang += [dong_lech(g) for g in gs]

viec_ba = "".join(f'<li><b>{e(v["tieu_de"])}</b> {e(v["noi_dung"])} <span class="refs">{e(", ".join(v.get("o", [])))}</span></li>' for v in GT["viec_cho_ba"])
sua_nguon = "".join(f'<li><b>{e(v["o"])}</b> {e(v["noi_dung"])}</li>' for v in GT["sua_nguon"])
luu_y = "".join(f'<li><b>{e(v["tieu_de"])}</b> {e(v["noi_dung"])}</li>' for v in GT["khop_can_luu_y"])
thay_doi = "".join(f"<li>{e(x)}</li>" for x in GT["thay_doi"])
nguoi = "".join(f'<li>{e(n["mo_ta"])}: '
                f'{e(", ".join(f"{v} tại {d}" if d else f"{v} (toàn hệ thống)" for v, d in n["vai_tro"]) or "không có vai trò thiết kế")}</li>'
                for n in KQ["nguoi"])

khop = len(rows) - len(lech)
page = f'''<title>{e(TIEU_DE)}</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap">
<style>
/* Bố cục: một cột đọc. Trên cùng là số liệu và lưới 16 cột × 12 thao tác để thấy ngay ô lệch; dưới là bảng giải thích từng ô (cuộn ngang trong khung riêng), cuối là việc cho BA và cách so. */
:root {{
  --bg: #f4f6f3; --surface: #ffffff; --ink: #1b231e; --muted: #59645d; --line: #d9dfda; --soft: #eef2ee;
  --accent: #36654a; --accent-soft: #e2eee6;
  --tk: #8a4a12; --tk-soft: #fbe9d6; --u02: #7c2f4a; --u02-soft: #f6e3ea; --warn: #8a6a00; --warn-soft: #f8efcc;
  --yes: #2d6a45; --yes-soft: #e1f0e6; --no: #6a5d58; --no-soft: #efebe9;
  --font-text: "Be Vietnam Pro", "Segoe UI", system-ui, sans-serif; --font-mono: "JetBrains Mono", ui-monospace, Consolas, monospace;
}}
@media (prefers-color-scheme: dark) {{
  :root:not([data-theme="light"]) {{
    --bg: #131815; --surface: #1b211d; --ink: #e6ebe7; --muted: #a1aca5; --line: #2e3631; --soft: #222924;
    --accent: #8fc0a0; --accent-soft: #23362b; --tk: #f0b47a; --tk-soft: #3d2b19; --u02: #eaa0bb; --u02-soft: #3c2330;
    --warn: #e6c65c; --warn-soft: #3a3217; --yes: #8fd0a6; --yes-soft: #1f3528; --no: #b9aea9; --no-soft: #2c2826; color-scheme: dark;
  }}
}}
:root[data-theme="dark"] {{
  --bg: #131815; --surface: #1b211d; --ink: #e6ebe7; --muted: #a1aca5; --line: #2e3631; --soft: #222924;
  --accent: #8fc0a0; --accent-soft: #23362b; --tk: #f0b47a; --tk-soft: #3d2b19; --u02: #eaa0bb; --u02-soft: #3c2330;
  --warn: #e6c65c; --warn-soft: #3a3217; --yes: #8fd0a6; --yes-soft: #1f3528; --no: #b9aea9; --no-soft: #2c2826; color-scheme: dark;
}}
* {{ box-sizing: border-box; }}
body {{ background: var(--bg); color: var(--ink); font-family: var(--font-text); font-size: 15px; line-height: 1.55;
  padding-left: max(16px, env(safe-area-inset-left, 0px)); padding-right: max(16px, env(safe-area-inset-right, 0px)); padding-block: 28px 48px; }}
.wrap {{ max-width: 1240px; margin: 0 auto; display: grid; gap: 28px; }}
h1 {{ font-size: 1.7rem; line-height: 1.25; margin: 0; text-wrap: balance; font-weight: 700; }}
h2 {{ font-size: 1.15rem; margin: 0 0 10px; font-weight: 600; text-wrap: balance; }}
p {{ margin: 0; }}
.sub {{ color: var(--muted); max-width: 75ch; margin-top: 8px; }}
.eyebrow {{ text-transform: uppercase; letter-spacing: .06em; font-size: .74rem; color: var(--muted); font-weight: 600; margin-bottom: 6px; }}
.stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; }}
.stat {{ background: var(--surface); border: 1px solid var(--line); border-radius: 8px; padding: 10px 14px; min-width: 0; }}
.stat b {{ display: block; font-size: 1.35rem; font-variant-numeric: tabular-nums; }}
.stat span {{ color: var(--muted); font-size: .85rem; }}
.stat.tk b {{ color: var(--tk); }} .stat.u02 b {{ color: var(--u02); }}
.panel {{ background: var(--surface); border: 1px solid var(--line); border-radius: 10px; padding: 18px 20px; min-width: 0; }}
.two {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 16px; }}
.two > * {{ min-width: 0; }}
ol, ul {{ margin: 0; padding-left: 20px; display: grid; gap: 8px; }}
.refs {{ font-family: var(--font-mono); font-size: .76rem; color: var(--muted); }}
.code {{ font-family: var(--font-mono); font-weight: 500; }}
.legend {{ display: flex; flex-wrap: wrap; gap: 6px 16px; font-size: .86rem; color: var(--muted); align-items: center; }}
.key {{ display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 5px; margin-right: 5px; font-size: .8rem; vertical-align: middle; }}
.gridbox {{ overflow-x: auto; background: var(--surface); border: 1px solid var(--line); border-radius: 10px; }}
table.grid {{ border-collapse: separate; border-spacing: 3px; min-width: 980px; padding: 8px; }}
.grid th {{ font-weight: 500; }}
.grid .corner {{ text-align: left; font-size: .74rem; color: var(--muted); text-transform: uppercase; letter-spacing: .05em; min-width: 190px; }}
.grid .colh {{ font-size: .7rem; color: var(--muted); vertical-align: bottom; width: 48px; text-align: center; line-height: 1.25; }}
.grid .colh .cl {{ display: block; font-family: var(--font-mono); font-size: .82rem; color: var(--ink); font-weight: 600; }}
.grid .colh .cn {{ display: block; }}
.grid .rowh {{ text-align: left; font-size: .86rem; padding-right: 8px; white-space: nowrap; }}
.cell {{ height: 30px; text-align: center; border-radius: 5px; font-size: .85rem; }}
.cell a {{ display: block; line-height: 30px; color: inherit; text-decoration: none; font-weight: 700; border-radius: 5px; }}
.cell a:hover {{ outline: 2px solid currentColor; outline-offset: -2px; }}
.ok-co, .key.ok-co {{ background: var(--yes-soft); color: var(--yes); }}
.ok-khong, .key.ok-khong {{ background: var(--soft); color: var(--muted); }}
.tk, .key.tk {{ background: var(--tk-soft); color: var(--tk); }}
.u02, .key.u02 {{ background: var(--u02-soft); color: var(--u02); }}
.badge {{ display: inline-block; padding: 2px 9px; border-radius: 999px; font-size: .78rem; font-weight: 600; white-space: nowrap; }}
.badge.a {{ background: var(--accent-soft); color: var(--accent); }}
.badge.c {{ background: var(--soft); color: var(--ink); border: 1px solid var(--line); }}
.badge.b {{ background: var(--warn-soft); color: var(--warn); }}
.badge.d {{ background: transparent; color: var(--muted, var(--ink)); border: 1px dashed var(--line); }}
.pill {{ display: inline-block; padding: 1px 8px; border-radius: 6px; font-size: .8rem; font-weight: 600; white-space: nowrap; }}
.pill.yes {{ background: var(--yes-soft); color: var(--yes); }} .pill.no {{ background: var(--no-soft); color: var(--no); }}
.pill.part {{ background: var(--warn-soft); color: var(--warn); }}
.filters {{ display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }}
.filters button, .copy {{ font: inherit; font-size: .86rem; border: 1px solid var(--line); background: var(--surface); color: var(--ink); padding: 6px 12px; border-radius: 999px; cursor: pointer; }}
.filters button[aria-pressed="true"] {{ background: var(--ink); color: var(--bg); border-color: var(--ink); }}
button:focus-visible, a:focus-visible {{ outline: 2px solid var(--accent); outline-offset: 2px; }}
.count {{ color: var(--muted); font-size: .88rem; margin-left: 4px; }}
.tablebox {{ overflow-x: auto; background: var(--surface); border: 1px solid var(--line); border-radius: 10px; }}
table.detail {{ border-collapse: collapse; width: 100%; min-width: 1120px; }}
.detail th, .detail td {{ text-align: left; vertical-align: top; padding: 12px 14px; border-bottom: 1px solid var(--line); }}
.detail th {{ font-size: .76rem; text-transform: uppercase; letter-spacing: .05em; color: var(--muted); font-weight: 600; }}
.detail tr:last-child td {{ border-bottom: 0; }}
.detail tr.grp td {{ background: var(--soft); font-weight: 600; font-size: .9rem; padding-block: 8px; }}
.detail tr:target td {{ background: var(--accent-soft); }}
td.role {{ width: 180px; font-weight: 500; }}
td.act {{ width: 160px; }}
td.act .cells {{ display: block; font-family: var(--font-mono); font-size: .78rem; color: var(--muted); margin-top: 2px; }}
td.dir {{ width: 100px; }} td.type {{ width: 120px; }}
td.why {{ min-width: 440px; }}
td.why > * + * {{ margin-top: 8px; }}
td.why .ctx {{ font-size: .88rem; color: var(--muted); }}
ol.chain {{ font-size: .88rem; gap: 4px; padding-left: 22px; }}
ol.chain li::marker {{ color: var(--muted); font-family: var(--font-mono); font-size: .8rem; }}
.todo {{ font-size: .88rem; background: var(--warn-soft); color: var(--ink); padding: 6px 10px; border-radius: 6px; }}
.note {{ border: 1px dashed var(--line); border-radius: 8px; padding: 8px 10px; }}
.note-h {{ display: flex; justify-content: space-between; align-items: center; gap: 8px; font-size: .74rem; text-transform: uppercase; letter-spacing: .05em; color: var(--muted); font-weight: 600; }}
.copy {{ padding: 2px 10px; font-size: .78rem; text-transform: none; letter-spacing: 0; }}
.note pre {{ margin: 6px 0 0; white-space: pre-wrap; font-family: var(--font-text); font-size: .86rem; color: var(--ink); }}
td.src {{ width: 200px; font-family: var(--font-mono); font-size: .76rem; color: var(--muted); line-height: 1.6; }}
.gloss {{ display: grid; grid-template-columns: max-content 1fr; gap: 6px 14px; font-size: .9rem; }}
.gloss dt {{ font-family: var(--font-mono); font-weight: 500; }} .gloss dd {{ margin: 0; color: var(--muted); }}
.users {{ font-size: .88rem; gap: 4px; }}
.small {{ font-size: .88rem; color: var(--muted); }}
@media (max-width: 560px) {{ h1 {{ font-size: 1.4rem; }} }}
@media (prefers-reduced-motion: reduce) {{ * {{ transition: none !important; scroll-behavior: auto !important; }} }}
</style>

<div class="wrap">
  <header>
    <div class="eyebrow">{e(KQ.get("phan_he", ""))} · {e(GT["ngay"])}</div>
    <h1>{e(TIEU_DE)}</h1>
    <p class="sub">{e(GT["gioi_thieu"])}</p>
  </header>

  <section class="stats" aria-label="Tóm tắt">
    <div class="stat"><b>{khop} / {len(rows)}</b><span>ô khớp</span></div>
    <div class="stat"><b>{len(lech)}</b><span>ô lệch</span></div>
    <div class="stat tk"><b>{huong_tk}</b><span>thiết kế cho, {e(MT)} không cho</span></div>
    <div class="stat u02"><b>{huong_u02}</b><span>{e(MT)} cho, thiết kế không cho</span></div>
    <div class="stat"><b>{dem_loai["A"]} · {dem_loai["A_BA"]} · {dem_loai["B"]}{(" · " + str(dem_loai["C"])) if dem_loai["C"] else ""}{(" · " + str(dem_loai["?"]) + " chưa giải thích") if dem_loai["?"] else ""}</b><span>khác ô nguồn · khác câu BA chốt · nguồn mâu thuẫn{" · lệch khi cài đặt" if dem_loai["C"] else ""}</span></div>
  </section>

  <section class="panel">
    <h2>Thay đổi so với bản trước</h2>
    <ul>{thay_doi}</ul>
  </section>

  <section>
    <h2>Lưới so sánh</h2>
    <div class="legend" style="margin-bottom:10px">
      <span><span class="key ok-co">●</span>cả hai cho</span>
      <span><span class="key ok-khong"></span>cả hai không cho</span>
      <span><span class="key tk">▲</span>thiết kế cho, {e(MT)} không cho</span>
      <span><span class="key u02">▼</span>{e(MT)} cho, thiết kế không cho (hoặc chỉ cho một phần)</span>
      <span>Bấm ô lệch để xem giải thích.</span>
    </div>
    <div class="gridbox">{"".join(luoi)}</div>
  </section>


  <section>
    <h2>Giải thích từng ô lệch</h2>
    <div class="legend" style="margin-bottom:12px">
      <span><span class="badge a">{LOAI["A"][0]}</span> {e(LOAI["A"][2])}</span>
      <span><span class="badge c">{LOAI["A_BA"][0]}</span> {e(LOAI["A_BA"][2])}</span>
      <span><span class="badge b">{LOAI["B"][0]}</span> {e(LOAI["B"][2])}</span>
      {('<span><span class="badge d">' + e(LOAI["C"][0]) + "</span> " + e(LOAI["C"][2]) + "</span>") if dem_loai["C"] else ""}
    </div>
    <div class="filters" role="group" aria-label="Lọc theo loại">
      <button type="button" id="f-all" data-f="all" aria-pressed="true">Tất cả</button>
      <button type="button" id="f-a" data-f="a" aria-pressed="false">{LOAI["A"][0]}</button>
      <button type="button" id="f-c" data-f="c" aria-pressed="false">{LOAI["A_BA"][0]}</button>
      <button type="button" id="f-b" data-f="b" aria-pressed="false">{LOAI["B"][0]}</button>
      {('<button type="button" id="f-d" data-f="d" aria-pressed="false">' + e(LOAI["C"][0]) + "</button>") if dem_loai["C"] else ""}
      <span class="count" id="count"></span>
    </div>
    <div class="tablebox" style="margin-top:12px">
      <table class="detail">
        <thead><tr><th>Vai trò</th><th>Thao tác</th><th>{e(MT)}</th><th>Thiết kế</th><th>Loại</th><th>Vì sao lệch</th></tr></thead>
        <tbody id="rows">{"".join(bang)}</tbody>
      </table>
    </div>
  </section>

  <section class="two">
    <div class="panel"><h2>Khớp nhưng cần lưu ý</h2><ul>{luu_y}</ul></div>
    <div class="panel">
      <h2>Cách so</h2>
      <p class="small" style="margin-bottom:10px">{e(GT["cach_so"])}</p>
      <h2 style="margin-top:16px">Người dùng thử của từng cột</h2>
      <ul class="users">{nguoi}</ul>
    </div>
  </section>
</div>

<script>
(function () {{
  var btns = document.querySelectorAll('.filters button');
  var rows = document.querySelectorAll('#rows tr[data-t]');
  var groups = document.querySelectorAll('#rows tr.grp');
  var count = document.getElementById('count');
  function apply(f) {{
    var n = 0;
    rows.forEach(function (r) {{ var show = f === 'all' || r.dataset.t === f; r.hidden = !show; if (show) n += 1; }});
    groups.forEach(function (g) {{
      var el = g.nextElementSibling, any = false;
      while (el && !el.classList.contains('grp')) {{ if (!el.hidden) any = true; el = el.nextElementSibling; }}
      g.hidden = !any;
    }});
    count.textContent = n + ' ô lệch';
    btns.forEach(function (b) {{ b.setAttribute('aria-pressed', String(b.dataset.f === f)); }});
  }}
  btns.forEach(function (b) {{ b.addEventListener('click', function () {{ apply(b.dataset.f); }}); }});
  document.querySelectorAll('.grid a[href^="#"]').forEach(function (a) {{
    a.addEventListener('click', function () {{ apply('all'); }});
  }});
  document.querySelectorAll('.copy').forEach(function (b) {{
    b.addEventListener('click', function () {{
      var text = b.dataset.note;
      var done = function () {{ b.textContent = 'Đã chép'; setTimeout(function () {{ b.textContent = 'Chép'; }}, 1500); }};
      var fallback = function () {{
        var pre = b.closest('.note').querySelector('pre'); var sel = window.getSelection(); var rg = document.createRange();
        rg.selectNodeContents(pre); sel.removeAllRanges(); sel.addRange(rg); b.textContent = 'Đã chọn, nhấn Ctrl+C';
      }};
      try {{ navigator.clipboard.writeText(text).then(done, fallback); }} catch (err) {{ fallback(); }}
    }});
  }});
  apply('all');
}})();
</script>
'''
open(RA, "w", encoding="utf-8").write(page)
print(f"{os.path.relpath(RA, LV)}: {len(lech)} ô lệch, {khop}/{len(rows)} ô khớp")
