# -*- coding: utf-8 -*-
"""Xuất thiết kế phân quyền sang DSL của playground (resource / role / derive / userset / resourceset / permit)
và bảng «ai được làm gì trên tài nguyên nào». KHÔNG sinh dữ liệu mẫu (user, instance, assign, relate, assert).

  python -I xuat_dsl.py <thu_muc_lam_viec> [--mot-tep] [--tai-nguyen a,b] [--chua-xac-nhan]

Đọc thiet_ke_phan_quyen.json, ra_soat.json (nếu có) và phan_quyen_import.json (tự chạy xuat_json.py nếu chưa có hoặc cũ hơn thiết kế).
- Cấu trúc lấy từ phan_quyen_import.json: vai trò trên tài nguyên → `role`, grantedTo → `derive`, vai trò chung → `role … "Tên": res:act`,
  quyền ABAC → `userset` / `resourceset` / `permit`.
- Đầu mỗi tệp DSL là khối chú thích «Ai được làm gì trên tài nguyên nào»: mỗi tài nguyên, mỗi vai trò, các hành động,
  phạm vi bằng chữ, điều kiện, nguồn gốc, và vai trò DSL thực hiện quyền đó.
- Ngoài playground.dsl (toàn bộ) còn tách playground_theo_mang/<mảng>.dsl: mỗi tệp chỉ có tài nguyên của một mảng,
  cộng cây và vai trò cầu nối cần để tính phạm vi (--mot-tep để bỏ).
- Tự kiểm trên cấu trúc (không cần bản ghi): với mỗi vai trò, lần theo `derive` từ nơi vai trò được gán, tính tập
  (tài nguyên, hành động) mà DSL cấp và loại phạm vi của đường đi (đơn vị mình / lan xuống cấp dưới / cấp duyệt / chung / ABAC),
  so với thiết kế. Lệch là lỗi của bước xuất.
- Tự kiểm điều kiện: quyền có điều kiện mà DSL cấp qua luật `permit` có tập hồ sơ chứa đủ điều kiện là «đã áp»;
  còn lại là «nới rộng» (DSL cấp trên mọi bản ghi trong phạm vi): báo số, liệt kê, ghi «chưa áp» ở bảng «ai được làm gì».
  Nới rộng không phải lỗi của bước xuất (khuôn chỉ có luật cấp thêm) nhưng phải có nơi chặn (bao_cao_xuat_json.md).
Điều kiện chưa áp được ghi thành chú thích cuối tệp.
Ghi: playground.dsl, playground_theo_mang/*.dsl, ai_duoc_lam_gi.md, bao_cao_playground.md
"""
import argparse, collections, json, os, re, subprocess, sys, unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import dieu_kien as DKM  # noqa: E402
import ha_muc as HM  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8"); sys.stderr.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
KIEU_DSL = {"string": "string", "number": "number", "bool": "bool", "time": "string", "array": "string"}
ABAC = {"do_minh_lap", "duoc_giao"}
# loại phạm vi mà đường derive phải cho ra, theo kiểu phạm vi của thiết kế
KY_VONG = {"toan_he_thong": {"chung"}, "danh_sach": {"chung"}, "don_vi_minh": {"minh"}, "cap_duyet": {"cap_duyet"},
           "don_vi_minh_va_cap_duoi": {"minh", "cap_duoi"}, "don_vi_minh_va_cap_duoi_truc_tiep": {"minh", "cap_duoi"},
           "do_minh_lap": {"ban_ghi"}, "duoc_giao": {"ban_ghi"}}
TEN_LOP = {"chung": "chung (không theo bản ghi / toàn hệ thống)", "minh": "nơi được gán", "cap_duoi": "lan xuống cấp dưới",
           "cap_duyet": "theo cấp duyệt", "abac": "ABAC", "ban_ghi": "gán trên bản ghi (người lập / người được giao)"}
NGUON = {"giu": "Theo tài liệu / BA chốt", "ke_thua": "Theo quy định chung", "them": "AI đề xuất thêm"}   # hai mục sau: thiết kế cũ
TEN_PV = {"toan_he_thong": "Toàn hệ thống", "don_vi_minh": "Đơn vị mình", "don_vi_minh_va_cap_duoi": "Đơn vị mình và mọi cấp dưới",
          "don_vi_minh_va_cap_duoi_truc_tiep": "Đơn vị mình và cấp dưới trực tiếp", "cap_duyet": "Bản ghi đang chờ đơn vị mình duyệt",
          "do_minh_lap": "Bản ghi do chính mình lập", "duoc_giao": "Bản ghi được giao cho mình"}


def doc(p, md=None):
    if not os.path.exists(p):
        return md
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def q_str(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', "'") + '"'


def gia_tri(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    return q_str(v)


def slug(s):
    s = s.lower().replace("đ", "d")
    s = "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")
    return "_".join(re.findall(r"[a-z0-9]+", s))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("thu_muc")
    ap.add_argument("--mot-tep", action="store_true", help="chỉ ghi playground.dsl, không tách tệp theo mảng")
    ap.add_argument("--tai-nguyen", help="chỉ xuất các tài nguyên này (key cách nhau bởi dấu phẩy) ra playground_chon/<key>__<key>.dsl, không ghi lại tệp khác")
    ap.add_argument("--chua-xac-nhan", action="store_true", help="xuất dù BA chưa xác nhận bản xem trước (chỉ để thử kỹ thuật)")
    a = ap.parse_args()
    wd = a.thu_muc
    if not a.chua_xac_nhan:
        tt = json.loads(subprocess.run([sys.executable, "-I", os.path.join(HERE, "xac_nhan.py"), "trang-thai", wd],
                                       capture_output=True, text=True, encoding="utf-8", check=True).stdout)
        if not tt["da_xac_nhan_xem_truoc"]:
            sys.exit("BA chưa xác nhận bản xem trước (hoặc thiết kế / ý kiến đã đổi sau khi xác nhận). "
                     "Chạy xac_nhan.py xem-truoc, để BA xác nhận, ghi bằng xac_nhan.py ghi <lv> xem_truoc dong_y, rồi xuất lại.")
    # bản nháp (rà soát nghiệp vụ dùng để so với ma trận của BA) có tệp đánh dấu; bản xuất đã xác nhận xoá tệp này
    p_nhap = os.path.join(wd, "BAN_NHAP_CHUA_XAC_NHAN.txt")
    if a.chua_xac_nhan:
        with open(p_nhap, "w", encoding="utf-8") as f:
            f.write("DSL, JSON import, ai_duoc_lam_gi.md trong thư mục này là BẢN NHÁP: BA chưa xác nhận bản xem trước.\n"
                    "Chỉ dùng để so với ma trận phân quyền khi rà soát. Bản cuối do /thiet-ke-phan-quyen xuất sau khi BA xác nhận.\n")
    elif os.path.exists(p_nhap):
        os.remove(p_nhap)
    p_tk, p_im = os.path.join(wd, "thiet_ke_phan_quyen.json"), os.path.join(wd, "phan_quyen_import.json")
    p_rs = os.path.join(wd, "ra_soat.json")
    moc = max(os.path.getmtime(p) for p in (p_tk, p_rs) if os.path.exists(p))
    if not os.path.exists(p_im) or os.path.getmtime(p_im) < moc:
        subprocess.run([sys.executable, "-I", os.path.join(HERE, "xuat_json.py"), wd], check=True)
    D, IM = doc(p_tk), doc(p_im)
    RS = (doc(p_rs, {"muc": {}}) or {}).get("muc", {})
    TN = {t["key"]: t for t in D["tai_nguyen"]}
    VT = {v["key"]: v for v in D["vai_tro"]}
    PV = {p["key"]: p for p in D["pham_vi"]}
    DK = {d["key"]: d for d in D["dieu_kien"]}
    HD = {(t["key"], h["key"]): h for t in D["tai_nguyen"] for h in t["hanh_dong"]}
    R = {r["key"]: r for r in IM["resources"]}
    ph = D.get("phan_he") or {}

    # ---------- quyền hiệu lực theo thiết kế (cùng cách tính với xuat_json.py) ----------
    cau_cua = {k: c["key"] for c in D.get("cau_mo_ta", []) for k in c["quyen"]}
    HL = []
    for q in D["quyen"]:
        kq = RS.get(q["khoa"], {}).get("ket_qua") or RS.get(cau_cua.get(q["khoa"], ""), {}).get("ket_qua")
        t = q["trang_thai"]
        if kq == "khong_dong_y":
            t = {"them": "bo", "bo": "giu"}.get(t, t)
        if t != "bo":
            HL.append(dict(q, trang_thai_hl=t))

    kieu_pv = lambda k: (PV.get(k) or {}).get("kieu") or k or "toan_he_thong"
    HL0 = list(HL)
    HL, _ = HM.ha_muc(HL, D, kieu_pv)   # cùng cách với xuat_json.py: xuất danh sách có điều kiện → mức bản ghi theo phạm vi xem
    ten_hd = lambda rk, act: HD[(rk, act)]["ten"].lower() if (rk, act) in HD else act
    ten_hd_q = lambda q: ten_hd(q["tai_nguyen"], q["hanh_dong"]) + (" (theo từng hồ sơ được xem)" if q.get("ha_muc") else "")
    CAY_REL = {rk: next((r["key"] for r in t.get("quan_he", []) if r["toi"] == rk), None) for rk, t in TN.items() if t.get("loai") == "cay"}
    TEN_RO = {k for r in IM["resources"] for k in r["roles"]}
    ten_chung = lambda k: f"{k}__quyen_chung" if k in TEN_RO else k   # tránh trùng key vai trò trên tài nguyên
    US_VT = lambda us: us[len("nguoi_giu_"):] if us.startswith("nguoi_giu_") else None   # userset «người giữ vai trò» (xuat_json.py)

    # cách áp từng quyền (xuat_json.py ghi cach_ap.json): khoá = (vai trò, tài nguyên, hành động, phạm vi, điều kiện)
    CA = {(c["vai_tro"], c["tai_nguyen"], c["hanh_dong"], c["pham_vi"], tuple(c["dieu_kien"])): c
          for c in (doc(os.path.join(wd, "cach_ap.json"), []) or [])}
    cach = lambda q: (CA.get((q["vai_tro"], q["tai_nguyen"], q["hanh_dong"], q["pham_vi"], tuple(q["dieu_kien"]))) or {}).get("cach")
    # quyền DSL mang tên khác quyền thiết kế (thêm mới kiểm trên cây, biến thể theo điều kiện) → (tài nguyên, hành động) thiết kế
    ALIAS = {tuple(p.split(":", 1)): (c["tai_nguyen"], c["hanh_dong"]) for c in CA.values()
             for p in c["quyen_dsl"] if tuple(p.split(":", 1)) != (c["tai_nguyen"], c["hanh_dong"])}
    KY_VONG_CACH = {"tao_tren_cay": {"minh"}, "bien_the": {"chung"}, "vai_tro_ban_ghi_theo_nguoi": {"ban_ghi"}, "vai_tro_ban_ghi": {"ban_ghi"}}
    HL_KC = [q for q in HL if cach(q) == "khong_cap"]           # không cấp vì chưa áp được: thiết kế có, DSL cố ý không cấp
    HL_KC += [q for q in HL0 if cach(q) == "khong_cap" and q not in HL_KC]   # xuất danh sách của vai trò không có quyền xem (ha_muc.py)
    HL = [q for q in HL if cach(q) != "khong_cap"]

    def ap_dsl(q, CSRf=()):
        """Quyền có điều kiện được DSL áp đủ (mọi cách áp trừ «nới rộng»; bước xuất không sinh cách này)."""
        return not any(d in DK for d in q["dieu_kien"]) or cach(q) != "noi_rong"

    BG = doc(os.path.join(wd, "vai_tro_tren_ban_ghi.json"), []) or []   # vai trò trên bản ghi do ứng dụng gán (xuat_json.py)
    BG_VT = {(m["tai_nguyen"], m["vai_tro"]) for m in BG}
    QH = doc(os.path.join(wd, "quan_he_theo_dieu_kien.json"), []) or []   # quan hệ theo điều kiện (xuat_json.py)
    QH_Q = {(m["tai_nguyen"], x["vai_tro"], x["hanh_dong"]) for m in QH for x in m["quyen"]}

    def thiet_ke_abac(q):
        if VT[q["vai_tro"]]["loai_pham_vi"] == "theo_ban_ghi":
            return True
        return kieu_pv(q["pham_vi"]) in ABAC and (q["tai_nguyen"], q["vai_tro"]) not in BG_VT

    # ---------- đồ thị derive: từ nơi gán vai trò tới vai trò trên tài nguyên ----------
    def lop(co):
        return "ban_ghi" if "ban_ghi" in co else "cap_duyet" if "cap_duyet" in co else "cap_duoi" if "cap_tren" in co else "minh"

    def dsl_cap(vk, Rf, Gp, CSRf=()):
        """(tài nguyên, hành động) → [tập loại phạm vi, tập vai trò DSL] mà DSL cấp cho người giữ vai trò vk."""
        E = collections.defaultdict(list)
        for rk, r in Rf.items():
            for k, ro in r["roles"].items():
                for g in (ro.get("grantedTo") or {}).get("users_with_role", []):
                    E[(g["on_resource"], g["role"])].append((rk, k, g["linked_by_relation"]))
        out = collections.defaultdict(lambda: [set(), set()])
        for p in Gp.get(vk, ()):
            rk, act = p.split(":", 1)
            out[(rk, act)][0].add("chung"); out[(rk, act)][1].add(ten_chung(vk))
        for r in CSRf:   # quyền toàn hệ thống có điều kiện: luật permit cho người giữ vai trò
            if US_VT(r["user_set"]) == vk:
                rk, act = r["permission"].split(":", 1)
                out[(rk, act)][0].add("chung"); out[(rk, act)][1].add(f"permit {r['user_set']} → {r['resource_set']}")
        hang = [((rk, vk), frozenset()) for rk in Rf if vk in Rf[rk]["roles"]]
        hang += [((m["tai_nguyen"], m["vai_tro_ban_ghi"]), frozenset({"ban_ghi"})) for m in BG
                 if m["vai_tro"] == vk and m["tai_nguyen"] in Rf and m["vai_tro_ban_ghi"] in Rf[m["tai_nguyen"]]["roles"]]
        da = set()
        while hang:
            (rk, k), co = hang.pop()
            if ((rk, k), co) in da:
                continue
            da.add(((rk, k), co))
            for p in Rf[rk]["roles"][k]["permissions"]:
                r2, act = p.split(":", 1)
                out[(r2, act)][0].add(lop(co)); out[(r2, act)][1].add(k)
            for r2, k2, rel in E.get((rk, k), []):
                c2 = set(co)
                if rel.startswith("cap_duyet"):
                    c2.add("cap_duyet")
                elif r2 == rk and rel == CAY_REL.get(rk):
                    c2.add("cap_tren")
                hang.append(((r2, k2), frozenset(c2)))
        for k in [k for k in out if k in ALIAS]:      # thêm mới kiểm trên cây, biến thể theo điều kiện → quyền thiết kế
            v = out.pop(k)
            t = out[ALIAS[k]]
            t[0] |= v[0]; t[1] |= {f"{x} ({k[0]}:{k[1]})" for x in v[1]}
        return out

    def bao_dong(rs):
        """Tài nguyên + vai trò cần giữ để các quyền trên rs tính đúng: vai trò cầu nối mà derive nhắc tới, cây mà quan hệ trỏ tới."""
        giu_tn, giu_ro = set(rs), {(rk, k) for rk in rs for k in R[rk]["roles"]}
        hang = list(giu_ro)
        while hang:
            rk, k = hang.pop()
            for g in (R[rk]["roles"][k].get("grantedTo") or {}).get("users_with_role", []):
                x = (g["on_resource"], g["role"])
                giu_tn.add(x[0])
                if g["role"] in R[x[0]]["roles"] and x not in giu_ro:
                    giu_ro.add(x); hang.append(x)
        doi = True
        while doi:
            doi = False
            for rk in list(giu_tn):
                for r in R[rk]["relations"].values():
                    if r["resource"] not in giu_tn:
                        giu_tn.add(r["resource"]); doi = True
        return giu_tn, giu_ro

    def thuoc(p, rs):
        """Quyền DSL p thuộc tập tài nguyên rs (kể cả quyền thêm mới đặt trên cây của tài nguyên trong rs)."""
        k = tuple(p.split(":", 1))
        return k[0] in rs or ALIAS.get(k, (None,))[0] in rs

    def loc(rs):
        """Phần cấu trúc import chỉ gồm quyền trên rs (None = toàn bộ)."""
        toan_bo = rs is None
        rs = set(R) if toan_bo else set(rs)
        giu_tn, giu_ro = (set(R), {(rk, k) for rk in R for k in R[rk]["roles"]}) if toan_bo else bao_dong(rs)
        Rf = collections.OrderedDict()
        for rk in R:
            if rk not in giu_tn:
                continue
            r = R[rk]
            roles = collections.OrderedDict()
            for k, ro in r["roles"].items():
                if (rk, k) in giu_ro:
                    roles[k] = dict(ro, permissions=[p for p in ro["permissions"] if thuoc(p, rs)])
            Rf[rk] = dict(r, roles=roles, actions=r["actions"] if rk in rs else [x for x in r["actions"] if ALIAS.get((rk, x), (None,))[0] in rs])
        Gp = {g["key"]: [p for p in g["permissions"] if thuoc(p, rs)] for g in IM["roles"]}
        CSRf = [r for r in IM.get("condition_set_rules", []) if r["permission"].split(":", 1)[0] in rs]
        return rs, Rf, Gp, CSRf, giu_ro

    # ---------- tự kiểm trên cấu trúc ----------
    def tu_kiem(rs, Rf, Gp, CSRf):
        lc, so = [], 0
        tk = collections.defaultdict(dict)        # vai trò → (tài nguyên, hành động) → kiểu phạm vi
        tk_abac = set()
        for q in HL:
            if q["tai_nguyen"] not in rs:
                continue
            if thiet_ke_abac(q):
                tk_abac.add((q["tai_nguyen"], q["hanh_dong"]))
            else:   # một hành động có thể có nhiều phạm vi (quyền xuất hạ theo nhiều phạm vi xem): kỳ vọng là hợp các phạm vi
                kv = KY_VONG_CACH.get(cach(q)) or KY_VONG.get(kieu_pv(q["pham_vi"]))
                tk[q["vai_tro"]].setdefault((q["tai_nguyen"], q["hanh_dong"]), []).append((kieu_pv(q["pham_vi"]), kv))
        vts = [vk for vk, v in VT.items() if v["loai_pham_vi"] != "theo_ban_ghi"]
        CAP = {}
        for vk in vts:
            cap = {k: v for k, v in dsl_cap(vk, Rf, Gp, CSRf).items() if k[0] in rs}
            CAP[vk] = cap
            for key in sorted(set(tk[vk]) | set(cap)):
                so += 1
                ten = f"«{VT[vk]['ten']}» – {ten_hd(*key)} – «{TN[key[0]]['ten']}»"
                if key not in cap:
                    lc.append(f"{ten}: thiết kế có, DSL không cấp")
                elif key not in tk[vk]:
                    lc.append(f"{ten}: DSL cấp ({', '.join(sorted(cap[key][1]))}) nhưng thiết kế không có")
                else:
                    ks = [x for x, _ in tk[vk][key]]
                    kv = set().union(*(y for _, y in tk[vk][key])) if all(y for _, y in tk[vk][key]) else None
                    if kv and cap[key][0] != kv:
                        lc.append(f"{ten}: phạm vi thiết kế «{', '.join((PV.get(x) or {}).get('ten', x) for x in ks)}», "
                                  f"DSL tính theo {', '.join(TEN_LOP[x] for x in sorted(cap[key][0]))}")
        dsl_abac = {tuple(r["permission"].split(":", 1)) for r in CSRf if not US_VT(r["user_set"])}
        for key in sorted(tk_abac ^ dsl_abac):
            so += 1
            lc.append(f"ABAC – {ten_hd(*key)} – «{TN[key[0]]['ten']}»: " + ("thiết kế có, DSL không cấp" if key in tk_abac else "DSL cấp nhưng thiết kế không có"))
        so += len(tk_abac & dsl_abac)
        nr = [f"«{VT[q['vai_tro']]['ten']}» – {ten_hd(q['tai_nguyen'], q['hanh_dong'])} – «{TN[q['tai_nguyen']]['ten']}»: "
              f"điều kiện «{' + '.join(DK[d]['ten'] for d in q['dieu_kien'] if d in DK)}» chưa áp, DSL cấp trên mọi bản ghi trong phạm vi"
              for q in HL if q["tai_nguyen"] in rs and any(d in DK for d in q["dieu_kien"]) and not ap_dsl(q, CSRf)]
        return so, lc, CAP, nr

    # ---------- ai được làm gì trên tài nguyên nào ----------
    def gan_tai(v):
        if v["loai_pham_vi"] == "toan_he_thong":
            return "toàn hệ thống"
        if v["loai_pham_vi"] == "theo_ban_ghi":
            return "mọi người dùng, xét theo bản ghi"
        g = TN.get(v.get("gan_tren"), {}).get("ten", v.get("gan_tren") or "?")
        return f"gán tại {g}" + (f", cấp {v['cap']}" if v.get("cap") else "")

    def pham_vi_chu(q):
        k = q["pham_vi"] or "toan_he_thong"
        c = cach(q)
        if c == "tao_tren_cay":
            return "đơn vị mình — kiểm trên đơn vị mà bản ghi mới gắn vào"
        if c == "bien_the":
            return "toàn hệ thống — kiểm theo dữ liệu sắp ghi"
        if kieu_pv(k) == "danh_sach":
            return "không theo bản ghi (mức danh sách)"
        ten = (PV.get(k) or {}).get("ten") or TEN_PV.get(kieu_pv(k), k)
        return ten + (" — vai trò trên bản ghi, ứng dụng gán theo người" if c == "vai_tro_ban_ghi_theo_nguoi" else "")

    def nguon_chu(q):
        t = NGUON.get(q["trang_thai_hl"], q["trang_thai_hl"])
        kt = sorted({x["id"] for x in q.get("quy_tac", []) if x.get("loai") == "ke_thua"})
        return t + (f" ({', '.join(kt)})" if q["trang_thai_hl"] == "ke_thua" and kt else "")

    def ai_lam_gi(rs, CAP, CSRf):
        """[(tài nguyên, [dòng])], mỗi dòng: dict ai, gan, lam, pham_vi, dieu_kien, nguon, dsl."""
        abac_tap = collections.defaultdict(set)
        for r in CSRf:
            abac_tap[r["permission"]].add(f"permit {r['user_set']} → {r['resource_set']}")
        out = []
        for rk in [t["key"] for t in D["tai_nguyen"] if t["key"] in rs]:
            nhom = collections.OrderedDict()
            for q in HL + HL_KC:
                if q["tai_nguyen"] != rk:
                    continue
                k = (q["vai_tro"], pham_vi_chu(q), tuple(q["dieu_kien"]), nguon_chu(q), cach(q) == "khong_cap")
                nhom.setdefault(k, []).append(q)
            dong = []
            thu_tu = list(VT)
            for (vk, pv, dk, ng, kc), qs in sorted(nhom.items(), key=lambda x: thu_tu.index(x[0][0])):
                if kc:
                    ly = "; ".join(sorted({(CA.get((q["vai_tro"], q["tai_nguyen"], q["hanh_dong"], q["pham_vi"], tuple(q["dieu_kien"]))) or {}).get("ghi_chu", "") for q in qs}))
                    dong.append({"ai": VT[vk]["ten"], "gan": gan_tai(VT[vk]), "lam": ", ".join(ten_hd_q(q) for q in qs), "pham_vi": pv,
                                 "dieu_kien": "; ".join((DK.get(d) or {}).get("ten", d) for d in dk), "nguon": ng, "dsl": f"KHÔNG CẤP — {ly}"})
                    continue
                dsl = set()
                for q in qs:
                    if thiet_ke_abac(q):
                        dsl |= abac_tap.get(f"{rk}:{q['hanh_dong']}", set())
                    else:
                        dsl |= CAP.get(vk, {}).get((rk, q["hanh_dong"]), [set(), set()])[1]
                chua_ap = [q for q in qs if not ap_dsl(q, CSRf)]
                ghi_chu = ""
                if chua_ap and dk:
                    ghi_chu = (" (chưa áp trong hệ phân quyền: ứng dụng chặn)" if len(chua_ap) == len(qs) else
                               " (chưa áp trong hệ phân quyền với " + ", ".join(ten_hd(rk, q["hanh_dong"]) for q in chua_ap) + ": ứng dụng chặn)")
                dong.append({"ai": VT[vk]["ten"], "gan": gan_tai(VT[vk]), "lam": ", ".join(ten_hd_q(q) for q in qs),
                             "pham_vi": pv, "dieu_kien": "; ".join((DK.get(d) or {}).get("ten", d) for d in dk) + ghi_chu,
                             "nguon": ng, "dsl": ", ".join(sorted(dsl)) or "—"})
            if dong:
                out.append((rk, dong))
        return out

    # ---------- điều kiện ràng buộc (chú thích cuối tệp) ----------
    rb = collections.defaultdict(list)
    for q in HL:
        if ap_dsl(q, IM.get("condition_set_rules", [])):
            continue
        for d in q["dieu_kien"]:
            if d in DK:
                rb[d].append((q["tai_nguyen"], f"{VT[q['vai_tro']]['ten']} · {ten_hd(q['tai_nguyen'], q['hanh_dong'])} «{TN[q['tai_nguyen']]['ten']}»"))

    def viet(ten_tep, rs_vao, tieu_de):
        rs, Rf, Gp, CSRf, giu_ro = loc(rs_vao)
        so, lc, CAP, nr = tu_kiem(rs, Rf, Gp, CSRf)
        bang = ai_lam_gi(rs, CAP, CSRf)
        vd_cau_noi = next((k for r in Rf.values() for k in r["roles"] if "__" in k and not k.endswith("__quyen_chung")), None)
        L = [f"// {tieu_de} — sinh tự động từ thiet_ke_phan_quyen.json bởi skill thiet-ke-phan-quyen.",
             "// Tệp chỉ có cấu trúc phân quyền (tài nguyên, vai trò, kế thừa qua quan hệ, quyền ABAC); không có người dùng, bản ghi mẫu.",
             "// Điều kiện theo thuộc tính bản ghi của quyền toàn hệ thống, người lập: luật permit cuối tệp. Điều kiện còn lại chưa áp: chú thích cuối tệp.",
             "// Tên vai trò cầu nối: <vai trò>__<phạm vi>" + (f", ví dụ {vd_cau_noi}" if vd_cau_noi else "") + "; …__quyen_chung là quyền không đọc, không ghi bản ghi (tải tệp mẫu).",
             "// Thêm mới, nhập: hành động <tài nguyên>__<hành động>[__<điều kiện>] kiểm trên nút cây mà bản ghi mới gắn vào (kiem_khi_tao.json).",
        ] + ([f"// Vai trò trên bản ghi (ứng dụng gán khi tạo / giao bản ghi, cho người đang giữ vai trò gốc): "
              + "; ".join(f"{m['tai_nguyen']}#{m['vai_tro_ban_ghi']} ← " + (
                  f"người có {m['thuoc_tinh']} là mình và giữ «{VT[m['vai_tro']]['ten']}»" if m.get("cach_gan", "theo_thuoc_tinh") == "theo_thuoc_tinh"
                  else f"từng người giữ «{VT[m['vai_tro']]['ten']}» theo phạm vi qua {m['quan_he']}")
                  + (f", CHỈ khi {m['dieu_kien_dsl']}" if m.get("dieu_kien_dsl") else "") for m in BG if m["tai_nguyen"] in rs)]
             if any(m["tai_nguyen"] in rs for m in BG) else []) + (
            [f"// Quan hệ theo điều kiện (ứng dụng CHỈ GHI khi hồ sơ thoả, gỡ khi hết thoả; xem quan_he_theo_dieu_kien.json): "
              + "; ".join(f"{m['tai_nguyen']}.{m['quan_he']} ← như {m['quan_he_goc']}, khi {m['dieu_kien_dsl']}" for m in QH if m["tai_nguyen"] in rs)]
             if any(m["tai_nguyen"] in rs for m in QH) else []) + [  # noqa: E131
             "", "// ========== AI ĐƯỢC LÀM GÌ TRÊN TÀI NGUYÊN NÀO ==========",
             "// Mỗi dòng: vai trò [nơi gán]: hành động — phạm vi bản ghi — điều kiện — nguồn gốc → vai trò DSL thực hiện."]
        for rk, dong in bang:
            L.append(f"// «{TN[rk]['ten']}» ({rk})")
            for d in dong:
                L.append(f"//   - {d['ai']} [{d['gan']}]: {d['lam']} — {d['pham_vi']}" + (f" — khi: {d['dieu_kien']}" if d["dieu_kien"] else "")
                         + f" — {d['nguon']} → {d['dsl']}")
        L += ["", f"tenant mac_dinh {q_str(ph.get('ten') or 'Mặc định')}", ""]
        for rk, r in Rf.items():
            L.append(f"resource {rk} {q_str(r['name'])} {{")
            if r["actions"]:
                L.append("  actions " + ", ".join(r["actions"]))
            if r["attributes"] and rk in rs:
                L.append("  attributes { " + ", ".join(f"{k}: {KIEU_DSL.get(x['type'], 'string')}" for k, x in r["attributes"].items()) + " }")
            if r["relations"]:
                L.append("  relations { " + ", ".join(f"{k}: {x['resource']}" for k, x in r["relations"].items()) + " }")
            if r["roles"]:
                L.append("")
            for k, ro in r["roles"].items():
                acts = [p.split(":", 1)[1] for p in ro["permissions"]]
                L.append(f"  role {k}" + (": " + ", ".join(acts) if acts else ""))
            der = [(k, g) for k, ro in r["roles"].items() for g in (ro.get("grantedTo") or {}).get("users_with_role", [])
                   if (g["on_resource"], g["role"]) in giu_ro or g["role"] not in R[g["on_resource"]]["roles"]]
            if der:
                L.append("")
                for k, g in der:
                    L.append(f"  derive {k} from {g['on_resource']}#{g['role']} via {g['linked_by_relation']}")
            L += ["}", ""]
        for g in IM["roles"]:
            if Gp[g["key"]]:
                L.append(f"role {ten_chung(g['key'])} {q_str(g['name'])}: " + ", ".join(Gp[g["key"]]))
        if CSRf:
            L += ["", "// ABAC: quyền theo thuộc tính (người lập, người được giao; người giữ vai trò toàn hệ thống × hồ sơ thoả điều kiện)"]
            dung = {r["user_set"] for r in CSRf} | {r["resource_set"] for r in CSRf}
            for c in IM["condition_sets"]:
                if c["key"] not in dung:
                    continue
                bt = DKM.dsl_dieu_kien(c["conditions"])
                L.append(f"userset {c['key']} {q_str(c['name'])} where {bt}" if c["type"] == "userset" else f"resourceset {c['key']} {q_str(c['name'])} on {c['resource']} where {bt}")
            gom = collections.defaultdict(list)
            for r in CSRf:
                gom[(r["user_set"], r["resource_set"])].append(r["permission"].split(":", 1)[1])
            for (us, rset), acts in gom.items():
                L.append(f"permit {us} to {rset}: {', '.join(acts)}")
        dk_tep = {d: sorted({m for rk, m in ds if rk in rs}) for d, ds in rb.items()}
        dk_tep = {d: ds for d, ds in dk_tep.items() if ds}
        if dk_tep:
            L += ["", "// ---------- điều kiện chưa áp trong DSL (quyền cấp trên mọi bản ghi trong phạm vi; ứng dụng hoặc hệ đích phải chặn) ----------"]
            for d, ds in dk_tep.items():
                bt = " VÀ ".join(f"{b['trai']} {b['phep']} {b['phai']}" for b in DK[d].get("bieu_thuc", []))
                L.append(f"// {DK[d]['ten']} ({bt}):")
                L += [f"//   - {m}" for m in ds]
        noi_dung = "\n".join(L) + "\n"
        p = os.path.join(wd, ten_tep)
        os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            f.write(noi_dung)
        return {"tep": ten_tep, "kb": round(len(noi_dung.encode("utf-8")) / 1024), "tn": len([k for k in Rf if k in rs]),
                "tn_ho_tro": len(Rf) - len([k for k in Rf if k in rs]),
                "vt": sum(len(r["roles"]) for r in Rf.values()) + len([1 for v in Gp.values() if v]),
                "dong": sum(len(d) for _, d in bang), "so": so, "lech": lc, "noi_rong": nr, "bang": bang,
                "khong_cap": [q for q in HL_KC if q["tai_nguyen"] in rs]}

    def in_kq(k):
        print(f"{k['tep']}: {k['kb']} KB · {k['tn']} tài nguyên (+{k['tn_ho_tro']} hỗ trợ) · {k['vt']} vai trò · "
              f"{k['dong']} dòng «ai được làm gì» · tự kiểm {k['so']} quyền, {len(k['lech'])} lệch · {len(k['noi_rong'])} nới rộng (điều kiện chưa áp) · "
              f"{len(k['khong_cap'])} không cấp (chưa áp được)")
        for x in k["lech"][:5]:
            print("  LỆCH", x)

    if a.tai_nguyen:
        chon = [k.strip() for k in a.tai_nguyen.split(",") if k.strip()]
        thieu = [k for k in chon if k not in R or not R[k]["actions"]]
        if thieu:
            sys.exit(f"Không có tài nguyên (hoặc không có hành động): {', '.join(thieu)}")
        in_kq(viet(os.path.join("playground_chon", "__".join(chon) + ".dsl"), chon, f"Phân quyền «{ph.get('ten', '')}» — chỉ {', '.join(chon)}"))
        return

    KQ = [viet("playground.dsl", None, f"Phân quyền phân hệ «{ph.get('ten', '')}» — toàn bộ")]
    mang = collections.OrderedDict()
    for t in D["tai_nguyen"]:
        if t["key"] in R and t.get("hanh_dong"):   # cây chỉ mang hành động thêm mới của tài nguyên khác: không tách tệp riêng
            mang.setdefault(t.get("mang") or "Khác", []).append(t["key"])
    if not a.mot_tep:
        for m, rs in mang.items():
            KQ.append(viet(os.path.join("playground_theo_mang", f"{slug(m)}.dsl"), rs, f"Phân quyền «{ph.get('ten', '')}» — mảng {m}"))

    # ---------- ai_duoc_lam_gi.md: toàn phân hệ, theo mảng → tài nguyên ----------
    bang_tb = dict(KQ[0]["bang"])
    A = [f"# Ai được làm gì trên tài nguyên nào — {ph.get('ten', '')}", "",
         "Sinh từ thiết kế BA đã xác nhận, đã áp mọi ý kiến rà soát. Mỗi dòng trả lời: **ai** (vai trò, nơi gán) "
         "**được làm gì** (hành động) **trên bản ghi nào** (phạm vi), **khi nào** (điều kiện), vì sao (nguồn gốc). "
         "Cột «Trong DSL» là vai trò hoặc luật trong tệp DSL thực hiện quyền đó. Không có dữ liệu mẫu.", ""]
    for m, rs in mang.items():
        A += [f"## {m}", ""]
        for rk in rs:
            if rk not in bang_tb:
                continue
            A += [f"### {TN[rk]['ten']} (`{rk}`)", "",
                  "| Ai | Nơi gán | Được làm | Trên bản ghi nào | Điều kiện | Nguồn gốc | Trong DSL |", "|---|---|---|---|---|---|---|"]
            for d in bang_tb[rk]:
                A.append(f"| {d['ai']} | {d['gan']} | {d['lam']} | {d['pham_vi']} | {d['dieu_kien'] or '—'} | {d['nguon']} | "
                         + ", ".join(f"`{x}`" for x in d["dsl"].split(", ")) + " |")
            A.append("")
    with open(os.path.join(wd, "ai_duoc_lam_gi.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(A) + "\n")

    B = [f"# Báo cáo xuất DSL playground — {ph.get('ten', '')}", "",
         "- Tệp DSL chỉ có cấu trúc phân quyền; không sinh người dùng, bản ghi, assert mẫu.",
         "- Bảng «ai được làm gì trên tài nguyên nào»: `ai_duoc_lam_gi.md` (toàn phân hệ) và khối chú thích đầu mỗi tệp DSL.",
         "- Tự kiểm trên cấu trúc: lần theo `derive` từ nơi gán từng vai trò, so tập quyền và loại phạm vi với thiết kế.", "",
         "- Tự kiểm điều kiện: quyền có điều kiện mà DSL không áp (cấp trên mọi bản ghi trong phạm vi) là «nới rộng»; nơi phải chặn ghi ở `bao_cao_xuat_json.md`.", "",
         "- Quyền không áp được phạm vi hoặc điều kiện thì **không cấp** (thiếu, không thừa); danh sách và lý do ở `bao_cao_xuat_json.md` mục «Quyền không cấp».", "",
         "| Tệp | KB | Tài nguyên (+ hỗ trợ) | Vai trò | Dòng «ai được làm gì» | Tự kiểm | Nới rộng | Không cấp |", "|---|---|---|---|---|---|---|---|"]
    for k in KQ:
        B.append(f"| `{k['tep']}` | {k['kb']} | {k['tn']} (+{k['tn_ho_tro']}) | {k['vt']} | {k['dong']} | {k['so']} quyền, **{len(k['lech'])} lệch** | {len(k['noi_rong'])} | {len(k['khong_cap'])} |")
    B += ["", "«Hỗ trợ» là cây và tài nguyên được giữ lại chỉ để tính phạm vi (không có hành động trong tệp đó).", ""]
    for k in KQ:
        if k["lech"]:
            B += [f"## Lệch trong `{k['tep']}`", ""] + [f"- {x}" for x in k["lech"][:80]] + [""]
    if KQ[0]["noi_rong"]:
        B += [f"## Quyền nới rộng ({len(KQ[0]['noi_rong'])}): điều kiện chưa áp trong DSL", ""] + [f"- {x}" for x in KQ[0]["noi_rong"][:120]] + [""]
    B += ["## Giới hạn của DSL hiện tại", "",
          "- DSL không đặt được điều kiện trên `derive`: quyền có điều kiện theo thuộc tính bản ghi cấp qua vai trò trên tài nguyên đi qua **quan hệ theo điều kiện** `<quan hệ>__<điều kiện>` (`quan_he_theo_dieu_kien.json`); ứng dụng chỉ ghi quan hệ này khi hồ sơ thoả điều kiện, gỡ khi hết thoả.",
          "- Điều kiện có so với người hỏi (ví dụ không tự duyệt) trên quyền theo phạm vi đơn vị: **vai trò trên bản ghi theo người** (`vai_tro_tren_ban_ghi.json`, cách gán «theo_pham_vi»): ứng dụng gán cho từng người đang có quyền theo phạm vi và thoả điều kiện.",
          "- DSL chỉ có `permit` cấp thêm quyền, không thu hẹp quyền của vai trò. Quyền toàn hệ thống có điều kiện theo thuộc tính bản ghi xuất thành `permit nguoi_giu_<vai trò> to tap_<tài nguyên>__<điều kiện>` (người dùng có `user.vai_tro_chung` chứa key vai trò).",
          "- Xuất danh sách: quyền trên từng bản ghi theo phạm vi xem của vai trò (KT-02). Thêm mới, nhập: hành động `<tài nguyên>__<hành động>[__<điều kiện>]` trên nút cây mà bản ghi mới gắn vào (`kiem_khi_tao.json`). Chỉ hành động không đọc, không ghi bản ghi (tải tệp mẫu) còn ở vai trò chung `…__quyen_chung`.",
          "- Quyền «trên bản ghi mình lập / được giao» của một vai trò theo đơn vị xuất thành vai trò trên bản ghi (`<vai trò>__<phạm vi>`, xem `vai_tro_tren_ban_ghi.json`): ứng dụng gán cho người lập / người được giao đang giữ vai trò gốc, gỡ khi người đó thôi giữ vai trò; tự kiểm theo từng vai trò.",
          "- Chỉ vai trò xét theo bản ghi (ví dụ «Người lập bản ghi») còn xuất bằng `resourceset … where resource.nguoi_lap == user.ma_nguoi_dung` cấp cho mọi tài khoản đang hoạt động.", ""]
    with open(os.path.join(wd, "bao_cao_playground.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(B) + "\n")
    for k in KQ:
        in_kq(k)
    print("ai_duoc_lam_gi.md, bao_cao_playground.md")
    # tệp thử (thiet-ke-phan-quyen bước 3), so sánh (ra-soat-phan-quyen bước 9): tệp thử mỗi vai trò một người dùng; nếu có so_sanh.json thì so với ma trận BA và sinh trang so sánh
    if not a.tai_nguyen:
        subprocess.run([sys.executable, "-I", os.path.join(HERE, "du_lieu_thu.py"), wd], check=False)
        if os.path.exists(os.path.join(wd, "so_sanh.json")):
            for s in ("so_sanh_thu.py", "trang_so_sanh.py"):
                subprocess.run([sys.executable, "-I", os.path.join(HERE, s), wd], check=False)


if __name__ == "__main__":
    main()
