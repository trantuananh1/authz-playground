# -*- coding: utf-8 -*-
"""Hỏi BA MỘT LẦN qua sheet Q&A: ghi mọi câu cần BA trả lời vào sheet Q&A của tệp Excel BA gửi, rồi đọc câu trả lời về.

  python -I hoi_dap.py xuat <lv> [--tep <xlsx>] [--sheet <tên>] [--chi-xem]
        gom mọi mục còn mở: câu hỏi nghiệp vụ chưa trả lời, câu «Thiếu nguồn» NG-…, điểm AI suy ra (BA rà: đồng ý hay sửa),
        ô lệch với baseline (so_sanh/giai_thich.json) → ghi thẳng vào sheet Q&A (tên có «QnA», «Q&A», «hỏi đáp»; không có thì tạo
        sheet «QnA»). Mỗi dòng có mã [CH-…] / [NG-…] / [Lxx] ở đầu ô Context để chạy lại không trùng: dòng cùng mã mà BA chưa trả
        lời thì ghi lại nội dung mới; BA đã trả lời thì giữ nguyên. Dòng cũ của sheet không có mã thì không đụng tới.
        Sao lưu tệp trước khi ghi vào <lv>/sao_luu/. Tệp Excel đích: --tep, hoặc ba_bang.json, hoặc nguon.json; không có tệp Excel nào
        thì tạo <lv>/hoi_dap_<mã phân hệ>.xlsx. --chi-xem: in các mục sẽ ghi, không ghi tệp.
  python -I hoi_dap.py doc <lv>
        đọc lại sheet Q&A → <lv>/hoi_dap_tra_loi.json (mã, ô, câu hỏi, câu trả lời của BA) và in JSON; câu CH-…, NG-… có trả lời được ghi
        vào ra_soat.json (xac_nhan ghi ch:<mã> da_tra_loi). AI đọc tệp này, đưa từng câu trả lời vào đặc tả với nguồn «BA chốt <mã>»
        (kèm ô «<sheet>!<ô>» của câu trả lời), lập lại thiết kế.

Cột của sheet Q&A nhận theo tên ở dòng tiêu đề: STT, Context (bối cảnh), Nhận định / câu hỏi, Việc của BA, BA confirm (câu trả lời);
thiếu cột nào thì thêm cột đó vào cuối dòng tiêu đề.
"""
import argparse, copy, datetime, hashlib, json, os, re, shutil, sys

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from xac_nhan import TK, doc, ghi_json, lenh_ghi  # noqa: E402

cf = lambda s: re.sub(r"\s+", " ", str(s if s is not None else "")).strip()
MAU_SHEET = re.compile(r"q\s*&?\s*n?\s*a\b|qna|hỏi\s*đáp|hoi\s*dap", re.I)
COT = [("stt", r"^stt$|^số\s*tt"), ("context", r"context|bối\s*cảnh|ngữ\s*cảnh"), ("cau_hoi", r"câu\s*hỏi|nhận\s*định"),
       ("viec_ba", r"việc\s*(của|cho)\s*ba"), ("tra_loi", r"ba\s*confirm|ba\s*trả\s*lời|trả\s*lời|xác\s*nhận")]
TEN_COT = {"stt": "STT", "context": "Context", "cau_hoi": "Nhận định / câu hỏi", "viec_ba": "Việc của BA", "tra_loi": "BA confirm"}
MA = re.compile(r"^\s*\[([A-Za-z0-9-]{2,24})\]")


# ======================================================================================== gom mục cần hỏi
def gom(lv):
    T = TK(lv)
    D = T.D
    ra = []
    for q in D.get("cau_hoi", []):
        da = q.get("tra_loi") and not q.get("suy_ra")
        if da or T.RS.get(f"ch:{q['id']}", {}).get("ket_qua"):
            continue
        lq = q.get("lien_quan") or {}
        vt = ", ".join(T.VT.get(k, {}).get("ten", k) for k in lq.get("vai_tro", []))
        if q.get("suy_ra"):
            ra.append({"ma": q["id"], "loai": "suy_ra", "context": f"{q.get('nhom', '')} — AI suy ra" + (f" — {vt}" if vt else ""),
                       "cau_hoi": f"{q['noi_dung']}\nAI đang áp dụng: {q.get('phuong_an_ap_dung', '')}"
                                  + (f"\nPhương án khác: {q['phuong_an_khac']}" if q.get("phuong_an_khac") else ""),
                       "viec_ba": "Ghi «Đồng ý» nếu giữ cách AI đang áp dụng; không đồng ý thì ghi phương án đúng."})
        else:
            ra.append({"ma": q["id"], "loai": "cau_hoi", "context": (q.get("nhom") or "Câu hỏi") + (f" — {vt}" if vt else ""),
                       "cau_hoi": q["noi_dung"] + (f"\nCác phương án: {q['phuong_an_khac']}" if q.get("phuong_an_khac") else ""),
                       "viec_ba": "Trả lời câu hỏi; phần chưa trả lời sẽ để trống trong thiết kế."})
    GT = doc(os.path.join(lv, "so_sanh", "giai_thich.json"), {}) or {}
    nhom = {}
    for g in GT.get("o_lech", []):          # các ô lệch cùng một việc cần BA quyết gộp thành một dòng
        if g.get("loai") in ("?", None):
            continue
        nhom.setdefault((g["loai"], g.get("viec_cho_ba") or g.get("tinh_huong")), []).append(g)
    ten_loai = {"A": "Nguồn nêu rõ, baseline khác", "A_BA": "Theo câu BA đã chốt, baseline khác", "B": "Nguồn chưa chốt"}
    for (lo, viec), gs in nhom.items():
        ma = "L-" + hashlib.md5((lo + "|" + str(viec)).encode("utf-8")).hexdigest()[:6].upper()   # ổn định khi chạy lại so sánh
        g = gs[0]
        ra.append({"ma": ma, "loai": "lech", "context": f"Lệch baseline — {ten_loai.get(lo, lo)} — {len(gs)} ô (cột {', '.join(x['cot'] for x in gs)})",
                   "cau_hoi": "\n".join(dict.fromkeys(x.get("tinh_huong") or "" for x in gs)) + ("\n" + "\n".join(g.get("chuoi_suy_ra") or []) if g.get("chuoi_suy_ra") else ""),
                   "viec_ba": viec or "Chốt theo thiết kế hay theo baseline."})
    return T, ra


# ======================================================================================== tệp, sheet
def tep_dich(lv, tep):
    if tep:
        return tep
    B = doc(os.path.join(lv, "ba_bang.json"), {}) or {}
    if B.get("duong_dan") and os.path.exists(B["duong_dan"]):
        return B["duong_dan"]
    for n in doc(os.path.join(lv, "nguon.json"), []) or []:
        if n.get("loai") == "excel" and os.path.exists(n.get("tep", "")):
            return n["tep"]
    return None


def tim_sheet(wb, ten):
    if ten:
        return wb[ten] if ten in wb.sheetnames else None
    return next((w for w in wb.worksheets if MAU_SHEET.search(w.title)), None)


def cot_sheet(ws):
    """(dòng tiêu đề, {trường: cột}) — dòng đầu tiên trong 10 dòng đầu khớp ít nhất 2 tên cột."""
    for r in range(1, min(ws.max_row, 10) + 1):
        cols = {}
        for c in range(1, ws.max_column + 1):
            h = cf(ws.cell(r, c).value).casefold()
            for f, mau in COT:
                if h and f not in cols and re.search(mau, h, re.I):
                    cols[f] = c
                    break
        if len(cols) >= 2:
            return r, cols
    return None, {}


def lenh_xuat(lv, tep, ten_sheet, chi_xem):
    T, ds = gom(lv)
    print(f"{len(ds)} mục cần BA trả lời: " + ", ".join(f"{x['ma']}" for x in ds))
    if chi_xem:
        for x in ds:
            print(f"- [{x['ma']}] {x['context']}\n  {x['cau_hoi'][:300]}")
        return
    tep = tep_dich(lv, tep)
    moi = tep is None
    if moi:
        tep = os.path.join(lv, f"hoi_dap_{(T.D.get('phan_he') or {}).get('ma') or 'phan_he'}.xlsx")
        if not os.path.exists(tep):
            wb = openpyxl.Workbook(); wb.active.title = "QnA"; wb.save(tep)
    thu = os.path.join(lv, "sao_luu"); os.makedirs(thu, exist_ok=True)
    bk = os.path.join(thu, f"{os.path.splitext(os.path.basename(tep))[0]}_{datetime.datetime.now():%Y%m%d_%H%M%S}.xlsx")
    shutil.copy2(tep, bk)
    wb = openpyxl.load_workbook(tep)
    ws = tim_sheet(wb, ten_sheet)
    if ws is None:
        ws = wb.create_sheet(ten_sheet or "QnA")
    r0, cols = cot_sheet(ws)
    if r0 is None:
        r0 = 1
    them = [f for f, _ in COT if f not in cols]
    cuoi = max([ws.max_column if r0 and ws.max_row >= r0 and any(cf(ws.cell(r0, c).value) for c in range(1, ws.max_column + 1)) else 0] + [0])
    for f in them:
        cuoi += 1
        cols[f] = cuoi
        c = ws.cell(r0, cuoi, TEN_COT[f]); c.font = Font(bold=True)
    # dòng đã có mã
    co = {}
    r_cuoi = r0
    for r in range(r0 + 1, ws.max_row + 1):
        if any(cf(ws.cell(r, c).value) for c in cols.values()):
            r_cuoi = r
        m = MA.match(cf(ws.cell(r, cols["context"]).value))
        if m:
            co[m.group(1)] = r
    mau = r_cuoi if r_cuoi > r0 else None
    stt = 0
    for r in range(r0 + 1, r_cuoi + 1):
        try:
            stt = max(stt, int(float(cf(ws.cell(r, cols["stt"]).value))))
        except ValueError:
            pass
    ghi, giu = [], []
    for x in ds:
        r = co.get(x["ma"])
        if r and cf(ws.cell(r, cols["tra_loi"]).value):
            giu.append(x["ma"]); continue
        if not r:
            r_cuoi += 1; r = r_cuoi; stt += 1
            ws.cell(r, cols["stt"], stt)
        for f, v in (("context", f"[{x['ma']}] {x['context']}"), ("cau_hoi", x["cau_hoi"]), ("viec_ba", x["viec_ba"])):
            c = ws.cell(r, cols[f])
            if mau:
                c._style = copy.copy(ws.cell(mau, cols[f])._style)
            c.value = v
            c.alignment = Alignment(wrap_text=True, vertical="top")
        c = ws.cell(r, cols["tra_loi"])
        if mau:
            c._style = copy.copy(ws.cell(mau, cols["tra_loi"])._style)
        c.fill = PatternFill("solid", fgColor="FFF2CC")
        c.alignment = Alignment(wrap_text=True, vertical="top")
        ghi.append((x["ma"], r))
    try:
        wb.save(tep)
    except PermissionError:
        sys.exit(f"Không ghi được {tep}: tệp đang mở trong Excel. Đóng tệp rồi chạy lại (bản sao lưu: {bk}).")
    ghi_json(os.path.join(lv, "hoi_dap.json"), {"tep": tep, "sheet": ws.title, "dong_tieu_de": r0, "cot": cols,
                                               "muc": {m: r for m, r in ghi} | {m: co[m] for m in giu}, "luc": datetime.datetime.now().isoformat(timespec="seconds")})
    print(f"Đã ghi {len(ghi)} dòng vào {tep} › sheet «{ws.title}» (ô trả lời tô vàng, cột «{TEN_COT['tra_loi']}» = {get_column_letter(cols['tra_loi'])})"
          + (f"; giữ {len(giu)} dòng BA đã trả lời" if giu else "") + f"; sao lưu: {bk}")


def lenh_doc(lv):
    H = doc(os.path.join(lv, "hoi_dap.json"))
    if not H:
        sys.exit("Chưa có hoi_dap.json — chạy «xuat» trước.")
    wb = openpyxl.load_workbook(H["tep"], data_only=True)
    ws = wb[H["sheet"]]
    r0, cols = cot_sheet(ws)
    cols = cols or {k: int(v) for k, v in H["cot"].items()}
    T = TK(lv)
    co, chua = [], []
    for r in range(r0 + 1, ws.max_row + 1):
        m = MA.match(cf(ws.cell(r, cols["context"]).value))
        if not m:
            continue
        tl = cf(ws.cell(r, cols["tra_loi"]).value)
        x = {"ma": m.group(1), "o": f"{ws.title}!{get_column_letter(cols['tra_loi'])}{r}", "context": cf(ws.cell(r, cols["context"]).value),
             "cau_hoi": str(ws.cell(r, cols["cau_hoi"]).value or ""), "tra_loi": tl}
        (co if tl else chua).append(x)
    ids = {q["id"] for q in T.D.get("cau_hoi", [])}
    for x in co:
        if x["ma"] in ids:
            lenh_ghi(T, f"ch:{x['ma']}", "da_tra_loi", f"{x['tra_loi']} ({x['o']})")
    ghi_json(os.path.join(lv, "hoi_dap_tra_loi.json"), {"da_tra_loi": co, "chua_tra_loi": chua})
    print(json.dumps({"da_tra_loi": co, "chua_tra_loi": [c["ma"] for c in chua]}, ensure_ascii=False, indent=1))
    print(f"{len(co)} câu đã trả lời, {len(chua)} câu còn trống → hoi_dap_tra_loi.json")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("lenh", choices=["xuat", "doc"])
    ap.add_argument("lv")
    ap.add_argument("--tep")
    ap.add_argument("--sheet")
    ap.add_argument("--chi-xem", action="store_true")
    a = ap.parse_args()
    if a.lenh == "xuat":
        lenh_xuat(a.lv, a.tep, a.sheet, a.chi_xem)
    else:
        lenh_doc(a.lv)


if __name__ == "__main__":
    main()
