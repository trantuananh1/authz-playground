# Bộ skill phân quyền (bản 25/11/2026)

Bộ gồm ba thư mục, chép cả ba vào `~/.claude/skills/` (thiếu `phan-quyen-chung` thì hai skill không chạy):

| Thư mục | Là gì | Kết thúc khi |
|---|---|---|
| `ra-soat-phan-quyen` | Skill rà soát nghiệp vụ: BA và đội phát triển cùng chốt nghiệp vụ | BA xác nhận bản xem trước |
| `thiet-ke-phan-quyen` | Skill thiết kế cuối: xuất tệp cho đội phát triển và tài liệu | Đã xuất tệp cuối |
| `phan-quyen-chung` | Phần dùng chung (không phải skill): công cụ, tài liệu tham chiếu, mẫu Excel | — |

Yêu cầu: Python 3.10 trở lên, `openpyxl` 3.1 trở lên; đọc PDF cần thêm `pymupdf`. Mọi công cụ chạy `python -I phan-quyen-chung/scripts/<công cụ>.py …`.

## Luồng làm việc

1. **`/ra-soat-phan-quyen <tệp Excel> <tài liệu nghiệp vụ …>`**
   - Đọc **cả tệp Excel**: mọi sheet là nguồn (sheet 3 bảng, quy tắc chung, QnA, bộ tài nguyên…), trừ sheet ma trận trải phẳng là **baseline so sánh**; sheet cũ chỉ tham khảo. BA nêu «chỉ dùng …» / «không dùng sheet …» thì theo lời BA.
   - Dựng thiết kế nháp (chế độ suy ra là mặc định với mọi đầu vào; `chi-nguon` để tắt), đối chiếu với 3 bảng, so với baseline.
   - **Hỏi BA một lần:** mọi câu hỏi (nghiệp vụ, xung đột, thiếu nguồn, điểm AI suy ra, ô lệch baseline) được ghi vào sheet Q&A của tệp Excel; BA trả lời một thể ở cột BA confirm.
2. **`/ra-soat-phan-quyen hoi-dap doc`** sau khi BA trả lời: đáp án thành «BA chốt», thiết kế lập lại, và BA nhận **một bộ** để nhìn:
   - bản xem trước (Artifact): ai được làm gì, phạm vi bằng chữ, chưa có nguồn, thay đổi so với 3 bảng;
   - trang so sánh với baseline (Artifact): từng ô khớp / lệch kèm giải thích;
   - bản trải phẳng theo thiết kế (Excel giữ khung baseline, ô lệch tô xanh / đỏ, ghi chú ô).

   BA bình luận trên trang (`/ra-soat-phan-quyen xem-truoc` để AI xử lý), rồi xác nhận.
3. **`/thiet-ke-phan-quyen`** sau khi BA xác nhận: JSON import, DSL playground (tự kiểm 0 lệch, không nới rộng quyền), `ai_duoc_lam_gi.md`, Excel cuối giữ định dạng template và tô màu thay đổi (kèm bản sạch), bản trải phẳng cuối, nạp lên playground.
4. Cần sửa sau khi xuất: `/ra-soat-phan-quyen cap-nhat <điều cần sửa>` → xác nhận lại → xuất lại.

Lệnh khác: `/ra-soat-phan-quyen mau-excel` (mẫu 3 bảng trống), `thay-doi`, `so-sanh <tệp> [sheet]`, `trai-phang <tệp khung> [sheet]` (chỉ khi không có baseline); `/thiet-ke-phan-quyen excel [--ban-sach] | trai-phang | dsl a,b | playground | thu | json`.

## Nguyên tắc chung

- **Mọi quyền có nguồn** (ô, đoạn tài liệu, «BA chốt», hoặc «AI suy ra» kèm ô căn cứ). Suy ra là mặc định; điểm suy ra đi vào sheet Q&A để BA đồng ý hoặc sửa. `chi-nguon` tắt suy ra: chỗ thiếu thành câu hỏi, để trống.
- **Không sinh dữ liệu giả** trong thiết kế; người dùng, hồ sơ thử chỉ có trong tệp thử và phép so, ghi «DỮ LIỆU THỬ».
- **Không nới rộng quyền**: quyền không áp được đủ phạm vi, điều kiện thì không cấp và được báo.
- Key tiếng Việt không dấu; không gộp hành động (ngoại lệ duy nhất: xem danh sách + xem chi tiết = `xem`); một quyền chỉ một đường cấp.
- Bước quy trình làm ngoài hệ thống không phân quyền.

## Nội dung `phan-quyen-chung`

- `scripts/`
  - đọc đầu vào: `trich_xuat.py` (docx, pdf, md, xlsx, drawio kèm nhãn vị trí), `ba_bang.py` (mẫu 3 bảng, cả bảng vai trò tách riêng và mẫu không ghi key), `mau_excel.py` (mẫu cũ 6 sheet), `bang_chuc_nang.py`, `quy_trinh_sang_giao_dich.py`, `ma_tran_sang_giao_dich.py`;
  - thiết kế, kiểm tra: `lap_thiet_ke.py`, `bo_key.py`, `dieu_kien.py`, `ha_muc.py`;
  - rà soát: `hoi_dap.py` (ghi / đọc sheet Q&A), `xac_nhan.py` (bản xem trước, xác nhận), `doi_chieu_ba_bang.py` (ghép với 3 bảng, bảng thay đổi, Excel cuối), `so_sanh_ma_tran.py`, `so_sanh_thu.py` + `trang_so_sanh.py` (so với baseline, bản trải phẳng theo thiết kế), `ma_tran_trai_phang.py` (bảng trải phẳng theo khung khác);
  - xuất: `xuat_json.py`, `xuat_dsl.py`, `du_lieu_thu.py`.
- `references/`: bộ key chuẩn, 21 quy định kế thừa, 24 nguyên tắc, cây đơn vị ngành CTĐ-CTCT, 14 mẫu thiết kế, cách đọc tài liệu BA, cấu trúc đặc tả, so sánh ma trận.
- `assets/`: mẫu 3 bảng trống `mau_3_bang_phan_quyen.xlsx`, mẫu cũ 6 sheet.
