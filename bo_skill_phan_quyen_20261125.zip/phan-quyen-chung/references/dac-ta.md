# Đặc tả thiết kế `dac_ta.json`

AI viết tệp này sau khi đọc tài liệu. Công cụ `lap_thiet_ke.py` áp đặc tả lên danh sách giao dịch (mọi tệp `giao_dich*.json`), dò chỗ thiếu nguồn theo quy định kế thừa (`quy-dinh-ke-thua.md`), rồi sinh `thiet_ke_phan_quyen.json` kèm câu mô tả theo vai trò cho BA. Đặc tả mô tả **quy tắc**, không liệt kê từng quyền: một phân hệ vài trăm giao dịch chỉ cần vài chục quy tắc.

**Quy định kế thừa không tự cấp quyền, không đặt phạm vi hay điều kiện mặc định.** Đặc tả phải viết đủ quyền, quy tắc `pham_vi`, `dieu_kien` cho mọi quyền, mỗi quy tắc có `nguon`. Chỗ một quy định kế thừa lẽ ra áp mà đặc tả chưa có (quyền xem đi kèm KT-01, người lập xem bản ghi của mình KT-03, phạm vi KT-06…KT-08, KT-16, điều kiện trạng thái, khoá, không tự duyệt KT-13…KT-15) được công cụ ghi thành câu hỏi «Thiếu nguồn» `NG-…`; AI suy ra (có nguồn «AI suy ra») hoặc hỏi BA, rồi ghi quy tắc vào đặc tả.

Công cụ kiểm tra mọi key mà quy tắc nhắc tới (vai trò, tài nguyên, hành động, phạm vi, điều kiện). Key chưa khai báo là **lỗi** `DT-01`; quy tắc không khớp gì là gợi ý `QT-01`.

Đầu vào là **mẫu Excel chung** (`mau_excel.py doc`): công cụ ghi `phan_he`, `tai_nguyen`, `vai_tro`, quy tắc `tac_nhan` và `pham_vi` từ Excel, đánh dấu `"tu_excel": true`; đọc lại Excel chỉ thay các mục này. AI không sửa mục `tu_excel`; muốn thêm trường cho một tài nguyên hay vai trò thì ghi vào `"mo_rong": {"tai_nguyen": {"<key>": {…}}, "vai_tro": {"<key>": {…}}}` (trường thay thế, `quan_he` được nối thêm). Vai trò từ Excel có thêm `vi_tri` (vị trí trên cây đơn vị) và `mang_phu_trach` nếu BA ghi.

## Khung

```json
{
  "phan_he": {"ten": "…", "ma": "…", "mo_ta": "…"},
  "nguyen_tac_ap_dung": ["NT-02", "NT-03", "…"],
  "tai_nguyen": [ … ],
  "vai_tro":    [ … ],
  "pham_vi":    [ … ],
  "dieu_kien":  [ … ],
  "quy_tac": {"bo_qua": [], "tai_nguyen": [], "hanh_dong": [], "tac_nhan": [], "theo_cap_duyet": [],
              "loc_vai_tro": [], "bo_sung": [], "pham_vi": [], "dieu_kien": []},
  "ke_thua": {"khong_ap_dung": [ … ]},
  "cau_hoi": [ … ],
  "suy_ra": {"bat": true, "ngay": "dd/mm/yyyy", "nguon_dung": "…"}
}
```

`suy_ra` có ở mọi đặc tả theo mặc định (SKILL.md của ra-soat-phan-quyen, mục «Chế độ suy ra»); chỉ bỏ khi BA chọn chế độ chỉ theo nguồn (`chi-nguon`). Khi bật: quy tắc, vai trò AI suy ra có trong `nguon` một mục bắt đầu bằng «AI suy ra» (ví dụ `"AI suy ra (chế độ suy ra, <dd/mm/yyyy>)"`, ở `co_so.nguon` là `{"vt": "AI suy ra …", "trich": "<lý do>"}`) cùng các ô căn cứ; mỗi quyết định suy ra một câu hỏi có `"suy_ra": true` (mục «Câu hỏi cho BA»). `nguon_dung` ghi phần tài liệu được làm nguồn khi BA giới hạn («chỉ dùng …»). Không bật mà có nguồn «AI suy ra» là lỗi `SR-01`.

## Mục `co_so` (dùng ở tài nguyên, vai trò)

```json
{"loai": "tai_lieu", "nguon": [{"vt": "B1.D3", "trich": "câu trích nguyên văn"}],
 "ly_do": "…", "nguyen_tac": ["NT-10"], "tin_cay": "cao | trung_binh | thap"}
```
`vt` lấy đúng nhãn vị trí trong `trich_xuat/N….md` (Đ…, B….D…) hoặc ô Excel (`Sheet!B12`); câu BA chốt ghi `"vt": "BA chốt CH-…"`. Vai trò phải có ít nhất một nguồn (lỗi `NG-02`). Không dùng `loai: de_xuat` (chế độ chỉ theo nguồn).

## Tài nguyên

| Trường | Ý nghĩa |
|---|---|
| `key`, `ten`, `mo_ta` | Key chữ thường không dấu; tên nghiệp vụ |
| `loai` | `cay` (cây tổ chức, nơi gán vai trò) · `du_lieu` · `tep` (kho tư liệu) · `he_thong` (tài khoản, phân quyền, cấu hình: kiểm tra KT-20) |
| `mang` | Mảng nghiệp vụ, dùng nhóm dòng trong ma trận và kiểm tra NT-02 |
| `quan_he` | `[{key, toi, y_nghia}]`. Cây có `cap_tren` trỏ về chính nó. Dữ liệu có quan hệ tới cây (`thuoc_to_chuc`, `thuoc_don_vi`, `cap_duyet`…) |
| `thuoc_tinh` | `[{key, kieu, y_nghia, gia_tri?}]`, kiểu `chuoi | so | ngay | dung_sai | danh_sach`. Khai mọi thuộc tính dùng trong điều kiện. `y_nghia` ghi tên cột và các giá trị CSDL theo nguồn (ví dụ «status: DRAFT, PENDING_APP, APPROVED, REJECTED (<ô nguồn>)»). `gia_tri` (tuỳ chọn): `{"<giá trị chuẩn>": "<giá trị CSDL>"}`, ví dụ `{"DU_THAO": "DRAFT", "CHO_DUYET": "PENDING_APP", "DA_DUYET": "APPROVED", "BI_TRA_LAI": "REJECTED"}`: điều kiện vẫn viết bằng giá trị chuẩn, JSON và DSL xuất ra dùng giá trị CSDL. Bắt buộc khi CSDL ghi khác giá trị chuẩn (`xuat_json.py` cảnh báo khi thiếu); chỉ khai theo nguồn, giá trị nguồn chưa nêu thì hỏi BA |
| `hanh_dong` | Danh sách key **đúng như tài liệu**, mỗi thao tác một key, không gộp (`tim_kiem`, `tao_moi`, `gui_phe_duyet`…; riêng xem danh sách, xem chi tiết là một key `xem`); tài liệu không có key thì dùng key loại ở `bo-key.md`. Dạng `{key, ten, muc, nhom, loai, tach_tu}`: `loai` = key loại khi công cụ không tự phân loại được (KEY-02); `tach_tu` = key gốc của tài liệu khi tách một key gộp (`lock_unlock` → `khoa`, `mo_khoa`). Thêm `"nhay_cam": true` cho tác vụ xem thông tin nhạy cảm (KT-16) |
| `vong_doi` | Với tài nguyên có gửi duyệt: `{"dang_soan": ["DU_THAO", "BI_TRA_LAI"], "cho_duyet": ["CHO_DUYET"], "da_duyet": ["DA_DUYET"]}` (KT-14). Dùng giá trị chuẩn; tên trạng thái trong tài liệu (dự thảo, bị trả lại…) ghi ở `mo_ta`. Thiếu thì công cụ dùng giá trị chuẩn và báo gợi ý |
| `nhay_cam` | `true` khi cả tài nguyên là thông tin nhạy cảm |

Khai đủ thuộc tính dùng trong điều kiện; công cụ không tự thêm điều kiện theo quy định kế thừa.

## Vai trò

| Trường | Ý nghĩa |
|---|---|
| `key`, `ten`, `mo_ta` | |
| `loai_pham_vi` | `toan_he_thong` hoặc `theo_don_vi` (gồm cả vai trò gán trên một bản ghi cụ thể: khi đó `gan_tren` là tài nguyên đó) |
| `gan_tren` | Key cây tổ chức nơi vai trò được gán (bắt buộc với `theo_don_vi`) |
| `cap` | Nhãn cấp, dùng nhóm cột ma trận (Trung ương, Đơn vị, Hội…) |
| `nhom` | `lanh_dao`, `chuyen_vien` (kiểm tra NT-21) hoặc `quan_tri` (kiểm tra KT-20) |
| `tham_quyen` | Tuỳ chọn, theo vị trí trên cây đơn vị (`cay-don-vi-ctd-ctct.md` mục 4, CD-05): `phe_duyet` (thủ trưởng đơn vị, thủ trưởng cơ quan chính trị: cấp có con dấu) · `de_nghi` (trưởng phòng, ban không có con dấu) · `xu_ly` (trợ lý, nhân viên). Vai trò `de_nghi` / `xu_ly` có `phe_duyet` bị cảnh báo `TQ-01` |

Công cụ không còn tự thêm vai trò «Người lập bản ghi» (KT-03); khi tài liệu chưa nêu, công cụ sinh câu hỏi `NG-…`.

## Phạm vi, điều kiện

```json
{"key": "don_vi_minh", "ten": "Đơn vị mình", "kieu": "don_vi_minh", "mo_ta": "…",
 "quan_he": {"*": "thuoc_don_vi", "don_vi": "(gan_truc_tiep)", "phieu_ban_giao": "noi_di"}}
```
- `kieu` (bo-key.md mục 2): ReBAC `don_vi_minh | don_vi_minh_va_cap_duoi_truc_tiep | don_vi_minh_va_cap_duoi | cap_duyet`; RBAC `toan_he_thong | danh_sach`; ABAC `do_minh_lap | duoc_giao` (khai thêm `bieu_thuc` thay cho `quan_he`, ví dụ `[{"trai": "resource.nguoi_duoc_giao", "phep": "bang", "phai": "user.ma_nguoi_dung"}]`).
- `quan_he`: theo từng tài nguyên, quan hệ nối bản ghi với nơi gán vai trò. `*` là mặc định. `(gan_truc_tiep)`: bản ghi chính là nút được gán. Trên cây, dùng `cap_tren` để lan xuống cấp dưới.
- Phạm vi `toan_he_thong` và `danh_sach` công cụ tự dùng: vai trò toàn hệ thống mặc định `toan_he_thong`; hành động mức danh sách của vai trò theo đơn vị luôn là `danh_sach`.
- **Chỉ theo nguồn:** quyền mức bản ghi của vai trò theo đơn vị phải có quy tắc `pham_vi` (có `nguon`) khớp. Không có thì công cụ **không** đặt phạm vi mặc định: quyền bị đưa ra khỏi thiết kế và thành câu hỏi `NG-…`. Vai trò `toan_he_thong` (khai có nguồn) dùng phạm vi toàn hệ thống.

```json
{"key": "dot_dang_mo", "ten": "Đợt đang mở", "mo_ta": "…",
 "bieu_thuc": [{"trai": "resource.trang_thai_dot", "phep": "thuoc", "phai": ["DANG_MO"]}]}
```
`phep`: `bang | khac | thuoc`. `phai` bắt đầu bằng `user.` là so với thuộc tính người dùng. Điều kiện trạng thái, khoá, không tự duyệt **không** còn tự sinh: tài liệu nêu thì viết điều kiện và quy tắc `dieu_kien` có `nguon`; chưa nêu thì công cụ sinh câu hỏi `NG-…`.

## Quy tắc

Mọi quy tắc có `id`, `ly_do`, `nguyen_tac`, `tin_cay`. Các nhóm `tac_nhan`, `theo_cap_duyet`, `loc_vai_tro`, `bo_sung`, `pham_vi`, `dieu_kien` **bắt buộc** có `nguon`: danh sách vị trí tài liệu (`"Sheet!A36:E36"`, `"B3.D4"`) hoặc `"BA chốt CH-…"` / `"BA chốt NG-…"`. Thiếu `nguon` → lỗi `NG-01`, quy tắc không được áp. Quy tắc đọc từ mẫu Excel (`tu_excel`) lấy nguồn là ô BA khai. Bản xem trước hiển thị nguồn ở mục «Vì sao» của từng ô.

| Nhóm | Dạng | Áp dụng |
|---|---|---|
| `bo_qua` | `mau_usecase` / `mau_giao_dich` / `mau_muc` (regex) hoặc `tac_nhan` (danh sách) | Giao dịch khớp không vào phân quyền (dashboard, API…). Bước tài liệu ghi làm ngoài hệ thống **luôn** bị bỏ qua, không cần quy tắc (trạng thái `ngoai_he_thong`, mẫu `bo_key.MAU_NGOAI_HE_THONG`) |
| `tai_nguyen` | `mau_giao_dich` (+`mau_usecase`) hoặc `mau_usecase` → `tai_nguyen` | Quy tắc đầu tiên khớp. Đặt quy tắc theo giao dịch trước, theo usecase sau |
| `hanh_dong` | `mau` (regex trên tên giao dịch) → `hanh_dong` | Quy tắc đầu tiên khớp **và** hành động có trên tài nguyên |
| `tac_nhan` | `tac_nhan` (tên đúng như tài liệu) → `vai_tro` | Chỉ khi tài liệu nêu ai giữ tác nhân đó; tên giống nhau không phải nguồn. Tác nhân không có quy tắc → câu hỏi `NG-…` |
| `theo_cap_duyet` | `mau_giao_dich` → `vai_tro` | Giao dịch khớp chỉ giữ cho các vai trò này; vai trò khác của tác nhân → `bo` (theo nguồn) |
| `loc_vai_tro` | `vai_tro` + một trong `chi_tai_nguyen`, `chi_nhom_hanh_dong`, `bo_nhom_hanh_dong`, `bo_hanh_dong`; tuỳ chọn `tai_nguyen` (chỉ xét các tài nguyên này) | Tài liệu hoặc BA chốt nói không cho → `bo` |
| `bo_sung` | `vai_tro` × `tai_nguyen` × `hanh_dong` | Quyền tài liệu nêu ở chỗ khác bảng giao dịch (quy tắc chung, câu BA chốt) → `giu` |
| `pham_vi` | `vai_tro`, `tai_nguyen`, `hanh_dong` (key, `@nhom`, `@ban_ghi`, `*` hoặc danh sách) → `pham_vi`; tuỳ chọn `uu_tien`, `ap_dung_toan_he_thong` | Quy tắc cụ thể nhất thắng; `uu_tien` cao thắng trước. `vai_tro: "*"` chỉ áp cho vai trò theo đơn vị; muốn áp cả vai trò toàn hệ thống (ví dụ phạm vi `cap_duyet` cho lãnh đạo cấp cao nhất) thì ghi `"ap_dung_toan_he_thong": true` hoặc nêu tên vai trò |
| `dieu_kien` | như `pham_vi` → `dieu_kien: [...]` | Cộng dồn mọi quy tắc khớp |

Nhóm hành động dùng trong `@nhom`: `xem`, `them_moi`, `chinh_sua`, `xoa`, `vong_doi`, `duyet`, `xuat_nhap`, `khac`; và `@danh_sach`, `@ban_ghi` theo mức (bo-key.md mục 1).

## Ngoại lệ quy định kế thừa

Khi tài liệu nêu rõ khác một quy định kế thừa, ghi ngoại lệ, có lý do và vị trí trích:

```json
"ke_thua": {"khong_ap_dung": [
  {"ma": "KT-07", "vai_tro": ["truong_phong"], "tai_nguyen": ["ho_so_can_bo"],
   "ly_do": "B3.D4: trưởng phòng chỉ xem hồ sơ của phòng mình, không xem phòng khác."}
]}
```
`vai_tro`, `tai_nguyen` bỏ trống là áp cho tất cả. Mã dùng được: KT-01, 02, 03, 06, 07, 08, 09, 13, 14, 15, 16, 20. Quy định kế thừa chỉ sinh câu hỏi; ghi `khong_ap_dung` khi tài liệu nêu rõ quy định không áp, để công cụ khỏi hỏi.

## Câu hỏi cho BA

```json
{"id": "CH-01", "nhom": "Vai trò | Phạm vi | Điều kiện | Luồng duyệt | …", "noi_dung": "…",
 "phuong_an_ap_dung": "phương án AI đang dùng trong thiết kế", "lien_quan": {"vai_tro": ["…"]},
 "luc": "truoc_thiet_ke | ra_soat", "tra_loi": "câu trả lời của người dùng / BA (nếu đã có)"}
```
Mọi câu ghi ở bước 2 của ra-soat-phan-quyen (`"luc": "truoc_thiet_ke"`) được ghi một lần vào sheet Q&A ở bước 6 (`hoi_dap.py xuat`); BA trả lời xong thì ghi `tra_loi` và đổi nguồn quy tắc liên quan thành «BA chốt <mã>» kèm ô trả lời.

Chế độ suy ra: mỗi điểm AI tự chốt ghi một câu `{"id": "CH-…", "suy_ra": true, "luc": "truoc_thiet_ke", "nhom": "…", "noi_dung": "<tài liệu chưa nêu / nói ngược nhau ở đâu>", "phuong_an_ap_dung": "<AI chọn>", "phuong_an_khac": "<phương án của nguồn kia hoặc phương án còn lại>", "tra_loi": "AI suy ra: …", "lien_quan": {…}}`. Bản xem trước hiện các câu này ở mục «AI suy ra — BA rà soát», không ở «Câu hỏi nghiệp vụ». BA đổi ý ở câu nào thì sửa quy tắc theo BA, bỏ `suy_ra`, ghi `tra_loi` của BA và đổi nguồn thành «BA chốt CH-…».
