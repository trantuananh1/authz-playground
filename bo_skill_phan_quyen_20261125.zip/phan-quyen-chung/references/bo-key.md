# Bộ key chuẩn

Một bộ key **tiếng Việt không dấu** dùng chung cho mọi nơi: đặc tả `dac_ta.json`, ma trận Excel của BA, JSON import, DSL playground, hệ phân quyền đích. **Hành động không gộp, không đổi key**: key hành động giữ đúng như tài liệu ghi; bảng hành động ở mục 1 chỉ để *phân loại* và gợi ý key. Ngoại lệ duy nhất: xem danh sách và xem chi tiết (`xem_ds`, `xem_ct`) là một hành động `xem`. Phạm vi, quan hệ, thuộc tính, trạng thái vẫn có bí danh (`own_unit`, `status`…): công cụ quy về key chuẩn và báo `KEY-01`.

Key tiếng Việt để người đọc thiết kế, JSON, DSL hiểu ngay. Chỉ các từ khoá cú pháp của playground (`resource`, `role`, `derive`, `permit`, `userset`, `resourceset`, tiền tố `user.` và `resource.`…) và tên trường theo khuôn JSON của hệ đích (`resources`, `roles`, `grantedTo`…) còn tiếng Anh, vì là cú pháp cố định. Mã người dùng trong điều kiện ABAC dùng thuộc tính `user.ma_nguoi_dung` (không dùng `user.key` có sẵn của playground/Permit); hệ đích phải đồng bộ thuộc tính này bằng mã tài khoản. Quyền toàn hệ thống có điều kiện theo thuộc tính bản ghi dùng thuộc tính `user.vai_tro_chung` (danh sách key vai trò toàn hệ thống tài khoản đang giữ, phép `contains`); hệ đích phải đồng bộ thuộc tính này cùng lúc gán vai trò.

Nguồn máy đọc: `scripts/bo_key.py`. Hai tệp phải giữ đồng bộ; in bảng hành động bằng `python -I scripts/bo_key.py`.

Quy tắc đặt key:
- chữ thường tiếng Việt không dấu, nối bằng `_`;
- key tài nguyên, vai trò do AI đặt theo từng phân hệ, cũng bằng tiếng Việt không dấu (`de_xuat_mua_sam`, `truong_phong`, `giam_doc_chi_nhanh`); tên có dấu để ở trường `ten`;
- quan hệ, thuộc tính, phạm vi, điều kiện riêng của phân hệ cũng tiếng Việt không dấu (`thuoc_truong`, `trang_thai_dot`, `hoi_noi_den`, `dot_dang_mo`);
- không đặt key hành động theo tài nguyên (`phe_duyet`, không phải `phe_duyet_de_xuat_mua_sam`): quyền luôn là cặp `tài_nguyên:hành_động`;
- key hành động lấy đúng như tài liệu (`tim_kiem`, `tao_moi`, `gui_phe_duyet`…; riêng `xem_ds`, `xem_ct` → `xem`). Key công cụ không phân loại được thì khai thêm `loai` (hoặc `nhom`, `muc`), công cụ báo `KEY-02`;
- **tài liệu / sheet không ghi key**: phân hệ có quy ước đặt key riêng thì theo quy ước đó; không có thì AI tự đặt key ngắn, dễ đọc từ tên (`ba_bang.py` đặt key đề xuất: bỏ dấu, chữ thường, nối `_`), bỏ phần mô tả thừa, tách thao tác gộp. Không bắt buộc dùng key loại ở mục 1 và không cần thống nhất giữa các phân hệ; key do AI đặt ghi thành điểm «AI suy ra» để BA rà.

## 1. Hành động

**Không gộp hành động.** Mỗi thao tác tài liệu nêu là một hành động riêng, key giữ đúng như tài liệu:
- `tim_kiem` khác `xem`: vai trò được xem không mặc nhiên được tìm kiếm;
- `nhap_lieu` (nhập tay) khác `import` (nhập tệp); `tra_lai`, `yeu_cau_chinh_sua` khác `tu_choi`; `xac_nhan` khác `phe_duyet`;
- hai cách viết **cùng một thao tác** (`sua` / `chinh_sua`) vẫn là một hành động: dùng đúng key của tài liệu, không đổi.

**Ngoại lệ duy nhất (áp cho mọi phân hệ): xem danh sách và xem chi tiết là một hành động `xem`.** Key tài liệu `xem_ds`, `xem_ct` (cả `xem_danh_sach`, `xem_chi_tiet`, «Xem danh sách», «Xem chi tiết») được công cụ đổi thành `xem` (báo `KEY-01`); ma trận đánh «x» ở một trong hai dòng là vai trò có `xem`. Tìm kiếm, tra cứu, lọc, xem lịch sử, xem nhạy cảm vẫn là hành động riêng.

**Key tài liệu gộp nhiều thao tác thì tách** thành từng hành động, mỗi hành động ghi `tach_tu` = key gốc của tài liệu (công cụ báo `KEY-03` nếu chưa tách):

| Key gộp | Tách thành |
|---|---|
| `lock_unlock` | `khoa`, `mo_khoa` |
| `khoa_mo_khoa` | `khoa`, `mo_khoa` |
| `phe_duyet_tu_choi` | `phe_duyet`, `tu_choi` |
| `duyet_tu_choi` | `phe_duyet`, `tu_choi` |
| `xuat_nhap` | `xuat`, `nhap` |
| `import_export` | `nhap`, `xuat` |
| mô tả kiểu «Phê duyệt/từ chối … và phân công …» | `phe_duyet`, `tu_choi`, `phan_cong` (theo key của tài liệu nếu có) |

**Bảng loại hành động.** Dùng để: (1) công cụ biết một key là xem, sửa, duyệt… và áp quy định kế thừa đúng loại; (2) gợi ý key khi tài liệu không đặt key. Cột cuối là các cách viết cùng nghĩa mà công cụ nhận ra để *phân loại*; key vẫn giữ nguyên (trừ ngoại lệ xem ở trên). Key không khớp cách viết nào thì phân loại theo tiền tố dài nhất (`phe_duyet_cap_phong` → loại `phe_duyet`); không phân loại được thì đặc tả ghi `loai`.

| Key loại | Tên | Mức | Nhóm | Cách viết cùng nghĩa (chỉ để phân loại) |
|---|---|---|---|---|
| `xem` | Xem (danh sách và chi tiết) | ban_ghi | xem | view, read, list, get |
| `tim_kiem` | Tìm kiếm | ban_ghi | xem | search, tim_kiem_nhanh, tim_kiem_nang_cao |
| `tra_cuu` | Tra cứu | ban_ghi | xem | lookup |
| `loc` | Lọc | ban_ghi | xem | filter |
| `xem_lich_su` | Xem lịch sử | ban_ghi | xem | history, view_history |
| `xem_nhay_cam` | Xem thông tin nhạy cảm | ban_ghi | xem | view_sensitive, xem_thong_tin_nhay_cam |
| `them_moi` | Thêm mới | danh_sach | them_moi | create, them, tao, tao_moi, lap, add, new, insert |
| `tai_len` | Tải lên | danh_sach | them_moi | upload |
| `khai_bao` | Khai báo | danh_sach | them_moi | declare |
| `nhap_lieu` | Nhập liệu | danh_sach | them_moi | data_entry |
| `chinh_sua` | Chỉnh sửa | ban_ghi | chinh_sua | update, sua, cap_nhat, edit, modify |
| `xoa` | Xoá | ban_ghi | xoa | delete, remove |
| `khoi_phuc` | Khôi phục | ban_ghi | xoa | restore |
| `gui_duyet` | Gửi duyệt | ban_ghi | vong_doi | submit, gui_phe_duyet, trinh, send_for_approval |
| `gui` | Gửi | ban_ghi | vong_doi | send |
| `phe_duyet` | Phê duyệt | ban_ghi | duyet | approve, duyet |
| `xac_nhan` | Xác nhận | ban_ghi | duyet | confirm |
| `tu_choi` | Từ chối | ban_ghi | duyet | reject, tu_choi_duyet, loai_bo |
| `tra_lai` | Trả lại | ban_ghi | duyet | return |
| `yeu_cau_chinh_sua` | Yêu cầu chỉnh sửa, bổ sung | ban_ghi | duyet | request_change |
| `tiep_nhan` | Tiếp nhận | ban_ghi | duyet | receive, phe_duyet_tiep_nhan, accept |
| `tu_choi_tiep_nhan` | Từ chối tiếp nhận | ban_ghi | duyet | decline_receipt |
| `khoa` | Khoá | ban_ghi | vong_doi | lock, khoa_so, khoa_du_lieu |
| `mo_khoa` | Mở khoá | ban_ghi | vong_doi | unlock |
| `sao_chep` | Sao chép | ban_ghi | them_moi | copy, duplicate, clone |
| `xuat` | Xuất danh sách | danh_sach | xuat_nhap | export, xuat_ds, xuat_excel, export_ds, xuat_danh_sach |
| `xuat_file` | Xuất tệp | danh_sach | xuat_nhap | export_file |
| `nhap` | Nhập danh sách | danh_sach | xuat_nhap | import, nhap_ds, nhap_excel, import_ds, nhap_danh_sach |
| `trich_luc` | Trích lục | ban_ghi | xuat_nhap | xuat_trich_luc |
| `in` | In | ban_ghi | xuat_nhap | print |
| `chia_tach` | Chia tách | ban_ghi | vong_doi | split |
| `sap_nhap` | Sáp nhập | ban_ghi | vong_doi | merge |
| `giai_the` | Giải thể | ban_ghi | vong_doi | dissolve |
| `chia_se` | Chia sẻ | ban_ghi | khac | share |
| `phan_hoi` | Phản hồi | ban_ghi | khac | feedback |
| `di_chuyen` | Di chuyển | ban_ghi | chinh_sua | move |
| `tai_xuong` | Tải xuống tệp | ban_ghi | xuat_nhap | download |
| `tai_xuong_ds` | Tải xuống danh sách | danh_sach | xuat_nhap | download_list |
| `danh_gia` | Đánh giá, xếp loại | ban_ghi | chinh_sua | evaluate, xep_loai |
| `giao_xu_ly` | Giao xử lý | ban_ghi | vong_doi | assign, phan_cong |
| `gan_vai_tro` | Gán vai trò | ban_ghi | khac | assign_role, phan_quyen |

Quy định kế thừa xét theo loại:
- KT-01, KT-03 («làm được / lập được bản ghi thì xem được bản ghi đó») cấp hành động `xem` nếu tài nguyên có; **không** tự cấp `tim_kiem`, `tra_cuu`, `loc`, `xem_lich_su`, `xem_nhay_cam`;
- KT-08, KT-13, KT-14 (chờ duyệt) áp cho loại `phe_duyet`, `xac_nhan`, `tu_choi`, `tra_lai`, `yeu_cau_chinh_sua`; KT-14 (đang soạn) cho `chinh_sua`, `xoa`, `gui_duyet`; KT-15 cho `chinh_sua`, `xoa`.

Mức `danh_sach`: kiểm tra khi chưa có bản ghi (thêm mới, xuất, nhập). Mức `ban_ghi`: kiểm tra trên một bản ghi cụ thể, có phạm vi và điều kiện. Danh sách hiển thị: hệ phân quyền trả ID các bản ghi người dùng được `xem` (List 1); ứng dụng truy vấn CSDL với điều kiện lọc **và** ID thuộc List 1 (List 2); xem chi tiết một bản ghi là kiểm tra `xem` trên bản ghi đó. Tìm kiếm kiểm tra quyền riêng `tim_kiem`.

Nhóm (dùng trong quy tắc `@nhom`): `xem`, `them_moi`, `chinh_sua`, `xoa`, `vong_doi`, `duyet`, `xuat_nhap`, `khac`; mức: `@danh_sach`, `@ban_ghi`; loại: `@<key loại>` (ví dụ `@tim_kiem`). Bí danh nhóm: `view`, `create`, `tao`, `update`, `sua`, `delete`, `lifecycle`, `approval`, `bulk`, `other`, `list`, `record`.

## 2. Kiểu phạm vi

| Key | Ý nghĩa | Cơ chế | Bí danh |
|---|---|---|---|
| `toan_he_thong` | Toàn hệ thống | RBAC | all, toan_bo |
| `danh_sach` | Mức danh sách (thêm, xuất, nhập) | RBAC | list, muc_danh_sach |
| `don_vi_minh` | Bản ghi của đơn vị nơi vai trò được gán | ReBAC | own_unit |
| `don_vi_minh_va_cap_duoi_truc_tiep` | Đơn vị mình và cấp dưới trực tiếp | ReBAC | unit_and_children, cap_duoi_truc_tiep |
| `don_vi_minh_va_cap_duoi` | Đơn vị mình và mọi cấp dưới | ReBAC | unit_and_descendants, toan_bo_cap_duoi, don_vi_va_cap_duoi |
| `cap_duyet` | Bản ghi đang chờ đơn vị mình duyệt | ReBAC | approval_unit |
| `do_minh_lap` | Bản ghi do chính mình lập (`resource.nguoi_lap = user.ma_nguoi_dung`) | ABAC | own_record, cua_minh |
| `duoc_giao` | Bản ghi được giao cho mình (`resource.nguoi_duoc_giao = user.ma_nguoi_dung`) | ABAC | assigned |

## 3. Quan hệ, thuộc tính, trạng thái, điều kiện

| Quan hệ | Ý nghĩa | Bí danh |
|---|---|---|
| `cap_tren` | Đơn vị cấp trên (trên cây đơn vị) | parent |
| `thuoc_don_vi` | Đơn vị sở hữu bản ghi | owner_unit |
| `thuoc_to_chuc` | Tổ chức (cây thứ hai, ví dụ hội) sở hữu bản ghi | owner_org |
| `don_vi_quan_ly` | Đơn vị quản lý tổ chức | managing_unit |
| `cap_duyet` | Đơn vị (cây đơn vị) đang phải duyệt bản ghi | approval_unit |
| `cap_duyet_to_chuc` | Tổ chức (cây thứ hai, ví dụ hội) đang phải duyệt bản ghi | approval_org |
| `noi_di` | Nơi chuyển đi | source_unit |
| `noi_den` | Nơi chuyển đến | target_unit |

| Thuộc tính | Kiểu | Ý nghĩa | Bí danh |
|---|---|---|---|
| `trang_thai` | chuỗi | Trạng thái vòng đời | status |
| `nguoi_lap` | chuỗi | Người lập bản ghi | created_by, nguoi_tao |
| `da_khoa` | đúng/sai | Bản ghi đã bị khoá | locked |
| `nguoi_duoc_giao` | chuỗi | Người được giao xử lý | assignee, nguoi_xu_ly |

Trạng thái vòng đời (`vong_doi` của tài nguyên): nhóm `dang_soan` (giá trị `DU_THAO`, `BI_TRA_LAI`), `cho_duyet` (`CHO_DUYET`), `da_duyet` (`DA_DUYET`). Bí danh: nhóm `draft` → `dang_soan`, `nhap` → `dang_soan`, `pending` → `cho_duyet`, `approved` → `da_duyet`; giá trị `DRAFT` → `DU_THAO`, `NHAP` → `DU_THAO`, `RETURNED` → `BI_TRA_LAI`, `BI_TU_CHOI` → `BI_TRA_LAI`, `TRA_LAI` → `BI_TRA_LAI`, `REJECTED` → `BI_TRA_LAI`, `PENDING` → `CHO_DUYET`, `PENDING_APPROVAL` → `CHO_DUYET`, `PENDING_APP` → `CHO_DUYET`, `APPROVED` → `DA_DUYET`, `LOCKED` → `DA_KHOA`. Bí danh chỉ để quy về key chuẩn trong thiết kế; CSDL ghi giá trị khác key chuẩn thì khai `gia_tri` cho thuộc tính (`dac-ta.md`) để JSON, DSL xuất đúng giá trị CSDL.

Điều kiện do quy định kế thừa sinh: `khong_tu_duyet` (KT-13), `dang_soan`, `cho_duyet` (KT-14), `chua_khoa` (KT-15). Bí danh: `not_self_approval`, `draft`, `pending`, `not_locked`.

## 4. Cây đơn vị

Cây đơn vị lấy từ **Cổng**, dùng chung mọi phân hệ: key `don_vi`, quan hệ `cap_tren`. Phân hệ không thiết kế quyền trên cây đơn vị; cây chỉ là nơi gán vai trò theo đơn vị và là gốc tính phạm vi. Đặc tả chưa có cây thì công cụ tự thêm; có hành động trên cây thì công cụ cảnh báo `CONG-01`. Bí danh: `unit`.

`don_vi` là **tên quy ước trong thiết kế**, không cần biết key thật của cây trên Cổng. Thiết kế chỉ dựa vào cấu trúc của cây (nút đơn vị, quan hệ cấp trên `cap_tren`): quy định kế thừa của phân hệ được đặt trước trên cấu trúc đó, còn dữ liệu cây (đơn vị nào, cấp trên là ai, người dùng thuộc đơn vị nào) do Cổng cung cấp khi hệ thống chạy. Tên key chỉ cần khớp ở bước đưa vào hệ phân quyền đích: nếu cây đồng bộ từ Cổng mang tên khác, ánh xạ một lần ở bộ chuyển khi import (hoặc đổi `CAY_CONG` trong `bo_key.py`), không phải sửa thiết kế.

Cây riêng của phân hệ (ví dụ cây tổ chức đoàn thể gắn vào đơn vị, M-01) vẫn khai trong đặc tả như tài nguyên `loai: cay`.

Phân hệ thuộc hệ sinh thái TCCT: cấu trúc thật của cây (gốc TCCT, 5 cấp, nhánh nội bộ / cấp dưới của mỗi đơn vị, cây tổ chức quần chúng) và quy tắc đặt vai trò trên cây ở `cay-don-vi-ctd-ctct.md`.

## 5. Tên vai trò cầu nối trong JSON import và DSL

Công cụ xuất tự sinh vai trò trên tài nguyên theo dạng `<vai trò>__<phạm vi>`: `__don_vi_minh`, `__don_vi_minh_va_cap_duoi`, `__cap_duyet`, `__o_<cây>_cap_tren`, `__o_<cây>_quan_ly[_hoac_cap_tren]`, `__<tên phạm vi riêng>`; vai trò chung trùng tên mang `__quyen_chung`; có điều kiện thì thêm `__<điều kiện>` (quan hệ, vai trò trên bản ghi). Thêm mới, nhập của vai trò theo đơn vị: hành động `<tài nguyên>__<hành động>[__<điều kiện>]` trên cây; của vai trò toàn hệ thống có điều kiện: `<hành động>__<điều kiện>` trên tài nguyên. Tenant của DSL là `mac_dinh`; tập điều kiện ABAC mang tiền tố `tap_`, tập người dùng `tai_khoan_hoat_dong` (`user.trang_thai = DANG_HOAT_DONG`).
