# Đọc tài liệu nghiệp vụ của BA để thiết kế phân quyền

Tài liệu BA không viết sẵn phân quyền, và BA thường không biết RBAC, ReBAC, ABAC. Thứ BA đưa ra là **vai trò nào được thực hiện tác vụ gì** (xem, thêm, sửa, xoá, gửi duyệt, phê duyệt…), nằm rải trong tài liệu thiết kế, bảng chức năng, sơ đồ drawio, mô tả quy trình. Nhiệm vụ:

1. rút đúng các cặp **vai trò – tác vụ** mà tài liệu nêu (đây là phần «Theo tài liệu»);
2. để quy định kế thừa (`quy-dinh-ke-thua.md`) tự suy ra quyền xem đi kèm, phạm vi theo cây đơn vị, ràng buộc trạng thái và tách nhiệm vụ: **không viết lại** những thứ này trong đặc tả;
3. dùng nguyên tắc (`nguyen-tac.md`) và mẫu (`mau-thiet-ke.md`) để đề xuất phần còn thiếu, có lý do và mức tin cậy.

Không hỏi BA về phạm vi hay kế thừa bằng thuật ngữ kỹ thuật. Khi cần hỏi, hỏi bằng tình huống nghiệp vụ: «Trưởng phòng có cần xem đề xuất của tổ trực thuộc không?», không hỏi «phạm vi toan_bo_cap_duoi?».

Nghiệp vụ mỗi phân hệ khác nhau; đừng cố tìm câu trả lời có sẵn trong tài liệu cho mọi ô.

## 1. Các phần cần tìm và lấy được gì

| Phần thường gặp trong tài liệu | Tên hay gặp | Lấy được |
|---|---|---|
| Nhóm người sử dụng | "Danh sách nhóm người sử dụng", "Tác nhân", "Đối tượng sử dụng" | Chức trách từng nhóm (lập, kiểm tra, duyệt, xem) → tách vai trò (NT-09, NT-10), cấp của vai trò |
| Bảng chức năng / usecase | "Danh sách chức năng chính", "Mô hình usecase", cột TT – Tên usecase – Tác nhân – Giao dịch | Danh sách thao tác cụ thể, tác nhân được làm → khung ma trận |
| Bảng thông tin quản lý | "Các thông tin quản lý", Đối tượng – Trường thông tin | Tài nguyên (đối tượng có trường riêng), thuộc tính, trạng thái, quan hệ (đơn vị quản lý, người duyệt) |
| Quy trình nghiệp vụ | Bảng Bước – Người thực hiện – Mô tả, sơ đồ làn | Luồng gửi duyệt nhiều cấp, ai duyệt cấp nào (NT-14), bước nào ngoài hệ thống (không phân quyền, công cụ tự bỏ qua) |
| Mô hình tổ chức | "Mô hình tổng thể", "Phạm vi", mô tả cấp đơn vị | Cây tổ chức, các cấp, quan hệ cấp trên |
| Ma trận phân quyền của BA | Bảng Excel dòng chức năng × cột vai trò, ô đánh dấu | Giao dịch có sẵn tác nhân (`ma_tran_sang_giao_dich.py`); nếu dùng làm đáp án thì đo bằng `so_sanh_ma_tran.py` |
| Sơ đồ quy trình | drawio có làn (swimlane), BPMN | Bước – người thực hiện (`quy_trinh_sang_giao_dich.py`); khối rẽ nhánh gợi ý điều kiện; tên trạng thái trên mũi tên → `vong_doi` của tài nguyên |
| Sơ đồ khác (drawio) | sơ đồ tổ chức, sơ đồ use case, sơ đồ trạng thái | Sơ đồ tổ chức → cây đơn vị và cấp; use case → cặp tác nhân – chức năng; sơ đồ trạng thái → `vong_doi` (nháp, chờ duyệt, đã duyệt). Đọc nhãn khối và mũi tên trong `trich_xuat/N….md` |
| Tài liệu thiết kế, mô tả màn hình | "Mô tả chức năng", "Thiết kế màn hình", bảng nút bấm – người dùng | Câu "X được / có thể …" và nút chức năng theo vai trò → giao dịch tự lập `giao_dich_tu_lap.json`, mỗi giao dịch có vị trí trích |
| Kết nối, API | "Kết nối, chia sẻ dữ liệu", usecase "API …" | Loại khỏi phân quyền người dùng (NT-18) |
| Dashboard, báo cáo | "Dashboard …", "Danh mục báo cáo" | Không là tài nguyên (NT-19) |

## 2. Trình tự

1. **Cây tổ chức**: các cấp và nút gán vai trò. Ghi rõ những cây khác nhau (ví dụ cây đơn vị hành chính và cây tổ chức đoàn thể gắn vào nó, M-01).
2. **Tài nguyên** từ bảng thông tin quản lý và tên usecase "Quản lý …". Gộp những usecase chỉ là màn hình khác nhau của cùng một loại dữ liệu. Áp NT-05.
3. **Hành động**: chuẩn hoá động từ của giao dịch về bộ key chuẩn (NT-06). Bảng quy đổi ở mục 3.
4. **Vai trò**: từ nhóm người sử dụng và tác nhân. Tách tác nhân gộp theo NT-10; đặt loại phạm vi (toàn hệ thống / theo đơn vị / theo bản ghi).
5. **Quan hệ**: tài nguyên nào thuộc đơn vị nào (`thuoc_don_vi`…), có cấp duyệt không (`cap_duyet`). Phạm vi mặc định do KT-06…KT-09 tự đặt từ các quan hệ này; chỉ viết quy tắc `pham_vi` khi tài liệu nêu khác (ví dụ danh mục dùng chung xem toàn bộ).
6. **Luồng duyệt, trạng thái, dữ liệu nhạy cảm**: khai `vong_doi` cho tài nguyên có gửi duyệt; đánh dấu `nhay_cam` cho tác vụ xem thông tin nhạy cảm. Điều kiện trạng thái, khoá, không tự duyệt do KT-13…KT-15 tự sinh; chỉ viết `dieu_kien` cho điều kiện riêng của nghiệp vụ (đợt đang mở, người được giao…).
7. **Kiểm tra** bằng công cụ, sửa đề xuất, ghi câu hỏi cho BA.

## 3. Hành động: giữ key tài liệu, không gộp

Mỗi thao tác tài liệu nêu là **một hành động riêng**. Tài liệu (ma trận, bảng chức năng) có key thì dùng đúng key đó (`tim_kiem`, `tao_moi`, `gui_phe_duyet`…), riêng xem danh sách và xem chi tiết (`xem_ds`, `xem_ct`) là một hành động `xem` (ngoại lệ duy nhất); tài liệu chỉ có tên thao tác thì đặt key theo loại tương ứng ở bảng dưới. Không quy hai thao tác khác nhau về một key, kể cả khi thường được cấp cùng nhau. Một key gồm nhiều thao tác (`lock_unlock`, «Phê duyệt/từ chối và phân công») thì tách, ghi `tach_tu`.

| Động từ đầu tên giao dịch | Key loại (khi tài liệu không có key) | Ghi chú |
|---|---|---|
| Xem, Xem danh sách, Xem chi tiết, Xem thông tin … | `xem` | một quyền (ngoại lệ gộp); List 1 → List 2 (KT-02) |
| Tìm kiếm (nhanh, nâng cao) | `tim_kiem` | tìm kiếm nhanh và nâng cao là hai key nếu tài liệu tách |
| Tra cứu · Lọc · Xem lịch sử | `tra_cuu` · `loc` · `xem_lich_su` | |
| Xem danh sách *X* thuộc *Y* (trong màn chi tiết Y) | hành động xem của X | X là tài nguyên riêng (NT-17) |
| Xem thông tin nhạy cảm (kỷ luật, sức khoẻ…) | `xem_nhay_cam` | KT-16 |
| Thêm mới, Tạo, Lập · Upload · Khai báo · Nhập liệu | `them_moi` · `tai_len` · `khai_bao` · `nhap_lieu` | |
| Chỉnh sửa, Sửa, Cập nhật | `chinh_sua` | |
| Xoá · Khôi phục | `xoa` · `khoi_phuc` | |
| Gửi duyệt, Gửi phê duyệt, Trình | `gui_duyet` | |
| Phê duyệt, Duyệt · Xác nhận · Tiếp nhận (khi là bước duyệt) | `phe_duyet` · `xac_nhan` · `tiep_nhan` | cấp duyệt ghi trong tên → vai trò của cấp đó |
| Từ chối · Trả lại · Yêu cầu chỉnh sửa, bổ sung | `tu_choi` · `tra_lai` · `yeu_cau_chinh_sua` | ba hành động khác nhau |
| Xuất Excel, xuất danh sách · Xuất tệp · Trích lục · In | `xuat` · `xuat_file` · `trich_luc` · `in` | |
| Nhập danh sách, Import, Nhập Excel | `nhap` | |
| Khoá · Mở khoá | `khoa` · `mo_khoa` | |
| Sao chép · Phản hồi · Phân công | `sao_chep` · `phan_hoi` · `giao_xu_ly` | |
| Chia sẻ, Di chuyển, Tải xuống (tệp) | `chia_se`, `di_chuyen`, `tai_xuong` | kho tư liệu |

Key tài liệu lạ, công cụ không phân loại được (`KEY-02`): ghi `"loai": "<key loại>"` cho hành động đó trong đặc tả để quy định kế thừa áp đúng.

## 4. Tín hiệu về phạm vi và cấp

| Cụm từ trong tài liệu | Gợi ý |
|---|---|
| "các cấp" trong tên tác nhân | vai trò theo đơn vị, gán ở nhiều cấp |
| "đơn vị mình", "trực thuộc", "trong phạm vi đơn vị" | `don_vi_minh` hoặc `don_vi_minh_va_cap_duoi` |
| "cấp trên trực tiếp", "gửi lên" | quan hệ cấp trên, luồng duyệt |
| "toàn ngành", "toàn hệ thống", cơ quan cấp cao nhất | `toan_he_thong` |
| "phê duyệt cấp A / cấp B" | NT-14: vai trò của từng cấp + `cap_duyet` |
| "nơi chuyển đi / nơi chuyển đến" | hai quan hệ tới hai đơn vị |
| "người lập", "người xem xét", "người tiếp nhận" trong bảng thông tin | thuộc tính người, điều kiện NT-16 |
| "trạng thái", "khoá", "đợt đang mở" | điều kiện NT-15 |

## 5. Mức tin cậy

| Mức | Khi nào | Ví dụ |
|---|---|---|
| `cao` | Tài liệu nêu trực tiếp, hoặc quy đổi cơ học không mơ hồ | "Chuyên viên có thể thêm mới hồ sơ" → `chuyen_vien:ho_so:them` |
| `trung_binh` | Suy ra từ tên, từ quy trình, từ cách dùng thống nhất trong tài liệu | "Phê duyệt cấp phòng" → vai trò trưởng phòng |
| `thap` | Tài liệu im lặng, chỉ dựa vào nguyên tắc / thông lệ | đề xuất cho người lập sửa, xoá bản nháp của mình (KT-05: không tự sinh) |

Quy định kế thừa không sinh quyền: chỗ quy định lẽ ra áp mà tài liệu chưa nêu thành câu hỏi «Thiếu nguồn» `NG-…`; quy tắc AI suy ra cho chỗ đó có mức `trung_binh`. Khi tài liệu nêu rõ khác một quy định, ghi ngoại lệ ở `ke_thua.khong_ap_dung`.

Đề xuất `thap` luôn kèm một câu hỏi cho BA.

## 6. Câu hỏi cho BA

**Hỏi lúc nào.** Điểm nghiệp vụ không phổ biến được ghi thành câu hỏi ngay sau khi đọc tài liệu (SKILL.md của ra-soat-phan-quyen, bước 2), nhưng **không hỏi ngay**: mọi câu của một vòng rà soát được ghi một lần vào sheet Q&A (bước 6) để BA trả lời một thể. Chỉ hỏi thêm khi câu trả lời chưa rõ hoặc mâu thuẫn.

Viết khi đề xuất có mức `thap`, khi tài liệu tự mâu thuẫn, hoặc khi lựa chọn ảnh hưởng an toàn dữ liệu. Mỗi câu hỏi: nêu điều tài liệu viết, điều chưa rõ, **phương án AI đang áp dụng** và hệ quả nếu BA chọn khác. Viết bằng ngôn ngữ nghiệp vụ và tình huống cụ thể, không dùng key, tên phạm vi hay thuật ngữ RBAC / ReBAC / ABAC. Không hỏi những điều nguyên tắc hoặc quy định kế thừa đã trả lời.
