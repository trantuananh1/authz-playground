# Quy định kế thừa quyền (KT-01 … KT-21)

Các quy định dưới đây áp cho mọi phân hệ và **không tự cấp quyền, không tự đặt phạm vi, không tự thêm điều kiện**. Chúng là danh sách những chỗ thiết kế hay bị thiếu: chỗ nào một quy định lẽ ra áp mà đặc tả chưa có, công cụ ghi mục `thieu_nguon` và sinh câu hỏi «Thiếu nguồn» (`NG-…`).

## Nguồn gốc của một quyền

| Nguồn gốc | Trạng thái trong thiết kế | Hiển thị cho BA |
|---|---|---|
| Tài liệu nêu, BA chốt, hoặc AI suy ra kèm ô căn cứ (chế độ suy ra) | `giu` | «Theo tài liệu / BA chốt», kèm ô nguồn; nhãn «Suy ra» nếu có phần suy ra |
| Tài liệu hoặc BA chốt nói bỏ (ví dụ chỉ cấp đang duyệt mới duyệt) | `bo` | «Bỏ theo tài liệu / BA chốt» |
| Tài liệu chưa nêu, chưa suy ra | không có trong thiết kế | mục «Chưa có nguồn» và câu hỏi `NG-…` |

## Nguyên tắc áp dụng

1. **Mọi quyền có nguồn.** Mọi quyền, phạm vi, điều kiện có `nguon`: ô / đoạn tài liệu, «BA chốt CH-… / NG-…», hoặc «AI suy ra» kèm ô căn cứ. Ghép tác nhân của tài liệu với vai trò cũng phải có nguồn nói ai giữ tác nhân đó; tên vai trò giống nhau không phải là nguồn.
2. **Câu `NG-…` được xử lý theo chế độ.** Chế độ suy ra (mặc định): AI tự chốt bằng quy tắc có nguồn «AI suy ra», hoặc ghi `ke_thua.khong_ap_dung` kèm lý do lấy từ tài liệu; điểm suy ra đi vào sheet Q&A để BA đồng ý hoặc sửa. Chế độ chỉ theo nguồn (`chi-nguon`): câu `NG-…` đi vào sheet Q&A, phần đó để trống. BA trả lời thì AI ghi quy tắc với `nguon: ["BA chốt NG-…"]` rồi lập lại; BA nói không thì không thêm gì.
3. **Suy luận lô-gíc từ hai câu tài liệu cũng là suy ra.** Ví dụ «được sửa thì được xem», «khoá chỉ áp cho hồ sơ đã duyệt nên hồ sơ khoá không sửa được»: ở chế độ suy ra ghi rõ «AI suy ra»; ở chế độ chỉ theo nguồn thì hỏi BA, không tự ghi.
4. **Câu hỏi không kèm phương án khuyến nghị.** Câu hỏi nêu điều tài liệu chưa nói và các lựa chọn trung lập.

Cột «Áp dụng» dưới đây: **Công cụ** nghĩa là `lap_thiet_ke.py` **phát hiện chỗ thiếu và sinh câu hỏi**; **AI** nghĩa là AI xét khi viết đặc tả (hỏi hoặc suy ra có nguồn); **Ứng dụng** là hệ thống nghiệp vụ phải bảo đảm (KT-02 là cách biểu diễn danh sách, không cấp thêm quyền). «Phạm vi mặc định» trong cột «Quy định» là phạm vi quy định gợi ý, không được công cụ tự đặt. Riêng KT-09: vai trò được khai `toan_he_thong` có nguồn thì phạm vi toàn hệ thống lấy theo khai báo vai trò.

## A. Kế thừa giữa các tác vụ của cùng một vai trò

| Mã | Quy định | Áp dụng |
|---|---|---|
| KT-01 | **Làm được trên bản ghi thì xem được bản ghi đó.** Vai trò được sửa, xoá, gửi duyệt, phê duyệt, trả lại, khoá, tiếp nhận… một bản ghi thì được `xem` bản ghi đó (xem danh sách và xem chi tiết là một quyền `xem`). **Không** tự cấp tìm kiếm, tra cứu, lọc, xem lịch sử, xem nhạy cảm: đó là hành động riêng (NT-06, NT-07). | Công cụ |
| KT-02 | **Danh sách là các bản ghi được xem.** Hệ phân quyền trả danh sách ID bản ghi người dùng được `xem` (List 1); ứng dụng truy vấn CSDL với điều kiện lọc **và** ID thuộc List 1 để ra danh sách hiển thị (List 2); xem chi tiết là kiểm tra `xem` trên bản ghi. Xuất danh sách cũng chỉ gồm List 1; mọi quyền xuất (có hay không có điều kiện) được công cụ xuất cấp trên từng bản ghi theo phạm vi xem của vai trò, để hệ phân quyền áp luôn phạm vi và điều kiện (`scripts/ha_muc.py`). Tìm kiếm kiểm tra quyền riêng `tim_kiem` (NT-07). | Ứng dụng |
| KT-03 | **Người lập xem được bản ghi do mình lập** (các hành động xem bản ghi như KT-01), ở mọi trạng thái và **kể cả khi đã chuyển sang đơn vị khác**. Quyền gắn với người lập, không gắn với vai trò hay đơn vị: **ABAC** `resource.nguoi_lap = user.ma_nguoi_dung` (NT-16). | Công cụ; ứng dụng ghi `nguoi_lap` khi tạo |
| KT-04 | **Xem không kéo theo xuất, nhập** (NT-08). | Công cụ (không sinh) |
| KT-05 | **Các tác vụ ghi không kéo theo nhau.** Được thêm không có nghĩa được sửa, xoá. "Người lập sửa, xoá bản nháp của mình" là đề xuất của AI, không phải quy định kế thừa (NT-01). | AI |

## B. Kế thừa theo cơ cấu tổ chức

Cây đơn vị lấy từ **Cổng** (`don_vi`, quan hệ `cap_tren`), dùng chung mọi phân hệ; phân hệ không thiết kế quyền trên cây đơn vị. Với phân hệ ngành CTĐ-CTCT, «đơn vị mình» và «cấp dưới» hiểu theo cây ngành dọc gốc TCCT; vai trò của cơ quan chính trị tính phạm vi từ đơn vị chủ quản (`cay-don-vi-ctd-ctct.md`, CD-01…CD-03).

| Mã | Quy định | Áp dụng |
|---|---|---|
| KT-06 | **Vai trò gán tại đơn vị nào làm việc trên dữ liệu của đơn vị đó.** Phạm vi mặc định của tác vụ ghi: `don_vi_minh` (NT-12). | Công cụ |
| KT-07 | **Cấp trên xem được tất cả dữ liệu của đơn vị mình và mọi đơn vị cấp dưới trên cây đơn vị; quyền ghi không lan xuống.** Phạm vi mặc định của `xem`: `don_vi_minh_va_cap_duoi`. Cấp trên không sửa, xoá, nhập thay cấp dưới (NT-13). | Công cụ; kiểm tra `KT-07` cảnh báo quyền ghi lan xuống cấp dưới |
| KT-08 | **Duyệt theo cấp: chỉ duyệt bản ghi đang chờ đơn vị mình duyệt.** Khi tài nguyên có quan hệ `cap_duyet`, phạm vi mặc định của `phe_duyet`, `tu_choi` là `cap_duyet`, áp cho mọi vai trò (NT-14). | Công cụ |
| KT-09 | **Vai trò toàn hệ thống (cấp cao nhất) làm việc trên toàn bộ dữ liệu** (`toan_he_thong`), trừ tác vụ duyệt theo KT-08 (NT-12). | Công cụ |
| KT-10 | **Tổ chức gắn vào đơn vị kế thừa phạm vi của đơn vị** (hội, ban, tổ công tác trực thuộc một đơn vị) (M-01). | AI (khai quan hệ trong phạm vi) |
| KT-11 | **Thông tin con theo quyền bản ghi cha.** Dòng chi tiết, tệp đính kèm, lịch sử xử lý không là tài nguyên riêng (NT-05). | AI |
| KT-12 | **Thư mục con kế thừa quyền thư mục cha** trong kho tư liệu, trừ khi được chia sẻ riêng (NT-20). | AI, ứng dụng |

## C. Ràng buộc tự động

| Mã | Quy định | Áp dụng |
|---|---|---|
| KT-13 | **Người lập không tự duyệt, tự trả lại bản ghi do mình lập**, kể cả khi giữ vai trò được duyệt (NT-03). Áp cho tài nguyên có tác vụ thêm hoặc gửi duyệt. | Công cụ (điều kiện chuẩn khi ghi: `khong_tu_duyet`, `resource.nguoi_lap ≠ user.ma_nguoi_dung`) |
| KT-14 | **Theo trạng thái của bản ghi**, khi tài nguyên có cả `gui_duyet` và `phe_duyet`: `chinh_sua`, `xoa`, `gui_duyet` chỉ khi `trang_thai` thuộc nhóm `dang_soan` (nháp, bị trả lại); `phe_duyet`, `tu_choi` chỉ khi thuộc nhóm `cho_duyet` (NT-15). Giá trị lấy từ `vong_doi` của tài nguyên. | Công cụ (điều kiện chuẩn khi ghi: `dang_soan`, `cho_duyet`) |
| KT-15 | **Dữ liệu đã khoá không sửa, không xoá**, khi tài nguyên có `khoa`; trừ vai trò được `mo_khoa` (M-07). Dữ liệu thuộc đợt đã đóng: AI viết điều kiện riêng (M-06). | Công cụ (điều kiện chuẩn khi ghi: `chua_khoa`) |
| KT-16 | **Thông tin nhạy cảm không lan theo cấp trên.** `xem_nhay_cam` (hoặc tác vụ xem đánh dấu `nhay_cam`) có phạm vi mặc định `don_vi_minh` thay vì `don_vi_minh_va_cap_duoi` (NT-17). | Công cụ; AI dùng `xem_nhay_cam` hoặc đánh dấu `nhay_cam` |

## D. Quan hệ giữa các vai trò

| Mã | Quy định | Áp dụng |
|---|---|---|
| KT-17 | **Không kế thừa theo chức vụ.** Lãnh đạo không mặc nhiên có quyền của chuyên viên cùng đơn vị, và ngược lại (NT-09, NT-21). | Công cụ (không sinh) |
| KT-18 | **Kiêm nhiệm là cộng quyền, ràng buộc vẫn theo người.** KT-13 áp cho chính người giữ nhiều vai trò (NT-23). | Ứng dụng (điều kiện so theo người) |
| KT-19 | **Uỷ quyền có thời hạn, không uỷ quyền tiếp**; ghi nhận người thực hiện thực tế. Chỉ áp khi phân hệ có nghiệp vụ uỷ quyền (NT-23). | AI, ứng dụng |
| KT-20 | **Quản trị hệ thống không kế thừa quyền nghiệp vụ**; không tự gán quyền cho chính mình (NT-22). Vai trò `nhom: quan_tri` có quyền trên tài nguyên không thuộc loại `he_thong` bị cảnh báo. | Công cụ (kiểm tra) |
| KT-21 | **Báo cáo, thống kê theo quyền xem dữ liệu gốc** (NT-19). | AI |

## Cách công cụ trình bày cho BA

`lap_thiet_ke.py` sinh **câu mô tả theo vai trò** (`cau_mo_ta` trong `thiet_ke_phan_quyen.json`): mỗi câu gộp các tác vụ cùng tài nguyên, cùng phạm vi, cùng điều kiện, cùng nguồn gốc. Ví dụ:

- «Được phê duyệt, từ chối Đề xuất mua sắm đang chờ đơn vị mình duyệt, chỉ khi bản ghi đang chờ duyệt.» — Theo tài liệu (mục 3.2).
- Câu hỏi `NG-…`: «Tài liệu không nêu người lập có được tự phê duyệt bản ghi do mình lập hay không.» — chưa có nguồn, không đưa vào thiết kế.

BA xác nhận các câu này qua sheet Q&A và bản xem trước trên Artifact; không cần biết RBAC, ReBAC, ABAC.
