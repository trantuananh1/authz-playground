# Cây đơn vị ngành CTĐ-CTCT (căn cứ thiết kế phạm vi ReBAC)

Nguồn: tài liệu «Kiến thức nghiệp vụ CTĐ-CTCT» do khách hàng cung cấp. Tài liệu tổng hợp kiến thức cơ bản ngành Công tác Đảng, công tác chính trị trong Quân đội nhân dân Việt Nam, gồm các mục: cây đơn vị, luồng triển khai nhiệm vụ, luồng công tác quần chúng, đối tượng quản lý, thuật ngữ. Tệp này áp dụng cho **mọi phân hệ thuộc hệ sinh thái Tổng cục Chính trị (TCCT)**. Phân hệ ngoài ngành thì bỏ qua tệp này và dùng mẫu M-01.

**Đọc tệp này khi:**
- đặt nơi gán và cấp cho vai trò;
- thiết kế phạm vi theo cây (KT-06…KT-10);
- thiết kế luồng duyệt nhiều cấp (M-03) và cây tổ chức quần chúng (M-01);
- viết câu mô tả phạm vi, câu hỏi cho BA.

Quy tắc thiết kế ở mục 8 (CD-01…CD-11). Trong lý do đề xuất, ghi mã CD-xx như mã NT-xx.

## 1. Một cây ngành dọc chung

- Trong cây tổ chức Bộ Quốc phòng (BQP), TCCT ngang cấp với các Tổng cục, Quân khu, Quân đoàn, Quân chủng, Binh chủng. Riêng về nghiệp vụ CTĐ-CTCT, TCCT là đơn vị đứng đầu, quản lý toàn quân. Cây dùng cho phân quyền là **cây ngành dọc CTĐ-CTCT, gốc là TCCT**.
- Mọi lĩnh vực đều tuân theo một cây chung này: tuyên huấn, tổ chức, kiểm tra, cán bộ, bảo vệ an ninh, dân vận, chính sách, quần chúng…
- Các trường hợp hiển thị theo cây khác:

| Lĩnh vực | Cây hiển thị | Quan hệ với cây chung |
|---|---|---|
| Công tác quần chúng: thanh niên, phụ nữ, công đoàn | Cây tổ chức quần chúng đặc thù (mục 6) | Gắn vào cây chung; luồng nghiệp vụ vẫn bám cây chung |
| Khiếu nại, tố cáo | Cây đơn vị nghiệp vụ Viện kiểm sát quân sự các cấp | Cây nghiệp vụ riêng. Tài liệu chưa mô tả cấu trúc và nguồn dữ liệu của cây này |
| Phim, Xuất bản | Cây nội bộ của Nhà xuất bản Quân đội nhân dân và Điện ảnh Quân đội nhân dân | Là nhánh thuộc cây chung, không phải cây tạo riêng |

## 2. Năm cấp của cây

| Cấp | Gồm | Số đơn vị (theo tài liệu) | Cơ quan chính trị; chức danh chính trị |
|---|---|---|---|
| 1 | Tổng cục Chính trị | 1 | Các Cục, Ban, Viện trực thuộc TCCT |
| 2 | Đơn vị trực thuộc BQP. Gồm: BTTM và các Tổng cục; Quân khu, BTL Thủ đô Hà Nội; Quân chủng, Quân đoàn, BĐBP, Cảnh sát biển, BTL86; Binh chủng, Ban Cơ yếu, BTL Lăng; học viện, nhà trường, cơ quan nghiên cứu; binh đoàn; bệnh viện; doanh nghiệp | 56 | Cục Chính trị / Phòng Chính trị / Cơ quan chính trị; Chính ủy, Bí thư Đảng ủy |
| 3 | Gồm: Cục đầu mối trực thuộc BQP và tương đương; Vùng (Cảnh sát biển, Hải quân); Lữ đoàn và tương đương; Sư đoàn; Bộ CHQS tỉnh, thành phố trực thuộc Trung ương | 877 | Phòng, ban, trợ lý chính trị; Chính ủy, Chính trị viên |
| 4 | Trung đoàn; cấp tương đương (Ban CHQS Phòng thủ khu vực…) | 1.499 | Ban Chính trị; Chính ủy, Chính trị viên |
| 5 | Phân đoàn: tiểu đoàn và tương đương, đại đội và tương đương | 11.921 | Chính trị viên, Chính trị viên phó |

Số cấp từ gốc tới một đơn vị **không cố định**. Có đơn vị «tương đương» ở nhiều cấp, và có nhánh không đi đủ năm cấp (bệnh viện, doanh nghiệp…).

## 3. Cấu trúc bên trong một nút đơn vị

Theo sơ đồ cây trong tài liệu (ví dụ Quân khu 1):

```
Tổng cục Chính trị
├── Các đơn vị nội bộ TCCT          (Cục, Ban, Viện trực thuộc TCCT — cơ quan chủ quản các phân hệ)
└── Quân khu 1, Quân khu 2, Binh chủng Thông tin, Bệnh viện Quân y 103, Tập đoàn CNVT Quân đội, …
     Quân khu 1
     ├── Các đơn vị nội bộ Quân khu
     │    └── Cục Chính trị
     │         └── Phòng Bảo vệ an ninh, Phòng Tuyên huấn, Phòng Dân vận, Phòng Công tác quần chúng, …
     └── Các đơn vị cấp dưới
          └── Sư đoàn 346
               ├── Nội bộ Sư đoàn
               │    └── Phòng Chính trị
               │         └── Ban Chính sách, Ban Bảo vệ an ninh, Ban Dân vận – Quần chúng, Ban Tuyên huấn, …
               └── Các đơn vị cấp dưới
                    └── Trung đoàn 246
                         └── Ban Chính trị        (không có đơn vị trực thuộc; trợ lý các mảng nằm trong Ban)
```

Điểm cần nắm:
- **Mỗi đơn vị có hai nhánh.** Nhánh nội bộ gồm cơ quan chính trị và các phòng, ban của cơ quan đó. Nhánh cấp dưới gồm các đơn vị cấp dưới. Cơ quan chính trị **ngang hàng** với các đơn vị cấp dưới, không phải cấp trên của chúng.
- **Tên cơ quan chính trị đổi theo cấp:** Cục Chính trị, Phòng Chính trị, Ban Chính trị. Phòng, ban nghiệp vụ trong cơ quan chính trị chia theo mảng.
- **Cấp trung đoàn và tương đương** thường chỉ có Ban Chính trị, trong Ban có trợ lý các mảng. Dưới Ban Chính trị không có nút.
- **Các nút nhóm** «Các đơn vị nội bộ», «Các đơn vị cấp dưới» có trên sơ đồ. Tài liệu không nêu cây trên Cổng có lưu các nút nhóm này hay không: [CẦN XÁC NHẬN] khi đối chiếu cây thật. Quy tắc CD-02 đúng trong cả hai trường hợp; CD-03 nêu chỗ khác nhau.

## 4. Chức danh và thẩm quyền

Thủ trưởng đơn vị **khác** thủ trưởng cơ quan chính trị. Ví dụ: Tổng giám đốc VTS khác Trưởng phòng Chính trị VTS; lãnh đạo Quân khu 1 khác Chủ nhiệm Chính trị Quân khu 1.

| Vị trí | Chức danh | Việc làm trong luồng | `tham_quyen` |
|---|---|---|---|
| Đơn vị (cấp có thẩm quyền, có con dấu): đơn vị trực thuộc BQP, sư đoàn, lữ đoàn, trung đoàn và tương đương | Thủ trưởng đơn vị | Phân công, phê duyệt. Hồ sơ không hợp lệ thì yêu cầu sửa đổi, bổ sung | `phe_duyet` |
| Cơ quan chính trị của đơn vị (có con dấu) | Chủ nhiệm, Phó Chủ nhiệm chính trị (thủ trưởng cơ quan chính trị) | Phân công, phê duyệt. Hồ sơ không hợp lệ thì yêu cầu sửa đổi, bổ sung | `phe_duyet` |
| Phòng, ban thuộc cơ quan chính trị (không có con dấu) | Trưởng phòng, Trưởng ban | Phân công, xem xét. Hợp lệ thì đề nghị lên cấp trên; không hợp lệ thì yêu cầu sửa đổi, bổ sung | `de_nghi` |
| Trợ lý, nhân viên | Trợ lý theo mảng: tuyên huấn, dân vận, bảo vệ an ninh, quần chúng… | Rà soát hồ sơ, tổng hợp, xử lý, phản hồi, báo cáo; yêu cầu cấp dưới sửa đổi, bổ sung | `xu_ly` |
| TCCT | Chủ nhiệm, Phó Chủ nhiệm TCCT; thủ trưởng các Cục, Ban, Viện trực thuộc TCCT | Triển khai nhiệm vụ bằng công văn, văn bản, hướng dẫn; nhận báo cáo cuối luồng | `phe_duyet` |

Quy đổi động từ của luồng sang bộ key chuẩn (gợi ý; tài liệu nói khác thì theo tài liệu):

| Trong tài liệu | Key |
|---|---|
| Phân công | `giao_xu_ly` |
| Phê duyệt | `phe_duyet` |
| Yêu cầu sửa đổi, bổ sung (trả về cấp dưới) | `yeu_cau_chinh_sua` (khác `tu_choi`, `tra_lai`) |
| Đề nghị lên cấp trên; báo cáo lên cấp trên khi báo cáo là bản ghi được gửi lên | `gui_duyet` |
| Rà soát, xử lý hồ sơ | `chinh_sua` hoặc hành động vòng đời riêng của phân hệ |

Thuật ngữ chức danh:
- **Chính ủy:** người chủ trì về chính trị của đơn vị (trung đoàn, sư đoàn, quân khu…); thường là thủ trưởng đơn vị hoặc Bí thư Đảng ủy, tuỳ đơn vị.
- **Chính trị viên:** người chủ trì về chính trị ở cấp đại đội, tiểu đoàn và tương đương.
- **Chủ nhiệm chính trị:** người đứng đầu cơ quan chính trị (ban, phòng, cục chính trị).
- **Trợ lý chính trị:** cán bộ tham mưu, thực hiện công tác chính trị theo nhiệm vụ được giao.
- **Cấp ủy:** nhóm lãnh đạo của tổ chức Đảng cùng cấp (Đảng ủy của Đảng bộ, Chi ủy của Chi bộ). Tài liệu nêu cấp ủy là một bước trong luồng nhưng không mô tả cây tổ chức Đảng: phân hệ cần cây này thì hỏi BA.

## 5. Luồng triển khai nhiệm vụ và báo cáo

**Chiều xuống:**
1. TCCT triển khai: Chủ nhiệm hoặc Phó Chủ nhiệm TCCT, hoặc thủ trưởng Cục, Ban, Viện trực thuộc TCCT.
2. Cấp đơn vị trực thuộc BQP, ví dụ Quân khu 1: thủ trưởng đơn vị → thủ trưởng cơ quan chính trị → trưởng phòng, ban → trợ lý.
3. Nếu triển khai tiếp xuống: thủ trưởng sư đoàn, lữ đoàn và tương đương → thủ trưởng cơ quan chính trị cấp đó → trưởng phòng, ban → trợ lý.
4. Nếu triển khai tiếp xuống: thủ trưởng trung đoàn và tương đương → thủ trưởng Ban Chính trị → trợ lý.

**Chiều lên:** trợ lý rà soát, xử lý, báo cáo; báo cáo đi ngược lại từng bước. Có ba cách kết thúc:
- báo cáo lên tới TCCT;
- dừng trong đơn vị khi nội dung không cần báo cáo cấp trên;
- triển khai tiếp xuống cấp dưới.

Mỗi bước gửi lên có hai kết quả theo mục 4: hợp lệ thì phê duyệt hoặc đề nghị lên trên; không hợp lệ thì yêu cầu sửa đổi, bổ sung.

**Không phải quy trình nào cũng đi qua thủ trưởng đơn vị hoặc cấp ủy các cấp.** Chỉ đưa vào thiết kế những bước mà quy trình của tài liệu BA có nêu.

## 6. Cây tổ chức quần chúng

| Mảng | Cấu trúc tổ chức (dưới lên) | Ghi chú |
|---|---|---|
| Thanh niên | Phân đoàn (nếu có) → Chi đoàn → Liên chi đoàn (nếu có) → Đoàn cơ sở | |
| Phụ nữ | Tổ phụ nữ → Chi hội phụ nữ (nếu có) → Hội phụ nữ | Hội 1 cấp: chỉ có Hội. Hội 2 cấp: Hội và tổ. Hội 3 cấp: Hội, chi hội và tổ |
| Công đoàn | Tổ công đoàn → Công đoàn bộ phận (nếu có) → Công đoàn cơ sở thành viên (nếu có) → Công đoàn cơ sở | |

**Luồng chung của ba mảng.**
1. Thành viên → các tầng của tổ chức quần chúng → tổ chức cơ sở (Đoàn cơ sở / Hội phụ nữ / Công đoàn cơ sở).
2. Từ tổ chức cơ sở, luồng chuyển sang cây chung: cơ quan chính trị cấp cơ sở → cấp ủy cùng cấp → thủ trưởng đơn vị cấp cơ sở.
3. Tiếp theo: cơ quan chính trị cấp trực thuộc BQP (Phòng Công tác quần chúng, trợ lý) → cấp ủy cùng cấp → thủ trưởng đơn vị trực thuộc BQP.
4. Cuối luồng là cơ quan thuộc TCCT của mảng: Ban Thanh niên Quân đội / Ban Phụ nữ Quân đội / Ban Công đoàn Quốc phòng.

Ví dụ tài liệu nêu (mảng thanh niên):
1. Đoàn viên → Chi đoàn TTGPCP → Liên chi đoàn Khối chính phủ → Đoàn thanh niên VTS.
2. → Phòng Chính trị VTS (trưởng phòng, trợ lý quần chúng) → Ban Tổng giám đốc VTS / Đảng ủy VTS.
3. → Cơ quan chính trị Tập đoàn → lãnh đạo Tập đoàn / Đảng ủy Tập đoàn.
4. → Ban Thanh niên Quân đội.

| Vị trí | Thanh niên | Phụ nữ | Công đoàn |
|---|---|---|---|
| Cơ quan thuộc TCCT | Ban Thanh niên Quân đội: Trưởng ban, Phó ban, trợ lý (mỗi trợ lý phụ trách một hoặc một số mảng) | Ban Phụ nữ Quân đội: như bên trái | Ban Công đoàn Quốc phòng: như bên trái |
| Đơn vị trực thuộc BQP | Thủ trưởng | Thủ trưởng | Thủ trưởng |
| Cơ quan chính trị đơn vị trực thuộc BQP | Chủ nhiệm, Phó Chủ nhiệm chính trị; Trưởng phòng Công tác quần chúng; trợ lý thanh niên | Như bên trái; trợ lý phụ nữ | Như bên trái; trợ lý công đoàn |
| Đơn vị cơ sở | Thủ trưởng | Thủ trưởng | Thủ trưởng |
| Cơ quan chính trị đơn vị cơ sở | Chủ nhiệm, Phó Chủ nhiệm chính trị; trợ lý công tác quần chúng thuộc phòng/ban chính trị | Như bên trái | Như bên trái |
| Tổ chức cơ sở | Đoàn thanh niên: Bí thư, Phó Bí thư, Ủy viên BCH | Hội phụ nữ: Chủ tịch, Phó Chủ tịch, Ủy viên | Công đoàn cơ sở: Chủ tịch, Phó Chủ tịch, Ủy viên BCH |
| Tầng giữa (nếu có) | Liên chi đoàn: Bí thư, Phó Bí thư, Ủy viên BCH | Chi hội phụ nữ: Chi hội trưởng, Chi hội phó | Công đoàn cơ sở thành viên; Công đoàn bộ phận: mỗi tổ chức có Chủ tịch, Phó Chủ tịch, Ủy viên BCH |
| Tầng dưới | Chi đoàn: Bí thư, Phó Bí thư, Ủy viên. Phân đoàn (nếu có): Phân đoàn trưởng | Tổ phụ nữ: Tổ trưởng | Tổ công đoàn: Tổ trưởng |
| Thành viên | Đoàn viên | Hội viên phụ nữ | Đoàn viên công đoàn |

## 7. Đối tượng quản lý chính (con người)

| Cơ quan quản lý | Đối tượng | CSDL |
|---|---|---|
| Cục Quân lực / BTTM (Phòng Quân số chính sách) | Quân nhân: QNCN, công nhân quốc phòng, viên chức quốc phòng, hạ sĩ quan – binh sĩ. Ngoài quân nhân: hợp đồng lao động, học sinh dưới 17 tuổi học tại trường quân đội, người nước ngoài có yếu tố quân sự | CSDL Cục Quân lực / BTTM |
| Cục Quân lực / BTTM (Phòng Dự bị động viên) | Hồ sơ công dân nam, nữ đủ tuổi vào ngạch dự bị; sĩ quan dự bị; hạ sĩ quan dự bị | CSDL Cục Quân lực / BTTM |
| Cục Cán bộ / TCCT | Sĩ quan; QNCN diện cán bộ; công chức quốc phòng | CSDL Cán bộ / TCCT |

Phân hệ dùng lại hồ sơ người từ các CSDL này thì hồ sơ là dữ liệu do nơi khác quản lý (M-08, M-14). Quyền sửa hồ sơ ở phân hệ đang thiết kế phải có căn cứ trong tài liệu; nếu không có thì hỏi BA.

## 8. Quy tắc thiết kế ReBAC theo cây CTĐ-CTCT

| Mã | Quy tắc | Cách áp trong đặc tả |
|---|---|---|
| CD-01 | **Gốc cây là TCCT.** Cục, Ban, Viện chủ quản phân hệ là nút con thuộc «các đơn vị nội bộ TCCT», không phải gốc. Cơ quan chủ quản theo dõi toàn quân theo ngành dọc của mảng mình; ví dụ Ban Thanh niên, Ban Phụ nữ, Ban Công đoàn với mảng quần chúng | Vai trò của cơ quan chủ quản: `loai_pham_vi: toan_he_thong` (KT-09). Không gán trên nút Cục/Ban rồi dùng «đơn vị mình và cấp dưới», vì nút Cục/Ban không có cấp dưới là các đơn vị toàn quân. Quyền ghi trên dữ liệu đơn vị vẫn chỉ theo tài liệu (KT-07) |
| CD-02 | **Phạm vi của cán bộ cơ quan chính trị tính từ đơn vị chủ quản**, tức đơn vị có con dấu mà cơ quan chính trị đó trực thuộc. Cơ quan chính trị nằm ở nhánh nội bộ, ngang hàng với các đơn vị cấp dưới. Nếu gán vai trò tại nút cơ quan chính trị hay phòng, ban thì «đơn vị mình và cấp dưới» chỉ gồm các phòng của cơ quan đó, không gồm sư đoàn, trung đoàn cấp dưới | Thủ trưởng cơ quan chính trị, trưởng phòng/ban, trợ lý: `gan_tren: don_vi`, hiểu là gán tại **nút đơn vị chủ quản**. Mảng hoặc phòng thể hiện bằng vai trò riêng (trợ lý thanh niên, trợ lý tuyên huấn…), không thể hiện bằng nút. Dữ liệu nghiệp vụ trỏ `thuoc_don_vi` tới nút đơn vị nơi lập. Hệ đích bắt buộc gán tại nút phòng/ban thì khai quan hệ `don_vi_chu_quan` (cơ quan chính trị, phòng → đơn vị) và tính phạm vi hai bước (M-01); nêu thành câu hỏi cho BA, SA |
| CD-03 | **Số cấp không cố định** (cấp tương đương, tầng «nếu có», nhánh bỏ cấp) | Không đặt vai trò hay phạm vi theo độ sâu cố định; dùng `cap_tren` đệ quy (`don_vi_minh_va_cap_duoi`). Chỉ tách vai trò theo cấp khi chức trách khác nhau thật (thủ trưởng đơn vị trực thuộc BQP khác thủ trưởng sư đoàn về thẩm quyền). Hạn chế `don_vi_minh_va_cap_duoi_truc_tiep`: nếu cây có nút nhóm «Các đơn vị cấp dưới», đơn vị cấp dưới trực tiếp nằm cách hai bước. Cần phạm vi này thì hỏi cấu trúc cây thật |
| CD-04 | **Thủ trưởng đơn vị và thủ trưởng cơ quan chính trị là hai vai trò khác nhau.** Hai vai trò cùng gán tại nút đơn vị (KT-17, NT-09) | Không gộp thành «lãnh đạo đơn vị». Tài liệu viết gộp thì tách và ghi lý do CD-04 |
| CD-05 | **Chỉ cấp có con dấu mới phê duyệt.** Phòng, ban không có con dấu xem xét rồi đề nghị lên cấp trên, hoặc yêu cầu sửa đổi, bổ sung. Trợ lý rà soát, xử lý, báo cáo, và yêu cầu cấp dưới sửa đổi | Khai `tham_quyen` cho vai trò: `phe_duyet` / `de_nghi` / `xu_ly` (mục 4). Phòng, ban dùng `gui_duyet`, `tu_choi`; trợ lý dùng `tu_choi` với cấp dưới. Vai trò `de_nghi` hoặc `xu_ly` có `phe_duyet` thì công cụ cảnh báo `TQ-01` |
| CD-06 | **Duyệt nhiều cấp bám luồng mục 5.** Mỗi lần chuyển sang đơn vị khác là một cấp duyệt. Các bước trong cùng một đơn vị (trợ lý → trưởng phòng → thủ trưởng cơ quan chính trị → thủ trưởng đơn vị) không đổi nút | `cap_duyet` trỏ tới nút đơn vị đang xử lý. Các bước trong cùng đơn vị phân biệt bằng trạng thái vòng đời (ví dụ chờ phòng xem xét, chờ thủ trưởng duyệt) và vai trò, không bằng nút; tài liệu chưa nêu thì hỏi BA. Chỉ đưa các cấp có trong quy trình (mục 5, đoạn cuối) |
| CD-07 | **Cây tổ chức quần chúng là cây riêng, gắn vào đơn vị cơ sở** (M-01, KT-10) | Tài nguyên `loai: cay` có `cap_tren` trỏ về chính nó; các tầng «nếu có» tự được bỏ qua. Tổ chức cơ sở có `don_vi_quan_ly` → `don_vi`. Vai trò Bí thư, Chủ tịch, Tổ trưởng… gán trên cây tổ chức. Cơ quan chính trị các cấp thấy dữ liệu qua `don_vi_quan_ly` và `cap_tren` của cây đơn vị. Luồng duyệt rời cây tổ chức tại tổ chức cơ sở, đi tiếp trên cây đơn vị: tài nguyên cần cả `cap_duyet_to_chuc` và `cap_duyet` |
| CD-08 | **Cấp ủy là bước riêng trong luồng**, không phải thủ trưởng đơn vị | Chỉ thêm khi quy trình nêu. Vai trò cấp ủy gán tại nút đơn vị cùng cấp; cách tổ chức cụ thể (cây tổ chức Đảng hay nhóm tại đơn vị) hỏi BA |
| CD-09 | **Khiếu nại, tố cáo dùng cây Viện kiểm sát quân sự**; phim, xuất bản dùng nhánh nội bộ của cây chung | Khiếu nại, tố cáo: khai tài nguyên `loai: cay` riêng (không dùng `don_vi`) và hỏi BA nguồn dữ liệu cây. Phim, xuất bản: dùng `don_vi` |
| CD-10 | **Một tác nhân, một tên gọi.** Tài liệu yêu cầu tên tác nhân đồng nhất từ mục Phạm vi, Đối tượng, Quy trình tới Danh sách chức năng | Tài liệu gọi một tác nhân bằng nhiều tên (ví dụ «Cơ quan chính trị đơn vị trực thuộc BQP» và «Đầu mối đơn vị trực thuộc BQP») thì lập một vai trò, ánh xạ mọi tên trong `quy_tac.tac_nhan`, và nêu ở bước 2 để BA sửa tài liệu |
| CD-11 | **Mô tả phạm vi bằng tên cấp thật của cây** | Câu mô tả, câu hỏi, ví dụ cho BA dùng tên cấp có trong cây: đơn vị trực thuộc BQP, sư đoàn, trung đoàn, cơ quan chính trị, chi đoàn… Không dùng nút giả («Đơn vị A»). Không đặt cơ quan chủ quản phân hệ làm gốc cây |

## 9. Tên phạm vi viết cho BA

Đặt `ten` của phạm vi trong `dac_ta.json` theo bảng dưới, để câu mô tả và bản xem trước đọc đúng ngôn ngữ ngành.

| Kiểu phạm vi | `ten` gợi ý |
|---|---|
| `toan_he_thong` | Toàn quân |
| `don_vi_minh` | Đơn vị mình (gồm cơ quan chính trị của đơn vị) |
| `don_vi_minh_va_cap_duoi` | Đơn vị mình và mọi đơn vị cấp dưới |
| `cap_duyet` | Hồ sơ đang chờ đơn vị mình xem xét, phê duyệt |
| Trên cây tổ chức quần chúng | Tổ chức mình và các tổ chức cấp dưới (chi đoàn, tổ…) |

## 10. Thứ tự các phân hệ

Khi liệt kê nhiều phân hệ hoặc nhiều mảng thuộc các phân hệ khác nhau, xếp theo thứ tự tài liệu quy định:
1. Tuyên huấn
2. Tổ chức
3. Kiểm tra, giám sát
4. Cán bộ
5. Bảo vệ an ninh Quân đội
6. Dân vận
7. Chính sách – Xã hội
8. Thanh niên
9. Phụ nữ
10. Công đoàn
11. Tư pháp
12. Kế hoạch tổng hợp
13. Các công tác khác
