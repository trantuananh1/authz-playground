# Hướng dẫn dùng bộ skill phân quyền

Có hai skill, dùng lần lượt:
- `/ra-soat-phan-quyen`: AI và BA cùng rà soát nghiệp vụ, kết thúc khi BA xác nhận.
- `/thiet-ke-phan-quyen`: xuất các tệp cuối cho tài liệu và đội phát triển.

## Chuẩn bị

Để chung một thư mục:
- **Tệp Excel phân quyền** theo mẫu 3 bảng. Chưa có mẫu thì gõ `/ra-soat-phan-quyen mau-excel` để lấy mẫu trống.
- **Tài liệu nghiệp vụ**: quy trình, SRS, sơ đồ drawio…

Nếu tệp Excel có sheet ma trận trải phẳng thì AI dùng sheet đó để so sánh, không lấy làm nguồn.

## Các bước

**Bước 1. Cho AI rà soát**
```
/ra-soat-phan-quyen <tệp Excel> <tài liệu 1> <tài liệu 2>
```
AI đọc toàn bộ tài liệu, dựng thiết kế nháp, rồi ghi mọi câu hỏi một lần vào **sheet QnA** của tệp Excel. Ô cần trả lời được tô vàng.

**Bước 2. BA trả lời trong sheet QnA**
- Điền vào cột **BA confirm**.
- Với điểm «AI suy ra»: ghi «Đồng ý», hoặc ghi phương án đúng.
- Câu nào chưa trả lời được thì để trống. Phần đó chưa đưa vào thiết kế.
- Lưu và **đóng tệp Excel** trước khi sang bước 3.

**Bước 3. Cho AI đọc câu trả lời**
```
/ra-soat-phan-quyen hoi-dap doc
```
BA nhận một bộ để xem:
- **Bản xem trước** (link): ai được làm gì, trên dữ liệu nào, khi nào;
- **Trang so sánh** (link): chỗ khớp và chỗ lệch với ma trận trải phẳng, kèm giải thích;
- **Excel trải phẳng theo thiết kế**: ô xanh là thiết kế thêm, ô đỏ là thiết kế bỏ.

**Bước 4. Duyệt và xác nhận**
- Trên trang xem trước: bôi chọn chỗ cần sửa, viết bình luận, rồi bấm **Send to Claude**.
- Gõ `/ra-soat-phan-quyen xem-truoc` để AI sửa theo bình luận và cập nhật trang (link giữ nguyên).
- Hết góp ý thì chọn **«Xác nhận»**.

**Bước 5. Xuất tệp cuối**
```
/thiet-ke-phan-quyen
```
Kết quả:
- **Excel cuối** giữ đúng mẫu 3 bảng, tô màu chỗ thay đổi (xanh là thêm, vàng là sửa, đỏ gạch là bỏ), mỗi ô thay đổi có ghi chú căn cứ;
- tệp JSON import và tệp DSL cho đội phát triển;
- bảng «ai được làm gì».

Cần bản không màu để dán vào tài liệu thì gõ `/thiet-ke-phan-quyen excel --ban-sach`.

**Bước 6. Cần sửa sau khi đã xuất**
```
/ra-soat-phan-quyen cap-nhat <điều cần sửa>
```
AI sửa thiết kế, BA xác nhận lại (bước 4), rồi chạy lại bước 5.

## Mẹo nhỏ

| Muốn | Gõ |
|---|---|
| Chỉ dùng một phần tài liệu | thêm «chỉ dùng …» sau tên tệp, ví dụ `… chỉ dùng bảng 1, 2, 3 sheet X` |
| AI không tự suy ra, chỗ thiếu chỉ hỏi | `/ra-soat-phan-quyen chi-nguon <tệp …>` |
| Không có ma trận trải phẳng nhưng muốn xem theo dạng đó | `/ra-soat-phan-quyen trai-phang <tệp khung> <sheet>` |
| Xem thử vài tài nguyên trên playground | `/thiet-ke-phan-quyen dsl <tài nguyên 1>,<tài nguyên 2>` |
